 ViMMeR - Virtual MIDI Multitrack Recorder
-----------------------------------------------------------------------

Purpose:

The main aim is to resurrect the efficient operational style of late 
1980's MIDI sequencing hardware, specifically the Alesis MMT-8, in an 
open source software tribute running on common platform.

Team:

  * Jimi James Brown
  * Matthew Harrold
  * Jonathon Van Rossum
  * Charles Weld
  * David Wilson

Using:

  * C++
  * MingW
  * StarUML
  * CodeBlocks
  * Doxygen
  * FLTK (1 and 2)
  * Boost
  * BZ2
  * SourceForge
  
Components:

  * MIDI classes (In,Out,Thru,Messages)
  * Real/virtual timer system (timing engine)
  * Application framework (Commands, Events, Observers, ...)
  * Music model (Song, Part, Track, ...)
  * Sequencer engine (playback/recording manager)
  * Application interface (high level sequencer operation layer)
  * FLTK GUI


Dependencies:
1. Boost [http://www.digitazero.org/download/boost-1.33.1-2cyd.DevPak, note
          we striped of the version info of the libs(-mgw-mt-s-1_33_1)]
2. BZip2 [http://www.bzip.org/ (compiled from latest stable release)]
3. FLTK 1.1 (for Chuck's GUI) [http://www.digitazero.org/download/fltk-1.1.7-1cyd.DevPak]
4. FLTK 2 (for Main GUI) [www.fltk.net (nightly build)]

Remember that a DevPak is realy just an .tar.bz2 archive so rename them to get the files inside.

or just download them from here: "http://filexoom.com/files/7040/Dependencies.zip" and unzip them 
into your codeblocks or dev-pak directory.

Install:
Here are the basic instructions of getting Vimmer to work on your pc,

1. Install CodeBlocks.
2. Install Dependencies (should be able to get them using dev-pak 
   plugin from Vimmer, or to get the ones we use follow the urls provided in the Dependencies section.
3. Open the CodeBlocks Workspace (/project/codeblocks/vimmer.workspace)
4. Compile the UI of your choice (or all of them :)

