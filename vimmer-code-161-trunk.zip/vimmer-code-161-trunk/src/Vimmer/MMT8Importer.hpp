/*
   Virtual MIDI Multitrack Recorder
   Copyright (c) 2006 MIDI Team

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/

/**
   MMT8Importer.hppile MMT8Importer.hpp
   Charles Weld, David Wilson, James Brown, Jonathan Van Rossum, and Matthew Harrold
   @brief Declaration of class MMT8Importer, part of Virtual MIDI Multitrack Recorder
*/

#ifndef _MMT8IMPORTER_H
#define _MMT8IMPORTER_H

#include "Importer.hpp"

#include "Store.hpp"

namespace Vimmer
{
    // forward declaration
    class Store;

    # pragma pack(1)
    /// @ingroup files
    union bigendian
    {
        char    short_bytes[2];
        short   value;              // bytes must be reversed when this is used.
    };

    # pragma pack(1)
    /// @ingroup files
    struct type_syx
    {
        char    sysex_f0;
        char    zero1;
        char    zero2;
        char    id_manufacturer;
        char    id_machine;
    };

    # pragma pack(1)
    /// @ingroup files
    struct type_mmt8_header
    {
        union bigendian     ptr_to_part[100];       // 0x000 - 0x0C7 : Absolute pointer to each part data.
        unsigned char       reserved1[7];           // 0x0C8 - 0x0CE : DO NOT ALTER.
        unsigned short      ptr_past_song_data;     // 0x0CF - 0x0D0 : Pointer to one byte past song data.
        unsigned char       reserved2[2];           // 0x0D1 - 0x0D2 : DO NOT ALTER.
        unsigned short      length_of_free_mem;     // 0x0D3 - 0x0D4 : 0xFF00 minus data in 0x0CF & 0x0D0
        unsigned char       reserved3[45];          // 0x0D5 - 0x101 : DO NOT ALTER.
        union bigendian     ptr_to_song[100];       // 0x102 - 0x1C9 : Absolute pointer to each song data.
        unsigned char       reserved4[54];          // 0x1CA - 0x1FF : DO NOT ALTER.
        // Data for PART 00 follows.
    };

    # pragma pack(1)
    /// @ingroup files
    struct type_part_data
    {
        unsigned short   number_of_bytes;        // 0x00 - 0x01 : Number of bytes in part, including header. (little endian)
        unsigned short   off_track_data[8];      // 0x02 - 0x11 : Offset from start of part to track data, Tracks 8 to 1. (little endian)
        unsigned short   number_of_beats_bcd;    // 0x12 - 0x13 : Number of beats in part, in BCD format (0 => empty part).
        unsigned char    track_midi_channel[8];  // 0x14 - 0x1B : MIDI channel for track, Tracks 8 to 1. (Channels 1-16, 0 => Unchanged).
        unsigned char    part_name[14];          // 0x1C - 0x29 : 14-digit ASCII name of part.
        // Data for TRACK 8 follows.
    };

    # pragma pack(1)
    /// @ingroup files
    struct type_song_step_data
    {
        char    unsigned part_number;    // PART NUMBER: (0-99)
        char    unsigned play_tracks;    // Which tracks to play: bit0 = track1, bit7 = track8; 0=off, 1=on).
    };

    # pragma pack(1)
    /// @ingroup files
    struct type_song_data
    {
        unsigned short   number_of_bytes;        // 0x00 - 0x01 : Number of bytes in song, including header.
        unsigned char    tempo;                  // 0x02 - 0x03 : Tempo of song, in BPM.
        unsigned char    song_name[14];          // 0x03 - 0x10 : 14-digit ASCII name of song.
        struct type_song_step_data step_data;    // (MULTIPLE)
        // Song step data follows.
        // This is terminated by part number 0xFF (end of song).
    };

    # pragma pack(1)
    /// @ingroup files
    struct type_midi_event_7byte
    {
        union
        {
            unsigned char    note_number;            // Byte  0  :   1nnnnnnn
            unsigned char    controller_number;      // Byte  0  :   1nnnnnnn
        };
        unsigned short   absolute_start_time;        // Bytes 1-2:
        union
        {
            unsigned char    note_velocity;          // Byte  3  :   zvvvvvvv
            unsigned char    controller_amount;      // Byte  3  :   zvvvvvvv
        };
        unsigned char    midi_channel;               // Byte  4  :   0000cccc
        union
        {
            union bigendian  note_duration;  // Bytes 5-6:
            unsigned short   pitchbend;      // Bytes 5-6:
        };
    };

    # pragma pack(1)
    /// @ingroup files
    struct type_midi_event_5byte
    {
        union
        {
            unsigned char    note_number;            // Byte  0  :   1nnnnnnn
            unsigned char    controller_number;      // Byte  0  :   1nnnnnnn
        };
        union
        {
            unsigned char    note_velocity;          // Byte  1  :   zvvvvvvv
            unsigned char    controller_amount;      // Byte  1  :   zvvvvvvv
        };
        unsigned char    midi_channel;               // Byte  2  :   0000cccc
        union
        {
            union bigendian   note_duration;  // Bytes 3-4:
            unsigned short    pitchbend;      // Bytes 3-4:
        };
    };


    /// @ingroup files
    class MMT8Importer : public Importer
    {

public:

        /** @brief  Constructor.
          * @param  store   The store the importer will write to.
         */
        MMT8Importer(Store* store);

        /** @brief  Get the filter string for this exporter.
          * @return The filter string.
         */
        virtual String getFilter();

        /** @brief  Import the whole store from a file.
          * @param  filename    The name of the file to import from.
         */
        virtual void fileImportStore (String filename);

        /** @brief  Import a particular song from a file.
          * @param  filename    The name of the file to import from.
          * @param  songnumber  The number of the song (0-based).
         */
        virtual void fileImportSong  (String filename, int songnumber);

        /** @brief  Import a particular part from a file.
          * @param  filename    The name of the file to import from.
          * @param  partnumber  The number of the part (0-based).
         */
        virtual void fileImportPart  (String filename, int partnumber);

protected:

        /// The store that is attached to this importer.
        Store* store;

        unsigned long divider;

        static const int MODE_STORE = 0;
        static const int MODE_PART = 1;
        static const int MODE_SONG = 2;

        void import(const char* filename, int mode, int number=0);

        void process_Part(Part* vimmer_part, unsigned char* mmt8_part, unsigned int number_of_bytes);
        void process_Track(Track* vimmer_track, unsigned char* mmt8_track, unsigned int number_of_bytes);
        void process_Event5(unsigned long absolute, struct type_midi_event_5byte* event5, Track* track, MIDIEventIterator* iterator);

        void process_Song(Song* vimmer_song, unsigned char* mmt8_song, unsigned int number_of_bytes);

        int convert_midi_mmt8(const unsigned char* source, unsigned char* dest, unsigned int source_size);


    };
}

#endif  //_MMT8IMPORTER_H
