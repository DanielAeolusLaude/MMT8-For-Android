/*
   Virtual MIDI Multitrack Recorder
   Copyright (c) 2006 MIDI Team

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/

/**
   @file   SongStep.cpp
   @author James Brown, Charles Weld
   @brief  Implementation of the class SongStep.
*/


#include "SongStep.hpp"
#include "Part.hpp"

namespace Vimmer
{
    SongStep::SongStep(Part* p):
        MultiTrackLink()
    {
        setPart(p);
    }

    SongStep::SongStep(const SongStep& step):
        MultiTrackLink(step)
    {
    }

    SongStep::~SongStep()
    {
    }

    SongStep& SongStep::operator = (const SongStep& step)
    {
        if (this != &step)
        {
            MultiTrackLink::operator=(step);
        }
        return *this;
    }

    void SongStep::setPart(Part* part)
    {
        setLink(static_cast<MultiTrack*>(part));
    }

    Part* SongStep::getPart()
    {
        return static_cast<Part*>(getLink());
    }
}
