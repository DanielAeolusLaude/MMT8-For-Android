/*
   Virtual MIDI Multitrack Recorder
   Copyright (c) 2006 MIDI Team

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/

/**
   StandardMIDIImporter.hppile StandardMIDIImporter.hpp
   Charles Weld, David Wilson, James Brown, Jonathan Van Rossum, and Matthew Harrold
   @brief Declaration of class StandardMIDIImporter, part of Virtual MIDI Multitrack Recorder
*/

/*

#include "LogManager.hpp"
LogManager* logger;
logger = LogManager::getSingleton();
logger->log("Can't close a closed port.", LogLevels::LEVEL_ERROR);

*/
#ifndef _STANDARDMIDIIMPORTER_H
#define _STANDARDMIDIIMPORTER_H

#include "Importer.hpp"

#include "Track.hpp"
#include "Part.hpp"
#include "Song.hpp"
#include "Store.hpp"

namespace Vimmer
{

    // STANDARD MIDI CHUNK
    # pragma pack(1)
    /// @ingroup files
    struct chunk_type
    {
        // CHUNK TYPE (4 bytes)
        union
        {
            unsigned int    type;
            char            type_byte[4];
        };

        // CHUNK LENGTH (4 bytes)
        union
        {
            unsigned int    length;
            char            length_byte[4];
        };

        // DATA
        unsigned int        data;
    };


    // HEADER CHUNK DATA
    # pragma pack(1)
    /// @ingroup files
    struct header_data_type
    {
        // Standard MIDI Format 0, 1, or 2.
        // FORMAT (2 bytes):    Big-Endian (MSB first)
        union
        {
            unsigned short  format;
            char            format_byte[2];
        };

        // Number of Tracks in this MIDI file.
        // NTRKS (2 bytes):     Big-Endian (MSB first)
        union
        {
            unsigned short  ntrks;
            char            ntrks_byte[2];
        };

        // Meaning of DELTA times.
        // DIVISION (2 bytes):  Big-Endian (MSB first)
        union
        {
            unsigned short  division;
            char            division_byte[2];
        };
    };

    // CHUNK TYPE (4 bytes)
    // (This is used for storing chunk types that we recognise.)
    # pragma pack(1)
    /// @ingroup files
    union chunk_type_type
    {
        unsigned int    type;
        char            type_byte[4];
    };

    # pragma pack(1)
    /// @ingroup files
    struct type_track_data
    {
        // Number of the current track
        unsigned int tracknumber;

        // Convert from the PULSES_PER_BEAT of this file
        // to the PULSES_PER_BEAT used by Vimmer.
        unsigned int pulse_divider;

        // Tempo (beats per minute)
        unsigned int tempo;

        // Part Length (pulses)
        unsigned int length;

        // Part Name
        String part_name;
    };

    /// @ingroup files
    class StandardMIDIImporter : public Importer
    {

    public:

        /** @brief  Constructor.
          * @param  store   The store the importer will write to.
         */
        StandardMIDIImporter(Store* store);

        /** @brief  Get the filter string for this exporter.
          * @return The filter string.
         */
        virtual String getFilter();

        /** @brief  Import the whole store from a file.
          * @param  filename    The name of the file to import from.
         */
        virtual void fileImportStore (String filename);

        /** @brief  Import a particular song from a file.
          * @param  filename    The name of the file to import from.
          * @param  songnumber  The number of the song (0-based).
         */
        virtual void fileImportSong  (String filename, int songnumber);

        /** @brief  Import a particular part from a file.
          * @param  filename    The name of the file to import from.
          * @param  partnumber  The number of the part (0-based).
         */
        virtual void fileImportPart  (String filename, int partnumber);

        /** @brief  Import a particular track from a file.
          * @param  filename    The name of the file to import from.
          * @param  partnumber  The number of the part which contains this track (0-based).
          * @param  tracknumber The number of the track (0-based).
         */
        virtual void fileImportTrack (String filename, int partnumber, int tracknumber);


protected:

        // DEBUGGING: These should be protected.
        //void import(const char* filename, MultiTrack* mt);
        //void import(const char* filename, Track* t);

        /// The store that is attached to this importer.
        Store* store;

        // Mode: passed to the import() function, determines how the data is imported.
        static const int MODE_TRACK = 0;    /// Import a single track.
        static const int MODE_PART = 1;     /// Import a part.
        static const int MODE_SONG = 2;     /// Import a song.

        /** @brief  Main function that handles importing.
          * @param  filename    The name of the file to import from.
          * @param  mode        Mode of importing (track, part, song).
          * @param  p           Part to import to.
          * @param  t           Track to import to (or NULL if not exporting a track).
         */
        void import(const char* filename, int mode, Track* t, MultiTrack* mt);

        // These CHUNKs are recognised
        union chunk_type_type chunk_MThd;   /// MThd:   Header
        union chunk_type_type chunk_MTrk;   /// MTrk:   Track data

        /** @brief  Read from MTrk chunk in memory, and create Track.
          * @note   This function is used when only a track is being imported to.
          * @param  chunk               Memory array to read this chunk from.
          * @param  track               Pointer to Track to write the data to.
          * @param  bytes_remaining     The maximum size of the chunk (prevents reading beyond array).
          * @param  track_data          Extra information used to write to the chunk.
          * @return                     The number of bytes used by this chunk data.
         */
        bool process_chunk_MTrk_Track(char* chunk_data, Track* track, struct type_track_data* track_data, int bytes_remaining);

        /** @brief  Read from MTrk chunk in memory, and create Track.
          * @note   This function is used when only a multitrack is being imported to.
          * @param  chunk               Memory array to read this chunk from.
          * @param  track               Pointer to Track to write the data to.
          * @param  bytes_remaining     The maximum size of the chunk (prevents reading beyond array).
          * @param  track_data          Extra information used to write to the chunk.
          * @return                     The number of bytes used by this chunk data.
         */
        bool process_chunk_MTrk_MultiTrack(char* chunk_data, MultiTrack* multitrack, struct type_track_data* track_data, int bytes_remaining);

        /** @brief  Process a short message from the chunk data, and write it to the Track.
          * @param  chunk               Position to read short message from.
          * @param  track               Pointer to Track to write the data to.
          * @param  extra               Extra information.
          * @param  bytes_remaining     The maximum size of the chunk (prevents reading beyond array).
          * @param  absolute            Absolute time (in pulses).
          * @param  running_status      Current running status.
          * @return                     The number of bytes read from the chunk data.
         */
        unsigned int process_MIDI_Short (char* data, Track* track, struct type_track_data* extra, int bytes_remaining, unsigned int absolute, unsigned int* running_status);

        /** @brief  Process a SYSEX F0 message from the chunk data.
          * @param  chunk               Position to read the message from.
          * @param  track               Pointer to Track to write the data to.
          * @param  extra               Extra information.
          * @param  bytes_remaining     The maximum size of the chunk (prevents reading beyond array).
          * @param  absolute            Absolute time (in pulses).
          * @return                     The number of bytes read from the chunk data.
         */
        unsigned int process_MIDI_F0    (char* data, Track* track, struct type_track_data* extra, int bytes_remaining, unsigned int absolute);

        /** @brief  Process a SYSEX F7 message from the chunk data.
          * @param  chunk               Position to read the message from.
          * @param  track               Pointer to Track to write the data to.
          * @param  extra               Extra information.
          * @param  bytes_remaining     The maximum size of the chunk (prevents reading beyond array).
          * @param  absolute            Absolute time (in pulses).
          * @return                     The number of bytes read from the chunk data.
         */
        unsigned int process_MIDI_F7    (char* data, Track* track, struct type_track_data* extra, int bytes_remaining, unsigned int absolute);

        /** @brief  Process a Meta-Event message from the chunk data.
          * @param  chunk               Position to read the message from.
          * @param  track               Pointer to Track to write the data to.
          * @param  extra               Extra information.
          * @param  bytes_remaining     The maximum size of the chunk (prevents reading beyond array).
          * @param  absolute            Absolute time (in pulses).
          * @return                     The number of bytes read from the chunk data.
         */
        unsigned int process_MIDI_FF    (char* data, Track* track, struct type_track_data* extra, int bytes_remaining, unsigned int absolute);

        /** @brief  Convert a "variable length quantity" to an integer.
          * @note   See the Standard MIDI file specification to read what this is.
          * @param  data        Memory array to read this quantity from.
          * @param  max_length  The maximum size of the array (prevents reading beyond array).
          * @param  quantity    The int variable to read the variable length quantity into.
          * @return             The number of bytes used by this variable length quantity.
         */
        unsigned int get_variable_length_quantity(char* data, unsigned int max_length, unsigned int* quantity);


    };
}


#endif  //_STANDARDMIDIIMPORTER_H
