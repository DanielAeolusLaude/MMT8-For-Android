/*
   Virtual MIDI Multitrack Recorder
   Copyright (c) 2006 MIDI Team

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/

/**
   @file   Song.hpp
   @author James Brown, Charles Weld
   @brief  Declaration of the class Song.
*/


#ifndef _SONG_H
#define _SONG_H

#include "Observable.hpp"
#include "Observer.hpp"
#include "Part.hpp"
#include "SongStep.hpp"
#include "VimmerPrerequisites.hpp"

using namespace MIDIToolkit;

namespace Vimmer
{
    /** @ingroup    store
     *  @brief      A Song is a list of Parts that are played sequentially.
     *
     *  OVERVIEW:
     *
     *  A part is the basic unit of storage for MIDI data (see Part class).
     *  These parts can be played together (one after the other) to make a
     *  complete "song". The song is represented by this class.
     *
     *  SONG STEP:
     *
     *  A song is a list of SongSteps (see SongStep class). Each SongStep
     *  represents a particular part, and its position with that song. SongStep
     *  extends upon MultiTrackLink (see MIDIToolkit::MultiTrackLink).
     *
     *  Note that a part can appear in more than one Song, or no Songs at all.
     *  Each different "instance" of the same part is represented by a different
     *  SongStep. Also note that the same part can appear multiple times within
     *  the same song, and each time is represented by a different SongStep.
     *
     *  SONG EDIT:
     *
     *  Song class provides various editing functions. Each operation is concerned
     *  with adding Parts to the Song, removing Parts from the Song, and changing
     *  the order of these parts. These operations are performed by adding,
     *  removing, and moving SongSteps respectively.
     *
     *  Song does NOT allow editing of the data within each part. This is the
     *  responsibility of the Part class itself. Song operations never influence
     *  the actual parts.
     *
     *  OTHER DATA:
     *
     *  Each Song has a numeric ID, and a name. The ID is used to identify the
     *  Song (see SongSystem class). The name is for user convenience only. The
     *  song also stores a tempo, which represents the "speed" of the music.
     *
     *  MISCELLANEOUS:
     *
     *  Song has no knowledge of the current state of any sequencer. It does not
     *  know whether or not it is active or being played (see SongSystem class).
     *
     */
    class Song : public Observable, public Observer
    {
    public:

        /** @brief  Constructor.
         */
        Song();

        /** @brief  Constructor.
          * @param  name    Name to give this Song.
          * @param  id      ID to give this Song.
         */
        Song(String name, int id);

        /** @brief  Destructor.
         */
        virtual ~Song();

        /** @brief  Set the name of this Song.
          * @param  name    The new name.
         */
        virtual void setName(String name);

        /** @brief  Get the name of this Song.
          * @return     The current name of this Song.
         */
        virtual String getName();

        /** @brief  Set the tempo stored for this Song.
          * @param  tempo   New tempo (beats per minute).
         */
        virtual void setTempo(int tempo);

        /** @brief  Get the tempo stored for this Song.
          * @return     The tempo (beats per minute).
         */
        virtual int getTempo() const;

        /** @brief  Set the ID for this Song.
          * @param  id      The new ID.
         */
        virtual void setID(int id);

        /** @brief  Get the ID for this Song.
          * @return     The current ID.
         */
        virtual int getID() const;

        /** @brief  Add a Part to this Song.
          * @note   The Part is wrapped in a SongStep, and added to the end of the Song.
          * @param  part    Pointer to Part to add.
         */
        virtual void add(Part* p);

        /** @brief  Add a SongStep to this Song.
          * @note   The SongStep is added to the end of the Song.
          * @param  step    Pointer to SongStep to add.
         */
        virtual void add(SongStep* step);

        /** @brief  Remove a SongStep (Part) from this Song.
          * @param  loc     Iterator pointing to the SongStep.
         */
        virtual void remove(SongStepIterator loc);

        /** @brief  Check if a Song is empty.
          * @return         (true) if Song is empty, (false) otherwise.
         */
        virtual bool isEmpty();

        /** @brief  Erase the Song's contents.
         */
        virtual void clear();

        /** @brief  Insert a Part into the Song, at a particular location.
          * @note   This Part is automatically wrapped in a SongStep.
          * @param  loc     Iterator pointing to the step before which to insert this one.
          * @param  p       Pointer to the Part.
         */
        virtual SongStepIterator insert(SongStepIterator loc, Part* p);

        /** @brief  Insert a SongStep (Part) into the Song, at a particular location.
          * @param  loc     Iterator pointing to the SongStep.
          * @param  p       Pointer to the SongStep.
         */
        virtual SongStepIterator insert(SongStepIterator loc, SongStep* p);

        /** @brief  Get an iterator from the beginning of the Song.
          * @return     The SongStep iterator.
         */
        virtual SongStepIterator getIteratorBegin();

        /** @brief  Get an iterator from the end of the Song.
          * @return     The SongStep iterator.
         */
        virtual SongStepIterator getIteratorEnd();

        /** @brief  Notify Song of an event.
          * @param  id      ID for the event.
          * @param  params  Pointer to any parameters relevant to the event.
         */
        virtual void onEvent(int id, void* params);

    private:

        /// @brief  List of SongSteps (pointers).
        SongStepList steps;

        /// @brief  Song ID.
        int id;

        /// @brief  Song Name.
        String name;

        /// @brief  Song Tempo (beats per minute).
        int tempo;

    };
}

#endif  //_SONG_H
