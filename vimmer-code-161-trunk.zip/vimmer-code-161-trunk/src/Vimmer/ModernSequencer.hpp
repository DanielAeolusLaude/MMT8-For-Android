/*
   Virtual MIDI Multitrack Recorder
   Copyright (c) 2006 MIDI Team

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/

/**
   @file ModernSequencer.hpp
   @author Charles Weld
   @brief Declaration of class ModernSequencer, part of Virtual MIDI Multitrack Recorder
*/

#ifndef _ModernSequencer_H
#define _ModernSequencer_H

#include "Observer.hpp"
#include "Store.hpp"
#include "SequencerManager.hpp"
#include "Device.hpp"
#include "Sequencer.hpp"
#include "FileManager.hpp"
#include "ConfigurationManager.hpp"

using namespace MIDIToolkit;

namespace Vimmer
{
    /**
        @brief The Modern Sequencer links all the backend components together.
        @ingroup seq
     */
    class ModernSequencer
    {
    public:
        ModernSequencer(int num_of_parts=100, int num_of_songs=100);
        virtual ~ModernSequencer();

        virtual Store* getStore();

        virtual SequencerManager* getSequencer();

        virtual MIDIToolkit::Device* getDevice();

        virtual FileManager* getFileManager();

        void addObserver(Observer* o);

        virtual void init();

        enum{
            SYX,MID,XML
        };

        enum{
            ALL,PART,SONG
        };

        bool load(const char* filename,int fileformat,int type=0,int identifier=0);
        bool save(const char* filename,int fileformat,int type=0,int identifier=0);
        void updateConfiguration();
    private:
        Store *m_Store;
        MIDIToolkit::Sequencer *m_Sequencer;
        MIDIToolkit::Device *m_Device;
        SequencerManager *m_SequencerMgr;
        Observer* vimmerUI;
        FileManager* m_FileManager;

        ConfigurationManager* m_Configuration;
    };
}

#endif  //_ModernSequencer_H
