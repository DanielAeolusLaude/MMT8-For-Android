/*
   Virtual MIDI Multitrack Recorder
   Copyright (c) 2006 MIDI Team

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/

/**
   @file XMLExporter.cpp
   Charles Weld
   @brief Declaration of class XMLExporter, part of Virtual MIDI Multitrack Recorder
*/

#include "XMLExporter.hpp"
#include "Store.hpp"
#include "tinyxml.h"
#include "PartSystem.hpp"
#include "Part.hpp"
#include "Track.hpp"
#include "ShortMessage.hpp"
#include "MessageTypes.hpp"
#include "StringConverter.hpp"
#include "StringCompress.hpp"
#include "LogManager.hpp"

using namespace MIDIToolkit;

namespace Vimmer
{
    XMLExporter::XMLExporter(Store* store):
        Exporter(store)
    {
        m_Store = store;
    }

    String XMLExporter::getFilter()
    {
        return String("vmr");
    }

    void XMLExporter::fileExportStore(String filename)
    {
        TiXmlDocument *xmlDoc = new TiXmlDocument();

        // parse doc
        TiXmlElement xVimmer("vimmer");

        // part system
        TiXmlElement* xPartSys = genPartSystem(m_Store->getPartSystem());
        xVimmer.LinkEndChild(xPartSys);

        // song system
        TiXmlElement* xSongSys = genSongSystem(m_Store->getSongSystem());
        xVimmer.LinkEndChild(xSongSys);

        // vimmer
        xmlDoc->InsertEndChild(xVimmer);

        // save
        xmlDoc->SaveFileBZ2(filename);

        // Clean up
        xmlDoc->Clear();
        delete xmlDoc;
    }

    TiXmlElement* XMLExporter::genPartSystem(PartSystem* psys)
    {
        TiXmlElement* xParts = new TiXmlElement("parts");
        xParts->SetAttribute("size", psys->count());

        // add parts
        int size = psys->count();
        for(int i=0;i<size;++i)
        {
            TiXmlElement* xPart = genPart(psys->getPart(i));
            xParts->LinkEndChild(xPart);
        }

        return xParts;
    }

    TiXmlElement* XMLExporter::genPart(Part* part)
    {
        TiXmlElement* xPart = new TiXmlElement("part");
        xPart->SetAttribute("id", part->getID());
        xPart->SetAttribute("name", part->getName().c_str());
        xPart->SetAttribute("track_count", part->count());
        xPart->SetAttribute("length", part->getLength());

        int size = part->count();
        for(int i=0;i<size;++i)
        {
            TiXmlElement* xTrack = genTrack(part->getTrack(i), i);
            xPart->LinkEndChild(xTrack);
        }

        return xPart;
    }

    TiXmlElement* XMLExporter::genTrack(Track* track, int id)
    {
        TiXmlElement* xTrack = new TiXmlElement("track");
        xTrack->SetAttribute("id", id);

        for(MIDIEventIterator iter = track->getIterator_begin();iter != track->getIterator_end();++iter)
        {
            if((*iter)->getMessage()->isA(MessageTypes::SHORT_MESSAGE))
            {
                TiXmlElement* xMessage = genMessage(*iter);
                xTrack->LinkEndChild(xMessage);
            }
        }

        return xTrack;
    }

    TiXmlElement* XMLExporter::genMessage(MIDIEvent* msg)
    {
        // generate event
        TiXmlElement* xEvent = new TiXmlElement("event");
        xEvent->SetAttribute("absolute", msg->absolute);
        xEvent->SetAttribute("delta", msg->delta);

        // generate message
        ShortMessage* smsg = static_cast<ShortMessage*>((msg->getMessage()));
        String status_str = StringConverter::intToHexString( smsg->getStatus() );
        String Data1_str = StringConverter::intToHexString( smsg->getPackageData1() );
        String Data2_str = StringConverter::intToHexString( smsg->getPackageData2()  );
        String str = status_str + _T(" ") + Data1_str + _T(" ") + Data2_str;

        TiXmlText* xMessage = new TiXmlText(str.c_str());
        xEvent->LinkEndChild(xMessage);

        return xEvent;
    }

    TiXmlElement* XMLExporter::genSongSystem(SongSystem* ssys)
    {
        TiXmlElement* xSongs = new TiXmlElement("songs");
        xSongs->SetAttribute("size", ssys->count());

        // add parts
        int size = ssys->count();
        for(int i=0;i<size;++i)
        {
            TiXmlElement* xSong = genSong(ssys->getSong(i));
            xSongs->LinkEndChild(xSong);
        }

        return xSongs;
    }

    TiXmlElement* XMLExporter::genSong(Song* song)
    {
        TiXmlElement* xSong = new TiXmlElement("song");
        xSong->SetAttribute("id", song->getID());
        xSong->SetAttribute("tempo", song->getTempo());
        xSong->SetAttribute("name", song->getName().c_str());

        for(SongStepIterator iter=song->getIteratorBegin(); iter!=song->getIteratorEnd(); iter++)
        {
            TiXmlElement* xSongStep = genSongStep(*iter);
            xSong->LinkEndChild(xSongStep);
        }

        return xSong;
    }

    TiXmlElement* XMLExporter::genSongStep(SongStep* songstep)
    {
        TiXmlElement* xSongStep = new TiXmlElement("step");
        xSongStep->SetAttribute("part", songstep->getPart()->getID());
        xSongStep->SetAttribute("size", songstep->trackCount());

        int size = songstep->trackCount();
        for(int i=0;i<size;++i)
        {
            TiXmlElement* xTrack = new TiXmlElement("track");
            xTrack->SetAttribute("id", i);
            xTrack->SetAttribute("state", songstep->getTrackState(i));
            xTrack->SetAttribute("channel", songstep->getTrackChannel(i));
            xSongStep->LinkEndChild(xTrack);
        }

        return xSongStep;
    }

}
