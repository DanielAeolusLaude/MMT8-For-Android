/*
   Virtual MIDI Multitrack Recorder
   Copyright (c) 2006 MIDI Team

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/

/**
   VimmerSequencer.hppile VimmerSequencer.hpp
   Charles Weld, David Wilson, James Brown, Jonathan Van Rossum, and Matthew Harrold
   @brief Declaration of class VimmerSequencer, part of Virtual MIDI Multitrack Recorder
*/

#ifndef _VIMMERSEQUENCER_H
#define _VIMMERSEQUENCER_H

#include "Observer.hpp"
#include "Store.hpp"
#include "SequencerManager.hpp"
#include "Device.hpp"
#include "Sequencer.hpp"

namespace Vimmer
{
    class VimmerSequencer
    {
    public:
        VimmerSequencer();
        virtual ~VimmerSequencer();
        virtual void onEvent(const int &e);
        virtual void addObserver(Observer *observer);
        virtual void invokeCommand(MIDIToolkit::String cmdID, void* params);
        virtual void invokeQuery(MIDIToolkit::String queryID, void* params);

        virtual Store* getStore(){return m_Store;}

    private:
        Store *m_Store;
        MIDIToolkit::Sequencer *m_Sequencer;
        MIDIToolkit::Device *m_Device;
        SequencerManager *m_SequencerMgr;
    };
}

#endif  //_VIMMERSEQUENCER_H
