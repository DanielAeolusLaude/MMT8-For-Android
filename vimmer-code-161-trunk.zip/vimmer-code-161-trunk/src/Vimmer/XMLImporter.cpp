/*
   Virtual MIDI Multitrack Recorder
   Copyright (c) 2006 MIDI Team

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/

/**
   Importer.cppile Importer.cpp
   Charles Weld, David Wilson, James Brown, Jonathan Van Rossum, and Matthew Harrold
   @brief Declaration of class Importer, part of Virtual MIDI Multitrack Recorder
*/

#include "XMLImporter.hpp"
#include "Store.hpp"
#include "Exceptions.hpp"
#include "Exception.hpp"
#include "StringConverter.hpp"
#include "MIDIEvent.hpp"
#include "MIDIMessage.hpp"
#include "MessageBuilder.hpp"
#include "StringCompress.hpp"

namespace Vimmer
{
    XMLImporter::XMLImporter(Store* store):
        Importer(store)
    {
        m_Store = store;
    }

    String XMLImporter::getFilter()
    {
        return String("vmr");
    }

    void XMLImporter::fileImportStore(String filename)
    {
        TiXmlDocument* xdoc = new TiXmlDocument();
        bool loadOkay = xdoc->LoadFileBZ2(filename);
        if (loadOkay)
        {
            // load vimmer element
            TiXmlElement *xVimmer = xdoc->FirstChildElement("vimmer");

            if (xVimmer)
            {
                // found vimmer element continue to load file.

                // clear memory
                m_Store->clear();

                // load part system element
                TiXmlElement *xpsys = xVimmer->FirstChildElement("parts");

                if (xpsys)
                {
                    // found psys element continue to load file.
                    genPartSystem(xpsys, m_Store->getPartSystem());
                }
                else
                {
                    // failed to find vimmer element destroy element.
                    throw Exception(Exceptions::XML_LOAD_FAILED, "Couldn't find the part system element (parts).", "void XMLImporter::fileImport(String filename)");
                }

                // load song system element
                TiXmlElement *xssys = xVimmer->FirstChildElement("songs");

                if (xssys)
                {
                    // found ssys element continue to load file.
                    genSongSystem(xssys, m_Store->getSongSystem());
                }
                else
                {
                    // failed to find vimmer element destroy element.
                    throw Exception(Exceptions::XML_LOAD_FAILED, "Couldn't find the song system element (songs).", "void XMLImporter::fileImport(String filename)");
                }
            }
            else
            {
                // failed to find vimmer element destroy element.
                throw Exception(Exceptions::XML_LOAD_FAILED, "Couldn't find the vimmer element.", "void XMLImporter::fileImport(String filename)");
            }
        }
        else
        {
            throw Exception(Exceptions::XML_LOAD_FAILED, "Failed to load the xml file.", "void XMLImporter::fileImport(String filename)");
        }

        // change active part to zero
        // hack to get around bug here (events beging fired that shouldn't be)
        m_Store->getPartSystem()->disableObservable();
        m_Store->getSongSystem()->disableObservable();
        m_Store->getPartSystem()->setActive(0);
        m_Store->getSongSystem()->setActive(0);
        m_Store->getPartSystem()->enableObservable();
        m_Store->getSongSystem()->enableObservable();
        m_Store->getSongSystem()->setActive(0);
        m_Store->getPartSystem()->setActive(0);
        // clean up
        xdoc->Clear();
        delete xdoc;
    }

    void XMLImporter::genPartSystem(TiXmlElement* xpsys, PartSystem* psys)
    {
        // add 'size' optimisation latter

        // get first part element
        TiXmlElement* xPart = xpsys->FirstChildElement("part");

        // Loop through each part in the part system
        while(xPart)
        {
            // create a new part
            Part* p = genPart(xPart);

            // add part to part system
            if(p)
                psys->addPart(p);

            // move to the next element
            xPart = xPart->NextSiblingElement("part");
        }
    }

    Part* XMLImporter::genPart(TiXmlElement* xpart)
    {


        if(xpart->Attribute("id") && xpart->Attribute("name") && xpart->Attribute("length"))
        {
            int id = StringConverter::stringToInt(xpart->Attribute("id"));
            String name = xpart->Attribute("name");
            int length = StringConverter::stringToInt(xpart->Attribute("length"));

            Part* part = new Part(name, id);

            // load tracks
            TiXmlElement* xTrack = xpart->FirstChildElement("track");

            // Loop through each track in the part
            while(xTrack)
            {
                // get id
                int trackID = StringConverter::stringToInt(xTrack->Attribute("id"));

                // set track
                genTrack(xTrack, part->getTrack(trackID));

                // move to the next element
                xTrack = xTrack->NextSiblingElement("track");
            }
            part->setLength(length);
            return part;
        }
        else
            throw Exception(Exceptions::XML_LOAD_FAILED, "Failed to load the xml file.", "Part* XMLImporter::genPart(TiXmlElement* xpart)");
    }

    void XMLImporter::genTrack(TiXmlElement* xtrack, Track* track)
    {
        // load messages
        TiXmlElement* xEvent = xtrack->FirstChildElement("event");

        // Loop through each midi event in the track
        while(xEvent)
        {
            // create a new part
            try
            {
                MIDIEvent* evt = genMessage(xEvent);

                // add part to part system
                if(evt)
                    track->insert(evt);
            }
            catch (Exception e)
            {
                ///@todo log couldn't add message.
            }

            // move to the next element
            xEvent = xEvent->NextSiblingElement("event");
        }
    }

    MIDIEvent* XMLImporter::genMessage(TiXmlElement* xevent)
    {
        // build message first
        TiXmlText* xMsg = NULL;
        if(xevent->FirstChild() && xevent->FirstChild()->Type() == TiXmlNode::TEXT)
        {
            xMsg = xevent->FirstChild()->ToText();
        }

        // actually build the message
        MIDIMessage* msg = NULL;
        if(xMsg)
        {
            //int smsg = 0;
            String str_msg = xMsg->Value();
            String str_status, str_data1, str_data2;
            int status_bit, data1_bit, data2_bit;

            // find status
            String::size_type loc = str_msg.find( " ", 0 );
            if( loc != String::npos )
            {
                // found status (now get it)
                str_status = str_msg.substr( 0, loc );
                status_bit = MIDIToolkit::StringConverter::hexStringToInt(str_status);

                // find data1
                String::size_type loc2 = str_msg.find( " ", loc+1 );
                if( loc != String::npos )
                {
                    // found data1 (now get it)
                    str_data1 = str_msg.substr( loc+1, loc2-loc-1 );
                    data1_bit = MIDIToolkit::StringConverter::hexStringToInt(str_data1);

                    // get data2
                    str_data2 = str_msg.substr( loc2+1, str_msg.size()-loc2 );
                    data2_bit = MIDIToolkit::StringConverter::hexStringToInt(str_data2);

                    // build message
                    msg = MessageBuilder::buildMessage( status_bit, data1_bit, data2_bit );
                }
            }
        }


        if(msg!=NULL)
        {
            // get absolute and delta time
            if(xevent->Attribute("delta") && xevent->Attribute("absolute"))
            {
                int delta = StringConverter::stringToInt( xevent->Attribute("delta") );
                int absolute = StringConverter::stringToInt( xevent->Attribute("absolute") );
                MIDIEvent* evt = new MIDIEvent(msg, absolute, delta);
                return evt;
            }
            else
                throw Exception(Exceptions::XML_LOAD_FAILED, "Failed to load the xml file.", "MIDIEvent* XMLImporter::genMessage(TiXmlElement* xevent)");
        }
        else
        {
            throw Exception(Exceptions::XML_LOAD_FAILED, "Failed to load the xml file.", "MIDIEvent* XMLImporter::genMessage(TiXmlElement* xevent)");
        }
    }

    // song support
    void XMLImporter::genSongSystem(TiXmlElement* xssys, SongSystem* ssys)
    {
        // get first part element
        TiXmlElement* xSong = xssys->FirstChildElement("song");

        // Loop through each part in the part system
        while(xSong)
        {
            // create a new part
            Song* s = genSong(xSong);

            // add part to part system
            if(s)
                ssys->addSong(s);

            // move to the next element
            xSong = xSong->NextSiblingElement("song");
        }
    }

    Song* XMLImporter::genSong(TiXmlElement* xsong)
    {
        if(xsong->Attribute("id") && xsong->Attribute("name") && xsong->Attribute("tempo"))
        {
            int id = StringConverter::stringToInt(xsong->Attribute("id"));
            int tempo = StringConverter::stringToInt(xsong->Attribute("tempo"));
            String name = xsong->Attribute("name");

            Song* song = new Song(name, id);
            song->setTempo(tempo);

            // load tracks
            TiXmlElement* xStep = xsong->FirstChildElement("step");

            // Loop through each track in the part
            while(xStep)
            {
                // get id
                SongStep* step = genSongStep(xStep);
                song->add(step);

                // move to the next element
                xStep = xStep->NextSiblingElement("step");
            }

            return song;
        }
        else
            throw Exception(Exceptions::XML_LOAD_FAILED, "Failed to load the xml file.", "Song* XMLImporter::genSong(TiXmlElement* xsong)");
    }

    SongStep* XMLImporter::genSongStep(TiXmlElement* xstep)
    {
        if(xstep->Attribute("part"))
        {
            int part = StringConverter::stringToInt(xstep->Attribute("part"));

            // get part from part system (should have already been loaded)
            Part* p = m_Store->getPartSystem()->getPart(part);

            // create songstep
            SongStep* step = new SongStep(p);

            // set track state and channel
            TiXmlElement* xTrack = xstep->FirstChildElement("track");
            while(xTrack)
            {
                // update track
                if(xTrack->Attribute("id") && xTrack->Attribute("channel") && xTrack->Attribute("state"))
                {
                    if(xTrack->Attribute("id") && xTrack->Attribute("channel") && xTrack->Attribute("state"))
                    {
                        int id = StringConverter::stringToInt(xTrack->Attribute("id"));
                        int channel = StringConverter::stringToInt(xTrack->Attribute("channel"));
                        int state = StringConverter::stringToInt(xTrack->Attribute("state"));

                        step->setTrackChannel(id, channel);
                        step->setTrackState(id, state);
                    }
                }
                // move to the next element
                xTrack = xTrack->NextSiblingElement("track");
            }

            return step;
        }
        else
        {
            throw Exception(Exceptions::XML_LOAD_FAILED, "Failed to load the xml file.", "SongStep* XMLImporter::genSongStep(TiXmlElement* xstep)");
        }

    }

}
