/*
   Virtual MIDI Multitrack Recorder
   Copyright (c) 2006 MIDI Team

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/

/**
   MMT8Exporter.cppile MMT8Exporter.cpp
   Charles Weld, David Wilson, James Brown, Jonathan Van Rossum, and Matthew Harrold
   @brief Declaration of class MMT8Exporter, part of Virtual MIDI Multitrack Recorder
*/

#include "MMT8Exporter.hpp"
#include "Store.hpp"

namespace Vimmer
{
    MMT8Exporter::MMT8Exporter(Store* s) : Exporter(s)
    {
        store = s;
    }

// ----------------------------------------------------------------------------------------------------
    String MMT8Exporter::getFilter()
    {
        return String("");
    }

// ----------------------------------------------------------------------------------------------------
    void MMT8Exporter::fileExportStore(String filename)
    {
        export_file(filename.c_str(), MODE_STORE, 0);
    }

// ----------------------------------------------------------------------------------------------------
    void MMT8Exporter::fileExportSong(String filename, int songnumber)
    {
        export_file(filename.c_str(), MODE_SONG, songnumber);
    }

// ----------------------------------------------------------------------------------------------------
    void MMT8Exporter::fileExportPart(String filename, int partnumber)
    {
        export_file(filename.c_str(), MODE_PART, partnumber);
    }

// ----------------------------------------------------------------------------------------------------
    void MMT8Exporter::fileExportTrack(String filename, int partnumber, int tracknumber)
    {
        // we don't support this yet.
    }

// ----------------------------------------------------------------------------------------------------
    void MMT8Exporter::export_file(const char* filename, int mode, int param1)
    {
        unsigned int max_file_size = 640000;
        unsigned char* data;

        if (data = (unsigned char*)malloc(max_file_size))
        {
            /// @warning Matt changed this to get rid of warnings, it might break, please check it.
            /// JVR: bytes_remaining must be signed, otherwise you can't tell if it is less than zero.

            int bytes_remaining = (int)max_file_size;
            unsigned int index = 0;

            if (bytes_remaining >= (int)sizeof(struct type_mmt8_header) + (int)sizeof(struct type_syx))
            {
                // SYSEX FILE HEADER
                struct type_syx* syx_file_header = (struct type_syx*)&data[index];
                syx_file_header->sysex_f0 = 0xF0;        // SYSEX F0
                syx_file_header->zero1 = 0;
                syx_file_header->zero2 = 0;
                syx_file_header->id_manufacturer = 0x0E; // ALESIS
                syx_file_header->id_machine = 0x00;      // MMT-8
                advance(&index, &bytes_remaining, sizeof(struct type_syx));

                // MMT-8 HEADER
                struct type_mmt8_header*    mmt8      = (struct type_mmt8_header*)&data[index];
                advance(&index, &bytes_remaining, sizeof(struct type_mmt8_header));

                // EXPORT EACH PART
                for (int i=0; i<100; i++)
                {
                    // Empty part
                    mmt8->ptr_to_part[i].value = 0;

                    if (mode == MODE_STORE || mode == MODE_PART && i == param1)
                    {
                        Part* vimmer_part = (store!=NULL) ? store->getPartSystem()->getPart(i) : NULL;
                        if (vimmer_part)
                        {
                            int number_of_bytes = process_Part(&data[index], vimmer_part, bytes_remaining);
                            if (number_of_bytes != 0)
                            {
                                // STORE POINTER (big endian)
                                mmt8->ptr_to_part[i].value = reverse_endian_short(index + 0x400);
                                advance(&index, &bytes_remaining, number_of_bytes);
                            }
                        }
                    }
                }

                // EXPORT EACH SONG
                for (int i=0; i<100; i++)
                {
                    // Empty song
                    mmt8->ptr_to_song[i].value = 0;

                    if (mode == MODE_STORE || mode == MODE_SONG && i == param1)
                    {
                        Song* vimmer_song = (store!=NULL) ? store->getSongSystem()->getSong(i) : NULL;
                        if (vimmer_song)
                        {
                            int number_of_bytes = process_Song(&data[index], vimmer_song, bytes_remaining);
                            if (number_of_bytes != 0)
                            {
                                // STORE POINTER (big endian)
                                mmt8->ptr_to_song[i].value = reverse_endian_short(index + 0x400);
                                advance(&index, &bytes_remaining, number_of_bytes);
                            }
                        }
                    }
                }

                // RESERVED 1
                for (unsigned int i = 0; i < 7; i++)
                {
                    mmt8->reserved1[i] = 0;
                }

                // RESERVED 2
                for (unsigned int i = 0; i < 2; i++)
                {
                    mmt8->reserved2[i] = 0;
                }

                // RESERVED 3
                for (unsigned int i = 0; i < 45; i++)
                {
                    mmt8->reserved3[i] = 0;
                }

                // RESERVED 4
                for (unsigned int i = 0; i < 54; i++)
                {
                    mmt8->reserved4[i] = 0;
                }

                // LENGTH OF FREE MEM
                mmt8->length_of_free_mem = (unsigned short)0xFF00 - mmt8->ptr_past_song_data;

                // WRITE DATA
                // (convert to MIDI 7-BIT format)
                unsigned char* memoryblock = (unsigned char*) malloc (index * 2);
                int filesize = convert_mmt8_midi(data, memoryblock, index);
                savefile(filename, (char*)memoryblock, filesize);
                free (data);
                free (memoryblock);
            }
        }
    }

// ----------------------------------------------------------------------------------------------------
    int MMT8Exporter::process_Part(unsigned char* data, Part* vimmer_part, int remaining_size)
    {
        if (data!=NULL && vimmer_part!=NULL && remaining_size>0)
        {
            if (vimmer_part->getLength() == 0)
            {
                // Empty part
                return 0;
            }
            else
            {
                struct type_part_data* mmt8_part = (struct type_part_data*)data;
                unsigned int index = 0;
                int bytes_remaining = remaining_size;
                advance(&index, &bytes_remaining, sizeof(struct type_part_data));

                // NUMBER OF BEATS (BCD)
                unsigned int num_of_beats = vimmer_part->getLength();
                mmt8_part->number_of_beats_bcd = convert_to_bcd(num_of_beats);

                // PART NAME
                unsigned char* name = (unsigned char*)(vimmer_part->getName().c_str());
                for (unsigned int i=0; i<14 && i<strlen((char*)name); i++)
                {
                    mmt8_part->part_name[i] = 0x7F & name[i];   // ASCII only, not extended ASCII
                }

                // TRACKS
                for (unsigned int i=7; i>0; i--)
                {
                    // TRACK CHANNELIZE
                    mmt8_part->track_midi_channel[8 - i - 1] = 0;   // No channelize.

                    // TRACK DATA
                    Track* t = vimmer_part->getTrack(i);
                    if (t != NULL && !(t->empty()))
                    {
                        mmt8_part->off_track_data[8 - i - 1] = index + 0x400;
                        int length_pulses = vimmer_part->getLength() * MIDIToolkit::PULSES_PER_BEAT;
                        int track_size_bytes = process_Track(&data[index], t, bytes_remaining, length_pulses);
                        advance(&index, &bytes_remaining, track_size_bytes);
                    }
                    else
                    {
                        // Empty Track
                        mmt8_part->off_track_data[8 - i - 1] = 0;
                    }
                }

                // NUMBER OF BYTES
                mmt8_part->number_of_bytes = index;

                return index;
            }
        }
        else
        {
            // Error.
            return 0;
        }
    }

// ----------------------------------------------------------------------------------------------------
    int MMT8Exporter::process_Track(unsigned char* data, Track* vimmer_track, int remaining_size, unsigned long length_pulses)
    {
        if (data != NULL && vimmer_track != NULL)
        {
            unsigned int index = 0;
            int bytes_remaining = remaining_size;

            // Current ABSOLUTE TIMESTAMP
            unsigned long absolute = 0;

            // Iterator in Track: for efficiency only
            MIDIEventIterator iterator = vimmer_track->getIterator_begin();

            while (bytes_remaining>14 && iterator!=vimmer_track->getIterator_end() && (*iterator)!=NULL)
            {
                unsigned long abs = (*iterator)->absolute;
                MIDIMessage*  m   = (*iterator)->getMessage();

                // Only process channel messages
                if (m!=NULL && m->isA(MessageTypes::CHANNEL_MESSAGE))
                {
                    ChannelMessage* chm = (ChannelMessage*)m;

                    // NOTE DURATION
                    unsigned int duration_pulses = 0;
                    if (chm->getCommand() == ChannelCommands::NoteOn)
                    {
                        duration_pulses = vimmer_track->duration_pulses(iterator);
                    }
                    else
                    {
                        duration_pulses = 0;
                    }

                    // MIDI EVENT TYPE
                    if (abs == absolute)
                    {
                        // 5-byte MIDI Event
                        int event_size = process_Event5(&data[index], chm, bytes_remaining, duration_pulses);
                        advance(&index, &bytes_remaining, event_size);
                    }
                    else
                    {
                        // 7-byte MIDI Event
                        int event_size = process_Event7(&data[index], chm, bytes_remaining, duration_pulses, absolute);
                        advance(&index, &bytes_remaining, event_size);
                        absolute = abs;
                    }
                }

                iterator++;
            }

            if (bytes_remaining > 7)
            {
                int event_size = process_Event7_TrackEnd(&data[index], bytes_remaining, length_pulses);
                advance(&index, &bytes_remaining, event_size);
            }

            return index;
        }
        else
        {
            // Error.
            return 0;
        }
    }

// ----------------------------------------------------------------------------------------------------
    int MMT8Exporter::process_Song(unsigned char* data, Song* vimmer_song, int remaining_size)
    {
        if (data!=NULL && vimmer_song!=NULL && remaining_size>17)
        {
            if (vimmer_song->isEmpty())
            {
                // Empty song
                return 0;
            }
            else
            {
                struct type_song_data* mmt8_song = (struct type_song_data*)data;
                unsigned int index = 0;
                int bytes_remaining = remaining_size;
                advance(&index, &bytes_remaining, 17);

                // TEMPO
                unsigned char tempo = (unsigned char)(vimmer_song->getTempo());
                mmt8_song->tempo = tempo;

                // SONG NAME
                unsigned char* name = (unsigned char*)(vimmer_song->getName().c_str());
                for (unsigned int i=0; i<14 && i<strlen((char*)name); i++)
                {
                    mmt8_song->song_name[i] = 0x7F & name[i];   // ASCII only, not extended ASCII
                }

                SongStepIterator iterator = vimmer_song->getIteratorBegin();
                while (iterator != vimmer_song->getIteratorEnd() && (*iterator) != NULL && bytes_remaining > 2)
                {
                    SongStep* vimmer_songstep;
                    struct type_song_step_data* mmt8_songstep;

                    vimmer_songstep = *iterator;
                    mmt8_songstep   = (struct type_song_step_data*)&data[index];

                    Part* p = vimmer_songstep->getPart();

                    if (p != NULL)
                    {
                        // PART NUMBER
                        unsigned char id = p->getID();

                        // PLAY TRACKS
                        unsigned char tracks = 0;
                        for (unsigned int i = 0; i < 8; i++)
                        {
                            if (vimmer_songstep->isPlaying(i))
                            {
                                tracks |= 0x01 << i;
                            }
                        }

                        mmt8_songstep->part_number = id;
                        mmt8_songstep->play_tracks = tracks;
                        advance(&index, &bytes_remaining, 2);
                    }

                    iterator ++;
                }

                // END OF SONG MARKER
                if (bytes_remaining >= 2)
                {
                    data[index + 0] = 0x80;
                    data[index + 0] = 0x00;
                    advance(&index, &bytes_remaining, 2);
                }

                // NUMBER OF BYTES
                mmt8_song->number_of_bytes = index;

                return index;
            }
        }
        else
        {
            // Error.
            return 0;
        }
    }

// ----------------------------------------------------------------------------------------------------
    int MMT8Exporter::process_Event5(unsigned char* data, ChannelMessage* chm, int bytes_remaining, unsigned int duration_pulses)
    {
        if (data != NULL && chm != NULL && bytes_remaining > 5)
        {
            struct type_midi_event_5byte* event5 = (struct type_midi_event_5byte*)data;

            unsigned char command = chm->getCommand();
            unsigned char channel = chm->getChannel();
            unsigned char data1   = chm->getData1();
            unsigned char data2   = chm->getData2();

            switch (command)
            {
                case ChannelCommands::NoteOn:
                {
                    // Check it's not a NOTE OFF in disguise!
                    if (data2 != 0)
                    {
                        event5->note_number         = 0x7F & data1;
                        event5->note_velocity       = 0x7F & data2;
                        event5->midi_channel        = 0x0F & channel;
                        event5->note_duration.value = reverse_endian_short(0x7FFF & (unsigned short)duration_pulses);
                    }
                    return 5;
                }
                case ChannelCommands::Controller:
                {
                    event5->controller_number   = Exporter::min(121, (unsigned short)data1);
                    event5->controller_amount   = 0x80 | data2;
                    event5->midi_channel        = 0x0F & channel;
                    event5->note_duration.value = 0x0000;
                    return 5;
                }
                case ChannelCommands::ProgramChange:
                {
                    event5->controller_number   = 122;
                    event5->controller_amount   = 0x80 | data1;
                    event5->midi_channel        = 0x0F & channel;
                    event5->note_duration.value = 0x0000;
                    return 5;
                }
                case ChannelCommands::ChannelPressure:
                {
                    event5->controller_number   = 123;
                    event5->controller_amount   = 0x80 | data1;
                    event5->midi_channel        = 0x0F & channel;
                    event5->note_duration.value = 0x0000;
                    return 5;
                }
                default:
                {
                    // Unknown channel message.
                    return 0;
                }
            }
        }
        else
        {
            // Error.
            return 0;
        }
    }

// ----------------------------------------------------------------------------------------------------
    int MMT8Exporter::process_Event7(unsigned char* data, ChannelMessage* chm, int bytes_remaining, unsigned int duration_pulses, unsigned long absolute)
    {
        if (data != NULL && chm != NULL && bytes_remaining > 7)
        {
            struct type_midi_event_5byte  event5;
            unsigned char*                event5_char = (unsigned char*)&event5;

            int event_size = process_Event5(event5_char, chm, min(5, (unsigned int)bytes_remaining), duration_pulses);
            if (event_size != 0)
            {
                struct type_midi_event_7byte* event7 = (struct type_midi_event_7byte*)&data;

                event7->note_number         = event5.note_number;
                event7->absolute_start_time = (int)absolute;
                event7->note_velocity       = event5.note_velocity;
                event7->midi_channel        = event5.midi_channel;
                event7->note_duration       = event5.note_duration;

                return 7;
            }
            else
            {
                return 0;
            }
        }
        else
        {
            // Error.
            return 0;
        }
    }

// ----------------------------------------------------------------------------------------------------
    int MMT8Exporter::process_Event7_TrackEnd(unsigned char* data, int bytes_remaining, unsigned long length_pulses)
    {
        unsigned char clocks_lsb = 0x00FF & length_pulses;
        unsigned char clocks_msb = 0x00FF & length_pulses;

        if (data != NULL && bytes_remaining > 7)
        {
            data[0] = 0x80;
            data[1] = clocks_lsb;
            data[2] = clocks_msb;
            data[3] = 0;
            data[4] = 0x80;
            data[5] = 0;
            data[6] = 0;
            return 7;
        }
        else
        {
            // Error.
            return 0;
        }
    }

// ----------------------------------------------------------------------------------------------------
// ----------------------------------------------------------------------------------------------------
// ----------------------------------------------------------------------------------------------------
// ----------------------------------------------------------------------------------------------------
// ----------------------------------------------------------------------------------------------------
// ----------------------------------------------------------------------------------------------------
    int MMT8Exporter::convert_mmt8_midi(const unsigned char* s, unsigned char* d, unsigned int source_size)
    {
        int destination_number_of_bytes = 0;
        if (s != NULL && d != NULL)
        {
            // Convert 7-bit MIDI data to 8-bit MMT8 format.
            // Source and destination cannot be identical.
            for (unsigned int si=0, di=0; si<source_size; si++)
            {
                unsigned char t = s[si] & 0x7F;
                switch (si % 7)
                {
                    case 0:
                        d[di+0] = t >> 1;
                        d[di+1] = (t & 0x01) << 6;
                        destination_number_of_bytes = di + 2;
                        break;
                    case 1:
                        d[di+1] |= t >> 2;
                        d[di+2] = (t & 0x03) << 5;
                        destination_number_of_bytes = di + 3;
                        break;
                    case 2:
                        d[di+2] |= t >> 3;
                        d[di+3] = (t & 0x07) << 4;
                        destination_number_of_bytes = di + 4;
                        break;
                    case 3:
                        d[di+3] |= t >> 4;
                        d[di+4] = (t & 0x0F) << 3;
                        destination_number_of_bytes = di + 5;
                        break;
                    case 4:
                        d[di+4] |= t >> 5;
                        d[di+5] = (t & 0x1F) << 2;
                        destination_number_of_bytes = di + 6;
                        break;
                    case 5:
                        d[di+5] |= t >> 6;
                        d[di+6] = (t & 0x3F) << 1;
                        destination_number_of_bytes = di + 7;
                        break;
                    case 6:
                        d[di+6] |= t >> 7;
                        d[di+7] = (t & 0x7F);
                        di += 8;
                        destination_number_of_bytes = di + 8;
                        break;
                }
            }
            return destination_number_of_bytes;
        }
        else
        {
            return 0;
        }
    }
}
