/*
   Virtual MIDI Multitrack Recorder
   Copyright (c) 2006 MIDI Team

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/

/**
   MMT8Exporter.hppile MMT8Exporter.hpp
   Charles Weld, David Wilson, James Brown, Jonathan Van Rossum, and Matthew Harrold
   @brief Declaration of class MMT8Exporter, part of Virtual MIDI Multitrack Recorder
*/

#ifndef _MMT8EXPORTER_H
#define _MMT8EXPORTER_H

#include "Exporter.hpp"

#include "MMT8Importer.hpp"
#include "ChannelMessage.hpp"
#include "MessageTypes.hpp"

#include "Store.hpp"

namespace Vimmer
{
    // forward declaration
    class Store;

    /// @ingroup files
    class MMT8Exporter : public Exporter
    {
    public:

        /** @brief  Constructor.
          * @param  store   The store the exporter will read from.
         */
        MMT8Exporter(Store* store);

        /** @brief  Get the filter string for this exporter.
          * @return The filter string.
         */
        virtual String getFilter();

        /** @brief  Export the whole store to a file.
          * @param  filename    The name of the file to export to.
         */
        virtual void fileExportStore (String filename);

        /** @brief  Export a particular song to a file.
          * @param  filename    The name of the file to export to.
          * @param  songnumber  The number of the song (0-based).
         */
        virtual void fileExportSong  (String filename, int songnumber);

        /** @brief  Export a particular part to a file.
          * @param  filename    The name of the file to export to.
          * @param  partnumber  The number of the part (0-based).
         */
        virtual void fileExportPart  (String filename, int partnumber);

        /** @brief  Export a particular track to a file.
          * @param  filename    The name of the file to export to.
          * @param  partnumber  The number of the part which contains this track (0-based).
          * @param  tracknumber The number of the track (0-based).
         */
        virtual void fileExportTrack (String filename, int partnumber, int tracknumber);


    protected:

        // Mode: passed to the export_file() function, determines how the data is imported.
        static const int MODE_TRACK = 0;
        static const int MODE_PART  = 1;
        static const int MODE_SONG  = 2;
        static const int MODE_STORE = 3;

        /// The store that is attached to this exporter.
        Store* store;

        void export_file(const char* filename, int mode, int param1);

        int convert_mmt8_midi(const unsigned char* source, unsigned char* dest, unsigned int source_size);

        int process_Part(unsigned char* mmt8_part, Part* vimmer_part, int remaining_size);
        int process_Track(unsigned char* data, Track* vimmer_track, int remaining_size, unsigned long length_pulses);
        int process_Song(unsigned char* mmt8_song, Song* vimmer_song, int remaining_size);

        int process_Event5(unsigned char* data, ChannelMessage* chm, int bytes_remaining, unsigned int duration_pulses);
        int process_Event7(unsigned char* data, ChannelMessage* chm, int bytes_remaining, unsigned int duration_pulses, unsigned long absolute);
        int process_Event7_TrackEnd(unsigned char* data, int bytes_remaining, unsigned long length_pulses);


    };
}

#endif  //_MMT8EXPORTER_H
