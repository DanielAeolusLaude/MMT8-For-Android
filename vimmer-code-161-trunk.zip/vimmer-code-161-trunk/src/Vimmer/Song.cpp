/*
   Virtual MIDI Multitrack Recorder
   Copyright (c) 2006 MIDI Team

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/

/**
   @file   Song.cpp
   @author James Brown, Charles Weld
   @brief  Implementation of the class Song.
*/


#include "Song.hpp"
#include "Part.hpp"
#include "Events.hpp"

using namespace MIDIToolkit;

namespace Vimmer
{
    Song::Song()
    {
        setTempo(120);
    }

    Song::Song(String name, int id)
    {
        setName(name);
        setID(id);
        setTempo(120);
    }

    Song::~Song()
    {
        for(SongStepIterator iter=getIteratorBegin();iter!=getIteratorEnd();++iter)
        {
            delete *iter;
        }
        steps.clear();
    }

    void Song::setName(String name)
    {
        this->name = name;
        raiseEvent(Events::SONG_NAME_CHANGED, this);
    }

    String Song::getName()
    {
        return name;
    }

    void Song::setTempo(int tempo)
    {
        this->tempo = tempo;
    }

    int Song::getTempo() const
    {
        return this->tempo;
    }

    void Song::setID(int id)
    {
        this->id = id;
    }

    int Song::getID() const
    {
        return this->id;
    }

    void Song::add(Part* p)
    {
        SongStep *s = new SongStep(p);
        steps.push_back(s);
        s->addObserver(this);
        //raiseEvent(Events::SONG_CONTENT_CHANGED, this);
    }

    void Song::add(SongStep* step)
    {
        steps.push_back(step);
        step->addObserver(this);
        raiseEvent(Events::SONG_CONTENT_CHANGED, this);
    }

    void Song::remove(SongStepIterator loc)
    {
        delete (*loc);
        steps.erase(loc);
        raiseEvent(Events::SONG_CONTENT_CHANGED, this);
    }

    void Song::clear()
    {
        for(SongStepIterator iter=getIteratorBegin();iter!=getIteratorEnd();++iter)
        {
            delete *iter;
        }
        steps.clear();
        raiseEvent(Events::SONG_CONTENT_CHANGED, this);
    }

    SongStepIterator Song::insert(SongStepIterator loc, Part* p)
    {
        SongStep* s = new SongStep(p);
        steps.insert(loc, s);
        raiseEvent(Events::SONG_CONTENT_CHANGED, this);
        SongStepIterator iter = loc;
        loc--;
        return loc;
    }

    SongStepIterator Song::insert(SongStepIterator loc, SongStep* s)
    {
        steps.insert(loc, s);
        raiseEvent(Events::SONG_CONTENT_CHANGED, this);
        SongStepIterator iter = loc;
        loc--;
        return loc;
    }

    SongStepIterator Song::getIteratorBegin()
    {
        return steps.begin();
    }

    SongStepIterator Song::getIteratorEnd()
    {
        return steps.end();
    }

    bool Song::isEmpty()
    {
        return (steps.begin() == steps.end());
    }

    void Song::onEvent(int id, void* params)
    {
        // forward on all events
        raiseEvent(id, params);
    }
}
