/*
   Virtual MIDI Multitrack Recorder
   Copyright (c) 2006 MIDI Team

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/

/**
   FileManager.hppile FileManager.hpp
   Charles Weld, David Wilson, James Brown, Jonathan Van Rossum, and Matthew Harrold
   @brief Declaration of class FileManager, part of Virtual MIDI Multitrack Recorder
*/

#ifndef _FILEMANAGER_H
#define _FILEMANAGER_H

#include <list>

#include "VimmerPrerequisites.hpp"
#include "Importer.hpp"
#include "Exporter.hpp"
#include "Store.hpp"
#include "Importer.hpp"

using namespace MIDIToolkit;

namespace Vimmer
{
    // typedefs
    /// @ingroup files
    typedef std::list<Exporter*> ExporterList;
    /// @ingroup files
    typedef std::list<Importer*> ImporterList;
    /// @ingroup files
    typedef std::list<Importer*>::iterator ImporterIterator;
    /// @ingroup files
    typedef std::list<Exporter*>::iterator ExporterIterator;

    // forward declartions
    class Store;

    /// @ingroup files
    class FileManager
    {
    public:
        FileManager(Store* store);
        ~FileManager();
        void savePart(String filename);
        void saveStore(String filename);
        void loadPart(String filename);
        void loadStore(String filename);
    private:
        ImporterList importers;
        ExporterList exporters;
        Store* m_Store;
    };
}

#endif  //_FILEMANAGER_H
