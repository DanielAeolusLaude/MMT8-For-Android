/*
   Virtual MIDI Multitrack Recorder
   Copyright (c) 2006 MIDI Team

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/

/**
   MMT8Importer.cppile MMT8Importer.cpp
   Charles Weld, David Wilson, James Brown, Jonathan Van Rossum, and Matthew Harrold
   @brief Declaration of class MMT8Importer, part of Virtual MIDI Multitrack Recorder
*/

#include "MMT8Importer.hpp"

#include "Store.hpp"
#include "Song.hpp"
#include "Part.hpp"
#include "SongStep.hpp"

// DEBUGGING ONLY
#include <iostream>

namespace Vimmer
{

// ----------------------------------------------------------------------------------------------------
    MMT8Importer::MMT8Importer(Store* s) : Importer(s)
    {
        store = s;
    }

    String MMT8Importer::getFilter()
    {
        return String("sys");   // is this right?
    }

// ----------------------------------------------------------------------------------------------------
    void MMT8Importer::fileImportStore(String filename)
    {
std::cout << "Importing...";
        import(filename.c_str(), MODE_STORE, 0);
std::cout << " DONE.\n";    }

// ----------------------------------------------------------------------------------------------------
    void MMT8Importer::fileImportSong(String filename, int songnumber)
    {
        import(filename.c_str(), MODE_SONG, songnumber);
    }

// ----------------------------------------------------------------------------------------------------
    void MMT8Importer::fileImportPart(String filename, int partnumber)
    {
        import(filename.c_str(), MODE_PART, partnumber);
    }

// ----------------------------------------------------------------------------------------------------
    void MMT8Importer::import(const char* filename, int mode, int number)
    {
        unsigned char* memoryblock;
        unsigned char* data;
        int filesize = 0;

        memoryblock = (unsigned char*) loadfile (filename, (int*)&filesize);
        data        = (unsigned char*) malloc (filesize);

        // Read the file into memory.
        if(memoryblock != NULL && data != NULL && (filesize > 0x200))
        {
            // Convert to 8-BIT format
            //int index = 0;
            //int bytes_remaining = convert_midi_mmt8(&memoryblock[5], data, filesize-5);

            struct type_mmt8_header* mmt8 = (struct type_mmt8_header*)data;

            for (int i=0; i<256; i++)
            {
                unsigned char c = data[i];
                unsigned int j = (unsigned int) c;
                std::cout << "[" << i << "]: " << j << "\n";
            }

            // PROCESS EACH PART (00-99)
            for (int i=0; i<100; i++)
            {
                if (mode == MODE_STORE || mode == MODE_PART && number == i)
                {
                    // Check if Part exists.
                    if (mmt8->ptr_to_part[i].value != 0)
                    {
                        // MMT8 PART
                        unsigned short ptr_to_part = reverse_endian_short(mmt8->ptr_to_part[i].value) - 0x400;

                        // VIMMER PART
                        Part* vimmer_part = (store) ? store->getPartSystem()->getPart(i) : NULL;
                        if (vimmer_part) vimmer_part->erase();

                        // NUMBER OF BYTES
                        unsigned short number_of_bytes = filesize - ptr_to_part;
                        if (i != 99 && mmt8->ptr_to_part[i+1].value != 0)
                        {
                            unsigned short difference = reverse_endian_short(mmt8->ptr_to_part[i+1].value) - ptr_to_part;
                            number_of_bytes = min(filesize - ptr_to_part, difference);
                        }
                        else
                        {
                            number_of_bytes = filesize;
                        }
std::cout << data;
                        // PROCESS
                        process_Part(vimmer_part, &data[ptr_to_part], number_of_bytes);
                    }
                }
            }

            // PROCESS EACH SONG (00-99)
            for (int i=0; i<100; i++)
            {
std::cout << "s";
                if (mode == MODE_STORE || mode == MODE_SONG && number == i)
                {
                    if (mmt8->ptr_to_song[i].value!=0)
                    {
                        // DEBUGGING
                        std::cout << "SONG " << i << "\n";

                        // MMT-8 SONG
                        unsigned short ptr_to_song = reverse_endian_short(mmt8->ptr_to_song[i].value) - 0x400;
                        unsigned char* mmt8_song = &data[ptr_to_song];

                        // VIMMER SONG
                        Song* vimmer_song = NULL;
                        if (store != NULL && i >= 0 && i <= 99)
                        {
                            vimmer_song = store->getSongSystem()->getSong(i);
                            vimmer_song->clear();
                        }

                        // NUMBER OF BYTES
                        unsigned short number_of_bytes = filesize - ptr_to_song;
                        if (i != 99 && mmt8->ptr_to_song[i+1].value != 0)
                        {
                            unsigned int difference = reverse_endian_short(mmt8->ptr_to_song[i+1].value) - ptr_to_song;
                            number_of_bytes = min(filesize - ptr_to_song, difference);
                        }
                        else
                        {
                            number_of_bytes = filesize;
                        }

                        process_Song(vimmer_song, mmt8_song, number_of_bytes);
                    }
                }
            }
std::cout << ".";

            free(data);
            free(memoryblock);
        }
    }

// ----------------------------------------------------------------------------------------------------
    void MMT8Importer::process_Part(Part* vimmer_part, unsigned char* data, unsigned int number_of_bytes)
    {
std::cout << "A";
        if (vimmer_part != NULL && data != NULL && number_of_bytes > sizeof(struct type_part_data))
        {
std::cout << "B";
            // PART DATA
            struct type_part_data* mmt8_part = (struct type_part_data*)data;
std::cout << "1";
            unsigned short b;
std::cout << "1";
            b = mmt8_part->number_of_bytes;
std::cout << "1";
            number_of_bytes = min((unsigned short)number_of_bytes, b);
std::cout << "2";

            // NUMBER OF BEATS)
            //   (convert from Binary Coded Decimal)
            unsigned short number_of_beats;
std::cout << "3";
            number_of_beats = convert_from_bcd(mmt8_part->number_of_beats_bcd);
            vimmer_part->setLength(number_of_beats);
std::cout << "C";

            // NAME
            String name;
            for (int i=0; i<14; i++)
            {
                name += mmt8_part->part_name[i];
            }
            if (vimmer_part) vimmer_part->setName(name);
std::cout << "D";

            // Process each TRACK
            for (int i=0; i<8; i++)
            {
                // Offset from start of header (ie. from char* mmt8_part)
                unsigned short track_offset = mmt8_part->off_track_data[i];
std::cout << "E";

                if (track_offset != 0)
                {
                    // Calculate the SIZE of the current track
                    //     This is not strictly needed, because each track should have
                    //     an END OF TRACK marker. By checking this, we prevent a corrupted
                    //     track from corrupting all that follow it, and prevent our program
                    //     from crashing.
                    int track_size_bytes = mmt8_part->number_of_bytes - track_offset;
                    for (int j = i; j < 8-1; j++)
                    {
                        unsigned short track_offset_next = mmt8_part->off_track_data[i+1];
                        if (track_offset_next != 0 && (track_offset_next - track_offset) < track_size_bytes)
                        {
                            track_size_bytes = track_offset_next - track_offset;
                            break;
                        }
                    }

                    // MMT8 Track
                    unsigned char* mmt8_track = &data[track_offset];

                    // VIMMER Track
                    Track* vimmer_track = (vimmer_part) ? (vimmer_part->getTrack(8-i-1)) : NULL;

std::cout << "F";

                    // PROCESS
                    process_Track(vimmer_track, mmt8_track, track_size_bytes);
std::cout << "G";
                }
            }
        }
std::cout << "H";
    }


// ----------------------------------------------------------------------------------------------------
    void MMT8Importer::process_Track(Track* vimmer_track, unsigned char* mmt8_track, unsigned int number_of_bytes)
    {
        if (vimmer_track != NULL && mmt8_track != NULL)
        {
            // Current ABSOLUTE TIMESTAMP
            unsigned long absolute = 0;

            // Iterator in Track: for efficiency only
            MIDIEventIterator iterator = vimmer_track->getIterator_begin();

            // Clear track
            vimmer_track->erase();

            unsigned int j = 0;
            while (j + 7 < number_of_bytes)
            {
std::cout << ".";

                unsigned char peek = mmt8_track[j];

                // Get MMT8 Event
                struct type_midi_event_5byte event5;
                if (peek & 0x80)
                {
                    // Check for TRACK END MARKER
                    if (peek == (unsigned char)0x80)
                    {
                        break;
                    }

                    // Get the 7-BYTE event
                    struct type_midi_event_7byte* event7 = (struct type_midi_event_7byte*)(&mmt8_track[j]);
                    event5.note_number   = event7->note_number;
                    event5.note_velocity = event7->note_velocity;
                    event5.midi_channel  = event7->midi_channel;
                    event5.note_duration = event7->note_duration;

                    // Get the new ABSOLUTE TIME
                    absolute = (unsigned long)(event7->absolute_start_time) * MIDIToolkit::PULSES_PER_BEAT / 96;

                    j += 7;
                }
                else
                {
                    // Get the 5-BYTE event.
                    event5 = *(struct type_midi_event_5byte*)(&mmt8_track[j]);
                    j += 5;
                }

                // PROCESS
                process_Event5(absolute, &event5, vimmer_track, &iterator);
            }
        }
    }

// ----------------------------------------------------------------------------------------------------
    void MMT8Importer::process_Event5(unsigned long absolute, struct type_midi_event_5byte* event5, Track* vimmer_track, MIDIEventIterator* iterator)
    {
        if (event5 != NULL && vimmer_track != NULL)
        {
            // Default iterator in case none is supplied.
            //   The iterator is only used for efficiency:
            //   it saves searching from the beginning each time an event is added.
            MIDIEventIterator i;
            if (iterator != NULL)
            {
                i = *iterator;
            }
            else
            {
                i = vimmer_track->getIterator_begin();
            }

            // Look at HIGH BIT of note velocity
            if ((event5->note_velocity & 0x80) == 0)
            {
                // NOTE MESSAGE
                //   Get Duration (convert from big-endian)
                int duration = reverse_endian_short(event5->note_duration.value);

                // NOTE ON
                ChannelMessage note_on(ChannelCommands::NoteOn, event5->midi_channel, event5->note_number, event5->note_velocity);
                vimmer_track->insert(absolute, &note_on, i);

                // NOTE OFF
                ChannelMessage note_off(ChannelCommands::NoteOff, event5->midi_channel, event5->note_number, 0);
                vimmer_track->insert(absolute + duration, &note_off, i);
            }
            else
            {
                // OTHER ...
                if (event5->note_number <= 121)
                {
                    // CONTROL CHANGE
                    ChannelMessage m(ChannelCommands::Controller, event5->midi_channel, event5->controller_number, event5->controller_amount);
                    //vimmer_track->insert(absolute, &m, i);
                }
                else
                {
                    switch (event5->note_number)
                    {
                        case 122:   // PROGRAM CHANGE
                        {
                            ChannelMessage m(ChannelCommands::ProgramChange, event5->midi_channel, event5->controller_amount, 0);
                            //vimmer_track->insert(absolute, &m, i);
                            break;
                        }
                        case 123:   // AFTER TOUCH
                        {
                            ChannelMessage m(ChannelCommands::ChannelPressure, event5->midi_channel, event5->controller_amount, 0);
                            //vimmer_track->insert(absolute, &m, i);
                            break;
                        }
                        case 124:   // PITCH BEND
                        {
                            //ChannelMessage m(ChannelCommands::Controller, event5->midi_channel, event5->controller_number, event5->controller_amount);
                            //vimmer_track->insert(absolute, &m, i);
                            break;
                        }
                        case 125:   // SYSEX
                        {
                            // Ignore - we don't support these yet.
                            break;
                        }
                        default:
                        {
                            // Ignore - Unknown type
                            break;
                        }
                    }
                }
            }
        }
    }

// ----------------------------------------------------------------------------------------------------
    void MMT8Importer::process_Song(Song* vimmer_song, unsigned char* mmt8_song, unsigned int number_of_bytes)
    {
        if (vimmer_song != NULL && mmt8_song != NULL && number_of_bytes > sizeof(struct type_song_data))
        {
            struct type_song_data* song = (struct type_song_data*)mmt8_song;
            if (number_of_bytes > song->number_of_bytes) number_of_bytes = song->number_of_bytes;

            if (song->number_of_bytes != 0)
            {
                int tempo = (int)(song->tempo);
                String name;

                std::cout << "  Tempo: " << tempo << "\n";
                std::cout << "  Name: ";

                for (int i=0; i<14; i++)
                {
                    name += (char)song->song_name[i];
                    std::cout << song->song_name[i];
                }
                name += (char)0;
                std::cout << "\n";

                std::cout << "  Song Step Data: \n";
                struct type_song_step_data* ssd = (struct type_song_step_data*)&(song->step_data);
                for (int i=0; ssd[i].part_number!=(unsigned char)0xFF; i++)
                {
                    int partnumber = (int)(ssd[i].part_number);
                    if (partnumber >= 0 && partnumber <= 99)
                    {
                        std::cout << "    Step " << i << ": Part " << partnumber << ", Tracks: ";

                        Part* vimmer_part = (store) ? store->getPartSystem()->getPart(partnumber) : NULL;
                        SongStep* vimmer_songstep = new SongStep(vimmer_part);

                        vimmer_song->add(vimmer_songstep);

                        // TRACK STATE
                        for (int j=0; j<8; j++)
                        {
                            if ((ssd[i].play_tracks >> j) & 0x01)
                            {
                                if (store!=NULL) vimmer_songstep->setTrackState(j, MultiTrackLink::TRACK_STATE_PLAY);
                                std::cout << "y";
                            }
                            else
                            {
                                if (store!=NULL) vimmer_songstep->setTrackState(j, MultiTrackLink::TRACK_STATE_CLEAR);
                                std::cout << "-";
                            }
                        }
                        std::cout << "\n";
                    }
                }
                std::cout << "\n";
            }
            std::cout << "\n";
        }
    }

// ----------------------------------------------------------------------------------------------------
    int MMT8Importer::convert_midi_mmt8(const unsigned char* s, unsigned char* d, unsigned int source_size)
    {
        // Number of bytes used by the destination.
        int destination_number_of_bytes = 0;

        // Convert 7-bit MIDI data to 8-bit MMT8 format.
        for (unsigned int si=0, di=0; si<source_size; si++)
        {
            unsigned char t = s[si];
            switch (si % 8)
            {
                case 0:
                    d[di+0] = (t << 1);
                    destination_number_of_bytes = di + 1;
                    break;
                case 1:
                    d[di+0] |= (t & 0x40) >> 6;
                    d[di+1] = (t << 2);
                    destination_number_of_bytes = di + 2;
                    break;
                case 2:
                    d[di+1] |= (t & 0x60) >> 5;
                    d[di+2] = (t << 3);
                    destination_number_of_bytes = di + 3;
                    break;
                case 3:
                    d[di+2] |= (t & 0x70) >> 4;
                    d[di+3] = (t << 4);
                    destination_number_of_bytes = di + 4;
                    break;
                case 4:
                    d[di+3] |= (t & 0x78) >> 3;
                    d[di+4] = (t << 5);
                    destination_number_of_bytes = di + 5;
                    break;
                case 5:
                    d[di+4] |= (t & 0x7C) >> 2;
                    d[di+5] = (t << 6);
                    destination_number_of_bytes = di + 6;
                    break;
                case 6:
                    d[di+5] |= (t & 0x7E) >> 1;
                    d[di+6] = (t << 7);
                    destination_number_of_bytes = di + 7;
                    break;
                case 7:
                    d[di+6] |= (t & 0x7F);
                    di += 7;
                    destination_number_of_bytes = di + 7;
                    break;
            }
        }
        return destination_number_of_bytes;
    }

}
