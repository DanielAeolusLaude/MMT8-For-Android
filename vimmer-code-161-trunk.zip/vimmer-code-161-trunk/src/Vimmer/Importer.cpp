/*
   Virtual MIDI Multitrack Recorder
   Copyright (c) 2006 MIDI Team

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/

/**
   Importer.cppile Importer.cpp
   Charles Weld, David Wilson, James Brown, Jonathan Van Rossum, and Matthew Harrold
   @brief Declaration of class Importer, part of Virtual MIDI Multitrack Recorder
*/

#include "Importer.hpp"

#include "Exporter.hpp"
#include "Store.hpp"

#include <iostream>
#include <fstream>

using namespace std;

namespace Vimmer
{
    Importer::Importer(Store* store)
    {
        logger = LogManager::getSingleton();
    }

    String Importer::getFilter()
    {
        return String("");
    }

    void Importer::fileImportStore (String filename)
    {
        logger->log("Import store feature no supported for this file format ()");
    }

    void Importer::fileImportSong  (String filename, int songnumber)
    {
        logger->log("Import song feature no supported for this file format ()");
    }

    void Importer::fileImportPart  (String filename, int partnumber)
    {
        logger->log("Import part feature no supported for this file format ()");
    }

    void Importer::fileImportTrack (String filename, int partnumber, int tracknumber)
    {
        logger->log("Import track feature no supported for this file format ()");
    }

    char* Importer::loadfile(const char* filename, int* size)
    {
        char* temp_memoryblock;
        int temp_size;

        // Check for NULL filename and size pointer.
        if (filename == 0 || size == 0)
        {
            //Error.
            return 0;
        }
        else
        {
            // Open the file
            std::ifstream file(filename, ios::in | ios::binary | ios::ate);

            // Check that open was successful.
            if (file.is_open())
            {
                // Get the size of the file
                temp_size = file.tellg();

                // Allocate memory
                temp_memoryblock = (char*)malloc(temp_size);

                if (temp_memoryblock != 0)
                {
                    // Seek to the beginning
                    file.seekg(0, ios::beg);

                    // Read the contents of the file into memory
                    file.read(temp_memoryblock, temp_size);
                }

                // Close the file
                file.close();

                // Return the pointer and size
                *size = temp_size;
                return temp_memoryblock;

            }
            else
            {
                // Error: The file was not opened.
                return 0;
            }
        }
    }

//----------------------------------------------------------------------------------------------
    void Importer::advance(unsigned int* index, signed int* remaining_bytes, unsigned int bytes)
    {
        Exporter::advance(index, remaining_bytes, bytes);
    }

//----------------------------------------------------------------------------------------------
    void Importer::swap(unsigned char* a, unsigned char* b)
    {
        Exporter::swap(a, b);
    }

//----------------------------------------------------------------------------------------------
    unsigned short Importer::reverse_endian_short(unsigned short little_endian)
    {
        return Exporter::reverse_endian_short(little_endian);
    }

//----------------------------------------------------------------------------------------------
    unsigned int   Importer::reverse_endian_int  (unsigned int   little_endian)
    {
        return Exporter::reverse_endian_int(little_endian);
    }

//----------------------------------------------------------------------------------------------
    unsigned int   Importer::reverse_endian_24   (unsigned int little_endian)
    {
        return Exporter::reverse_endian_24(little_endian);
    }

//----------------------------------------------------------------------------------------------
    unsigned short Importer::convert_from_bcd (unsigned short bcd)
    {
        return Exporter::convert_from_bcd(bcd);
    }

//----------------------------------------------------------------------------------------------
    unsigned short Importer::convert_to_bcd   (unsigned short number)
    {
        return Exporter::convert_to_bcd(number);
    }
//----------------------------------------------------------------------------------------------

    unsigned short Importer::min(unsigned short a, unsigned short b)  {return ((a<b) ? a : b);}
    unsigned short Importer::max(unsigned short a, unsigned short b)  {return ((a>b) ? a : b);}

    unsigned int Importer::min(unsigned int a, unsigned int b)        {return ((a<b) ? a : b);}
    unsigned int Importer::max(unsigned int a, unsigned int b)        {return ((a>b) ? a : b);}

//----------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------

}
