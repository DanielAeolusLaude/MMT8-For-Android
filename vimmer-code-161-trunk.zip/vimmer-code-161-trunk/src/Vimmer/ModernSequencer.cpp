/*
   Virtual MIDI Multitrack Recorder
   Copyright (c) 2006 MIDI Team

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/

/**
   @file ModernSequencer.cpp
   @author Charles Weld
   @brief Declaration of class ModernSequencer, part of Virtual MIDI Multitrack Recorder
*/

#include "ModernSequencer.hpp"
#include "Observer.hpp"
#include "Events.hpp"
#include "MMT8Importer.hpp"
#include "StandardMIDIImporter.hpp"
#include "XMLImporter.hpp"
#include "MMT8Exporter.hpp"
#include "StandardMIDIExporter.hpp"
#include "XMLExporter.hpp"
#include "Group.hpp"
#include "Entry.hpp"
#include "Exception.hpp"
#include "LogManager.hpp"

using namespace MIDIToolkit;

namespace Vimmer
{
    ModernSequencer::ModernSequencer(int num_of_parts, int num_of_songs)
    {
        m_Sequencer = new MIDIToolkit::Sequencer();
        m_Device = new Device();
        m_Device->connect(m_Sequencer);
        m_Sequencer->connect(m_Device);

        m_Store = new Store(num_of_parts, num_of_songs);
        m_SequencerMgr = new SequencerManager(m_Sequencer, m_Store);

        m_Store->addObserver(m_SequencerMgr->getSongSequencer());

        m_FileManager = new FileManager(m_Store);

        m_Configuration = ConfigurationManager::getSingleton();
    }

    ModernSequencer::~ModernSequencer()
    {
        // update and save configuration
        updateConfiguration();
        m_Configuration->save("config.xml");

        delete m_Sequencer;
        delete m_Device;
        delete m_Store;
        delete m_SequencerMgr;
        delete m_FileManager;
    }

    void ModernSequencer::updateConfiguration()
    {
        m_Configuration->getRoot().addGroup("General");
        Group& general = m_Configuration->getRoot().getGroup("General");
        general.addEntry("input port", m_Device->getInput());
        general.addEntry("output port", m_Device->getOutput());
        general.addEntry("through", m_Device->isThruEnabled());
        general.addEntry("loop", m_SequencerMgr->getLoop());
        general.addEntry("overdub", m_SequencerMgr->getPartSequencer()->getOverDub());
        general.addEntry("record click", m_SequencerMgr->getClickRecord());
        general.addEntry("play click", m_SequencerMgr->getClickPlay());
        general.addEntry("countin", m_SequencerMgr->getCountin());
        general.addEntry("click interval", m_SequencerMgr->getClickInterval());
    }

    Store* ModernSequencer::getStore()
    {
        return m_Store;
    }

    SequencerManager* ModernSequencer::getSequencer()
    {
        return m_SequencerMgr;
    }

    MIDIToolkit::Device* ModernSequencer::getDevice()
    {
        return m_Device;
    }

    FileManager* ModernSequencer::getFileManager()
    {
        return m_FileManager;
    }

    void ModernSequencer::addObserver(Observer* o)
    {
        vimmerUI = o;
        // Store
        m_Store->addObserver(o);

        // Sequencer
        m_SequencerMgr->addObserver(o);
        m_SequencerMgr->getPartSequencer()->getActiveStep().addObserver(o);

        // device
        m_Device->addObserver(o);
    }

    void ModernSequencer::init()
    {
        // load configuration (if exists)
        if(!m_Configuration->load("config.xml"))
        {
            // load defaults
            updateConfiguration();
        }
        else
        {
            try
            {
                Group& general = m_Configuration->getRoot().getGroup("General");

                // ports
                m_Device->setInput(general["input port"].getIntValue());
                m_Device->setOutput(general["output port"].getIntValue());

                // through
                if(general["through"].getBoolValue())
                    m_Device->enableThru();
                else
                    m_Device->disableThru();

                m_SequencerMgr->setLoop(general["loop"].getBoolValue());
                m_SequencerMgr->getPartSequencer()->setOverDub(general["overdub"].getBoolValue());
                m_SequencerMgr->setClickRecord(general["record click"].getBoolValue());
                m_SequencerMgr->setClickPlay(general["play click"].getBoolValue());
                m_SequencerMgr->setCountin(general["countin"].getIntValue());
                m_SequencerMgr->setClickInterval(general["click interval"].getIntValue());
            }
            catch(Exception e)
            {
                LogManager::getSingleton()->log(e.getDescription());
                updateConfiguration();
            }
        }

        int beat = m_SequencerMgr->getPartSequencer()->getBeat();
        vimmerUI->fireEvent(Events::INIT_VIMMER);
        vimmerUI->fireEvent(Events::SEQUENCER_BEAT_UPDATE,&beat);
        vimmerUI->fireEvent(Events::SEQUENCER_STATE_CHANGED);
        vimmerUI->fireEvent(Events::TRACK_STATE_CHANGED);
        vimmerUI->fireEvent(Events::SEQUENCER_TEMPO_CHANGED);
        vimmerUI->fireEvent(Events::THRU_STATE_CHANGED);
        vimmerUI->fireEvent(Events::SEQUENCER_MODE_CHANGED);
        vimmerUI->fireEvent(Events::ACTIVE_SONG_CHANGED,m_Store->getSongSystem()->getActive());
        vimmerUI->fireEvent(Events::ACTIVE_PART_CHANGED);
        vimmerUI->fireEvent(Events::SEQUENCER_LOOP_CHANGED);
        vimmerUI->fireEvent(Events::PART_SEQUENCER_OVERDUB_CHANGED);
    }


    bool ModernSequencer::load(const char* filename,int fileformat,int type,int identifier)
    {
        Importer* loader=0;
        switch(fileformat){
            case XML:
            {
                loader=new XMLImporter(m_Store);
                break;
            }

            case MID:
            {
                loader=new StandardMIDIImporter(m_Store);
                break;
            }

            case SYX:
            {
                loader=new MMT8Importer(m_Store);
                break;
            }

            default:
            {
                return false;
                break;
            }

        }

        switch(type){
            case ALL:
            {
                loader->fileImportStore(filename);
                break;
            }

            case PART:
            {
                loader->fileImportPart(filename, identifier);
                break;
            }

            case SONG:
            {
                loader->fileImportSong(filename, identifier);
                break;
            }

            default:
            {
                return false;
                break;
            }
        }
        if(!loader==0) delete loader;
        return true;
    }

    bool ModernSequencer::save(const char* filename,int fileformat,int type,int identifier)
    {
        Exporter* saver=0;
        switch(fileformat){
            case XML:
            {
                saver=new XMLExporter(m_Store);
                break;
            }

            case MID:
            {
                saver=new StandardMIDIExporter(m_Store);
                break;
            }

            case SYX:
            {
                saver=new MMT8Exporter(m_Store);
                break;
            }

            default:
            {
                return false;
                break;
            }

        }

        switch(type){
        case ALL:
            {
                saver->fileExportStore(filename);
                break;
            }

        case PART:
            {
                saver->fileExportPart(filename, identifier);
                break;
            }

         case SONG:
            {
                saver->fileExportSong(filename, identifier);
                break;
            }
        }
        if(!saver==0) delete saver;
        return true;
    }
}
