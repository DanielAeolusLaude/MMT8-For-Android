/*
   Virtual MIDI Multitrack Recorder
   Copyright (c) 2006 MIDI Team

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/

/**
   StandardMIDIImporter.cppile StandardMIDIImporter.cpp
   Charles Weld, David Wilson, James Brown, Jonathan Van Rossum, and Matthew Harrold
   @brief Declaration of class StandardMIDIImporter, part of Virtual MIDI Multitrack Recorder
*/

#include "StandardMIDIImporter.hpp"
#include "Store.hpp"

#include <windows.h>


#include <iostream>
#include <fstream>

//using namespace std;


namespace Vimmer
{

    StandardMIDIImporter::StandardMIDIImporter(Store* s):
        Importer(s)
    {
            // STORE
            store = s;

            // HEADER CHUNK: MThd
            chunk_MThd.type_byte[0] = 'M';
            chunk_MThd.type_byte[1] = 'T';
            chunk_MThd.type_byte[2] = 'h';
            chunk_MThd.type_byte[3] = 'd';

            // TRACK CHUNK: MThd
            chunk_MTrk.type_byte[0] = 'M';
            chunk_MTrk.type_byte[1] = 'T';
            chunk_MTrk.type_byte[2] = 'r';
            chunk_MTrk.type_byte[3] = 'k';
    }


    String StandardMIDIImporter::getFilter()
    {
        return String("mid");
    }

//----------------------------------------------------------------------------------------------
    void StandardMIDIImporter::fileImportStore(String filename)
    {
        // Erase store
        SongSystem* ss = store->getSongSystem();
        PartSystem* ps = store->getPartSystem();
        for (int i = 0; i < ss->count(); i++)
        {
            Song* s = ss->getSong(i);
            s->clear();
        }
        for (int i = 0; i < ps->count(); i++)
        {
            Part* p = ps->getPart(i);
            p->erase();
        }

        // Import to PART 00
        fileImportPart(filename.c_str(), 0);
    }

//----------------------------------------------------------------------------------------------
    void StandardMIDIImporter::fileImportSong(String filename, int songnumber)
    {
    }

//----------------------------------------------------------------------------------------------
    void StandardMIDIImporter::fileImportPart(String filename, int partnumber)
    {
        if (store != NULL)
        {
            PartSystem* partsystem = store->getPartSystem();
            Part* p = partsystem->getPart(partnumber);

            if (p != NULL)
            {
                import(filename.c_str(), MODE_PART, NULL, p);
            }
        }
    }

//----------------------------------------------------------------------------------------------
    void StandardMIDIImporter::fileImportTrack(String filename, int partnumber, int tracknumber)
    {
        PartSystem* partsystem = store->getPartSystem();
        MultiTrack* p = partsystem->getPart(partnumber);
        Track* t = p->getTrack(tracknumber);

        import(filename.c_str(), MODE_TRACK, t, NULL);
    }

//----------------------------------------------------------------------------------------------
    void StandardMIDIImporter::import(const char* filename, int mode, Track* track, MultiTrack* multitrack)
    {
        // File
        char* memoryblock;
        unsigned int filesize;

        // Read the file into memory.
        memoryblock = loadfile(filename, (int*)&filesize);
        if(memoryblock != NULL)
        {
            // Index into the file (an array in memory).
            unsigned int index;

            struct type_track_data track_data;
            track_data.part_name = "";
            track_data.tracknumber = 0;
            track_data.pulse_divider = 1;
            track_data.tempo = 120;
            track_data.length = 0;

            struct chunk_type           chunk;          // General Chunk (eg. Track)
            struct header_data_type     header_data;    // Header Data

            bool header_is_defined = false;             // Make sure we have a header!

            index = 0;
            while(filesize-index >= 8)
            {
                // CHUNK TYPE
                chunk.type_byte[0] = memoryblock[index+0];
                chunk.type_byte[1] = memoryblock[index+1];
                chunk.type_byte[2] = memoryblock[index+2];
                chunk.type_byte[3] = memoryblock[index+3];

                // CHUNK LENGTH
                // These bytes are stored as BID-ENDIAN, therefore must be reversed to get length.
                chunk.length_byte[0] = memoryblock[index+7];
                chunk.length_byte[1] = memoryblock[index+6];
                chunk.length_byte[2] = memoryblock[index+5];
                chunk.length_byte[3] = memoryblock[index+4];

                // INDEX TO DATA
                chunk.data = index + 8;

                // Check that LENGTH of CHUNK doesn't exceed remaining length of file.
                if (index + 8 + chunk.length > filesize)
                {
                    chunk.length = filesize - (index + 8);
                }

                // DEBUGGING
                std::cout << "Chunk Type: ";
                std::cout << chunk.type_byte[0];
                std::cout << chunk.type_byte[1];
                std::cout << chunk.type_byte[2];
                std::cout << chunk.type_byte[3];
                std::cout << "\n";
                std::cout << "Chunk Length: ";
                std::cout << chunk.length;
                std::cout << "\n";
                std::cout << "\n";

                if (chunk.type == chunk_MThd.type)
                {
                    // HEADER (and only header) should be the first chunk.
                    // Also, minimum number of fields
                    if (chunk.length >= 6)
                    {
                        // We have a header!
                        header_is_defined = true;

                        // FORMAT (Big-Endian)
                        header_data.format_byte[1] =    memoryblock[index+8+0];
                        header_data.format_byte[0] =    memoryblock[index+8+1];

                        // NTRKS (Big-Endian)
                        header_data.ntrks_byte[1] =     memoryblock[index+8+2];
                        header_data.ntrks_byte[0] =     memoryblock[index+8+3];

                        // DIVISION (Big-Endian)
                        header_data.division_byte[1] =  memoryblock[index+8+4];
                        header_data.division_byte[0] =  memoryblock[index+8+5];

                        // What does "division" represent? (check high bit.)
                        if (header_data.division & 0x80)
                        {
                            // Negative SMPTE format
                            track_data.pulse_divider = 1;
                            //track_data.tempo = 60*a*b/MIDIToolkit::PULSES_PER_BEAT;
                        }
                        else
                        {
                            // Ticks per quater-note
                            if (header_data.division!=0)
                            {
                                // This converts to the PULSES_PER_BEAT used by Vimmer.
                                track_data.pulse_divider = MIDIToolkit::PULSES_PER_BEAT / header_data.division;
                            }
                        }
                    }
                    else
                    {
                        // IGNORE.
                    }
                }
                else if (chunk.type == chunk_MTrk.type)
                {
                    // A header should already be defined before any TRACK chunks.
                    if (index != 0 && header_is_defined)
                    {
                        if      (mode == MODE_TRACK)
                        {
                            if (track!=NULL) process_chunk_MTrk_Track(&memoryblock[chunk.data], track, &track_data, chunk.length);
                        }
                        else if (mode == MODE_PART)
                        {
                            if (multitrack!=NULL) process_chunk_MTrk_MultiTrack(&memoryblock[chunk.data], multitrack, &track_data, chunk.length);
                        }
                        else
                        {
                            // Error: This mode is not supported!
                        }
                    }
                    else
                    {
                        // This should not be the first header.
                    }
                }
                else
                {
                    // This CHUNK TYPE is not supported.
                }

                // Next chunk length
                index = index + 8 + chunk.length;
            }
        }
        else
        {
            std::cout << "memoryblock==NULL\n";
        }

        free(memoryblock);
    }

//----------------------------------------------------------------------------------------------
    bool StandardMIDIImporter::process_chunk_MTrk_MultiTrack(char* chunkdata, MultiTrack* mt, struct type_track_data* track_data, int bytes_remaining)
    {
        if (mt!=NULL && chunkdata!=NULL && track_data!=NULL)
        {
            Track* t = NULL;
            unsigned int* tracknumber = &(track_data->tracknumber);

            // Check we are not exceeding the number of tracks.
            if (*tracknumber < mt->count())
            {
                // Use this track
                t = mt->getTrack(*tracknumber);
            }
            else
            {
                // Get the last track
                t = mt->getTrack(mt->count() - 1);
            }
            if (t!=NULL)
            {
                process_chunk_MTrk_Track(chunkdata, t, track_data, bytes_remaining);

                if (!(t->empty()))
                {
                    if (track_data->tracknumber == 0)
                    {
                        Part* p = (Part*)mt;
                        p->setName(track_data->part_name);
                        //String s = "MIDI";
                        //p->setName(s);
                    }

                    mt->setLength(track_data->length / MIDIToolkit::PULSES_PER_BEAT);

                    (*tracknumber)++;

                }
            }
            return true;
        }
        else
        {
            return false;
        }
    }

//----------------------------------------------------------------------------------------------
    bool StandardMIDIImporter::process_chunk_MTrk_Track(char* chunkdata, Track* track, struct type_track_data* extra, int size)
    {
        // Index into the CHUNK DATA of current <MTrk event> .
        unsigned int index = 0;
        int bytes_remaining = size;

        // Running status command (used for MIDI SHORT message only).
        unsigned int running_status = 0;

        // <MTrk event> = <delta-time> <event>

        unsigned long absolute_time = 0;        // Absolute time of event, in pulses.
        unsigned int  delta_time    = 0;        // Delta time

       // bool sequence_name_defined = false;
       // bool track_name_defined    = false;

        // Iterate through each event
        if (chunkdata!=NULL && track!=NULL && extra!=NULL)
        {
            //track->erase();
            while (bytes_remaining > 0)
            {
                // GET <delta-time>
                unsigned int temp = get_variable_length_quantity(&chunkdata[index], bytes_remaining, &delta_time);
                advance(&index, &bytes_remaining, temp);

                // Current time
                std::cout << "IN Delta Time: " << delta_time << std::endl;
                absolute_time += (unsigned long)delta_time;

                if (bytes_remaining >= 1)
                {
                    // <event> = <MIDI event> | <sysex event> | <meta-event>
                    //           The type of event is determined by the first byte.

                    // PEEK at first byte.
                    unsigned int i = (unsigned int)((unsigned char)chunkdata[index]);
                    if      (i == 0xF0)
                    {
                        // SYSEX (F0)
                        // <sysex event> = F0 <length> <bytes to be transmitted after F0>
                        unsigned int size = process_MIDI_F0 (&chunkdata[index], track, extra, bytes_remaining, absolute_time);
                        advance(&index, &bytes_remaining, size);
                        if (size == 0) return false;
                    }
                    else if (i == 0xF7)
                    {
                        // SYSEX (F7)
                        // <sysex event> = F7 <length> <all bytes to be transmitted>
                        unsigned int size = process_MIDI_F7 (&chunkdata[index], track, extra, bytes_remaining, absolute_time);
                        advance(&index, &bytes_remaining, size);
                        if (size == 0) return false;
                    }
                    else if (i == 0xFF)
                    {
                        // META-EVENT
                        // <meta-event> = FF <type> <length> <bytes>
                        unsigned int size = process_MIDI_FF (&chunkdata[index], track, extra, bytes_remaining, absolute_time);
                        advance(&index, &bytes_remaining, size);
                        if (size == 0) return false;
                    }
                    else
                    {
                        // MIDI SHORT
                        unsigned int size = process_MIDI_Short (&chunkdata[index], track, extra, bytes_remaining, absolute_time, &running_status);
                        advance(&index, &bytes_remaining, size);
                        if (size == 0) return false;
                    }
                }
                else
                {
                    // This chunk has fatal errors.
                    return false;
                }
            }
        }
        /// @todo was this right?
        return true;
    }

//----------------------------------------------------------------------------------------------
    unsigned int StandardMIDIImporter::process_MIDI_Short (char* data, Track* track, struct type_track_data* extra, int bytes_remaining, unsigned int absolute, unsigned int* running_status)
    {
        unsigned index = 0;
        if (data!=NULL && track!=NULL && extra!=NULL && running_status!=NULL && bytes_remaining >= 3)
        {
            unsigned int midi_command = 0;
            unsigned int midi_channel = 0;
            unsigned int midi_data1 = 0;
            unsigned int midi_data2 = 0;

            // STATUS
            unsigned int i = (unsigned int)((unsigned char)data[0]);
            if (i >= 0x80 && i < 0xF0)
            {
                midi_command = 0xF0 & i;
                midi_channel = 0x0F & i;

                *running_status = i;
                index++;
            }
            else
            {
                midi_command = 0xF0 & *running_status;
                midi_channel = 0x0F & *running_status;
            }

            // DATA 1
            midi_data1 = (unsigned int)((unsigned char)data[index]);
            index++;

            // DATA 2
            int c = midi_command;
            if (c==0x80 || c==0x90 || c==0xA0 || c==0xB0 || c==0xE0)
            {
                midi_data2 = (unsigned int)((unsigned char)data[index]);
                index++;
            }
            else
            {
                midi_data2 = 0;
            }

            // Insert event into track.
            ChannelMessage ch(midi_command, midi_channel, midi_data1, midi_data2);
            track->insert(absolute, &ch);
std::cout << ".";

            // Next <MTrk event>.
            return index;
        }
        return 0;
    }

//----------------------------------------------------------------------------------------------
    unsigned int StandardMIDIImporter::process_MIDI_F0 (char* data, Track* track, struct type_track_data* extra, int bytes_remaining, unsigned int absolute)
    {
        // SYSEX (F0)
        // <sysex event> = F0 <length> <bytes to be transmitted after F0>

        unsigned index = 0;
        if (data!=NULL && track!=NULL && extra!=NULL && bytes_remaining > 1 && (unsigned char)data[0] == 0xF0)
        {
            // F0
            advance(&index, &bytes_remaining, 1);

            // <length>
            unsigned int number_of_bytes = 0;
            unsigned int temp = get_variable_length_quantity(&data[index], bytes_remaining, &number_of_bytes);
            advance(&index, &bytes_remaining, temp);

            // <bytes to be transmitted after F0>
            advance(&index, &bytes_remaining, number_of_bytes);

            // Next <MTrk event>.
            return index;
        }
        return 0;
    }

//----------------------------------------------------------------------------------------------
    unsigned int StandardMIDIImporter::process_MIDI_F7 (char* data, Track* track, struct type_track_data* extra, int bytes_remaining, unsigned int absolute)
    {
        // SYSEX (F7)
        // <sysex event> = F7 <length> <all bytes to be transmitted>

        unsigned index = 0;
        if (data!=NULL && track!=NULL && extra!=NULL && bytes_remaining > 1 && (unsigned char)data[0] == 0xF7)
        {
            // F7
            advance(&index, &bytes_remaining, 1);

            // <length>
            unsigned int number_of_bytes = 0;
            unsigned int temp = get_variable_length_quantity(&data[index], bytes_remaining, &number_of_bytes);
            advance(&index, &bytes_remaining, temp);

            // <bytes to be transmitted after F0>
            advance(&index, &bytes_remaining, number_of_bytes);

            // Next <MTrk event>.
            return index;
        }
        return 0;
    }

//----------------------------------------------------------------------------------------------
    unsigned int StandardMIDIImporter::process_MIDI_FF (char* data, Track* track, struct type_track_data* extra, int bytes_remaining, unsigned int absolute)
    {
        // META-EVENT
        // <meta-event> = FF <type> <length> <bytes>

        unsigned index = 0;
        if (data!=NULL && track!=NULL && extra!=NULL && bytes_remaining > 1 && (unsigned char)data[0] == 0xFF)
        {
            // FF
            advance(&index, &bytes_remaining, 1);

            // <type>
            unsigned char type = (unsigned char)data[index];
            advance(&index, &bytes_remaining, 1);

            // <length>
            unsigned int number_of_bytes = 0;
            unsigned int temp = get_variable_length_quantity(&data[index], bytes_remaining, &number_of_bytes);
            advance(&index, &bytes_remaining, temp);

            // <bytes>
            switch (type)
            {
                case 0x03:  // Sequence Name / Track Name
                {
                    if (extra->tracknumber==0 && extra->part_name=="")
                    {
                        for (unsigned int i=0; i<number_of_bytes && (int)i<bytes_remaining; i++)
                        {
                            char c = data[index + i];
                            extra->part_name += c;
                        }
                    }
                    break;
                }
                case 0x2F:  // End of Track
                {
                    if (absolute / extra->pulse_divider > extra->length)
                    {
                        extra->length = absolute / extra->pulse_divider;
                    }
                    break;
                }
            }
            advance(&index, &bytes_remaining, number_of_bytes);

            // Next <MTrk event>.
            return index;
        }
        return 0;
    }

//----------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------
    unsigned int StandardMIDIImporter::get_variable_length_quantity(char* data, unsigned int max_length, unsigned int* quantity)
    {
        // The quantity so far.
        unsigned int q = 0;

        // The current byte we are looking at.
        unsigned char variable_length_char;
        unsigned int variable_length_int;

        unsigned int i = 0;
        while(true)
        {
            // Check bounds
            if (i<sizeof(int) && i<max_length)
            {
                // Get the next byte.
                variable_length_char = (unsigned char)data[i];
                variable_length_int = (unsigned int)variable_length_char;

                q = q << 7;
                q = q | (variable_length_int & 0x7F);

                i++;

                // Check high bit.
                if (variable_length_int < 0x80)
                {
                    // HIGH BIT CLEAR
                    // (This is the last byte of the variable length value).
                    break;
                }
            }
            else
            {
                *quantity = 0;
                return 0;
            }
        }

        *quantity = q;
        std::cout << "Delta in: " << q << std::endl;
        return i;
    }

}
