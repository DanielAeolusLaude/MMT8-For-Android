/*
   Virtual MIDI Multitrack Recorder
   Copyright (c) 2006 MIDI Team

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/

/**
   StandardMIDIExporter.cppile StandardMIDIExporter.cpp
   Charles Weld, David Wilson, James Brown, Jonathan Van Rossum, and Matthew Harrold
   @brief Declaration of class StandardMIDIExporter, part of Virtual MIDI Multitrack Recorder
*/

#include "StandardMIDIExporter.hpp"

#include "StandardMIDIImporter.hpp"
#include "Store.hpp"
#include "MessageTypes.hpp"

namespace Vimmer
{
    unsigned int StandardMIDIExporter::CHUNK_TYPE_MTHD = 0;
    unsigned int StandardMIDIExporter::CHUNK_TYPE_MTRK = 0;
    unsigned int StandardMIDIExporter::CHUNK_TYPE_ZZZZ = 0;

    StandardMIDIExporter::StandardMIDIExporter(Store* s):
        Exporter(s)
    {
        store = s;

        unsigned char mthd[4] = {'M', 'T', 'h', 'd'};
        unsigned char mtrk[4] = {'M', 'T', 'r', 'k'};
        unsigned char zzzz[4] = {'\0', '\0', '\0', '\0'};

        CHUNK_TYPE_MTHD = *((unsigned int*)mthd);
        CHUNK_TYPE_MTRK = *((unsigned int*)mtrk);
        CHUNK_TYPE_ZZZZ = *((unsigned int*)zzzz);

    }

/*
    typedef std::list<MIDIEvent*>::iterator MIDIEventIterator;

    typedef std::list<MIDIEvent*> MIDIEventList;

    typedef std::vector<Track> TrackVector;

    typedef std::vector<bool> BoolVector;
*/

    String StandardMIDIExporter::getFilter()
    {
        return String("mid");
    }

//----------------------------------------------------------------------------------------------
    void StandardMIDIExporter::fileExportStore(String filename)
    {
        Part* part = store->getPartSystem()->getPart(0);
        exportfile(filename.c_str(), NULL, part, NULL, 0);
    }

//----------------------------------------------------------------------------------------------
    void StandardMIDIExporter::fileExportSong(String filename, int songnumber)
    {
        // ignore.
    }

//----------------------------------------------------------------------------------------------
    void StandardMIDIExporter::fileExportPart(String filename, int partnumber)
    {
        Part* part = store->getPartSystem()->getPart(partnumber);
        exportfile(filename.c_str(), NULL, part, NULL, 0);
    }

//----------------------------------------------------------------------------------------------
    void StandardMIDIExporter::fileExportTrack(String filename, int partnumber, unsigned int tracknumber)
    {
        Part* part = store->getPartSystem()->getPart(partnumber);
        Track* t = part->getTrack(tracknumber);
        exportfile(filename.c_str(), NULL, part, t, 0);
    }

//----------------------------------------------------------------------------------------------
    void StandardMIDIExporter::exportfile(const char* filename, Song* song, Part* part, Track* track, unsigned short format)
    {
std::cout << "a";
        static const int MAX_FILE_SIZE = 1000000;

        unsigned char* memory_block = (unsigned char*)malloc(MAX_FILE_SIZE);
        unsigned int filesize;

        unsigned int index = 0;
        signed   int remaining_bytes = MAX_FILE_SIZE;

        if (memory_block != NULL)
        {

std::cout << "b";
            unsigned int*            MThd_type    = (unsigned int*)&memory_block[0];
            unsigned int*            MThd_length = (unsigned int*)&memory_block[4];
            struct header_data_type* MThd_data   = (struct header_data_type*)&memory_block[8];

            *MThd_type   = CHUNK_TYPE_MTHD;
            *MThd_length = reverse_endian_int(sizeof(header_data_type));
            MThd_data->format   = reverse_endian_short(format);
            MThd_data->ntrks    = reverse_endian_short(0);
            MThd_data->division = reverse_endian_short(0x7FFF & MIDIToolkit::PULSES_PER_BEAT);
            advance(&index, &remaining_bytes, 14);

std::cout << "c";
            switch (format)
            {
                case 0:
                {
std::cout << "d";
                    Track temp_track;

                    struct type_track_data_optional optional;
                    optional.track_length = 0;
                    optional.sequence_number = 0;
                    optional.track_number = 0;
                    optional.tempo = 120;
                    optional.sequence_name = "";

                    if (song != NULL)
                    {
std::cout << "e";
                        // Merge all parts and tracks onto one.
                        MultiTrack mt;
                        optional.track_length = 0;
                        merge_multitracks(&mt, song);
                        merge_tracks(&temp_track, &mt);
std::cout << "f";
                    }
                    else if (part != NULL)
                    {
std::cout << "g";
                        // Merge all tracks onto one.
                        optional.track_length = part->getLength() * MIDIToolkit::PULSES_PER_BEAT;
                        merge_tracks(&temp_track, part);
                        track = &temp_track;
std::cout << "h";
                    }
                    else if (track != NULL)
                    {
std::cout << "i";
                        // One single source track
                        optional.track_length = 0;
                        temp_track.merge(track);
std::cout << "j";
                    }

                    // Length of MTrk chunk, including <type> <length> and <data> fields.
std::cout << "Process...";
                    int chunk_length = process_chunk_MTrk_Track(&memory_block[index], track, remaining_bytes, &optional);
std::cout << "DONE.\n";
                    advance(&index, &remaining_bytes, chunk_length);
                    MThd_data->ntrks = reverse_endian_short(1);
                    track = NULL;
                    break;
                }
                case 1:
                {
std::cout << "k";
                    MultiTrack temp_multitrack;

                    if (song != NULL)
                    {
                        // Merge all parts and tracks onto one.
                        merge_multitracks(&temp_multitrack, song);
                    }
                    else if (part != NULL)
                    {
                        //temp_multitrack.merge(part);
                    }

                    // Length of MTrk chunk, including <type> <length> and <data> fields.
                    unsigned short ntrks = 0;
                    int chunk_length = process_chunk_MTrk_MultiTrack(&memory_block[index], &temp_multitrack, remaining_bytes, &ntrks);
                    advance(&index, &remaining_bytes, chunk_length);
                    MThd_data->ntrks = reverse_endian_short(ntrks);
                    break;
                }
                case 2:
                {
std::cout << "l";
                }
            }
std::cout << "m";

            if (remaining_bytes >= 8)
            {
                unsigned int* ZZZZ_type   = (unsigned int*)&memory_block[index];
                unsigned int* ZZZZ_length = (unsigned int*)&memory_block[index + 4];
                *ZZZZ_type   = CHUNK_TYPE_ZZZZ;
                *ZZZZ_length = 0;
                index          += 8;
                remaining_bytes -= 8;
            }

            filesize = index;
            savefile((char*)filename, (char*)memory_block, filesize);

        }

    }

//----------------------------------------------------------------------------------------------
    void StandardMIDIExporter::merge_tracks(Track* destination, MultiTrack* source)
    {
        if (destination != NULL && source != NULL)
        {
            unsigned int number_of_tracks = source->count();
            for (unsigned int i=0; i<number_of_tracks; i++)
            {
                Track* t = source->getTrack(i);
                destination->merge(t);
            }
        }
    }

//----------------------------------------------------------------------------------------------
    void StandardMIDIExporter::merge_multitracks(MultiTrack* destination, Song* source)
    {
        if (destination != NULL && source != NULL)
        {
            SongStepIterator iterator;
            iterator = source->getIteratorBegin();

            while (iterator != source->getIteratorEnd())
            {
                SongStep* songstep = (*iterator);
                if (songstep != NULL)
                {
                   // MultiTrack* mt = songstep->getPart();
                    //destination->copy(mt);
                }
            }
        }
    }

//----------------------------------------------------------------------------------------------
    unsigned int StandardMIDIExporter::process_chunk_MTrk_MultiTrack(unsigned char* chunk, MultiTrack* multitrack, unsigned int maxsize, unsigned short* ntrks)
    {
        return 0;
    }

//----------------------------------------------------------------------------------------------
    unsigned int StandardMIDIExporter::process_chunk_MTrk_Track(unsigned char* chunk, Track* track, unsigned int maxsize, struct type_track_data_optional* optional)
    {
        unsigned int index = 0;
        signed   int remaining_bytes = maxsize;

        // Track Length
        unsigned int track_length;
        if (optional!=NULL)
        {
            track_length = optional->track_length;
        }
        else
        {
            track_length = 0;
        }

        // Tempo
        unsigned int tempo;
        if (optional!=NULL && optional->tempo != 0)
        {
            tempo = optional->tempo;
        }
        else
        {
            tempo = 120;
        }

        // Sequence Name
        String name;
        if (optional!=NULL && optional->sequence_name != "")
        {
            name = optional->sequence_name;
        }
        else
        {
            name = "VMM-R: (Unnamed Sequence)";
        }

        if (chunk!=NULL && track!=NULL && remaining_bytes>8)
        {
            unsigned int*  MTrk_type   = (unsigned int*)&chunk[0];
            unsigned int*  MTrk_length = (unsigned int*)&chunk[4];
            advance(&index, &remaining_bytes, 8);

            MIDIEventIterator iterator;
            iterator = track->getIterator_begin();

            unsigned int absolute = 0;

            // <meta-event>: SET TEMPO
            unsigned int length_tempo = process_chunk_MTrk_Tempo(&chunk[index], remaining_bytes, tempo);
            advance(&index, &remaining_bytes, length_tempo);

            // <meta-event>: SEQUENCE NAME
            unsigned int length_name = process_chunk_MTrk_SequenceName(&chunk[index], remaining_bytes, name);
            advance(&index, &remaining_bytes, length_name);


            while (iterator!=(track->getIterator_end()) && (*iterator)!=NULL && remaining_bytes > 8)
            {
std::cout << ".";
                unsigned int new_absolute = (*iterator)->absolute;

                MIDIMessage* m = (*iterator)->getMessage();
                if (m!=NULL && m->isA(MessageTypes::CHANNEL_MESSAGE))
                {
                    ChannelMessage* chm = (ChannelMessage*)m;
                    unsigned char command = 0xF0 & chm->getCommand();
                    unsigned char channel = 0x0F & chm->getChannel();
                    unsigned char data1 = chm->getData1();
                    unsigned char data2 = chm->getData2();

                    // <delta-time>
                    unsigned int deltatime = (new_absolute - absolute);
                    absolute = new_absolute;
                    unsigned int length_of_deltatime = set_variable_length_quantity(&chunk[index], remaining_bytes, deltatime);
                    advance(&index, &remaining_bytes, length_of_deltatime);

                    // <midi-event>
                    switch (command)
                    {
                        case 0x80:
                        case 0x90:
                        case 0xA0:
                        case 0xB0:
                        case 0xE0:
                            chunk[index + 0] = command | channel;
                            chunk[index + 1] = data1;
                            chunk[index + 2] = data2;
                            advance(&index, &remaining_bytes, 3);
                            break;
                        case 0xC0:
                        case 0xD0:
                            chunk[index + 0] = command | channel;
                            chunk[index + 1] = data1;
                            advance(&index, &remaining_bytes, 2);
                            break;
                    }
                }

                iterator++;

                // Check for end of track
                if (iterator == track->getIterator_end())
                {
                    // <delta-time>
                    unsigned int deltatime;
                    if (track_length != 0 && track_length > new_absolute)
                    {
                        deltatime = (track_length - new_absolute);//(PULSES_PER_BEAT/72);
                    }
                    else
                    {
                        deltatime = 0;
                    }
                    unsigned int length_of_deltatime = set_variable_length_quantity(&chunk[index], remaining_bytes, deltatime);
                    advance(&index, &remaining_bytes, length_of_deltatime);

                    // <meta-event>
                    chunk[index + 0] = 0xFF;    // Meta event
                    chunk[index + 1] = 0x2F;    // End of track
                    chunk[index + 2] = 0x00;
                    advance(&index, &remaining_bytes, 3);
                    break;
                }
            }

            *MTrk_type   = CHUNK_TYPE_MTRK;
            *MTrk_length = reverse_endian_int(index);
            return index;
        }
        else
        {
            return 0;
        }
    }
//----------------------------------------------------------------------------------------------
    unsigned int StandardMIDIExporter::process_chunk_MTrk_Tempo(unsigned char* chunk, unsigned int maxsize, unsigned int tempo)
    {
        if (chunk != NULL && maxsize >= 7 && tempo != 0)
        {
            // Calculate tempo in this format
            unsigned int microseconds_per_beat = (60*1000*1000)/96/tempo;
            unsigned int micros_bigendian = reverse_endian_24(microseconds_per_beat);

            // <delta-time> <meta-event>
            chunk[0] = 0x00;    // Deltatime
            chunk[1] = 0xFF;    // Meta event
            chunk[2] = 0x51;    // End of track
            chunk[3] = 0x03;    // Length of data
            chunk[4] = 0xFF & (micros_bigendian >>  0); // tt
            chunk[5] = 0xFF & (micros_bigendian >>  8); // tt
            chunk[6] = 0xFF & (micros_bigendian >> 16); // tt
            return 7;
        }
        else
        {
            return 0;
        }
    }

//----------------------------------------------------------------------------------------------
    unsigned int StandardMIDIExporter::process_chunk_MTrk_SequenceNumber(unsigned char* chunk, unsigned int maxsize, unsigned int number)
    {
        if (chunk != NULL && maxsize >= 6)
        {
            unsigned int ssss = reverse_endian_short(number);

            // <delta-time> <meta-event>
            chunk[0] = 0x00;    // Deltatime
            chunk[1] = 0xFF;    // Meta event
            chunk[2] = 0x00;    // End of track
            chunk[3] = 0x02;    // Length of data
            chunk[4] = 0xFF & (ssss >>  0); // ss
            chunk[5] = 0xFF & (ssss >>  8); // ss
            return 6;
        }
        else
        {
            return 0;
        }
    }

//----------------------------------------------------------------------------------------------
    unsigned int StandardMIDIExporter::process_chunk_MTrk_SequenceName(unsigned char* chunk, unsigned int maxsize, String name)
    {
        if (chunk != NULL && maxsize >= 6)
        {
            const char* c = name.c_str();

            unsigned short length = (unsigned short)strlen(c);

            // <delta-time> <meta-event>
            chunk[0] = 0x00;    // Deltatime
            chunk[1] = 0xFF;    // Meta event
            chunk[2] = 0x03;    // End of track

            unsigned int length_of_len = set_variable_length_quantity(&chunk[3], maxsize-3, length);

            for (unsigned int i=0; i<length && maxsize > 3+length_of_len+i+1; i++)
            {
                chunk[3 + length_of_len + i] = (unsigned char)c[i];
            }

            return 3 + length_of_len + length;
        }
        else
        {
            return 0;
        }
    }

//----------------------------------------------------------------------------------------------
    unsigned int StandardMIDIExporter::set_variable_length_quantity(unsigned char* data, unsigned int max_length, unsigned int quantity)
    {
        std::cout << "Export Delta: " << quantity << std::endl;
        if (data != NULL && max_length >= 5)
        {
            if      (quantity < (1 <<  7))
            {
                data[0] = 0x7F & quantity;
                return 1;
            }
            else if (quantity < (1 << 14))
            {
                data[0] = 0x80 | (0x7F & (quantity >>  7));
                data[1] = 0x00 | (0x7F & (quantity >>  0));
                return 2;
            }
            else if (quantity < (1 << 21))
            {
                data[0] = 0x80 | (0x7F & (quantity >> 14));
                data[1] = 0x80 | (0x7F & (quantity >>  7));
                data[2] = 0x00 | (0x7F & (quantity >>  0));
                return 3;
            }
            else if (quantity < (1 << 28))
            {
                data[0] = 0x80 | (0x7F & (quantity >> 21));
                data[1] = 0x80 | (0x7F & (quantity >> 14));
                data[2] = 0x80 | (0x7F & (quantity >>  7));
                data[3] = 0x00 | (0x7F & (quantity >>  0));
                return 4;
            }
            else
            {
                data[0] = 0x80 | (0x7F & (quantity >> 28));
                data[1] = 0x80 | (0x7F & (quantity >> 21));
                data[2] = 0x80 | (0x7F & (quantity >> 14));
                data[3] = 0x80 | (0x7F & (quantity >>  7));
                data[4] = 0x00 | (0x7F & (quantity >>  0));
                return 5;
            }
        }
        else
        {
            return 0;
        }
    }
}

