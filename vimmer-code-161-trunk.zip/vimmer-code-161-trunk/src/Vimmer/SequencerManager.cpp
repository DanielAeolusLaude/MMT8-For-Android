/*
   Virtual MIDI Multitrack Recorder
   Copyright (c) 2006 MIDI Team

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/

/**
   SequencerManager.cppile SequencerManager.cpp
   Charles Weld, David Wilson, James Brown, Jonathan Van Rossum, and Matthew Harrold
   @brief Declaration of class SequencerManager, part of Virtual MIDI Multitrack Recorder
*/

#include "SequencerManager.hpp"
#include "SequencerModes.hpp"
#include "Events.hpp"


namespace Vimmer
{
    SequencerManager::SequencerManager(MIDIToolkit::Sequencer* sequencer, Store* store)
    {
        // set mode to something invalid to for setMode to fire on the first time.
        mode = -1;

        songSequencer = new SongSequencer(sequencer, store->getSongSystem());
        partSequencer = new PartSequencer(sequencer, store->getPartSystem());

        // default to part mode
        activeSequencer = partSequencer;
        activeSequencer->activate();

        setMode(SequencerModes::PART_MODE);
    }

    SequencerManager::~SequencerManager()
    {
        delete partSequencer;
        delete songSequencer;
    }

    bool SequencerManager::isCountin()
    {
        return activeSequencer->isCountin();
    }

    void SequencerManager::addObserver(Observer* obs)
    {
        Observable::addObserver(obs);

        // also add this subscriber to part sequencer and song sequencer (latter).
        partSequencer->addObserver(obs);

        songSequencer->addObserver(obs);

    }

    int SequencerManager::getMode()
    {
        return mode;
    }

    void SequencerManager::setMode(int mode)
    {
        if(this->mode != mode)
        {
            this->mode = mode;
            if(mode == SequencerModes::SONG_MODE)
            {
                songSequencer->setEnabled(true);
                partSequencer->setEnabled(false);
                partSequencer->disableObservable();
                songSequencer->enableObservable();
                activeSequencer = songSequencer;
                activeSequencer->activate();

            }
            else if(mode == SequencerModes::PART_MODE)
            {
                songSequencer->disableObservable();
                songSequencer->setEnabled(false);
                partSequencer->enableObservable();
                partSequencer->setEnabled(true);
                activeSequencer = partSequencer;
                activeSequencer->activate();
            }
        }
        raiseEvent(Events::SEQUENCER_MODE_CHANGED);
    }

    void SequencerManager::setLoop(bool loop)
    {
        activeSequencer->setLoop(loop);
    }

    bool SequencerManager::getLoop()
    {
        return activeSequencer->getLoop();
    }

    void SequencerManager::setClickPlay(bool click)
    {
        activeSequencer->setClickPlay(click);
    }

    bool SequencerManager::getClickPlay()
    {
        return activeSequencer->getClickPlay();
    }

    void SequencerManager::setClickRecord(bool click)
    {
        activeSequencer->setClickRecord(click);
    }

    bool SequencerManager::getClickRecord()
    {
        return activeSequencer->getClickRecord();
    }

    void SequencerManager::setClickInterval(int interval)
    {
        activeSequencer->setClickInterval(interval);
    }

    int SequencerManager::getClickInterval()
    {
        return activeSequencer->getClickInterval();
    }

    MIDIToolkit::SequencerStates::SequencerState SequencerManager::getState()
    {
        return activeSequencer->getState();
    }

    void SequencerManager::play()
    {
        activeSequencer->play();
    }

    void SequencerManager::stop()
    {
        activeSequencer->stop();
    }

    void SequencerManager::jump(int beat)
    {
        activeSequencer->jump(beat);
    }

    void SequencerManager::record(bool state)
    {
        activeSequencer->record(state);
    }

    void SequencerManager::setTempo(int tempo)
    {
        activeSequencer->setTempo(tempo);
    }

    int SequencerManager::getTempo()
    {
        return activeSequencer->getTempo();
    }

    int SequencerManager::getBeat()
    {
        return activeSequencer->getBeat();
    }

    int SequencerManager::getLength()
    {
        return activeSequencer->getLength();
    }

    bool SequencerManager::isRecordArmed()
    {
        return activeSequencer->isRecordArmed();
    }

    SongStep& SequencerManager::getActiveStep()
    {
        return activeSequencer->getActiveStep();
    }

    void SequencerManager::setCountin(int count_in)
    {
        activeSequencer->setCountin(count_in);
    }

    int SequencerManager::getCountin()
    {
        return activeSequencer->getCountin();
    }

}
