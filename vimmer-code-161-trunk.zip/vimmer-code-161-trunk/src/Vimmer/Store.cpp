/*
   Virtual MIDI Multitrack Recorder
   Copyright (c) 2006 MIDI Team

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/

/**
   @file   Store.cpp
   @author James Brown, Charles Weld
   @brief  Implementation of the class Store.
*/


#include "Store.hpp"
#include "PartSystem.hpp"
#include "SongSystem.hpp"

namespace Vimmer
{
    Store::Store(int numOfParts, int numOfSongs)
    {
        partSys = new PartSystem(numOfParts);
        songSys = new SongSystem(numOfSongs);
    }

    Store::~Store()
    {
        delete partSys;
        delete songSys;
    }

    PartSystem* Store::getPartSystem()
    {
        return partSys;
    }

    SongSystem* Store::getSongSystem()
    {
        return songSys;
    }

    void Store::clear()
    {
        partSys->clear();
        songSys->clear();
    }

    void Store::addObserver(Observer *observer)
    {
        songSys->addObserver(observer);
        partSys->addObserver(observer);
    }

    void Store::save(String filename)
    {

    }

    void Store::open(String filename)
    {

    }

    void Store::save()
    {

    }

    void Store::open()
    {

    }
}
