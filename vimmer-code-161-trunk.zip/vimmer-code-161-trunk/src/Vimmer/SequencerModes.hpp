/*
   Virtual MIDI Multitrack Recorder
   Copyright (c) 2006 MIDI Team

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/

/**
   @file SequencerModes.hpp
   @author Charles Weld
   @brief Declaration of class SequencerModes, part of Virtual MIDI Multitrack Recorder
*/

#ifndef _SEQUENCERMODES_H
#define _SEQUENCERMODES_H


namespace Vimmer
{
    /**
     * @brief Defines what modes are available to the Sequencer Manger.
     *
     * Defines what modes are available to the Sequencer Manger.
     * @ingroup sequencer
     */
    class SequencerModes
    {
    public:
        /// Represents Song Mode.
        static const int SONG_MODE = 0;

        /// Represents Part Mode.
        static const int PART_MODE = 1;
    };
}

#endif  //_SEQUENCERMODES_H
