/*
   Virtual MIDI Multitrack Recorder
   Copyright (c) 2006 MIDI Team

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/

/**
   Exporter.cppile Exporter.cpp
   Charles Weld, David Wilson, James Brown, Jonathan Van Rossum, and Matthew Harrold
   @brief Declaration of class Exporter, part of Virtual MIDI Multitrack Recorder
*/

#include "Exporter.hpp"
#include "Store.hpp"

#include <iostream>
#include <fstream>

using namespace std;

namespace Vimmer
{
    Exporter::Exporter(Store* store)
    {
        logger = LogManager::getSingleton();
    }

    String Exporter::getFilter()
    {
        return String("");
    }

//----------------------------------------------------------------------------------------------
    void Exporter::fileExportStore (String filename)
    {
        logger->log("Import store feature no supported for this file format ()");
    }

    void Exporter::fileExportSong  (String filename, int songnumber)
    {
        logger->log("Import song feature no supported for this file format ()");
    }

    void Exporter::fileExportPart  (String filename, int partnumber)
    {
        logger->log("Import part feature no supported for this file format ()");
    }

    void Exporter::fileExportTrack (String filename, int partnumber, int tracknumber)
    {
        logger->log("Import track feature no supported for this file format ()");
    }

//----------------------------------------------------------------------------------------------
    int Exporter::savefile(const char* filename, const char* data, int size)
    {
        if (filename == 0)
        {
            //Error.
            return -1;
        }
        else
        {
            // Open the file
            std::ofstream file(filename, ios::out | ios::binary | ios::trunc);

            // Check that open was successful.
            if (file.is_open())
            {
                file.write(data, size);
                file.close();

                // Success
                return 0;
            }
            else
            {
                // Error: The file was not opened.
                return -1;
            }
        }
    }

//----------------------------------------------------------------------------------------------
    void Exporter::advance(unsigned int* index, signed int* remaining_bytes, unsigned int bytes)
    {
        (*index)           += bytes;
        (*remaining_bytes) -= bytes;
    }

//----------------------------------------------------------------------------------------------
    void Exporter::swap(unsigned char* a, unsigned char* b)
    {
        unsigned char temp = *a;
        *a = *b;
        *b = temp;
    }

//----------------------------------------------------------------------------------------------
    unsigned short Exporter::reverse_endian_short(unsigned short little_endian)
    {
        unsigned short big_endian = little_endian;
        unsigned char* c = (unsigned char*)&big_endian;
        swap(&c[0], &c[1]);
        return big_endian;
    }

//----------------------------------------------------------------------------------------------
    unsigned int Exporter::reverse_endian_int(unsigned int little_endian)
    {
        unsigned int big_endian = little_endian;
        unsigned char* c = (unsigned char*)&big_endian;
        swap(&c[0], &c[3]);
        swap(&c[1], &c[2]);
        return big_endian;
    }

//----------------------------------------------------------------------------------------------
    unsigned int Exporter::reverse_endian_24(unsigned int little_endian)
    {
        unsigned int big_endian = little_endian;
        unsigned char* c = (unsigned char*)&big_endian;
        swap(&c[0], &c[2]);
        c[3] = 0;
        return big_endian;
    }

//----------------------------------------------------------------------------------------------
    unsigned short Exporter::convert_from_bcd (unsigned short bcd)
    {
        unsigned short number;
        number  =   bcd & (unsigned short)0x000F;                // BCD NIBBLE 0
        number += ((bcd & (unsigned short)0x00F0) >>  4) *   10; // BCD NIBBLE 1
        number += ((bcd & (unsigned short)0x0F00) >>  8) *  100; // BCD NIBBLE 2
        number += ((bcd & (unsigned short)0xF000) >> 12) * 1000; // BCD NIBBLE 3
        return number;
    }

//----------------------------------------------------------------------------------------------
    unsigned short Exporter::convert_to_bcd   (unsigned short number)
    {
        // Limit to 4 digits.
        if (number > 9999)  number = 9999;

        unsigned short bcd;
        bcd  = ((number /    1) % 10);          // BCD NIBBLE 0
        bcd |= ((number /   10) % 10) << 4;     // BCD NIBBLE 1
        bcd |= ((number /  100) % 10) << 8;     // BCD NIBBLE 2
        bcd |= ((number / 1000) % 10) << 12;    // BCD NIBBLE 3
        return bcd;
    }

//----------------------------------------------------------------------------------------------

    unsigned short Exporter::min(unsigned short a, unsigned short b)  {return ((a<b) ? a : b);}
    unsigned short Exporter::max(unsigned short a, unsigned short b)  {return ((a>b) ? a : b);}

    unsigned int Exporter::min(unsigned int a, unsigned int b)        {return ((a<b) ? a : b);}
    unsigned int Exporter::max(unsigned int a, unsigned int b)        {return ((a>b) ? a : b);}

//----------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------------

}
