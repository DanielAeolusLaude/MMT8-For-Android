/*
   Virtual MIDI Multitrack Recorder
   Copyright (c) 2006 MIDI Team

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/

/**
   @file   SongSystem.hpp
   @author James Brown, Charles Weld
   @brief  Declaration of the class SongSystem.
*/


#ifndef _SONGSYSTEM_H
#define _SONGSYSTEM_H

#include "Song.hpp"
#include "VimmerPrerequisites.hpp"
#include "Observable.hpp"
#include "Observer.hpp"

namespace Vimmer
{
    /** @ingroup    store
     *  @brief      SongSystem acts as a repository for all songs.
     *
     *  OVERVIEW:
     *
     *  SongSystem is a collection of independent Songs (see Song class).
     *  SongSystem provides functions to add and remove stored songs,
     *  and to access any song currently stored.
     *
     *  SongSystem also records what is considered to be the "current" (active)
     *  song.
     *
     *  SongSystem is a subsystem of Store. The song-equivalent to SongSystem
     *  is PartSystem.
     *
     */
    class SongSystem : public Observable, public Observer
    {
    public:

        /** @brief  Constructor; create a SongSystem of a given size.
          * @param  size    Number of Songs to create in this SongSystem.
         */
        SongSystem(int size);

        /** @brief  Destructor.
         */
        virtual ~SongSystem();

        /** @brief  Set the active ("current") Song.
          * @param  index   Number of the new song to activate.
         */
        virtual void setActive(int index);

        /** @brief  Get the active Song.
          * @return         Pointer to the active Song.
         */
        virtual Song* getActive();

        /** @brief  Count the number of Songs in this SongSystem.
          * @return         The number of Songs.
         */
        virtual int count() const;

        /** @brief  Get a particular Song from this SongSystem.
          * @param  index   The number of the Song to get.
          * @return         The pointer to the Song.
         */
        virtual Song* getSong(int index);

        /** @brief  Add a song to this SongSystem.
          * @param  song    Pointer to the Song to add.
          * @note   This Song replaces any that has the same ID.
         */
        virtual void addSong(Song* song);

        /** @brief  Adds an Observer to this SongSystem.
          * @param  observer    Pointer to the observer.
         */
        virtual void addObserver(Observer *observer);

        /** @brief Erases the song system.
         */
        virtual void clear();

        /**
         @brief Removes a specific song from the song system.

         Removes a specific song from the song system this song identified by it's id.

         @param song_id The song's id.
         */
        virtual void removeSong(int song_id);

        /** @brief  Notify the SongSystem of an event.
          * @param  id      ID for the event.
          * @param  params  Pointer to any parameters relevant to the event.
          * @note   This event is also passed to all of the SongSystem's observers.
         */
        virtual void onEvent(int id, void* params);

    private:

        /// @brief  Vector of Songs (pointers).
        SongVector songs;

        /// @brief  Number (index) of the current "active" Song.
        int activeSongIndex;
    };
}

#endif  //_SONGSYSTEM_H
