/*
   Virtual MIDI Multitrack Recorder
   Copyright (c) 2006 MIDI Team

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/

/**
   @file   PartSystem.cpp
   @author James Brown, Charles Weld
   @brief  Implementation of the class PartSystem.
*/


#include "PartSystem.hpp"
#include "Part.hpp"
#include "Events.hpp"
#include <iostream>
using namespace std;
namespace Vimmer
{
    PartSystem::PartSystem(int size)
    {
        activePartIndex = size==0?-1:0;
        parts.resize(size);
        for(int i=0;i<size;++i)
        {
            char buffer [50];
            sprintf (buffer, "Part %i", i);
            String name = buffer;
            parts[i] = new Part(name, i);
            parts[i]->addObserver(this);
        }
    }

    PartSystem::~PartSystem()
    {
        int size = count();
        for(int i=0;i<size;++i)
        {
            delete parts[i];
        }
        parts.clear();
    }

    void PartSystem::setActive(int index)
    {
        if(index >= 0 && index<count())
        {
            activePartIndex=index;
        }
        else
        {
            /// @todo log out of bounds exception.
            activePartIndex = -1;
        }

        this->raiseEvent(Events::ACTIVE_PART_CHANGED,NULL);
    }

    int PartSystem::count()
    {
        return parts.size();
    }

    Part* PartSystem::getActive()
    {
        if(activePartIndex != -1)
        {
            return parts[activePartIndex];
        }
        else
        {
            /// @todo log warning.
            return NULL;
        }
    }

    Part* PartSystem::getPart(int index)
    {
        return parts[index];
    }

    void PartSystem::clear()
    {
        setActive(-1);
        int size = count();
        for(int i=0;i<size;++i)
        {
            delete parts[i];
        }
        parts.clear();
    }

    void PartSystem::addPart(Part* part)
    {
        // set all intermediate parts between the last part and the new part to null.
        int partID = part->getID();
        int size = count();
        if(partID>=size)
        {
            parts.resize(partID+1);
            for(int i=size;i<partID;++i)
            {
                parts[i] = NULL;
            }
        }

        // add the new part.
        parts[partID] = part;
        parts[partID]->addObserver(this);

        // update the active index if necissary.
        if(activePartIndex==-1)
            setActive(partID);

        // fire update
        raiseEvent(Events::ACTIVE_PART_CHANGED);
    }

    void PartSystem::removePart(int index)
    {
        this->disableObservable();

        // update the active index.
        int tmp = activePartIndex;
        if(activePartIndex == index)
            activePartIndex=-1;

        // remove the currently active part.
        Part* p = parts[index];
        PartVector::iterator iter = parts.begin();
        for(int i=0;i<index;++i)
            iter++;

        parts.erase(iter);
        delete p;

        // update the part ids
        for(int i=0;i<parts.size();++i)
        {
            parts[i]->setID(i);
        }

        // update active part index
        if(tmp < parts.size())
            setActive(tmp);
        else
            setActive(tmp-1);

        this->enableObservable();

        // fire update
        raiseEvent(Events::ACTIVE_PART_CHANGED);
    }

    void PartSystem::onEvent(int id, void* params)
    {
        raiseEvent(id, params);
    }
}
