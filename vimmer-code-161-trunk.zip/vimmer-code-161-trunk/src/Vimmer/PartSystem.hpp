/*
   Virtual MIDI Multitrack Recorder
   Copyright (c) 2006 MIDI Team

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/

/**
   @file   PartSystem.hpp
   @author James Brown, Charles Weld
   @brief  Declaration of the class PartSystem.
*/


#ifndef _PARTSYSTEM_H
#define _PARTSYSTEM_H

#include "Part.hpp"
#include "VimmerPrerequisites.hpp"
#include "Observable.hpp"
#include "Observer.hpp"

using namespace MIDIToolkit;

namespace Vimmer
{
    /** @ingroup    store
     *  @brief      PartSystem acts as a repository for all parts.
     *
     *  OVERVIEW:
     *
     *  PartSystem is a collection of independent Parts (see Part class).
     *  PartSystem provides functions to add and remove stored parts,
     *  and to access any part currently stored.
     *
     *  PartSystem also records what is considered to be the "current" (active)
     *  part.
     *
     *  PartSystem is a subsystem of Store. The song-equivalent to PartSystem
     *  is SongSystem.
     *
     */
    class PartSystem : public Observable, public Observer
    {
    public:

        /** @brief  Constructor.
          * @param  size    The number of Parts to create in this PartSystem.
         */
        PartSystem(int size);

        /** @brief  Destructor.
         */
        virtual ~PartSystem();

        /** @brief  Set the active ("current") Part.
          * @param  index   Part number to activate.
         */
        virtual void setActive(int index);

        /** @brief  Count the number of Parts in this PartSystem.
          * @return         The number of Parts.
         */
        virtual int count();

        /** @brief  Get the active Part.
          * @return         Pointer to the active Part.
         */
        virtual Part* getActive();

        /** @brief  Get a particular Part.
          * @param  index   Part number to get.
          * @return         Pointer to this Part, .
         */
        virtual Part* getPart(int index);

        /** @brief  Remove a Part from the PartSystem.
          * @param  index   Part number to remove
          * @note   All Parts after this Part have their number (index) moved down by one.
         */
        virtual void removePart(int index);

        /** @brief  Erase the PartSystem.
         */
        virtual void clear();

        /** @brief  Add a Part to the Part System.
          * @param  part    Pointer to the Part to add.
          * @note   The Part is added to the end of the PartSystem.
         */
        virtual void addPart(Part* part);

        /** @brief  Notify PartSystem of an event.
          * @param  id      ID for the event.
          * @param  params  Pointer to any parameters relevant to the event.
         */
        virtual void onEvent(int id, void* params);

    private:

        /// @brief  Vector of Part (pointers) stored in this PartSystem.
        PartVector parts;

        /// @brief  The number (index) of the current "active" Part.
        int activePartIndex;
    };
}

#endif  //_PARTSYSTEM_H
