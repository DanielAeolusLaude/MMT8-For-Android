/*
   Virtual MIDI Multitrack Recorder
   Copyright (c) 2006 MIDI Team

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/

/**
   @file StringCompress.cpp
   @author Charles Weld
   @brief Declaration of class StringCompress, part of Virtual MIDI Multitrack Recorder
*/

#include <bzlib.h>
#include "StringCompress.hpp"
#include "Exception.hpp"
#include "Exceptions.hpp"

// debugging
#include <iostream>
using namespace std;


namespace Vimmer
{
    StringCompress::StringCompress()
    {
        logger = LogManager::getSingleton();
    }

    StringCompress::StringCompress(const StringCompress& test)
    {
    }

    StringCompress::~StringCompress()
    {
    }

    StringCompress& StringCompress::operator = (const StringCompress& test)
    {
        return *this;
    }

//    String StringCompress::decompress(String filename)
//    {
//        FILE* f;
//        BZFILE* b;
//        int nBuf = 4092;
//        char buf[nBuf];
//        int bzerror;
//        int nWritten;
//        String data="";
//
//        // open file.
//        f = fopen ( filename.c_str(), "r" );
//        if ( !f ) {
//            throw Exception(Exceptions::DECOMPRESSION_FAILED,"Failed to open file.", "String StringCompress::decompress(String filename)");
//        }
//
//        // init decompression algorithm
//        b = BZ2_bzReadOpen ( &bzerror, f, 0, 0, NULL, 0 );
//        if ( bzerror != BZ_OK ) {
//            BZ2_bzReadClose ( &bzerror, b );
//            throw Exception(Exceptions::DECOMPRESSION_FAILED,"Failed to initialize file for decompression.", "String StringCompress::decompress(String filename)");
//        }
//
//        // decompress file and get result
//        bzerror = BZ_OK;
//        while ( bzerror == BZ_OK) {
//            nBuf = BZ2_bzRead ( &bzerror, b, buf, nBuf);
//            if ( bzerror == BZ_OK || bzerror == BZ_STREAM_END ) {
//
//                data.append(buf, nBuf-1);
//            }
//        }
//
//        // clean up
//        if ( bzerror != BZ_STREAM_END ) {
//            BZ2_bzReadClose ( &bzerror, b );
//            throw Exception(Exceptions::DECOMPRESSION_FAILED,"Failed to decompress file.", "String StringCompress::decompress(String filename)");
//        } else {
//            BZ2_bzReadClose ( &bzerror, b );
//        }
//
//        return data;
//    }
//
//    void StringCompress::compress(String filename, String data)
//    {
//        FILE* f;
//        BZFILE* b;
//        int nBuf=4092;
//        char buf[nBuf+100];
//        int bzerror;
//        int nWritten;
//        int begin_index=0;                                                            // starting index
//        int buf_size = (data.size()>begin_index+nBuf ? nBuf : data.size()-begin_index);   // size of buffer
//        cout << "data size: " << data.size() << endl;
//
//        // open file.
//        f = fopen ( filename.c_str(), "w" );
//        if (!f) {
//            throw Exception(Exceptions::COMPRESSION_FAILED,"Failed to open file.", "void StringCompress::compress(String data, String filename)");
//        }
//
//        // prepare write.
//        b = BZ2_bzWriteOpen ( &bzerror, f, 9, 0, 30 );
//        if (bzerror != BZ_OK) {
//            BZ2_bzWriteClose ( &bzerror, b, 0, NULL, NULL );
//            throw Exception(Exceptions::COMPRESSION_FAILED,"Failed to compress data.", "void StringCompress::compress(String data, String filename)");
//        }
//
//        // write file
//        while ( begin_index <= data.size() )
//        {
//            // copy current data into buf and update begin and end.
//            data.copy( buf, buf_size, begin_index );
//
//            // get data to write into buf, and set nBuf appropriately
//            BZ2_bzWrite ( &bzerror, b, buf, buf_size);
//
//            buf[buf_size]='\0';
//            logger->log(buf);
//            cout << "Writing Section: " << begin_index << " to " << (buf_size + begin_index) << "[" << buf_size << "] of " << data.size() << endl;
//
//
//            // update indexs
//            begin_index += nBuf;
//            buf_size = (data.size()>begin_index+nBuf ? nBuf : data.size()-begin_index);
//
//            if (bzerror == BZ_IO_ERROR) {
//                BZ2_bzWriteClose ( &bzerror, b, 0, NULL, NULL );
//                throw Exception(Exceptions::COMPRESSION_FAILED,"Failed to compress data.", "void StringCompress::compress(String data, String filename)");
//            }
//        }
//
//        // close file
//        BZ2_bzWriteClose ( &bzerror, b, 0, NULL, NULL );
//        if (bzerror == BZ_IO_ERROR) {
//            throw Exception(Exceptions::COMPRESSION_FAILED,"Failed to compress data.", "void StringCompress::compress(String data, String filename)");
//        }
//    }


    void StringCompress::compress(String filename, String data)
    {
        unsigned int sourceLen = data.size()+1;
        unsigned int destLen = (unsigned int)(sourceLen*1.01+600);
        char source[sourceLen];
        char dest[destLen];
        data.copy(source, sourceLen);
        source[sourceLen-1]='\0';

        int error = BZ2_bzBuffToBuffCompress(dest, &destLen, source, sourceLen, 9, 0, 30);
        if(error != BZ_OK)
        {
             throw Exception(Exceptions::COMPRESSION_FAILED,"Failed to compress data.", "void StringCompress::compress(String data, String filename)");
        }

        // write data

    }

    String StringCompress::decompress(String filename)
    {
        return "";
    }
}
