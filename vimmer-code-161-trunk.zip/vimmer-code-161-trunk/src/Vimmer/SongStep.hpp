/*
   Virtual MIDI Multitrack Recorder
   Copyright (c) 2006 MIDI Team

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/

/**
   @file   SongStep.hpp
   @author James Brown, Charles Weld
   @brief  Declaration of the class SongStep.
*/


#ifndef _SONGSTEP_H
#define _SONGSTEP_H

#include "MultiTrackLink.hpp"
#include "Part.hpp"

namespace Vimmer
{
    /** @ingroup    store
     *  @brief      A SongStep is a unit step within a Song.
     *
     *  OVERVIEW:
     *
     *  A song (see Song class) is a list of SongSteps, each of which is played
     *  sequentially. Each SongStep represents a particular part (see Part class),
     *  and its position within that song.
     *
     *  SongStep extends upon MultiTrackLink (see MIDIToolkit::MultiTrackLink).
     *
     *  PARTS:
     *
     *  A Part can appear in more than one Song, or no Songs at all. Each
     *  different "instance" of the same Part is represented by a different
     *  SongStep. Note that the same part can also appear multiple times within
     *  the same song, and each time is represented by a different SongStep.
     *
     *  Parts can be added to, removed from, and moved within any number of songs;
     *  by adding, removing, and moving the SongSteps. At no time is the actual
     *  Part itself modified by these operations.
     *
     *  DATA:
     *
     *  Each SongStep contains other information relevant to each part within
     *  a Song, but which is not relevant to the Song itself. The SongStep stores
     *  information about the state of each Track within the Part, such as whether
     *  it is enabled or disabled (muted). This information can be different for
     *  different SongSteps that refer to the same Part.
     *
     */
    class SongStep : public MultiTrackLink
    {
    public:
        /** @brief  Constructor; link the SongStep to a particular Part.
          * @param  p   Pointer to the Part.
         */
        SongStep(Part* p = NULL);

        /** @brief  Constructor; make a copy of another SongStep.
          * @param  step    SongStep to copy.
         */
        SongStep(const SongStep& step);

        /** @brief  Destructor.
         */
        virtual ~SongStep();

        /** @brief  Copy another SongStep to this one.
          * @param  step    SongStep to copy.
         */
        virtual SongStep& operator = (const SongStep& step);

        /** @brief  Set the Part this SongStep links to.
          * @param  part    Pointer to the Part.
         */
        virtual void setPart(Part* part);

        /** @brief  Get the Part currently linked to.
          * @return         Pointer to the Part.
         */
        virtual Part* getPart();

    };
}

#endif  //_SONGSTEP_H
