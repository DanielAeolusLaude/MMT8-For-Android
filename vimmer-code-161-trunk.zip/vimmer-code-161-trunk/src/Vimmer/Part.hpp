/*
   Virtual MIDI Multitrack Recorder
   Copyright (c) 2006 MIDI Team

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/

/**
   @file   Part.hpp
   @author James Brown, Charles Weld
   @brief  Declaration of the class Part.
*/


#ifndef _PART_H
#define _PART_H

#include "MultiTrack.hpp"

using namespace MIDIToolkit;

namespace Vimmer
{
    /** @ingroup    store
     *  @brief      Part contains a group of Tracks that are played simultaneously.
     *
     *  OVERVIEW:
     *
     *  Part extends upon the MultiTrack class. (See MIDIToolkit::MultiTrack class).
     *
     *  EDITING:
     *
     *  The Part also provides various editing functions, through its base class.
     *  These include:
     *
     *      - Erase
     *      - Copy
     *      - Merge
     *      - Quantize
     *      - Transpose
     *
     *  OTHER DATA:
     *
     *  Each Part has a numeric ID, and a name. The ID is used to identify the
     *  Part (see PartSystem class). The name is for user convenience only.
     *
     *  MISCELLANEOUS:
     *
     *  Part has no knowledge of the current state of any sequencer. It does not
     *  know whether or not it is active or being played (see PartSystem class).
     *  It also has no knowledge of the playing status of its Tracks (see
     *  SongStep class).
     *
     */
    class Part : public MultiTrack
    {
    public:

        /** @brief  Constructor.
          * @param  name    Name of this Part.
          * @param  id      ID of this Part.
         */
        Part(String name, int id);

        /** @brief  Destructor.
         */
        virtual ~Part();

        /** @brief  Get the name of this Part.
          * @return     The name.
         */
        virtual String getName();

        /** @brief  Set the name of this Part.
          * @param  name    The new name for this Part.
         */
        virtual void setName(String name);

        /** @brief  Get the ID of this Part.
          * @return     The ID.
         */
        virtual int getID();

        /** @brief  Set the ID of this Part.
          * @param  id      The new ID for this Part.
         */
        virtual void setID(int id);

        /** @brief  Append another Part to the end of this Part.
          * @todo   This function is not yet implemented.
          * @param  part    The source Part to add.
          * @param  tracks  Mark which Tracks are to be appended.
         */
        virtual void append(Part part, bool tracks[8]);

    protected:

        /// @brief  Part Name.
        String name;

        /// @brief  Part ID.
        int id;
    };
}

#endif  //_PART_H
