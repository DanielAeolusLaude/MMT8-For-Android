/*
   Virtual MIDI Multitrack Recorder
   Copyright (c) 2006 MIDI Team

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/

/**
   @file ISequencer.hpp
   @author Charles Weld
   @brief Declaration of class ISequencer, part of Virtual MIDI Multitrack Recorder
*/

#ifndef _ISEQUENCER_H
#define _ISEQUENCER_H

#include "VimmerPrerequisites.hpp"
#include "SequencerStates.hpp"

namespace Vimmer
{
    /// Represents the concept of a Sequencer.
    /**
     * A Sequencer is a device that can record and playback data (in this case MIDI Events),
     * and therefore must have support for a number of operations/commands such as play, arming,
     * record, etc.
     * @ingroup sequencer
     */
    class ISequencer
    {
    public:
        /**
         * Destructor.
         */
        virtual ~ISequencer(){}

        /**
         * Gets the state of the sequencer, ie if it's playing, stopped, or recording.
         * @return The sequencer's state.
         */
        virtual MIDIToolkit::SequencerStates::SequencerState getState()=0;

        /// Activates the sequencer.
        /**
         * This allows this sequencer to take control of the actual MIDIToolkit Sequencer
         * @see MIDIToolkit::Sequencer and therefore one MIDIToolkit Sequencer can be used
         * by multiple Vimmer Sequencers.
         */
        virtual void activate() = 0;

        /**
         * Start playing MIDI Events.
         */
        virtual void play()=0;

        /**
         * Stop playing MIDI Events.
         */
        virtual void stop()=0;

        /**
         * Sets whether the sequencer will record incomming MIDI Events.
         * @param state The new recording state of the sequencer.
         */
        virtual void record(bool state)=0;

        /**
         * Get's whether or not recording is armed.
         * @return The recording state of the sequencer.
         */
        virtual bool isRecordArmed()=0;

        /**
         * Jumps to a specific beat.
         * @param beat The beat to jump to.
         */
        virtual void jump(int beat)=0;

        /**
         * Gets the current beat that the sequencer's playing.
         * @return The current beat.
         */
        virtual int getBeat() = 0;

        /**
         * Gets the length of the musical piece.
         * @return The length in beats.
         */
        virtual int getLength() = 0;

        /**
         * Sets the tempo of the sequencer.
         * @param tempo The new tempo of the sequencer.
         */
        virtual void setTempo(int tempo)=0;

        /**
         * Gets the tempo of the sequencer.
         * @return The sequencers tempo.
         */
        virtual int getTempo()=0;

        /**
         * Sets whether or not the sequencer will replay the current peice when it gets to the end,
         * ie loop.
         * @param loop whether or not the sequencer will loop back to the beginning of the musical piece.
         */
        virtual void setLoop(bool loop)=0;

        /**
         * Gets whether or not the sequencer is set to replay the current peice when it gets to the end (loop).
         * @return The loop state.
         */
        virtual bool getLoop()=0;

        /**
         * Gets the active step of the sequencer (ie what part it's currently playing).
         * @return The current step.
         */
        virtual SongStep& getActiveStep()=0;

        /**
         * Sets the play click state of the sequencer.
         * The play click state determines whether or not the sequencer will play a click track
         * when its playing back MIDI Events.
         * @param click The new click state.
         */
        virtual void setClickPlay(bool click)=0;

        /**
         * Gets the play click state of the sequencer
         * @return The play click state of the sequencer.
         */
        virtual bool getClickPlay()=0;

        /**
         * Sets the record click state of the sequencer.
         * The record click state determines whether or not the sequencer will play a click track
         * when its recording MIDI Events.
         * @param click The new click state.
         */
        virtual void setClickRecord(bool click)=0;

        /**
         * Gets the record click state of the sequencer.
         * @return The record click state of the sequencer.
         */
        virtual bool getClickRecord()=0;

        /// Sets the click interval of the sequencer.
        /**
         * The Click Interval is how fast the click is and
         * has a number of different values these are
         * 1/2, 1/4, 1/8, 1/16, 1/24, 1/32, 1/48, 1/64.
         * @param interval The Click Interval of the sequencer, note that this is actually the denominator of the real interval (ie for the interval 1/4 the interval is 4).
         */
        virtual void setClickInterval(int interval)=0;

        /**
         * Gets the Click Interval of the sequencer.
         * @return The click interval.
         */
        virtual int getClickInterval()=0;

        /**
         * Sets how many beats to count in.
         * @param count_in The number of beats.
         */
        virtual void setCountin(int count_in)=0;

        /**
         * Gets how many beats to count in.
         * @return The number of beats.
         */
        virtual int getCountin()=0;

        /**
         * Gets whether or not the sequencer is playing the count in part, or a real part.
         * @return True if the sequencer is playing the count in, otherwise false.
         */
        virtual bool isCountin() = 0;
    };
}

#endif  //_PARTSEQUENCER_H
