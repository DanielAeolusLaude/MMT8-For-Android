/*
   Virtual MIDI Multitrack Recorder
   Copyright (c) 2006 MIDI Team

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA and Charles Weld
*/

/**
   @file SongSequencer.cpp
   @author James Brown
   @brief Declaration of class SongSequencer, part of Virtual MIDI Multitrack Recorder
*/

#include "SongSequencer.hpp"
#include "SongSystem.hpp"
#include "Events.hpp"
#include "Exceptions.hpp"
#include "Exception.hpp"

#include <iostream>
using namespace std;

using namespace MIDIToolkit;

namespace Vimmer
{
    SongSequencer::SongSequencer(MIDIToolkit::Sequencer* sequencer, SongSystem* songSystem)
    {
        this->sequencer = sequencer;
        this->songSystem = songSystem;

        // add this to sequencer event handlers
        songSystem->addObserver(this);
        sequencer->addObserver(this);
        if(songSystem->getActive()!=NULL)
            iterator = songSystem->getActive()->getIteratorBegin();

        // countin
        m_CountinPart = new Part("",0);
        m_CountinPart->setLength(4);
        m_Step = new SongStep(m_CountinPart);
        m_PlayingClick = false;

        setLoop(false);
        setEnabled(false);
    }

    SongSequencer::~SongSequencer()
    {
        delete m_CountinPart;
        delete m_Step;
    }

    MIDIToolkit::SequencerStates::SequencerState SongSequencer::getState()
    {
        return sequencer->getState();
    }

    void SongSequencer::play()
    {
        if(songSystem->getActive() != NULL && !songSystem->getActive()->isEmpty())
        {
            if(!m_PlayingClick && sequencer->getClickPlay())
            {
                m_PlayingClick=true;
                sequencer->setMultiTrackLink(m_Step);
            }

            sequencer->setRecordArmed(false);
            sequencer->play();

            raiseEvent(Events::SEQUENCER_STATE_CHANGED);
        }
    }

    void SongSequencer::stop()
    {
        if(songSystem->getActive() != NULL && !songSystem->getActive()->isEmpty())
        {
            sequencer->stop();
            raiseEvent(Events::SEQUENCER_STATE_CHANGED);
        }
    }

    void SongSequencer::record(bool state)
    {
        // not implemented.
    }

    bool SongSequencer::isRecordArmed()
    {
        return false;
    }

    void SongSequencer::jump(int beat)
    {
        if(beat==0)
            m_PlayingClick=false;

        if(songSystem->getActive() != NULL && !songSystem->getActive()->isEmpty() && beat >= 0 && beat <= getLength())
        {
            // get what state the sequencer is in.
            int curState = sequencer->getState();

            // find part that we reside in
            SongStepIterator iter = songSystem->getActive()->getIteratorBegin();
            SongStepIterator end_iterator = songSystem->getActive()->getIteratorEnd();
            while( iter != end_iterator && (*iter)->getPart()->getLength() != 0 && beat > (*iter)->getPart()->getLength() )
            {
                beat -= (*iter)->getPart()->getLength();
                iter++;
            }

            // if the part the beat resides in isn't the currently playing part stop and move sequencer to this part.
            if( iter!=end_iterator && (*iter)->getPart() != (*iterator)->getPart() )
            {
                iterator = iter;
                sequencer->setMultiTrackLink(*iterator);
            }
            else if( iter==end_iterator )
            {
                iter--;
                sequencer->setMultiTrackLink(*iter);
            }

            // jump to correct beat
            sequencer->jump(beat);

            // make sure we're playing if we where originally
            if(curState != SequencerStates::STOPPED)
            {
                sequencer->play();
            }
        }
    }

    void SongSequencer::activate()
    {
        if(songSystem->getActive() != NULL && !songSystem->getActive()->isEmpty())
        {
            sequencer->setMultiTrackLink(*iterator);
        }
        raiseEvent(Events::SONG_CONTENT_CHANGED, getSong());
        int beat = getBeat();
        raiseEvent(Events::SEQUENCER_BEAT_UPDATE, &beat);

    }

    void SongSequencer::setActiveStep(SongStep& s)
    {
        if(songSystem->getActive() != NULL)
        {
            //Song* song = songSystem->getActive();
            SongStepIterator begin_iterator = songSystem->getActive()->getIteratorBegin();
            SongStepIterator end_iterator = songSystem->getActive()->getIteratorEnd();

            SongStepIterator i = begin_iterator;

            while (i != end_iterator && *i != &s)
            {
                i++;
            }

            if (*i == &s)
            {
                iterator = i;
                sequencer->setMultiTrackLink(*iterator);
            }
            else
            {
                sequencer->setMultiTrackLink(NULL);
            }

            raiseEvent(Events::SONG_CONTENT_CHANGED, getSong());
        }
    }

    SongStep& SongSequencer::getActiveStep()
    {
        if(songSystem->getActive() == NULL || songSystem->getActive()->isEmpty())
        {
            throw Exception(Exceptions::SEQUENCER_FAIL, "Couldn't get active step (doesn't exist).", "SongStep& SongSequencer::getActiveStep()");
        }
        return *(*iterator);
    }

    void SongSequencer::setTempo(int tempo)
    {
        if(songSystem->getActive() != NULL && !songSystem->getActive()->isEmpty())
        {
            sequencer->setTempo(tempo);
            getSong()->setTempo(tempo);
        }
    }

    int SongSequencer::getTempo()
    {
        return sequencer->getTempo();
    }

    void SongSequencer::setClickPlay(bool click)
    {
        if(songSystem->getActive() != NULL)
        {
            sequencer->setClickPlay(click);

            // update song sequencers state
            if(m_PlayingClick)
            {
                m_PlayingClick = false;
                int state = sequencer->getState();
                if(!getSong()->isEmpty())
                {
                    sequencer->setMultiTrackLink(*iterator);
                    if(state!=SequencerStates::STOPPED)
                        sequencer->play();


                    raiseEvent(Events::SEQUENCER_STATE_CHANGED);
                }
                else
                {
                     sequencer->setMultiTrackLink(NULL);
                }
            }
        }
    }

    bool SongSequencer::getClickPlay()
    {
        return sequencer->getClickPlay();
    }

    void SongSequencer::setClickInterval(int interval)
    {
        sequencer->setClickInterval(interval);
    }

    int SongSequencer::getClickInterval()
    {
        return sequencer->getClickInterval();
    }

    void SongSequencer::setCountin(int count_in)
    {
        m_CountinPart->setLength(count_in);
    }

    int SongSequencer::getCountin()
    {
        return m_CountinPart->getLength();
    }

    void SongSequencer::setClickRecord(bool click)
    {
    }

    bool SongSequencer::getClickRecord()
    {
        return false;
    }

    void SongSequencer::onEvent(int id, void* params)
    {
        // these only fire when enabled
        if(getEnabled())
        {
            switch(id)
            {
                case(Events::SEQUENCER_STOPPED):
                {
                    //raiseEvent(Events::SEQUENCER_STATE_CHANGED, params);
                    break;
                }
                case(Events::SEQUENCER_PLAYING):
                {
                    //raiseEvent(Events::SEQUENCER_STATE_CHANGED, params);
                    break;
                }
                case(Events::SEQUENCER_BEAT_UPDATE):
                {
                    int beat = getBeat();
                    raiseEvent(Events::SEQUENCER_BEAT_UPDATE, &beat);
                    break;
                }
                case(Events::SEQUENCER_MULTITRACK_END):
                {
                    if(songSystem->getActive() != NULL)
                    {
                        if(m_PlayingClick && sequencer->getClickPlay())
                        {
                            m_PlayingClick=false;
                            sequencer->setMultiTrackLink(*iterator);
                            sequencer->play();
                        }
                        else
                        {
                            SongStepIterator iter = iterator;
                            iter++;
                            if(iter != songSystem->getActive()->getIteratorEnd())
                            {
                                iterator++;
                                sequencer->setMultiTrackLink(*iterator);
                                sequencer->play();
                                raiseEvent(Events::SONG_CONTENT_CHANGED, this);
                            }
                            else if(getLoop())
                            {
                                iterator = songSystem->getActive()->getIteratorBegin();
                                sequencer->setMultiTrackLink(*iterator);
                                sequencer->play();
                            }
                            else
                            {
                                m_PlayingClick=false;
                            }
                        }
                    }
                    break;
                }
                case(Events::SEQUENCER_ACTIVITY_MIDI_IN):
                {
                    break;
                }
                case(Events::SEQUENCER_ACTIVITY_MIDI_OUT):
                {
                    break;
                }
                default:
                {
                    // forward all others on;
                    raiseEvent(id, params);
                }
            }
        }

        // these always fire
        switch(id)
        {
            case (Events::ACTIVE_SONG_CHANGED):
            {
                if(songSystem->getActive() != NULL)
                {
                    iterator = songSystem->getActive()->getIteratorBegin();
                    sequencer->setTempo(getSong()->getTempo());
                }
                break;
            }
        }
    }

    void SongSequencer::setLoop(bool loop)
    {
        m_Loop = loop;
        raiseEvent(Events::SEQUENCER_LOOP_CHANGED);
    }

    bool SongSequencer::getLoop()
    {
        return m_Loop;
    }

    // I'm adding my editing function here don't add / remove anything bellow this comment.
    void SongSequencer::addSong()
    {
        Song* song = new Song("New Song", songSystem->count());
        songSystem->addSong(song);
    }

    void SongSequencer::removeSong()
    {
        if(songSystem->getActive())
        {
            sequencer->stop();
            songSystem->removeSong(songSystem->getActive()->getID());
        }
    }


    void SongSequencer::SongSequencer::addStep(Part* part)
    {
        if(songSystem->getActive() != NULL && songSystem->getActive()->isEmpty())
        {
            this->disableObserver();
            songSystem->getActive()->add(part);
            iterator = getSong()->getIteratorBegin();
            activate();
            this->enableObserver();
        }
        else if(songSystem->getActive() != NULL)
        {
            songSystem->getActive()->add(part);
        }

        raiseEvent(Events::SONG_CONTENT_CHANGED, getSong());
    }

    void SongSequencer::removeStep(SongStepIterator loc)
    {
        if(songSystem->getActive() != NULL)
        {
            // get part
            this->disableObserver();

            SongStep* step = (*loc);
            Part* part = step->getPart();
            int curState = getState();
            if(part == sequencer->getMultiTrackLink()->getLink())
            {
                SongStepIterator iter = iterator;
                iter++;
                if(iterator!= getSong()->getIteratorBegin() && iter==getSong()->getIteratorEnd())
                {
                    iterator--;
                    sequencer->setMultiTrackLink(*iterator);
                }
                else if(iter!=getSong()->getIteratorEnd())
                {
                    iterator++;
                    sequencer->setMultiTrackLink(*iterator);
                }
                else
                {
                    sequencer->setMultiTrackLink(NULL);
                    iterator=getSong()->getIteratorBegin();
                }
                //if(getSong()->())
            }
            getSong()->remove(loc);
            if(curState != SequencerStates::STOPPED)
                sequencer->play();

            this->enableObserver();
            raiseEvent(Events::SONG_CONTENT_CHANGED, getSong());
        }
    }

    int SongSequencer::getBeat()
    {
        int beat=0;
        if(songSystem->getActive() != NULL)
        {
            SongStepIterator iter = songSystem->getActive()->getIteratorBegin();
            SongStepIterator end_iterator = songSystem->getActive()->getIteratorEnd();
            while( iter != end_iterator && (*iter) != (*iterator) )
            {
                beat += (*iter)->getPart()->getLength();
                iter++;
            }
            beat += sequencer->getBeat();
        }
        return beat;

    }

    int SongSequencer::getLength()
    {
        if(m_PlayingClick)
        {
            return m_CountinPart->getLength();
        }
        else if(songSystem->getActive() != NULL)
        {
            int beat=0;
            SongStepIterator iter = songSystem->getActive()->getIteratorBegin();
            SongStepIterator end_iterator = songSystem->getActive()->getIteratorEnd();
            while(iter != end_iterator)
            {
                beat += (*iter)->getPart()->getLength();
                iter++;
            }
            return beat;
        }
        return 0;
    }

    void SongSequencer::clear()
    {
        if(songSystem->getActive() != NULL && !songSystem->getActive()->isEmpty())
        {
            sequencer->stop();
            sequencer->setMultiTrackLink(NULL);
            songSystem->getActive()->clear();
        }
    }

    void SongSequencer::moveStep(SongStepIterator source, SongStepIterator dest)
    {
        if(songSystem->getActive() != NULL && !songSystem->getActive()->isEmpty())
        {
            if(source!=getSong()->getIteratorEnd())
            {
                getSong()->disableObservable();
                int state = getState();
                stop();

                // remove source from song
                SongStep* step = new SongStep(*(*source));
                removeStep(source);

                // insert source into song at just before dest.
                iterator = getSong()->insert(dest, step);

                // update currently playing index
                setActiveStep(*step);

                // start playing again (if we where)
                if(state != SequencerStates::STOPPED)
                    play();
                getSong()->enableObservable();

                // update song
                bool ob = isObservableEnabled();
                enableObservable();
                raiseEvent(Events::SONG_CONTENT_CHANGED, getSong());
                if(!ob)
                    disableObservable();

                // update pos
                int beat = getBeat();
                raiseEvent(Events::SEQUENCER_BEAT_UPDATE, &beat);
            }
        }
    }

    bool SongSequencer::isCountin()
    {
        return m_PlayingClick;
    }

    void SongSequencer::setActiveSong(int i)
    {
        // for now we just change the active song.
        songSystem->setActive(i);
        if(getSong()!=NULL)
            iterator = getSong()->getIteratorBegin();
        activate();
    }

    Song* SongSequencer::getSong()
    {
        return songSystem->getActive();
    }

    void SongSequencer::setEnabled(bool enable)
    {
        m_Enabled = enable;
    }

    bool SongSequencer::getEnabled()
    {
        return m_Enabled;
    }
}


