/*
   Virtual MIDI Multitrack Recorder
   Copyright (c) 2006 MIDI Team

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/

/**
   @file   SongSystem.cpp
   @author James Brown, Charles Weld
   @brief  Implementation of the class SongSystem.
*/


#include "SongSystem.hpp"
#include "Song.hpp"
#include "Events.hpp"

namespace Vimmer
{
    SongSystem::SongSystem(int size)
    {
        activeSongIndex = size==0?-1:0;
        songs.resize(size);
        for (int i=0;i<size;++i)
        {
            char buffer [50];
            sprintf (buffer, "Song %i", i);
            songs[i] = new Song(buffer, i);
            songs[i]->addObserver(this);
        }
    }

    SongSystem::~SongSystem()
    {
        int size = count();
        for (int i=0;i<size;++i)
        {
            delete songs[i];
        }
        songs.clear();
    }

    void SongSystem::setActive(int index)
    {
        if (index >= 0 && index<count())
        {
            activeSongIndex = index;
            raiseEvent(Events::ACTIVE_SONG_CHANGED,getActive());
        }
        else
        {
            /// @todo log out of bounds exception.
            activeSongIndex = -1;
        }
    }

    void SongSystem::addObserver(Observer *observer)
    {
        Observable::addObserver(observer);
    }

    Song* SongSystem::getActive()
    {
        if (activeSongIndex != -1)
        {
            return songs[activeSongIndex];
        }
        else
        {
            /// @todo log warning
            return NULL;
        }
    }

    int SongSystem::count() const
    {
        return songs.size();
    }

    Song* SongSystem::getSong(int index)
    {
        if (index >= 0 && index<count())
        {
            return songs[index];
        }
        else
        {
            /// @todo log warning
            return NULL;
        }
    }

    void SongSystem::clear()
    {
        setActive(-1);
        int size = count();
        for (int i=0;i<size;++i)
        {
            delete songs[i];
        }
        songs.clear();

        raiseEvent(Events::ACTIVE_SONG_CHANGED);
        raiseEvent(Events::SONG_CONTENT_CHANGED, NULL);
    }

    void SongSystem::addSong(Song* song)
    {
        disableObservable();

        int songID = song->getID();
        int size = count();
        if (songID>=size)
        {
            songs.resize(songID+1);
            for (int i=size;i<songID;++i)
            {
                songs[i] = NULL;
            }
        }
        songs[songID] = song;
        song->addObserver(this);

        // update the active index if necissary.
        if(activeSongIndex==-1)
            setActive(songID);

        enableObservable();

        raiseEvent(Events::ACTIVE_SONG_CHANGED);
        raiseEvent(Events::SONG_CONTENT_CHANGED, songs[songID]);
    }

    void SongSystem::removeSong(int index)
    {
        this->disableObservable();

        // update the active index.
        unsigned int tmp = activeSongIndex;
        if(activeSongIndex == index)
            activeSongIndex=-1;

        // remove the currently active part.
        Song* p = songs[index];
        SongVector::iterator iter = songs.begin();
        for(int i=0;i<index;++i)
            iter++;

        songs.erase(iter);
        delete p;

        // update the part ids
        for(int i=0;i<songs.size();++i)
        {
            songs[i]->setID(i);
        }

        // update active part index
        if(tmp < songs.size())
            setActive(tmp);
        else
            setActive(tmp-1);

        this->enableObservable();

        // fire update
        raiseEvent(Events::ACTIVE_SONG_CHANGED);
    }

    void SongSystem::onEvent(int id, void* params)
    {
        // for now just forward on events.
        raiseEvent(id, params);
    }
}
