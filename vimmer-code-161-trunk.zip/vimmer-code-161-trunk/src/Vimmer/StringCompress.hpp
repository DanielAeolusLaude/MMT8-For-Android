/*
   Virtual MIDI Multitrack Recorder
   Copyright (c) 2006 MIDI Team

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/

/**
   Plugin.hppile Plugin.hpp
   Charles Weld, David Wilson, James Brown, Jonathan Van Rossum, and Matthew Harrold
   @brief Declaration of class Plugin, part of Virtual MIDI Multitrack Recorder
*/

#ifndef _StringCompress_H
#define _StringCompress_H

#include "VimmerPrerequisites.hpp"
#include "LogManager.hpp"
#include "Log.hpp"

using namespace MIDIToolkit;

namespace Vimmer
{
    /**
    @class StringCompress

    @ingroup misc

    @todo Function to compress a String type
    */

    class StringCompress
    {
    public:
        StringCompress();

        /**
         @brief Function to compress a Dereferenced String type.

         Function to compress a Dereferenced String type.

         @param Dereference a const String
         @return dereferenced pointer.
        */
        StringCompress(const StringCompress& test);

        /**
         @brief Destructor.

         Destructor.
        */
        ~StringCompress();

        /**
         @brief Dereference a pointer to a String type

         Dereference a pointer to a String type

         @param Dereference a const String
         @return a pointer.
        */
        StringCompress& operator = (const StringCompress& test);

        /**
         @brief Function call to compress specific String.

         Function call to compress specific String.

         @param String containing filename
         @param String containing data
         @return This compressed String.
        */
        void compress(String filename, String data);

        /**
         @brief Function to decompress a specific String.

         Function to decompress a specific String.

         @param String containing filename
         @return This decompressed String.
        */
        String decompress(String filename);
    private:
        LogManager* logger;
    };
}

#endif
