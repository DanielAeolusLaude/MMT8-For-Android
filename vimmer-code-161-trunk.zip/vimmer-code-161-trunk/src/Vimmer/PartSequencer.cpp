/*
   Virtual MIDI Multitrack Recorder
   Copyright (c) 2006 MIDI Team

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/

/**
   PartSequencer.cppile PartSequencer.cpp
   Charles Weld, David Wilson, James Brown, Jonathan Van Rossum, and Matthew Harrold
   @brief Declaration of class PartSequencer, part of Virtual MIDI Multitrack Recorder
*/

#include "PartSequencer.hpp"
#include "PartSystem.hpp"
#include "Events.hpp"
#include "SequencerStates.hpp"
#include <iostream>

using namespace std;

namespace Vimmer
{
    PartSequencer::PartSequencer(MIDIToolkit::Sequencer* sequencer, PartSystem* partSystem)
    {
        this->partSystem = partSystem;
        this->sequencer = sequencer;
        partLink = new SongStep(partSystem->getActive());

        // countin
        m_CountinPart = new Part("",-1);
        m_CountinPart->setLength(4);
        m_Step = new SongStep(m_CountinPart);

        // event handling linkage
        partSystem->addObserver(this);
        sequencer->addObserver(this);

        setLoop(false);
        setEnabled(false);
        m_PlayingClick = false;
        m_Record = sequencer->isRecordArmed();
        m_Tempo = 120;
    }

    PartSequencer::~PartSequencer()
    {
        delete partLink;
        delete m_CountinPart;
        delete m_Step;
    }

    MIDIToolkit::SequencerStates::SequencerState PartSequencer::getState()
    {
        MIDIToolkit::SequencerStates::SequencerState state = sequencer->getState();
        if(state == SequencerStates::PLAYING && m_Record)
        {
            state = SequencerStates::RECORDING;
        }
        return state;
    }

    void PartSequencer::activate()
    {
        int s = getState();
        sequencer->stop();
        sequencer->setTempo(m_Tempo);
        partLink->setPart(partSystem->getActive());
        if(partLink->getLink()!=NULL)
        {
            sequencer->setMultiTrackLink(partLink);
            if(s != SequencerStates::STOPPED)
            {
                play();
            }
        }
    }

    void PartSequencer::play()
    {
        if(partLink->getLink()!=NULL)
        {
            int s = getState();
            if(!m_PlayingClick && sequencer->getClickPlay() && !sequencer->isRecordArmed() && getBeat()==0)
            {
                // Sequencer will be PLAYING
                m_PlayingClick=true;
                sequencer->setMultiTrackLink(m_Step);
                m_Record = sequencer->isRecordArmed();
                sequencer->setRecordArmed(false);
            }
            else if(!m_PlayingClick && sequencer->getClickRecord() && sequencer->isRecordArmed() && getBeat()==0)
            {
                /// Added by JVR 21\11\2006
                /*
                    Set the countin part to have the same tracks recording
                    as the actual part. Any events recorded onto the countin
                    part go to the first beat of the actual part.
                */
                if (m_Step!=NULL && partLink!=NULL)
                {
                    Part* p1 = m_Step->getPart();
                    Part* p2 = partLink->getPart();
                    for (unsigned int i=0; (p1!=NULL && p2!=NULL && i<p1->count() && i<p2->count()); i++)
                    {
                        if (partLink->isRecording(i))
                        {
                            m_Step->setTrackState(i, MultiTrackLink::TRACK_STATE_RECORD);
                        }
                    }
                }

                // Sequencer will be RECORDING
                m_PlayingClick=true;
                sequencer->setMultiTrackLink(m_Step);
                m_Record = sequencer->isRecordArmed();
                sequencer->setRecordArmed(true);        /// Modified by JVR 21\11\2006
            }
            else
            {
                sequencer->setRecordArmed(m_Record);
            }

            sequencer->play();
            if(s==SequencerStates::STOPPED)
                raiseEvent(Events::SEQUENCER_STATE_CHANGED);

            int beat = getBeat();
            raiseEvent(Events::SEQUENCER_BEAT_UPDATE, &beat);
        }
    }

    void PartSequencer::stop()
    {
        if(partLink->getLink()!=NULL)
        {
            int s = getState();
            sequencer->stop();
            if(s != SequencerStates::STOPPED)
                raiseEvent(Events::SEQUENCER_STATE_CHANGED);
        }
    }

    void PartSequencer::record(bool state)
    {
        if(partLink->getLink()!=NULL)
        {
           // bool rec = m_Record;
            int s = getState();

            if(!m_PlayingClick)
            {
                sequencer->setRecordArmed(state);
            }

            m_Record = state;

            if(s!=getState())
                raiseEvent(Events::SEQUENCER_STATE_CHANGED);
        }
    }

    bool PartSequencer::isRecordArmed()
    {
        return m_Record;
    }

    void PartSequencer::jump(int beat)
    {
        if(partLink->getLink()!=NULL)
        {
            sequencer->jump(beat);
            if(beat==0)
                m_PlayingClick=false;
        }
    }

    SongStep& PartSequencer::getActiveStep()
    {
        return *partLink;
    }

    int PartSequencer::getBeat()
    {
        return sequencer->getBeat();
    }

    int PartSequencer::getLength()
    {
        if(partLink->getLink()!=NULL)
        {
            if(m_PlayingClick)
                return m_CountinPart->getLength();
            else
                return partLink->getPart()->getLength();
        }
        else
        {
            return 0;
        }
    }

    void PartSequencer::setTempo(int tempo)
    {
        sequencer->setTempo(tempo);
        m_Tempo = tempo;
    }

    int PartSequencer::getTempo()
    {
        return sequencer->getTempo();
    }

    void PartSequencer::setClickPlay(bool click)
    {
        sequencer->setClickPlay(click);

        if(partLink->getLink()!=NULL)
        {
            // update song sequencers state
            if(m_PlayingClick)
            {
                m_PlayingClick = false;
                int state = sequencer->getState();
                sequencer->setMultiTrackLink(partLink);
                if(state!=SequencerStates::STOPPED)
                    sequencer->play();

                raiseEvent(Events::SEQUENCER_STATE_CHANGED);
            }
        }
    }

    bool PartSequencer::getClickPlay()
    {
        return sequencer->getClickPlay();
    }

    void PartSequencer::setClickRecord(bool click)
    {
        sequencer->setClickRecord(click);

        if(partLink->getLink()!=NULL)
        {
            // update song sequencers state
            if(m_PlayingClick)
            {
                m_PlayingClick = false;
                int state = sequencer->getState();
                sequencer->setMultiTrackLink(partLink);
                if(state!=SequencerStates::STOPPED)
                    sequencer->play();

                raiseEvent(Events::SEQUENCER_STATE_CHANGED);
            }
        }
    }

    bool PartSequencer::getClickRecord()
    {
        return sequencer->getClickRecord();
    }

    void PartSequencer::setClickInterval(int interval)
    {
        sequencer->setClickInterval(interval);
    }

    int PartSequencer::getClickInterval()
    {
        return sequencer->getClickInterval();
    }

    void PartSequencer::setCountin(int count_in)
    {
        m_CountinPart->setLength(count_in);
    }

    int PartSequencer::getCountin()
    {
        return m_CountinPart->getLength();
    }

    void PartSequencer::setLength(int length)
    {
        if(partLink->getLink()!=NULL)
        {
            // for now don't allow editing the part while playing.
            sequencer->stop();
            if(partLink!=NULL && partLink->getPart()!=NULL)
            {
                partLink->getPart()->setLength(length);
                sequencer->setMultiTrackLink(partLink);
                raiseEvent(Events::PART_CONTENT_CHANGED, partLink->getPart());
            }
        }
    }

    void PartSequencer::onEvent(int id, void* params)
    {
        // these only fire if part sequencer is enabled
        if(getEnabled())
        {
            if(id == Events::SEQUENCER_STOPPED)
            {
                //raiseEvent(Events::SEQUENCER_STATE_CHANGED);
            }
            else if(id == Events::SEQUENCER_PLAYING)
            {
                //raiseEvent(Events::SEQUENCER_STATE_CHANGED);
            }
            else if(id == Events::SEQUENCER_STATE_CHANGED)
            {
                // block state changed events.
            }
            else if(id == Events::SEQUENCER_BEAT_UPDATE)
            {
                raiseEvent(Events::SEQUENCER_BEAT_UPDATE, params);
            }
            else if(id == Events::SEQUENCER_ACTIVITY_MIDI_IN)
            {
            }
            else if(id == Events::SEQUENCER_ACTIVITY_MIDI_OUT)
            {
            }
            else if(id == Events::SEQUENCER_MULTITRACK_END)
            {
                if(partLink->getLink()!=NULL)
                {
                    if(m_PlayingClick && (sequencer->getClickPlay() || (sequencer->getClickRecord() && m_Record)) )
                    {
                        /// Added by JVR
                        /*
                            Only if recording ...
                            This section checks for any notes that were recorded
                            onto the click track, and puts them at the first beat
                            of the actual recorded part.
                        */
                        if (m_Record && partLink!=NULL)
                        {
                            // For each TRACK
                            Part* p1 = m_Step->getPart();   // source
                            Part* p2 = partLink->getPart(); // destination
                            for (unsigned int i=0; (p1!=NULL && p2!=NULL && i<p1->count() && i<p2->count()); i++)
                            {
                                Track* t1 = p1->getTrack(i);
                                Track* t2 = p2->getTrack(i);

                                // For each MIDI Event in this track.
                                if (t1!=NULL && t2!=NULL)
                                {
                                    MIDIEventIterator it = t1->getIterator_begin();
                                    while (it != t1->getIterator_end())
                                    {
                                        MIDIEvent* e = (*it);
                                        if (e != NULL)
                                        {
                                            e->absolute = 0;
                                            t2->insert(e);
                                        }
                                        it++;
                                    }
                                }
                            }
                        }

                        m_PlayingClick=false;
                        sequencer->setMultiTrackLink(partLink);
                        sequencer->jump(0);
                        sequencer->play();
                        sequencer->setRecordArmed(m_Record);
                        int beat = getBeat();
                        raiseEvent(Events::SEQUENCER_BEAT_UPDATE, &beat);

                    }
                    else
                    {
                        if(getLoop())
                        {
                            // punch out
                            if(!m_OverDub)
                            {
                                record(false);
                                SongStep& step = getActiveStep();
                                for(unsigned int i=0;i<step.trackCount();++i)
                                {
                                    if(step.getTrackState(i) == SongStep::TRACK_STATE_RECORD)
                                    {
                                        step.setTrackState(i, SongStep::TRACK_STATE_PLAY);
                                    }
                                }
                            }
                            else if(sequencer->isRecordArmed())
                            {
                                // advanced auto increment feature
                                SongStep& step = getActiveStep();
                                bool foundEmptyTrack=false;
                                for(int i=0;i<step.trackCount();++i)
                                {
                                    if(foundEmptyTrack && step.getTrackState(i) == SongStep::TRACK_STATE_RECORD)
                                    {
                                        step.setTrackState(i, SongStep::TRACK_STATE_PLAY);
                                    }
                                    else if(!foundEmptyTrack && !step.getPart()->getTrack(i)->empty() && step.getTrackState(i) == SongStep::TRACK_STATE_RECORD)
                                    {
                                        step.setTrackState(i, SongStep::TRACK_STATE_PLAY);
                                    }
                                    else if(!foundEmptyTrack && step.getPart()->getTrack(i)->empty())
                                    {
                                        step.setTrackState(i, SongStep::TRACK_STATE_RECORD);
                                        foundEmptyTrack = true;
                                    }
                                }
                            }

                            // if looping loop back to beginning
                            jump(0);
                            sequencer->play();
                        }
                        else
                        {
                            record(false);
                            SongStep& step = getActiveStep();
                            for(int i=0;i<step.trackCount();++i)
                            {
                                if(step.getTrackState(i) == SongStep::TRACK_STATE_RECORD)
                                {
                                    step.setTrackState(i, SongStep::TRACK_STATE_PLAY);
                                }
                            }

                            // not looping stop.
                            m_PlayingClick=false;
                            sequencer->stop();
                        }

                        raiseEvent(Events::SEQUENCER_STATE_CHANGED);
                    }
                }
            }
            else
            {
                raiseEvent(id, params);
            }
        }

        // these always fire
        if(id == Events::ACTIVE_PART_CHANGED)
        {
            int s = getState();
            if(partLink->getLink()!=NULL)
            {
                sequencer->stop();
            }
            partLink->setPart(partSystem->getActive());
            sequencer->setMultiTrackLink(partLink);
            if(partLink->getLink()!=NULL && s != SequencerStates::STOPPED)
            {
                play();
            }
        }
    }

    bool PartSequencer::isCountin()
    {
        return m_PlayingClick;
    }

    void PartSequencer::setActivePart(int id)
    {
        partSystem->setActive(id);
        activate();
    }

    void PartSequencer::setLoop(bool loop)
    {
        m_Loop = loop;
        raiseEvent(Events::SEQUENCER_LOOP_CHANGED);
    }

    bool PartSequencer::getLoop()
    {
        return m_Loop;
    }

    void PartSequencer::addPart()
    {
        Part* part = new Part("New Part", partSystem->count());
        partSystem->addPart(part);
    }

    void PartSequencer::removePart()
    {
        if(partSystem->getActive())
        {
            sequencer->stop();
            partSystem->removePart(partSystem->getActive()->getID());
        }
    }

    void PartSequencer::setEnabled(bool enable)
    {
        m_Enabled = enable;
    }

    bool PartSequencer::getEnabled()
    {
        return m_Enabled;
    }

    void PartSequencer::setOverDub(bool overDub)
    {
        m_OverDub = overDub;
        raiseEvent(Events::PART_SEQUENCER_OVERDUB_CHANGED);
    }

    bool PartSequencer::getOverDub()
    {
        return m_OverDub;
    }
}
