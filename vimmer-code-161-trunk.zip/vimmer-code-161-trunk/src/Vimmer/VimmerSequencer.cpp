/*
   Virtual MIDI Multitrack Recorder
   Copyright (c) 2006 MIDI Team

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/

/**
   VimmerSequencer.cppile VimmerSequencer.cpp
   Charles Weld, David Wilson, James Brown, Jonathan Van Rossum, and Matthew Harrold
   @brief Declaration of class VimmerSequencer, part of Virtual MIDI Multitrack Recorder
*/

#include "VimmerSequencer.hpp"
#include "Observer.hpp"

namespace Vimmer
{
    VimmerSequencer::VimmerSequencer()
    {
        m_Sequencer = new MIDIToolkit::Sequencer();
        m_Device = new Device();
        m_Device->connect(m_Sequencer);
        m_Sequencer->connect(m_Device);
        m_Device->setInput(0);
        m_Device->setOutput(0);
        m_Device->start();

        m_Store = new Store(100,100);
        m_SequencerMgr = new SequencerManager(m_Sequencer, m_Store);
    }

    VimmerSequencer::~VimmerSequencer()
    {
        delete m_Sequencer;
        delete m_Device;
        delete m_Store;
        delete m_SequencerMgr;
    }

    void VimmerSequencer::onEvent(const int &e)
    {

    }

    void VimmerSequencer::addObserver(Observer *observer)
    {

    }

    void VimmerSequencer::invokeCommand(MIDIToolkit::String cmdID, void* params)
    {
        if(cmdID == "record")
        {
            m_SequencerMgr->getActiveStep().setTrackStateAll(MultiTrackLink::TRACK_STATE_CLEAR);
            m_SequencerMgr->getActiveStep().setTrackState(0, MultiTrackLink::TRACK_STATE_RECORD);
            m_SequencerMgr->jump(0);
            m_SequencerMgr->record(true);
            m_SequencerMgr->play();
        }
        else if(cmdID == "play")
        {
            m_SequencerMgr->getActiveStep().setTrackStateAll(MultiTrackLink::TRACK_STATE_PLAY);
            m_SequencerMgr->jump(0);
            m_SequencerMgr->play();
        }
        else if(cmdID == "stop")
        {
            m_SequencerMgr->stop();
        }
    }

    void VimmerSequencer::invokeQuery(MIDIToolkit::String queryID, void* params)
    {
        if(queryID == "sequencer state")
        {
            int* state = static_cast<int*>(params);
            *state = m_SequencerMgr->getState();
        }
    }
}
