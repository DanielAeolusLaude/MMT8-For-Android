/*
   Virtual MIDI Multitrack Recorder
   Copyright (c) 2006 MIDI Team

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/

/**
   StandardMIDIExporter.hppile StandardMIDIExporter.hpp
   Charles Weld, David Wilson, James Brown, Jonathan Van Rossum, and Matthew Harrold
   @brief Declaration of class StandardMIDIExporter, part of Virtual MIDI Multitrack Recorder
*/

#ifndef _STANDARDMIDIEXPORTER_H
#define _STANDARDMIDIEXPORTER_H

#include "Exporter.hpp"

#include "MultiTrack.hpp"

namespace Vimmer
{
    // forward declaration
    class Store;

    # pragma pack(1)
    /// @ingroup files
    struct type_track_data_optional
    {
        unsigned int track_length;
        unsigned int sequence_number;
        unsigned int track_number;
        unsigned int tempo;
        String sequence_name;
    };

    /// @ingroup files
    class StandardMIDIExporter : public Exporter
    {

    public:

        /** @brief  Constructor.
          * @param  store   The store the exporter will read from.
         */
        StandardMIDIExporter(Store* store);

        /** @brief  Get the filter string for this exporter.
          * @return The filter string.
         */
        virtual String getFilter();

        /** @brief  Export the whole store to a file.
          * @param  filename    The name of the file to export to.
         */
        virtual void fileExportStore (String filename);

        /** @brief  Export a particular song to a file.
          * @param  filename    The name of the file to export to.
          * @param  songnumber  The number of the song (0-based).
         */
        virtual void fileExportSong  (String filename, int songnumber);

        /** @brief  Export a particular part to a file.
          * @param  filename    The name of the file to export to.
          * @param  partnumber  The number of the part (0-based).
         */
        virtual void fileExportPart  (String filename, int partnumber);

        /** @brief  Export a particular track to a file.
          * @param  filename    The name of the file to export to.
          * @param  partnumber  The number of the part which contains this track (0-based).
          * @param  tracknumber The number of the track (0-based).
         */
        virtual void fileExportTrack (String filename, int partnumber, unsigned int tracknumber);

        /// The default format (0, 1, 2) for this Standard MIDI file.
        static const int FORMAT = 0;

    protected:

        /// The store that is attached to this exporter.
        Store* store;

        /// Standard MIDI Exporter creates these chunk types.
        static unsigned int CHUNK_TYPE_MTHD;    ///<    MThd:   Header.
        static unsigned int CHUNK_TYPE_MTRK;    ///<    MTrk:   Track data.
        static unsigned int CHUNK_TYPE_ZZZZ;    ///<    0000:   End of file marker.

        /** @brief  Main function that handles exporting.
          * @param  filename    The name of the file to export to.
          * @param  s           Song to export (or NULL if not exporting a song).
          * @param  p           Part to export (or NULL if not exporting a part).
          * @param  t           Track to export (or NULL if not exporting a track).
          * @param  format      Standard MIDI format to use (0, 1, 2).
         */
        virtual void exportfile(const char* filename, Song* s, Part* p, Track* t, unsigned short format);

        /** @brief  Merge all tracks from a multitrack into a single track.
          * @param  destination     Merge all into this track.
          * @param  source          Multitrack containing all of the source tracks.
         */
        void merge_tracks(Track* destination, MultiTrack* source);

        /** @brief  Join all parts from a song into a single part.
          * @param  destination     Merge all into this multitrack.
          * @param  source          Song containing all of the source parts.
         */
        void merge_multitracks(MultiTrack* destination, Song* source);

        /** @brief  Create MTrk chunk in memory from Track.
          * @note   This function is used when only a track is being exported.
          * @param  chunk       Memory array to write this chunk into.
          * @param  track       Pointer to Track to read data from.
          * @param  maxsize     The maximum size of the chunk (prevents writing beyond array).
          * @param  optional    Extra information used to write to the chunk.
          * @return             The number of bytes used by this chunk data.
         */
        unsigned int process_chunk_MTrk_Track(unsigned char* chunk, Track* track, unsigned int maxsize, struct type_track_data_optional* optional);

        /** @brief  Create MTrk chunk in memory from Track.
          * @note   This function is used when only a multitrack is being exported.
          * @param  chunk       Memory array to write this chunk into.
          * @param  track       Pointer to Track to read data from.
          * @param  maxsize     The maximum size of the chunk (prevents writing beyond array).
          * @param  optional    Extra information used to write to the chunk.
          * @return             The number of bytes used by this chunk data.
         */
        unsigned int process_chunk_MTrk_MultiTrack(unsigned char* chunk, MultiTrack* multitrack, unsigned int maxsize, unsigned short* ntrks);

        /** @brief  Create a "Tempo" Meta-Event inside some chunk data.
          * @param  chunk       Position to write the Meta-Event to.
          * @param  maxsize     The maximum size of the meta-event (prevents writing beyond array).
          * @param  tempo       The tempo itself.
          * @return             The number of bytes used by this Meta-Event.
         */
        unsigned int process_chunk_MTrk_Tempo          (unsigned char* chunk, unsigned int maxsize, unsigned int tempo);

        /** @brief  Create a "Sequence Number" Meta-Event inside some chunk data.
          * @param  chunk       Position to write the Meta-Event to.
          * @param  maxsize     The maximum size of the meta-event (prevents writing beyond array).
          * @param  number      Sequence number itself.
          * @return             The number of bytes used by this Meta-Event.
         */
        unsigned int process_chunk_MTrk_SequenceNumber (unsigned char* chunk, unsigned int maxsize, unsigned int number);

        /** @brief  Create a "Sequence Name" Meta-Event inside some chunk data.
          * @param  chunk       Position to write the Meta-Event to.
          * @param  maxsize     The maximum size of the meta-event (prevents writing beyond array).
          * @param  name        The name of the sequence (ie. part name).
          * @return             The number of bytes used by this Meta-Event.
         */
        unsigned int process_chunk_MTrk_SequenceName   (unsigned char* chunk, unsigned int maxsize, String name);

        /** @brief  Convert an integer to a "variabled length quantity".
          * @note   See the Standard MIDI file specification to read what this is.
          * @param  data        Memory array to write this quantity into.
          * @param  max_length  The maximum size of the array (prevents writing beyond array).
          * @param  quantity    The quantity to write as a variable length quantity.
          * @return             The number of bytes used by this variable length quantity.
         */
        unsigned int set_variable_length_quantity(unsigned char* data, unsigned int max_length, register unsigned int quantity);


/*

        bool process_chunk_MTrk_Track(chunk_type chunk, char* chunk_data, Track* track, struct type_track_data* track_data);
        bool process_chunk_MTrk_MultiTrack(chunk_type chunk, char* chunk_data, MultiTrack* multitrack, struct type_track_data* track_data);


        void import(const char* filename, int mode, Track* t, MultiTrack* mt);
*/

    };
}

#endif  //_STANDARDMIDIEXPORTER_H
