/*
   Virtual MIDI Multitrack Recorder
   Copyright (c) 2006 MIDI Team

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/

/**
   @file   Store.hpp
   @author James Brown, Charles Weld
   @brief  Declaration of the class Store.
*/


#ifndef _STORE_H
#define _STORE_H

#include "VimmerPrerequisites.hpp"
#include "PartSystem.hpp"
#include "SongSystem.hpp"
//#include "Observable.hpp"
#include "Observer.hpp"

using namespace MIDIToolkit;

namespace Vimmer
{
    /** @ingroup    store
     *  @brief      Store acts as a repository for all parts and songs.
     *
     *  OVERVIEW:
     *
     *  Store provides storage facilities for all parts and songs (see Part and
     *  Song classes respectively). Store is split up into two subsystems,
     *  PartSystem class and SongSequencer class, and provides free access to these.
     *
     *  MISCELLANEOUS:
     *
     *  Store also provides facilities to load and save itself to external files.
     *  This is currently not implemented. For these features, please see the
     *  subclass of Importer or Exporter that is relevant to the particular file
     *  type.
     *
     */
    class Store
    {
    public:

        /** @brief  Construct store, with a given number of parts and songs.
         *  @param  numOfParts  Number of Parts.
         *  @param  numOfSongs  Number of Songs.
         */
        Store(int numOfParts, int numOfSongs);

        /** @brief  Destructor.
         */
        virtual ~Store();

        // model related methods
        /**
         * Gets the song's part system.
         * @return The song's part system.
         */
        virtual PartSystem* getPartSystem();

        /**
         * @brief Gets the store's song system.
         *
         * Gets the store's song system.
         * @return The store's song system.
         */
        virtual SongSystem* getSongSystem();

        /** @brief  Erases the entire store.
         */
        virtual void clear();

        /** @brief  Add an observer to the Store.
          * @param  observer    Pointer to the Observer to add.
          * @note   This observer is notified of events, such as changes
          *         in the Store's contents.
         */
        virtual void addObserver(Observer *observer);

        // persistence methods
        /** @brief  Save the entire Store to a file.
          * @todo   This function needs to be implemented, or removed.
          * @param  filename    Name of file to save into.
         */
        virtual void save(String filename);

        /** @brief  Load the entire Store from a file.
          * @todo   This function needs to be implemented, or removed.
          * @param  filename    Name of file to load from.
         */
        virtual void open(String filename);

        /** @brief  Save the entire Store.
          * @todo   This function needs to be implemented, or removed.
          * @note   The store is (presumably) saved to the file held by the "String filename" member.
         */
        virtual void save();

        /** @brief  Load the entire Store.
          * @todo   This function needs to be implemented, or removed.
          * @note   The store is (presumably) loaded from the file held by the "String filename" member.
         */
        virtual void open();

    protected:

        /// @brief  Subsystem that stores the Parts.
        PartSystem *partSys;

        /// @brief  Subsystem that stores the Songs.
        SongSystem *songSys;

        /// @brief  Filename from which to load and save the Store.
        /// @note   This would be used by save() and open() functions.
        String filename;
    };
}

#endif  //_STORE_H
