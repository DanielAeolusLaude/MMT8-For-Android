/*
   Virtual MIDI Multitrack Recorder
   Copyright (c) 2006 MIDI Team

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/

/**
   @file   Part.cpp
   @author James Brown, Charles Weld
   @brief  Implementation of the class Part.
*/


#include "Part.hpp"
#include "Events.hpp"

namespace Vimmer
{
    Part::Part(String name, int id):
        MIDIToolkit::MultiTrack()
    {
        setName(name);
        setID(id);
    }

    Part::~Part()
    {

    }

    String Part::getName()
    {
        return name;
    }

    void Part::setName(String name)
    {
        this->name = name;
        raiseEvent(Events::PART_CONTENT_CHANGED, this);
    }

    int Part::getID()
    {
        return id;
    }

    void Part::setID(int id)
    {
        this->id = id;
    }

    void Part::append(Part part, bool tracks[8])
    {
        /// TODO
    }
}
