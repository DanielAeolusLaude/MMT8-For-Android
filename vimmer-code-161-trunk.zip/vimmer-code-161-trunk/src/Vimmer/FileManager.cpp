/*
   Virtual MIDI Multitrack Recorder
   Copyright (c) 2006 MIDI Team

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/

/**
   FileManager.cppile FileManager.cpp
   Charles Weld, David Wilson, James Brown, Jonathan Van Rossum, and Matthew Harrold
   @brief Declaration of class FileManager, part of Virtual MIDI Multitrack Recorder
*/

#include "FileManager.hpp"
#include "XMLExporter.hpp"
#include "XMLImporter.hpp"
#include "StandardMIDIExporter.hpp"
#include "StandardMIDIImporter.hpp"
#include "MMT8Exporter.hpp"
#include "MMT8Importer.hpp"
#include <iostream>
using namespace std;

namespace Vimmer
{
    FileManager::FileManager(Store* store)
    {
        m_Store = store;

        // load supported importers
        importers.push_back(new XMLImporter(store));
        importers.push_back(new MMT8Importer(store));
        importers.push_back(new StandardMIDIImporter(store));

        // load supported exporters
        exporters.push_back(new XMLExporter(store));
        exporters.push_back(new MMT8Exporter(store));
        exporters.push_back(new StandardMIDIExporter(store));
    }

    FileManager::~FileManager()
    {
        // delete importers
        for(ImporterIterator iter=importers.begin();iter!=importers.end();iter++)
        {
            delete (*iter);
        }

        // delete exporters
        for(ExporterIterator iter=exporters.begin();iter!=exporters.end();iter++)
        {
            delete *iter;
        }
    }

    void FileManager::saveStore(String filename)
    {
        // find extension
        String::size_type last = filename.find_last_of( "." );
        if( last != String::npos )
        {
            String ext = filename.substr(last+1);
            for(ExporterIterator iter=exporters.begin();iter!=exporters.end();iter++)
            {
                if( ext == (*iter)->getFilter() )
                {
                    (*iter)->fileExportStore(filename);
                    break;
                }
            }
        }
    }

    void FileManager::loadStore(String filename)
    {
        String::size_type last = filename.find_last_of( "." );
        if( last != String::npos )
        {
            String ext = filename.substr(last+1);
            for(ImporterIterator iter=importers.begin();iter!=importers.end();iter++)
            {
                if( ext == (*iter)->getFilter() )
                {
                    (*iter)->fileImportStore(filename);
                    break;
                }
            }
        }
    }

    void FileManager::loadPart(String filename)
    {
        // first make sure theres a part thats active in the store (if not add one)
        PartSystem* psys = m_Store->getPartSystem();
        if(psys->getActive()==NULL)
        {
            psys->addPart(new Part("Empty Part", psys->count()));
        }

        // now import the part.
        String::size_type last = filename.find_last_of( "." );
        if( last != String::npos )
        {
            String ext = filename.substr(last+1);
            for(ImporterIterator iter=importers.begin();iter!=importers.end();iter++)
            {
                if( ext == (*iter)->getFilter() )
                {
                    (*iter)->fileImportPart(filename, m_Store->getPartSystem()->getActive()->getID());
                    break;
                }
            }
        }
    }

    void FileManager::savePart(String filename)
    {
        // first make sure theres a part thats active in the store (if not add one)
        PartSystem* psys = m_Store->getPartSystem();
        if(psys->getActive()!=NULL)
        {

            // now export the part.
            String::size_type last = filename.find_last_of( "." );
            if( last != String::npos )
            {
                String ext = filename.substr(last+1);
                for(ExporterIterator iter=exporters.begin();iter!=exporters.end();iter++)
                {
                    if( ext == (*iter)->getFilter() )
                    {
                        (*iter)->fileExportPart(filename, psys->getActive()->getID());
                        break;
                    }
                }
            }
        }
    }
}
