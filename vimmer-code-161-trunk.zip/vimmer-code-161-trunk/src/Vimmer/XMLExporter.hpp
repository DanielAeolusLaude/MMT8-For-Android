/*
   Virtual MIDI Multitrack Recorder
   Copyright (c) 2006 MIDI Team

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/

/**
   @file XMLExporter.hpp
   Charles Weld, David Wilson, James Brown, Jonathan Van Rossum, and Matthew Harrold
   @brief Declaration of class XMLExporter, part of Virtual MIDI Multitrack Recorder
*/

#ifndef _XMLEXPORTER_H
#define _XMLEXPORTER_H

#include "VimmerPrerequisites.hpp"
#include "tinyxml.h"
#include "PartSystem.hpp"
#include "Part.hpp"
#include "Track.hpp"
#include "ShortMessage.hpp"
#include "SongSystem.hpp"
#include "Song.hpp"
#include "SongStep.hpp"
#include "Exporter.hpp"

using namespace MIDIToolkit;

namespace Vimmer
{
    // forward declaration
    class Store;

    /// @ingroup files
    class XMLExporter : public Exporter
    {
    public:
        XMLExporter(Store* store);
        virtual String getFilter();

        virtual void fileExportStore (String filename);

    private:
        // part support
        TiXmlElement* genPartSystem(PartSystem* psys);
        TiXmlElement* genPart(Part* part);
        TiXmlElement* genTrack(Track* track, int id);
        TiXmlElement* genMessage(MIDIEvent* msg);

        // song support
        TiXmlElement* genSongSystem(SongSystem* ssys);
        TiXmlElement* genSong(Song* song);
        TiXmlElement* genSongStep(SongStep* songstep);
    private:
        Store* m_Store;
    };
}

#endif  //_EXPORTER_H
