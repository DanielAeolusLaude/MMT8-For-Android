/*
   Virtual MIDI Multitrack Recorder
   Copyright (c) 2006 MIDI Team

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/

/**
   @file SequencerManager.hpp
   @author Charles Weld
   @brief Declaration of class SequencerManager, part of Virtual MIDI Multitrack Recorder
*/

#ifndef _SEQUENCERMANAGER_H
#define _SEQUENCERMANAGER_H

#include "VimmerPrerequisites.hpp"
#include "SongSequencer.hpp"
#include "PartSequencer.hpp"
#include "Sequencer.hpp"
#include "Store.hpp"
#include "Observable.hpp"

using namespace MIDIToolkit;

namespace Vimmer
{
    /**
     * @brief Manages the song and part sequencers.
     *
     * The Sequencer Manager has two components these are the Song Sequencer,
     * and Part Sequencer, based what mode it's in the sequencer manager will
     * rought calls onto the currect sequencer, ie calling play when it's in
     * song mode will result in play being called on it's song sequencer.
     *
     * @ingroup sequencer
     */
    class SequencerManager : public Observable
    {
    public:
        /**
         * @brief Initializes the Sequencer Manager.
         *
         * Initializes the Sequencer Manager.
         * @param sequencer The sequencer used to playback and record parts and songs.
         * @param store The store that holds the parts and songs.
         */
        SequencerManager(MIDIToolkit::Sequencer* sequencer, Store* store);

        /**
         * @brief Cleans up the sequencer manager.
         *
         * Cleans up the sequencer manager.
         */
        virtual ~SequencerManager();

        /**
         * @see MIDIToolkit::Observable::addObserver(Observer*)
         */
        virtual void addObserver(Observer* obs);

        /**
         * @brief Gets the mode the sequencer is currently in.
         *
         * Gets the mode the sequencer is currently in.
         * @return The sequencers mode.
         * @see SequencerModes
         */
        virtual int getMode();

        /**
         * @brief Gets the state of the active sequencer.
         *
         * Gets the state of the active sequencer.
         * @return The active sequencers state.
         */
        virtual MIDIToolkit::SequencerStates::SequencerState getState();

        /**
         * @brief Informs the active sequencer to start playing.
         *
         * Informs the active sequencer to start playing.
         */
        virtual void play();

        /**
         * @brief Informs the active sequencer to change it's recording state.
         *
         * Informs the active sequencer to change it's recording state.
         * @param record The active sequencers new recording state.
         */
        virtual void record(bool state);

        /**
         * @brief Gets the recording state from the active sequencer.
         *
         * Gets the recording state from the active sequencer.
         * @return The active sequencers recording state.
         */
        virtual bool isRecordArmed();

        /**
         * @brief Informs the active sequencer to stop playing.
         *
         * Informs the active sequencer to stop playing.
         */
        virtual void stop();

        /**
         * @brief Informs the active sequencer to 'jump' to a new location.
         *
         * Informs the active sequencer to 'jump' to a new location.
         * @param beat The location.
         */
        virtual void jump(int beat);

        /**
         * @brief Changes the mode that sequencer manager is in.
         *
         * Changes the mode that sequencer manager is in.
         * If the mode is Part Mode then all sequencing operations are
         * roughted through to the part mode. If the mode is Song Mode
         * all sequencing operations are roughted through to the song
         * sequencer.
         * @param mode The new mode.
         */
        virtual void setMode(int mode);

        /**
         * @brief Gets the currently playing part from the active sequencer.
         *
         * Gets the currently playing part from the active sequencer.
         * @return The currently playing part.
         */
        virtual SongStep& getActiveStep();

        /**
         * @brief Informs the active sequencer to update it's tempo.
         *
         * Informs the active sequencer to update it's tempo.
         * @param tempo The tempo.
         */
        virtual void setTempo(int tempo);

        /**
         * @brief Gets the tempo from the active sequencer.
         *
         * Gets the tempo from the active sequencer.
         * @return The active sequencers tempo.
         */
        virtual int getTempo();

        /**
         * @brief Gets the location from the active sequencer.
         *
         * Gets the location from the active sequencer.
         * @return The location in beats.
         */
        virtual int getBeat();

        /**
         * @brief Gets the length of the current musical piece from the active sequencer.
         *
         * Gets the length of the current musical piece from the active sequencer.
         * @return The length in beats.
         */
        virtual int getLength();

        /**
         * @brief Sets the loop state of the currently active sequencer.
         *
         * Sets the loop state of the currently active sequencer.
         * @param loop The new loop state.
         */
        void setLoop(bool loop);

        /**
         * @brief Gets the loop state of the currently active sequencer.
         *
         * Gets the loop state of the currently active sequencer.
         * @return The loop state.
         */
        bool getLoop();

        /**
         * @brief Sets the play click state of the currently active sequencer.
         *
         * Sets the play click state of the currently active sequencer.
         * @param click The new play click state.
         */
        void setClickPlay(bool click);

        /**
         * @brief Gets the play click state of the currently active sequencer.
         *
         * Gets the play click state of the currently active sequencer.
         * @return the play click state of the currently active sequencer.
         */
        bool getClickPlay();

        /**
         * @brief Sets the record click state of the currently active sequencer.
         *
         * Sets the record click state of the currently active sequencer.
         * @param click The new record click state.
         */
        void setClickRecord(bool click);

        /**
         * @brief Gets the record click state of the currently active sequencer.
         *
         * Gets the record click state of the currently active sequencer.
         * @return the record click state of the currently active sequencer.
         */
        bool getClickRecord();

        /**
         * @brief Sets the click interval of the currently active sequencer.
         *
         * Sets the click interval of the currently active sequencer.
         * @param interval The new click interval.
         */
        void setClickInterval(int interval);

        /**
         * @brief Gets the click interval of the currently active sequencer.
         *
         * Gets the click interval of the currently active sequencer.
         * @return The click interval.
         */
        int getClickInterval();

        /**
         * @brief Sets the countin in beats of the currently active sequencer.
         *
         * Sets the countin in beats of the currently active sequencer.
         */
        void setCountin(int count_in);

        /**
         * @brief Gets the countin in beats of the currently active sequencer.
         *
         * Gets the countin in beats of the currently active sequencer.
         * @return the countin.
         */
        int getCountin();
        virtual bool isCountin();

        /**
         * @brief Gets the part sequencer.
         *
         * Gets the part sequencer.
         * @return The part sequencer.
         */
        virtual PartSequencer* getPartSequencer()
        {
            return partSequencer;
        }

        /**
         * @brief Gets the song sequencer.
         *
         * Gets the song sequencer.
         * @return the song sequencer.
         */
        virtual SongSequencer* getSongSequencer()
        {
            return songSequencer;
        }


    private:
        int mode;
        SongSequencer* songSequencer;
        PartSequencer* partSequencer;
        ISequencer* activeSequencer;

    };
}

#endif  //_SEQUENCERMANAGER_H
