/*
   Virtual MIDI Multitrack Recorder
   Copyright (c) 2006 MIDI Team

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/

/**
   Exporter.hppile Exporter.hpp
   Charles Weld, David Wilson, James Brown, Jonathan Van Rossum, and Matthew Harrold
   @brief Declaration of class Exporter, part of Virtual MIDI Multitrack Recorder
*/

#ifndef _EXPORTER_H
#define _EXPORTER_H

#include "VimmerPrerequisites.hpp"
#include "LogManager.hpp"

using namespace MIDIToolkit;

namespace Vimmer
{
    // forward declaration
    class Store;

    /// @ingroup files
    class Exporter
    {
    public:

        /** @brief  Constructor.
          * @param  store   The store the exporter will read from.
         */
        Exporter(Store* store);

        /** @brief  Get the filter string for this exporter.
          * @return The filter string.
         */
        virtual String getFilter();

        /** @brief  Export the whole store to a file.
          * @param  filename    The name of the file to export to.
         */
        virtual void fileExportStore (String filename);

        /** @brief  Export a particular song to a file.
          * @param  filename    The name of the file to export to.
          * @param  songnumber  The number of the song (0-based).
         */
        virtual void fileExportSong  (String filename, int songnumber);

        /** @brief  Export a particular part to a file.
          * @param  filename    The name of the file to export to.
          * @param  partnumber  The number of the part (0-based).
         */
        virtual void fileExportPart  (String filename, int partnumber);

        /** @brief  Export a particular track to a file.
          * @param  filename    The name of the file to export to.
          * @param  partnumber  The number of the part which contains this track (0-based).
          * @param  tracknumber The number of the track (0-based).
         */
        virtual void fileExportTrack (String filename, int partnumber, int tracknumber);

    protected:

        /// Errors will be logged to this object.
        LogManager* logger;

    public:     // THESE SHOULD BE PROTECTED

        /** @brief  Load a file into memory.
          *     Opens a file, reads its entire contents into memory, and closes it.
          *     The functions allocates (and returns) a char array holding the
          *     files data. The caller must free this when done.
          *     The size of this block is returned in the "size" variable.
          * @param  filename    The name of the file to save as.
          * @param  data        Pointer to data to save.
          * @param  size        Number of bytes to write to file.
          * @return ZERO for successful save, NON-ZERO for failure.
         */
        virtual int savefile(const char* filename, const char* data, int size);

        /** @brief  Swaps two bytes.
          * @param  a   First byte.
          * @param  b   Second byte.
         */
        static void swap(unsigned char* a, unsigned char* b);

        /** @brief  Advances current position of parser.
          * @note   This function just makes the source code easier to read.
          * @param  index           Current position ("bytes" is added to this number)
          * @param  remaining_bytes Remaining bytes ("bytes" is subtracted from this number.
          * @param  bytes           The number of bytes by which to advance the parsing.
         */
        static void advance(unsigned int* index, signed int* remaining_bytes, unsigned int bytes);

        /** @brief  Reverses the bytes of a 2-byte integer.
          * @note   This has the effect of converting LITTLE ENDIAN to BIG ENDIAN format,
          *         or vice versa.
          * @param  little_endian   The original number.
          * @return The converted number.
         */
        static unsigned short reverse_endian_short(unsigned short little_endian);

        /** @brief  Reverses the bytes of a 4-byte integer.
          * @note   This has the effect of converting LITTLE ENDIAN to BIG ENDIAN format,
          *         or vice versa.
          * @param  little_endian   The original number.
          * @return The converted number.
         */
        static unsigned int   reverse_endian_int  (unsigned int   little_endian);

        /** @brief  Reverses the bytes of a 3-byte integer.
          * @note   This has the effect of converting LITTLE ENDIAN to BIG ENDIAN format,
          *         or vice versa.
          * @param  little_endian   The original number.
          * @return The converted number.
         */
        static unsigned int   reverse_endian_24   (unsigned int little_endian);

        /** @brief  Converts from BCD representation to an integer.
          * @param  bcd     Number in BCD representation (must be two bytes, ie. 0000-9999).
          * @return The actual number.
         */
        static unsigned short convert_from_bcd (unsigned short bcd);

        /** @brief  Converts from an integer to BCD representation.
          * @param  number  The actual number (must be 0000-9999).
          * @return BCD representation of this number.
         */
        static unsigned short convert_to_bcd   (unsigned short number);

        /** @brief  Returns the lowest of two unsigned integers.
          * @param  a   First integer.
          * @param  b   Second integer.
          * @return The lowest of these integers.
         */
        static unsigned short min(unsigned short a, unsigned short b);

        /** @brief  Returns the greatest of two unsigned integers.
          * @param  a   First integer.
          * @param  b   Second integer.
          * @return The greatest of these integers.
         */
        static unsigned short max(unsigned short a, unsigned short b);

        /** @brief  Returns the minimum of two unsigned integers.
          * @param  a   First integer.
          * @param  b   Second integer.
          * @return The lowest of these integers.
         */
        static unsigned int min(unsigned int a, unsigned int b);

        /** @brief  Returns the greatest of two unsigned integers.
          * @param  a   First integer.
          * @param  b   Second integer.
          * @return The greatest of these integers.
         */
        static unsigned int max(unsigned int a, unsigned int b);

    };
}

#endif  //_EXPORTER_H
