/*
   Virtual MIDI Multitrack Recorder
   Copyright (c) 2006 MIDI Team

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/

/**
   @file SongSequencer.hpp
   @author Charles Weld, James Brown
   @brief Declaration of class SongSequencer, part of Virtual MIDI Multitrack Recorder
*/

#ifndef _SONGSEQUENCER_H
#define _SONGSEQUENCER_H

#include "ISequencer.hpp"
#include "Sequencer.hpp"
#include "SongSystem.hpp"
#include "SequencerStates.hpp"
#include "Part.hpp"
#include "Observable.hpp"
#include "Observer.hpp"

using namespace MIDIToolkit;

namespace Vimmer
{

    /**
     * @brief Represents a Song Sequencer.
     *
     * A Song Sequencer is a sequencer specifically designed to play back songs.
     * This sequencer also provides a number of facilities for editing songs,
     * this interface is defined here so that we can keep the sequencer and store in sinc.
     *
     * @see Vimmer::Song
     * @ingroup sequencer
     */
    class SongSequencer : public ISequencer, public Observer, public Observable
    {
    public:
        /**
         * @brief Creates a new Song Sequencer that uses a given MIDITookit Sequencer and Song System.
         *
         * Creates a new Song Sequencer that uses a given MIDITookit Sequencer and
         * Song System.
         * @param sequencer The sequencer to use to do the sequencing.
         * @param songSystem The song system to use (were it gets it's songs from).
         */
        SongSequencer(MIDIToolkit::Sequencer* sequencer, SongSystem* songSystem);

        /**
         * @brief Cleans up the song sequencer.
         *
         * Cleans up the song sequencer.
         */
        virtual ~SongSequencer();


        /**
         * @brief Activates the sequencer.
         *
         * This allows this sequencer to take control of the actual MIDIToolkit Sequencer
         * @see MIDIToolkit::Sequencer and therefore one MIDIToolkit Sequencer can be used
         * by multiple Vimmer Sequencers.
         */
        virtual void activate();

        /**
         * @brief Gets the state of the sequencer.
         *
         * Gets the state of the sequencer, ie if it's playing, stopped, or recording.
         * @return The sequencer's state.
         */
        virtual MIDIToolkit::SequencerStates::SequencerState getState();

        /**
         * @brief Start playing the currently active song.
         *
         * Start playing the currently active song.
         */
        virtual void play();

        /**
         * @brief The song sequener doesn't support recording.
         *
         * The song sequener doesn't support recording.
         */
        virtual void record(bool state);

        /**
         * @brief Stop playing the currently active song.
         *
         * Stop playing the currently active song.
         */
        virtual void stop();

        /**
         * @brief Jumps to a specific beat in the part.
         *
         * Jumps to a specific beat in the part.
         * @param beat The beat to jump to.
         */
        virtual void jump(int beat);

        /**
         * @brief The song sequener doesn't support recording.
         *
         * The song sequener doesn't support recording.
         */
        virtual bool isRecordArmed();

        /**
         * @brief Sets the current step of the song.
         *
         * Sets the current step of the song.
         * @param s The new step, note that this step must exists in the currently active song.
         */
        virtual void setActiveStep(SongStep& s);

        /**
         * @brief Gets the song step the sequencer's playing.
         *
         * Gets the song step the sequencer's playing.
         * @return The Song Step the sequencers playing.
         */
        virtual SongStep& getActiveStep();

        /**
         * @brief Sets the tempo of the sequencer.
         *
         * Sets the tempo of the sequencer.
         * @param tempo The new tempo of the sequencer.
         */
        virtual void setTempo(int tempo);

        /**
         * @brief Gets the tempo of the sequencer.
         *
         * Gets the tempo of the sequencer.
         * @return The sequencers tempo.
         */
        virtual int getTempo();

        /**
         * @brief Gets the current location in the song in beats.
         *
         * Gets the current location in the song in beats.
         * @return The current location in beats.
         * @note That the location starts from the very first step of the song,
         * ie the location's not relitive to the step that's currently playing.
         */
        virtual int getBeat();

        /**
         * @brief Gets the length of the currently active song.
         *
         * Gets the length of the currently active song.
         * @return The length in beats.
         */
        virtual int getLength();

        /**
         * @brief Sets the play click state of the sequencer.
         *
         * Sets the play click state of the sequencer.
         * The play click state determines whether or not the sequencer will play a click track
         * when its playing back MIDI Events.
         * @param click The new click state.
         */
        virtual void setClickPlay(bool click);

        /**
         * @brief Gets the play click state of the sequencer.
         *
         * Gets the play click state of the sequencer.
         * @return The play click state of the sequencer.
         */
        virtual bool getClickPlay();

        /**
         * @brief Sets the record click state of the sequencer.
         *
         * Sets the record click state of the sequencer.
         * The record click state determines whether or not the sequencer will play a click track
         * when its recording MIDI Events.
         * @param click The new click state.
         */
        virtual void setClickRecord(bool click);

        /**
         * @brief Gets the record click state of the sequencer.
         *
         * Gets the record click state of the sequencer.
         * @return The record click state of the sequencer.
         */
        virtual bool getClickRecord();


        /**
         * @brief Sets the click interval of the sequencer.
         *
         * The Click Interval is how fast the click is and
         * has a number of different values these are
         * 1/2, 1/4, 1/8, 1/16, 1/24, 1/32, 1/48, 1/64.
         * @param interval The Click Interval of the sequencer, note that this is actually the denominator of the real interval (ie for the interval 1/4 the interval is 4).
         */
        virtual void setClickInterval(int interval);

        /**
         * @brief Gets the Click Interval of the sequencer.
         *
         * Gets the Click Interval of the sequencer.
         * @return The click interval.
         */
        virtual int getClickInterval();

        /**
         * @brief Sets how many beats to count in.
         *
         * Sets how many beats to count in.
         * @param count_in The number of beats.
         */
        virtual void setCountin(int count_in);

        /**
         * @brief Gets how many beats to count in.
         *
         * Gets how many beats to count in.
         * @return The number of beats.
         */
        virtual int getCountin();

        /**
         * @brief Gets whether or not the sequencer is playing the count in part, or a real part.
         *
         * Gets whether or not the sequencer is playing the count in part, or a real part.
         * @return True if the sequencer is playing the count in, otherwise false.
         */
        virtual bool isCountin();

        /**
         * @brief Sets whether or not the sequencer will Loop.
         *
         * Sets whether or not the sequencer will replay the current song when it gets to the end,
         * ie loop.
         * @param loop whether or not the sequencer will loop back to the beginning of the song.
         */
        virtual void setLoop(bool loop);

        /**
         * @brief Gets whether or not the sequencer will Loop.

         *
         * Gets whether or not the sequencer is set to replay the current song when it gets to the end (loop).
         * @return The loop state.
         */
        virtual bool getLoop();

        virtual void addSong();

        virtual void removeSong();

        /**
         * @brief Adds a song step to the end of the song.
         *
         * Adds a song step to the end of the song.
         * @param part The part contained in the song step that's added.
         */
        virtual void addStep(Part* part);

        /**
         * @brief Removes a specific song step from the song.
         *
         * Removes a specific song step from the song.
         * @param loc Identifies the song step to remove.
         */
        virtual void removeStep(SongStepIterator loc);

        /**
         * @brief Removes all song steps from the song.
         *
         * Removes all song steps from the song.
         */
        virtual void clear();

        /**
         * @brief Moves a specific song step to another location in the song
         *
         * Moves a specific song step to another location in the song (used to rearange the song).
         * @param source The song step to move.
         * @param dest Inserts source infront of dest.
         */
        virtual void moveStep(SongStepIterator source, SongStepIterator dest);

        /**
         * @brief Sets the active song.
         *
         * Sets the active song.
         * @param i The new active song.
         */
        virtual void setActiveSong(int i);

        /**
         * @brief Gets the song that's currently playing
         *
         * Gets the song that's currently playing (the active song).
         * @return The active song.
         */
        virtual Song* getSong();

        /**
         * @brief ets the Enabled state of the Sequencer.
         *
         * Sets the Enabled state of the Sequencer.
         * @param enable The new enabled state.
         */
        void setEnabled(bool enable);

        /**
         * @brief Gets the Enabled state of the Sequencer.
         *
         * Gets the Enabled state of the Sequencer.
         * @return If the sequencer is enabled or not.
         */
        bool getEnabled();

        /**
         * @see MIDIToolkit::Observer::onEvent.
         */
        virtual void onEvent(int id, void* params);
    protected:
        MIDIToolkit::Sequencer* sequencer;
        SongSystem* songSystem;
        SongStepIterator iterator;
        Part* m_CountinPart;
        SongStep* m_Step;
        bool m_PlayingClick;
        bool m_Loop;
        bool m_Enabled;
    };
}

#endif  //_SONGSEQUENCER_H
