/*
   Virtual MIDI Multitrack Recorder
   Copyright (c) 2006 MIDI Team

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/

/**
   @file PartSequencer.hpp
   @author Charles Weld
   @brief Declaration of class PartSequencer, part of Virtual MIDI Multitrack Recorder
*/

#ifndef _PARTSEQUENCER_H
#define _PARTSEQUENCER_H

#include "ISequencer.hpp"
#include "SongStep.hpp"
#include "PartSystem.hpp"

// from midi toolkit
#include "Sequencer.hpp"
#include "Observer.hpp"
#include "Observable.hpp"

namespace Vimmer
{
    /**
     * @brief Represents a Part Sequencer.
     *
     * A Part Sequencer is a sequencer specifically designed to play back and record
     * parts. This sequencer also provides a number of facilities for editing parts,
     * the interface is defined here so that we can keep the sequencer and store in sinc.
     *
     * @see Vimmer::Part
     * @ingroup sequencer
     */
    class PartSequencer : public ISequencer, public Observer, public Observable
    {
    public:
        /**
         * @brief Creates a new Part Sequencer
         *
         * Creates a new Part Sequencer that uses a given MIDITookit Sequencer and
         * Part System.
         * @param sequencer The sequencer to use to do the sequencing.
         * @param partSystem The part system to use (were it gets it's parts from).
         */
        PartSequencer(MIDIToolkit::Sequencer* sequencer, PartSystem* partSystem);

        /**
         * @brief Cleans up the part sequencer.
         *
         * Cleans up the part sequencer.
         */
        virtual ~PartSequencer();


        /**
         * @brief Activates the sequencer.
         *
         * This allows this sequencer to take control of the actual MIDIToolkit Sequencer
         * @see MIDIToolkit::Sequencer and therefore one MIDIToolkit Sequencer can be used
         * by multiple Vimmer Sequencers.
         */
        virtual void activate();

        /**
         * @brief Gets the state of the sequencer
         *
         * Gets the state of the sequencer, ie if it's playing, stopped, or recording.
         * @return The sequencer's state.
         */
        virtual MIDIToolkit::SequencerStates::SequencerState getState();

        /**
         * @brief Start playing the currently active part.
         *
         * Start playing the currently active part.
         */
        virtual void play();

        /**
         * @brief Stop playing the currently active part.
         *
         * Stop playing the currently active part.
         */
        virtual void stop();

        /**
         * @brief Sets whether the sequencer will record incoming MIDI Events.
         *
         * Sets whether the sequencer will record incoming MIDI Events.
         * @param state The new recording state of the sequencer.
         */
        virtual void record(bool state);

        /**
         * @brief Get's whether or not recording is armed.
         *
         * Get's whether or not recording is armed.
         * @return The recording state of the sequencer.
         */
        virtual bool isRecordArmed();

        /**
         * @brief Jumps to a specific beat in the part.
         *
         * Jumps to a specific beat in the part.
         * @param beat The beat to jump to.
         */
        virtual void jump(int beat);

        /**
         * @brief Gets the current location in beats.
         *
         * Gets the current location in beats.
         * @return The current location in beats.
         */
        virtual int getBeat();

        /**
         * @brief Gets the length of the currently active part.
         *
         * Gets the length of the currently active part.
         * @return The length in beats.
         */
        virtual int getLength();

        /**
         * @brief Sets the tempo of the sequencer.
         *
         * Sets the tempo of the sequencer.
         * @param tempo The new tempo of the sequencer.
         */
        virtual void setTempo(int tempo);

        /**
         * @brief Gets the tempo of the sequencer.
         *
         * Gets the tempo of the sequencer.
         * @return The sequencers tempo.
         */
        virtual int getTempo();

        /**
         * @brief Gets the part the sequencer's playing.
         *
         * Gets the part the sequencer's playing.
         * @return The part the sequencers playing.
         */
        virtual SongStep& getActiveStep();

        /**
         * @brief Sets whether or not the sequencer will loop.
         *
         * Sets whether or not the sequencer will replay the current part when it gets to the end,
         * ie loop.
         * @param loop whether or not the sequencer will loop back to the beginning of the part.
         */
        virtual void setLoop(bool loop);

        /**
         * @brief Gets whether or not the sequencer will loop.
         *
         * Gets whether or not the sequencer is set to replay the current part when it gets to the end (loop).
         * @return The loop state.
         */
        virtual bool getLoop();

        /**
         * @brief Sets the play click state of the sequencer.
         *
         * Sets the play click state of the sequencer.
         * The play click state determines whether or not the sequencer will play a click track
         * when its playing back MIDI Events.
         * @param click The new click state.
         */
        virtual void setClickPlay(bool click);

        /**
         * @brief Gets the play click state of the sequencer
         *
         * Gets the play click state of the sequencer
         * @return The play click state of the sequencer.
         */
        virtual bool getClickPlay();

        /**
         * @brief Sets the record click state of the sequencer.
         *
         * Sets the record click state of the sequencer.
         * The record click state determines whether or not the sequencer will play a click track
         * when its recording MIDI Events.
         * @param click The new click state.
         */
        virtual void setClickRecord(bool click);

        /**
         * @brief Gets the record click state of the sequencer.
         *
         * Gets the record click state of the sequencer.
         * @return The record click state of the sequencer.
         */
        virtual bool getClickRecord();


        /**
         * @brief Sets the click interval of the sequencer.
         *
         * The Click Interval is how fast the click is and
         * has a number of different values these are
         * 1/2, 1/4, 1/8, 1/16, 1/24, 1/32, 1/48, 1/64.
         * @param interval The Click Interval of the sequencer, note that this is actually the denominator of the real interval (ie for the interval 1/4 the interval is 4).
         */

        virtual void setClickInterval(int interval);

        /**
         * @brief Gets the Click Interval of the sequencer.
         *
         * Gets the Click Interval of the sequencer.
         * @return The click interval.
         */
        virtual int getClickInterval();

        /**
         * @brief Sets how many beats to count in.
         *
         * Sets how many beats to count in.
         * @param count_in The number of beats.
         */
        virtual void setCountin(int count_in);

        /**
         * @brief Gets how many beats to count in.
         *
         * Gets how many beats to count in.
         * @return The number of beats.
         */
        virtual int getCountin();

        /**
         * @brief Gets whether or not the sequencer is playing the count in part, or a real part.
         *
         * Gets whether or not the sequencer is playing the count in part, or a real part.
         * @return True if the sequencer is playing the count in, otherwise false.
         */
        virtual bool isCountin();

        /**
         * @brief Sets the Enabled state of the Sequencer
         *
         * Sets the Enabled state of the Sequencer
         * @param enable The new enabled state.
         */
        void setEnabled(bool enable);

        /**
         * @brief Gets the Enabled state of the Sequencer.
         *
         * Gets the Enabled state of the Sequencer.
         * @return If the sequencer is enabled or not.
         */
        bool getEnabled();

        // editing functions
        /**
         * @brief Sets the new length of the current part.
         *
         * Sets the new length of the current part.
         * @param length The new length of the current part.
         */
        void setLength(int length);

        /**
         * @brief Adds a part to the part system.
         *
         * Adds a part to the part system (defined here so that
         * we keep the sequencer and store in sync).
         */
        void addPart();

        /**
         * @brief Removes the current part from the part system.
         *
         * Removes the current part from the part system (defined here so that
         * we keep the sequencer and store in sync).
         */
        void removePart();

        /**
         * @brief Changes the currently active part.
         *
         * Changes the currently active part.
         * @param id The id of the new active part.
         */
        virtual void setActivePart(int id);

        /**
         * @see MIDIToolkit::Observer::onEvent.
         */
        virtual void onEvent(int id, void* params);

        /**
         * @brief Sets the over dub state.
         *
         * Sets weither or not overdubing is enabled or not.
         * Over dubing is basically that when looping and
         * overdub is on the sequencer won't turn off record
         * automatically at the end of the track.
         *
         * @param overDub Weither or not overdubbing is enabled/disabled.
         */
        virtual void setOverDub(bool overDub);

        /**
         * @brief Gets the over dub state.
         *
         * Gets weither or not overdubing is enabled or not.
         * Over dubing is basically that when looping and
         * overdub is on the sequencer won't turn off record
         * automatically at the end of the track.
         *
         * @return Weither or not overdubbing is enabled/disabled.
         */
        virtual bool getOverDub();
    private:
        MIDIToolkit::Sequencer* sequencer;
        SongStep* partLink;
        PartSystem* partSystem;
        bool m_Loop;
        bool m_Enabled;
        bool m_Record;
        Part* m_CountinPart;
        SongStep* m_Step;
        bool m_PlayingClick;
        int m_Tempo;
        bool m_OverDub;
    };
}

#endif  //_PARTSEQUENCER_H
