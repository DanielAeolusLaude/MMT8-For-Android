/*
   Virtual MIDI Multitrack Recorder
   Copyright (c) 2006 MIDI Team

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/

/**
   @file StringConverter.hpp
   @author Charles Weld
   @brief Declaration of class StringConverter, part of Virtual MIDI Multitrack Recorder
*/

#ifndef _STRINGCONVERTER_H
#define _STRINGCONVERTER_H

#include "MIDIToolkitPrerequisites.hpp"

namespace MIDIToolkit
{

/**
    @brief Provides number to string and string to number conversion services.

    @ingroup misc
*/

    class StringConverter
    {
    public:

	    /**
	     @brief Convert an int type to a String.

	     Convert an int type to a String.

	     @param Convert into the String
	     @return The converted int as a String.
	    */
        static String intToString(int num);

	    /**
	     @brief Convert a float type to a String.

	     Convert a float type to a String.

	     @param Convert into the String
	     @return The converted float as a String.
	    */
        static String floatToString(float num);

	    /**
	     @brief Convert an int type to a hex type into a String.

	     Convert an int type to a hex type into a String.

	     @param Convert into hex and the String
	     @return The converted int-to-hex as a String.
	    */
        static String intToHexString(int num);

	    /**
	     @brief Convert a String type to an int type into a String.

	     Convert a String type to an int type into a String.

	     @param Convert to int and the String
	     @return The converted String-to-int as a String.
	    */
        static int stringToInt(String num);

	    /**
	     @brief Convert a String type to a float type into a String.

	     Convert a String type to a float type into a String.

	     @param Convert to float and the String
	     @return The converted String-to-float as a String.
	    */
        static float stringToFloat(String num);

	    /**
	     @brief Convert a hex-String type to an int type into a String.

	     Convert a hex-String type to an int type into a String.

	     @param Convert to an int and the String
	     @return The converted hex-String-to-int as a String.
	    */
        static int hexStringToInt(String num);
    };
}

#endif
