/*
   Virtual MIDI Multitrack Recorder
   Copyright (c) 2006 MIDI Team

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/

/**
   @file Group.hpp
   @author David Wilson
   @brief Declaration of class Group, part of Virtual MIDI Multitrack Recorder
*/

#ifndef _GROUP_H
#define _GROUP_H

#include "Node.hpp"
#include "Entry.hpp"
#include "MIDIToolkitPrerequisites.hpp"

namespace MIDIToolkit
{

/**
    @brief Represents a group of configuration groups and entries.

    @ingroup config
*/
    class Group : public Node
    {
    public:

        /**
         @brief Creates a specific Group name.

         Creates a specific Group by Name.

         @param Create a new String.
         @return The created String name.
        */
        Group(String name="");

        /**
         @brief Destructor

         Destructor
        */
        virtual ~Group(){}



        /**
         @brief Add a new Group to this Group hierarchy.

         Add a new Group to this Group hierarchy.

         @param Create a new Group.
         @return The created Group name.
        */
        void addGroup(String name);

        /**
         @brief Add a new element with a given name to this Group.

         Add a new element with a given name to this Group.

         @param Add a new Element.
         @return The created Element String name.
         @return The created Element int value.
        */
        void addEntry(String name, String value);

        /**
         @brief Add a new element with a given name to this Group.

         Add a new element with a given name to this Group.

         @param name The name of the entity to add.
         @param value The value of the entity to add.
        */
        void addEntry(String name, int value);


        /**
         @brief Add a new element with a given name to this Group.

         Add a new element with a given name to this Group.

         @param name The name of the entity to add.
         @param value The value of the entity to add.
        */
        void addEntry(String name, bool value);


        /**
         @brief Add a reference to a specific Group within this Group.

         Add a reference to a specific Group within this Group.

         @param group The group to add.
        */
        void add(Group& group);

        /**
         @brief Add a reference to a specific Entry within this Group entry.

         Add a reference to a specific Entry within this Group entry.

         @param entry The entry to add.
        */
        void add(Entry& entry);

        /**
         @brief Remove a specific Group.

         Remove a specific Group.

         @param name The name of the group to remove.
        */
        void removeGroup(String name);

        /**
         @brief Remove a specific Entry from this Group.

         Remove a specific Entry from this Group.

         @param name The name of the Entry to remove.
        */
        void removeEntry(String name);

        /**
         @brief Removes all groups and entries form this group.

         Removes all groups and entries form this group.
        */
        void clear();

        /**
         @brief Gets a specific Group from this Group.

         Gets a specific Group from this Group.

         @param name The name of the group to get.
         @return The selected Group to get.
        */
        Group& getGroup(String name);

        /**
         @brief Gets a specific Entry from this Group.

         Gets a specific Entry from this Group.

         @param name The name of the Entry to get.
         @return The selected Entry to get.
        */
        Entry& getEntry(String name);

        /**
         @brief Gets a specific Entry from this Group.

         Gets a specific Entry from this Group.

         @param name The name of the Entry to get.
         @return The selected Entry to get.
        */
        Entry& operator[](String& name) {
            return getEntry(name);
        }

        /**
         @brief Gets a specific Entry from this Group.

         Gets a specific Entry from this Group.

         @param name The name of the Entry to get.
         @return The selected Entry to get.
        */
        Entry& operator[](const char* name) {
            return getEntry(name);
        }

        /**
         @brief Searches for a specific Group from this Group.

         Searches for a specific Group from this Group..

         @param Search for an existing Group.
        */
        GroupMapIterator getGroupIterator();

        /**
         @brief Searches for a specific Entry from this Group.

         Searches for a specific Entry from this Group.

         @param Search for an existing Entry.
        */
        EntryMapIterator getEntryIterator();

        /**
         @brief Get a reference to a specific XML element.

         Get a reference to a specific XML element.

         @param Get XML reference.
        */
        TiXmlElement* getXML();

        /**
         @brief Set a reference to a specific XML element.

         Set a reference to a specific XML element.

         @param elem The xml element to set.
         @return The selected Entry to get.
        */
        void setXML(TiXmlElement* elem);

    private:
        EntryMap entrys;
        GroupMap groups;

        /*
            // Group inherits this value from Node
            // (don't uncomment, otherwise you'll be defining it twice).
            String name;
        */

    };
}

#endif  //_GROUP_H
