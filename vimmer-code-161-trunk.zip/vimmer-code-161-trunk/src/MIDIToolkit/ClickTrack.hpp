/**
  * @ Project : ViMMeR - Virtual MIDI Multitrack Recorder
  * @ File Name : Filter.hpp
  * @ Date : 28/04/2006
  * @ Author : Charles, Dave, Jimi, Jon, and Matt.
  *
  * This program is free software; you can redistribute it and/or modify
  * it under the terms of the GNU General Public License as published by
  * the Free Software Foundation; either version 2 of the License, or
  * (at your option) any later version.
  *
  * This program is distributed in the hope that it will be useful,
  * but WITHOUT ANY WARRANTY; without even the implied warranty of
  * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  * GNU General Public License for more details.
  *
  * You should have received a copy of the GNU General Public License
  * along with this program; if not, write to the Free Software
  * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
  *
  */

/**
   @file   ClickTrack.hpp
   @author Charles Weld
   @brief  Declaration of the class ClickTrack.
*/

#ifndef _CLICK_TRACK_H_
#define _CLICK_TRACK_H_

#include <vector>

#include "MIDIToolkitPrerequisites.hpp"

using namespace std;

namespace MIDIToolkit
{
    /** @ingroup midiseq
     *  @brief Provides click (metronome) support.
     *
     *  ClickTrack allows a click at a number of different intervals
     *  (see setClickInterval(...) function). The interval represents how many
     *  times per beat a click is played.
     *
     *  ClickTrack can be enabled and disabled independently, for both playback
     *  and recording.
     *
     *  The play() function is called each time the Sequencer advances to the next
     *  pulse (a subdivision of a beat). The ClickTrack decides whether or not to
     *  play a "click", based on what the current pulse is and the interval the
     *  ClickTrack is set to.
     *
     */
    class ClickTrack
    {
    public:
        /**
         * Default constructor.
         */
        ClickTrack();

        /**
         * Destructor.
         */
        ~ClickTrack();

        /**
         * Plays a note every beat.
         */
        void play(ULong32 relative);

        /// Sets the interval to click to.
        /// (2, 4, 6, 8, 12, 16, 24, 32, 48, 64)
        void setClickInterval(int interval);

        /// Gets the interval to click to.
        /// (2, 4, 6, 8, 12, 16, 24, 32, 48, 64)
        int getClickInterval();

        /// converts: (0, 1, 2, 3,  4,  5,  6,  7,  8,  9)
        /// to:       (2, 4, 6, 8, 12, 16, 24, 32, 48, 64)
        static int getInterval(int click_id);

        /// converts: (2, 4, 6, 8, 12, 16, 24, 32, 48, 64)
        /// to:       (0, 1, 2, 3,  4,  5,  6,  7,  8,  9)
        static int getClickID(int click_interval);

    protected:

        //! Makes sure only one note_on / off is played per beat.
        bool played;

        //! The last beat that this occured.
        ULong32 lastBeat;

        /// Interval to click to.
        /// (2, 4, 6, 8, 12, 16, 24, 32, 48, 64)
        int clickInterval;
    };
}

#endif  //_FILTER_H
