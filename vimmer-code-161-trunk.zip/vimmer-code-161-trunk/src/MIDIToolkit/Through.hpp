/*
   Virtual MIDI Multitrack Recorder
   Copyright (c) 2006 MIDI Team

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU Lesser General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU Lesser  General Public License for more details.

   You should have received a copy of the GNU Lesser General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/

/**
   @file Through.hpp
   Charles Weld, David Wilson, James Brown, Jonathan Van Rossum, and Matthew Harrold
   @brief Declaration of class Through, part of Virtual MIDI Multitrack Recorder
*/

#ifndef _THROUGH_H
#define _THROUGH_H

#include "Modulator.hpp"
#include "MIDIEvent.hpp"

namespace MIDIToolkit
{
    /// @brief Through provides through MIDI Services to MIDIToolkit.
    /**
     * Through services refers to the ability to imediatly pass
     * on incomming MIDI Events from the InputFilter through to
     * the OutputFilter and finally out the Output Port.
     *
     * @ingroup mididev
     */
    class Through : public Modulator
    {
    public:
        /// @brief Default Constructor.
        /**
         * Default Constructor.
         */
        Through();

        /// @brief Default Distructor.
        /**
         * Default Distructor.
         */
        virtual ~Through();

        /**
         * @brief This is called when the Analyser receives a MIDI Event and thus a message.
         *
         * This is called when the Analyser receives a MIDI Event and thus a message.
         * @param evt The MIDI Event.
         */
        virtual void receive(MIDIEvent* evt);

        /**
         * @brief Enables Through.
         *
         * Enables Through.
         */
        virtual void enable();

        /**
         * @brief Disables Through.
         *
         * Disables Through.
         */
        virtual void disable();

        /**
         * @brief Gets Through's state.
         *
         * Gets Through's state.
         * @return True if through is enabled, otherwise false.
         */
        bool isEnabled();
    private:
        //! Holds throughs enabled state.
        bool enabled;
    };
}

#endif  //_THROUGH_H
