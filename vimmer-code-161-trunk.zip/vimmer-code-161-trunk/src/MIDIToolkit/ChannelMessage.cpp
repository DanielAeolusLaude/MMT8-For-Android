/*
   Virtual MIDI Multitrack Recorder
   Copyright (c) 2006 MIDI Team

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU Lesser General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU Lesser  General Public License for more details.

   You should have received a copy of the GNU Lesser General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/

/**
   ChannelMessage.cppile ChannelMessage.cpp
   Charles Weld, David Wilson, James Brown, Jonathan Van Rossum, and Matthew Harrold
   @brief Declaration of class ChannelMessage, part of Virtual MIDI Multitrack Recorder
*/

#include "ChannelMessage.hpp"
#include "MessageTypes.hpp"

// DEBUGGING ONLY
#include <iostream>

namespace MIDIToolkit
{
    ChannelMessage::ChannelMessage(ChannelCommand command, unsigned long midiChannel, unsigned long data1)
        : ShortMessage::ShortMessage()
    {
        type = MessageTypes::CHANNEL_MESSAGE;
        this->setCommand(command);
        this->setChannel(midiChannel);
        this->setData1(data1);
    }

    ChannelMessage::ChannelMessage(unsigned long msg)
        : ShortMessage::ShortMessage()
    {
        type = MessageTypes::CHANNEL_MESSAGE;
        message = msg;
    }

    ChannelMessage::ChannelMessage(ChannelCommand command, unsigned long midiChannel, unsigned long data1, unsigned long data2)
        : ShortMessage::ShortMessage()
    {
        type = MessageTypes::CHANNEL_MESSAGE;
        this->setCommand(command);
        this->setChannel(midiChannel);
        this->setData1(data1);
        this->setData2(data2);
    }

    ChannelMessage::~ChannelMessage()
    {

    }

    MIDIMessage* ChannelMessage::clone()
    {
        return new ChannelMessage(message);
    }

    unsigned long ChannelMessage::unpackChannel(unsigned long msg)
    {
        return (msg & DataMask & CommandMask);
    }

    unsigned long ChannelMessage::packChannel(unsigned long channel, unsigned long msg)
    {
        return (msg & MidiChannelMask) | channel;
    }

    ChannelCommand ChannelMessage::unpackCommand(unsigned long msg)
    {
        return (ChannelCommand)(msg & DataMask & MidiChannelMask);
    }

    unsigned long ChannelMessage::packCommand(ChannelCommand command, unsigned long msg)
    {
        return (msg & CommandMask) | command;
    }

    int ChannelMessage::dataBytesPerType(ChannelCommand command)
    {
        int result;

        if(command == ChannelCommands::ChannelPressure ||
            command == ChannelCommands::ProgramChange)
        {
            result = 1;
        }
        else
        {
            result = 2;
        }

        return result;
    }

    unsigned long ChannelMessage::getChannel()
    {
        return (message & DataMask & CommandMask);
    }

    void ChannelMessage::setChannel(unsigned long channel)
    {
        message = (message & MidiChannelMask) | channel;
    }

    ChannelCommand ChannelMessage::getCommand()
    {
        return (ChannelCommand)(message & DataMask & MidiChannelMask);
    }

    void ChannelMessage::setCommand(ChannelCommand command)
    {
        message = (message & CommandMask) | command;
    }


    unsigned long ChannelMessage::getData1()
    {
        return getPackageData1();
    }

    void ChannelMessage::setData1(unsigned long data)
    {
        setPackageData1(data);
    }

    unsigned long ChannelMessage::getData2()
    {
        return getPackageData2();
    }

    void ChannelMessage::setData2(unsigned long data)
    {
        setPackageData2(data);
    }

    void ChannelMessage::print()
    {
        std::cout << "CHANNEL: ";
        switch (getCommand())
        {
            case (ChannelCommands::NoteOn):          std::cout << "NoteOn"; break;
            case (ChannelCommands::NoteOff):         std::cout << "NoteOff"; break;
            case (ChannelCommands::PolyPressure):    std::cout << "PolyPressure"; break;
            case (ChannelCommands::Controller):      std::cout << "Controller"; break;
            case (ChannelCommands::ProgramChange):   std::cout << "ProgramChange"; break;
            case (ChannelCommands::ChannelPressure): std::cout << "ChannelPressure"; break;
            case (ChannelCommands::PitchWheel):      std::cout << "PitchWheel"; break;
            default: std::cout << "(Unknown)"; break;
        }
        std::cout << "St(" << getStatus() << ") Ch(" << getChannel() << ") D1(" << getData1() << ") D2(" << getData2() << ").";
    }

    bool ChannelMessage::isA(MessageType msgType)
    {
        return (msgType == MessageTypes::CHANNEL_MESSAGE || msgType==MessageTypes::SHORT_MESSAGE || msgType==MessageTypes::MIDI_MESSAGE);
    }


}
