/*
   Virtual MIDI Multitrack Recorder
   Copyright (c) 2006 MIDI Team

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/

/**
   @file MIDIToolkitPrerequisites.hpp
   @author Charles Weld
   @brief The package MIDIToolkit's Prerequistes (Typedefs etc).
*/

#ifndef MIDITOOLKIT_MIDITOOLKITPREREQUISITES_H_
#define MIDITOOLKIT_MIDITOOLKITPREREQUISITES_H_

#include <vector>
#include <list>
#include <string>
#include <map>
#include <wchar.h>

namespace MIDIToolkit
{
    // forward declarations
    class Group;
    class Entry;
    class Log;
    class IInputPort;
    class IOutputPort;
    class ChannelMessage;
    class ShortMessage;
    class MIDIEvent;
    class Track;
    class Analyser;
    class Observer;

    // typedefs
    /// @ingroup midibase
    typedef int MessageType;

    /// @ingroup midibase
    typedef unsigned long ChannelCommand;

    /// @ingroup midibase
    typedef unsigned long ControllerType;

    /// @ingroup midibase
    typedef std::list<Observer*> ObserverList;

    /// @ingroup midibase
    typedef std::list<Observer*>::iterator ObserverIterator;

    /// @ingroup midibase
    typedef std::list<Analyser*> AnalyserList;

    /// @ingroup midibase
    typedef std::list<Analyser*>::iterator AnalyserIterator;

    /// @ingroup midibase
    typedef std::string String;

    /// @ingroup midibase
    typedef std::map<String,Group> GroupMap;

    /// @ingroup midibase
    typedef std::map<String,Entry> EntryMap;

    /// @ingroup midibase
    typedef std::map<String,Group>::iterator GroupMapIterator;

    /// @ingroup midibase
    typedef std::map<String,Entry>::iterator EntryMapIterator;

    /// @ingroup midibase
    typedef std::map<String, Log*> LogMap;

    /// @ingroup midibase
    typedef std::map<String, Log>::iterator LogMapIterator;

    /// @ingroup midibase
    typedef String InputCaps;

    /// @ingroup midibase
    typedef String OutputCaps;

    /// @ingroup midibase
    typedef std::vector<IInputPort> InputPortVector;

    /// @ingroup midibase
    typedef std::vector<IOutputPort> OutputPortVector;

    /// @ingroup midibase
    typedef std::list<ChannelMessage*>::iterator ChannelMessageIterator;

    /// @ingroup midibase
    typedef std::list<ChannelMessage*> ChannelMessageList;

    /// @ingroup midibase
    typedef std::list<ShortMessage*>::iterator ShortMessageIterator;

    /// @ingroup midibase
    typedef std::list<ShortMessage*> ShortMessageList;

    /// @ingroup midibase
    typedef std::list<MIDIEvent*>::iterator MIDIEventIterator;

    /// @ingroup midibase
    typedef std::list<MIDIEvent*> MIDIEventList;

    /// @ingroup midibase
    typedef std::vector<Track> TrackVector;

    /// @ingroup midibase
    typedef std::vector<bool> BoolVector;

    /// @ingroup midibase
    static const unsigned int PULSES_PER_BEAT = 384;

    typedef char            Char;
    typedef unsigned char   Bool;
    typedef unsigned char   UChar;
    typedef int             Int32;
    typedef unsigned int    UInt32;
    typedef short           Int16;
    typedef unsigned short  UInt16;
    typedef unsigned long ULong32;

    #define True  ((Bool)1)
    #define False ((Bool)0)
    #define _T(m) MIDIToolkit::String(m)
}

#endif
