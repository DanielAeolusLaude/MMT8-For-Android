/*
   Virtual MIDI Multitrack Recorder
   Copyright (c) 2006 MIDI Team

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU Lesser General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU Lesser  General Public License for more details.

   You should have received a copy of the GNU Lesser General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/

/**
   IInputPort.hppile IInputPort.hpp
   Charles Weld, David Wilson, James Brown, Jonathan Van Rossum, and Matthew Harrold
   @brief Declaration of class IInputPort, part of Virtual MIDI Multitrack Recorder
*/

#ifndef _IINPUTPORT_H
#define _IINPUTPORT_H

#include "MIDIToolkitPrerequisites.hpp"
#include "Generator.hpp"

namespace MIDIToolkit
{
    /**
     * @brief Defines the interface that all Input Port's must inherit.
     *
     * Defines the interface that all Input Port's must inherit.
     * An Input Port is a MIDI Device that allows the user to receive MIDI Events.
     */
    /// @ingroup midiport
    class IInputPort : public Generator
    {
    public:
        /**
         * @brief Destructor
         *
         * Destructor.
         */
        virtual ~IInputPort(){}

        /**
         * @brief Opens a Input Port with a given ID.
         *
         * Opens a Input Port with a given ID.
         * @param port_id The port's id.
         */
        virtual void open(int port_id) = 0;

        /**
         * @brief Closes the Input Port.
         *
         * Closes the Input Port.
         */
        virtual void close() = 0;

        /**
         * @brief Starts the Input Port.
         *
         * Starts the Input Port.
         */
        virtual void start() = 0;

        /**
         * @brief Stops the Input Port.
         *
         * Stops the Input Port.
         */
        virtual void stop() = 0;

        /**
         * @brief Resets the Input Port.
         *
         * Resets the Input Port.
         */
        virtual void reset() = 0;

        /**
         * @brief Gets the name of a given port identified by an id.
         *
         * Gets the name of a given port identified by an id.
         * @param dev The id of the port.
         * @return The name of the port.
         */
        virtual String getPortName(int dev) = 0;

        /**
         * @brief Gets the number of Input Ports available.
         *
         * Gets the number of Input Ports available.
         * @return The number of Input Ports.
         */
        virtual int getNumPorts() = 0;

        /**
         * @brief Gets the Port Number of this Port.
         *
         * Gets the Port Number of this Port.
         */
        virtual int getPortNumber() = 0;
    };
}

#endif  //_IINPUTPORT_H
