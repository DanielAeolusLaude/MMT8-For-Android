/*
   Virtual MIDI Multitrack Recorder
   Copyright (c) 2006 MIDI Team

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU Lesser General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU Lesser  General Public License for more details.

   You should have received a copy of the GNU Lesser General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/

/**
   @file Win32InputPort.hpp
   Charles Weld, David Wilson, James Brown, Jonathan Van Rossum, and Matthew Harrold
   @brief Declaration of class Win32InputPort, part of Virtual MIDI Multitrack Recorder
*/

#ifndef _WIN32INPUTPORT_H
#define _WIN32INPUTPORT_H

#include "MIDIToolkitPrerequisites.hpp"
#include "InputPort.hpp"
#include <windows.h>

namespace MIDIToolkit
{
    /**
     * The Win32InputPort class provides Windows32 Support for Input Ports.
     */
    /// @ingroup midiport
    class Win32InputPort : public InputPort
    {
    public:
        /**
         * @brief Creates a new closed Input Port.
         *
         * Creates a new closed Input Port.
         * Note that this Input Port isn't open,
         * and is therefore not receiving any MIDI Events.
         */
        Win32InputPort();

        /**
         * @brief Creates a new open Input Port.
         *
         * Creates a new open Input Port.
         * @param port_id The id of the Port to open.
         */
        Win32InputPort(int port_id);

        /**
         * @brief Destructor.
         *
         * Destructor.
         */
        virtual ~Win32InputPort();

        /**
         * @see IInputPort::open(int)
         */
        virtual void open(int port_id);

        /**
         * @see IInputPort::close()
         */
        virtual void close();

        /**
         * @see IInputPort::start()
         */
        virtual void start();

        /**
         * @see IInputPort::stop()
         */
        virtual void stop();

        /**
         * @see IInputPort::reset()
         */
        virtual void reset();

        /**
         * @see IInputPort::getPortName()
         */
        virtual String getPortName(int port);

        /**
         * @see IInputPort::getNumPorts()
         */
        virtual int getNumPorts();

        /**
         * @brief This is called back by Windows when the Win32 Input Device that was opened receives
         * a MIDI Event.
         *
         * This is called back by Windows when the Win32 Input Device that was opened receives
         * a MIDI Event.
         */
        virtual void midiCallback(HMIDIIN handle, UINT uMsg, DWORD dwParam1, DWORD dwParam2);
    protected:
        // windows centric
        HMIDIIN			handle;
        MIDIHDR			midiHdr;

    };
}

#endif  //_INPUTPORT_H
