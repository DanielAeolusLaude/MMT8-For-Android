/*
   Virtual MIDI Multitrack Recorder
   Copyright (c) 2006 MIDI Team

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/

/**
   Entry.cppile Entry.cpp
   Charles Weld, David Wilson, James Brown, Jonathan Van Rossum, and Matthew Harrold
   @brief Declaration of class Entry, part of Virtual MIDI Multitrack Recorder
*/

#include "Entry.hpp"
#include "StringConverter.hpp"

namespace MIDIToolkit
{

    Entry::Entry(String n, String v)
    {
        name = n;
        value = v;
        logger = LogManager::getSingleton();
    }

    void Entry::setValue(String val)
    {
        value = val;
    }

    String Entry::getStringValue()
    {
        return value;
    }

    void Entry::setValue(int val)
    {
        value = StringConverter::intToString(val);
    }

    int Entry::getIntValue()
    {
        return StringConverter::stringToInt(value);
    }

    void Entry::setValue(float val)
    {
        value = StringConverter::floatToString(val);
    }

    float Entry::getFloatValue()
    {
        return StringConverter::stringToFloat(value);
    }

    void Entry::setValue(bool val)
    {
        if(val)
            value = "true";
        else
            value = "false";
    }

    bool Entry::getBoolValue()
    {
        if(value == _T("true"))
            return true;
        else
            return false;
    }

    TiXmlElement* Entry::getXML()
    {
        TiXmlElement* xEntry = new TiXmlElement("entry");
        xEntry->SetAttribute("name", getName());
        xEntry->SetAttribute("value", getStringValue());

        return xEntry;
    }

    void Entry::setXML(TiXmlElement* elem)
    {
        setName(elem->Attribute("name"));
        setValue(_T(elem->Attribute("value")));
        logger->log(_T("Loaded Entry[") + getName() + _T("]=") + getStringValue());
    }

}
