/*
   Virtual MIDI Multitrack Recorder
   Copyright (c) 2006 MIDI Team

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU Lesser General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU Lesser  General Public License for more details.

   You should have received a copy of the GNU Lesser General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/

/**
   @file Device.cpp
   Charles Weld, David Wilson, James Brown, Jonathan Van Rossum, and Matthew Harrold
   @brief Declaration of class Device, part of Virtual MIDI Multitrack Recorder
*/

#include "Device.hpp"
// for now we only allow win32 api ports
#include "Win32InputPort.hpp"
#include "Win32OutputPort.hpp"
#include "InputFilter.hpp"
#include "OutputFilter.hpp"
#include "Through.hpp"
#include "Events.hpp"

namespace MIDIToolkit
{
    Device::Device()
    {
        logger = LogManager::getSingleton();

        // create all components
        m_InputFilter = new InputFilter();
        m_OutputFilter = new OutputFilter();
        m_Through = new Through();
        m_InputPort = new Win32InputPort();
        m_OutputPort = new Win32OutputPort();

        // link them together.
        m_InputPort->connect(m_InputFilter);
        m_InputFilter->connect(m_Through);
        m_Through->connect(m_OutputFilter);
        m_OutputFilter->connect(m_OutputPort);
    }

    Device::~Device()
    {
        delete m_InputFilter;
        delete m_OutputFilter;
        delete m_Through;
        delete m_InputPort;
        delete m_OutputPort;
    }

    void Device::setInput(int id)
    {
        m_InputPort->open(id);
        start();
    }

    int Device::getInput()
    {
        return m_InputPort->getPortNumber();
    }

    void Device::setOutput(int id)
    {
        m_OutputPort->open(id);
        start();
    }

    int Device::getOutput()
    {
        return m_OutputPort->getPortNumber();
    }

    String Device::getInputName()
    {
        if(m_InputPort->getPortNumber()!=-1)
            return m_InputPort->getPortName(m_InputPort->getPortNumber());
        else
            return String("NONE");
    }

    String Device::getOutputName()
    {
        if(m_OutputPort->getPortNumber() != -1)
            return m_OutputPort->getPortName(m_OutputPort->getPortNumber());
        else
            return String ("NONE");
    }

    int Device::getInputCount()
    {
        return m_InputPort->getNumPorts();
    }

    int Device::getOutputCount()
    {
        return m_OutputPort->getNumPorts();
    }

    PortVector Device::getInputs()
    {
        PortVector ports;
        ports.resize(m_InputPort->getNumPorts());
        int size =m_InputPort->getNumPorts();
        for(int i=0;i<size;++i)
        {
            ports[i] = m_InputPort->getPortName(i);
        }
        return ports;
    }

    PortVector Device::getOutputs()
    {
        PortVector ports;
        ports.resize(m_OutputPort->getNumPorts());
        int size =m_OutputPort->getNumPorts();
        for(int i=0;i<size;++i)
        {
            ports[i] = m_OutputPort->getPortName(i);
        }
        return ports;
    }

    void Device::start()
    {
        m_InputPort->start();
    }

    void Device::stop()
    {
        m_InputPort->stop();
    }

    void Device::reset()
    {
        m_InputPort->reset();
    }

    void Device::receive(MIDIEvent* evt)
    {
        m_OutputFilter->receive(evt);
    }

     void Device::connect(Analyser* a)
    {
        raiseEvent(Events::SEQUENCER_ACTIVITY_MIDI_OUT);
        m_InputFilter->connect(a);
    }

    void Device::disconnect(Analyser* a)
    {
        m_InputFilter->disconnect(a);
    }

    void Device::disconnectAll()
    {
        m_InputFilter->disconnectAll();
        m_InputFilter->connect(m_Through);
    }

    void Device::enableThru()
    {
        m_Through->enable();
        raiseEvent(Events::THRU_STATE_CHANGED);
    }

    void Device::disableThru()
    {
        m_Through->disable();
        raiseEvent(Events::THRU_STATE_CHANGED);
    }

    bool Device::isThruEnabled()
    {
        return m_Through->isEnabled();
    }

    void Device::addObserver(Observer* o)
    {
        Observable::addObserver(o);

        m_InputFilter->addObserver(o);
        m_OutputFilter->addObserver(o);
    }


    InputFilter* Device::getInputFilter()
    {
        return m_InputFilter;
    }
}
