/*
   Virtual MIDI Multitrack Recorder
   Copyright (c) 2006 MIDI Team

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU Lesser General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU Lesser  General Public License for more details.

   You should have received a copy of the GNU Lesser General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/

/**
   ShortMessage.cppile ShortMessage.cpp
   Charles Weld, David Wilson, James Brown, Jonathan Van Rossum, and Matthew Harrold
   @brief Declaration of class ShortMessage, part of Virtual MIDI Multitrack Recorder
*/

#include "ShortMessage.hpp"
#include "MessageTypes.hpp"

// DEBUGGING ONLY
#include <iostream>

namespace MIDIToolkit
{
    unsigned long ShortMessage::getStatus()
    {
        return message & DataMask;
    }

    unsigned long ShortMessage::getMessage()
    {
        return message;
    }

    void ShortMessage::setStatus(unsigned long status)
    {
        message = (message & StatusMask) | status;
    }

    unsigned long ShortMessage::getPackageData1()
    {
        return (message & ~Data1Mask) >> Shift;
    }

    void ShortMessage::setPackageData1(unsigned long data1)
    {
        message = (message & Data1Mask) | (data1 << Shift);
    }

    unsigned long ShortMessage::getPackageData2()
    {
        return (message & ~Data2Mask) >> (Shift * 2);
    }

    void ShortMessage::setPackageData2(unsigned long data2)
    {
        message = (message & Data2Mask) | (data2 << (Shift * 2));
    }

    ShortMessage::ShortMessage()
    {
        message = 0;
        type = MessageTypes::SHORT_MESSAGE;
    }

    ShortMessage::~ShortMessage()
    {

    }

    unsigned long ShortMessage::unpackStatus(unsigned long msg)
    {
        return msg & DataMask;
    }

    unsigned long ShortMessage::packStatus(unsigned long status, unsigned long msg)
    {
        return (msg & StatusMask) | status;
    }

    unsigned long ShortMessage::unpackData1(unsigned long msg)
    {
        return (msg & ~Data1Mask) >> Shift;
    }

    unsigned long ShortMessage::packData1(unsigned long data1, unsigned long msg)
    {
        return (msg & Data1Mask) | (data1 << Shift);
    }

    unsigned long ShortMessage::unpackData2(unsigned long msg)
    {
        return (msg & ~Data2Mask) >> (Shift * 2);
    }

    unsigned long ShortMessage::packData2(unsigned long data2, unsigned long msg)
    {
        return (msg & Data2Mask) | (data2 << (Shift * 2));
    }

    void ShortMessage::print()
    {
        std::cout << "MIDI SHORT: UNKNOWN";
    }

    bool ShortMessage::isA(MessageType msgType)
    {
        return (msgType==MessageTypes::SHORT_MESSAGE || msgType==MessageTypes::MIDI_MESSAGE);
    }


}
