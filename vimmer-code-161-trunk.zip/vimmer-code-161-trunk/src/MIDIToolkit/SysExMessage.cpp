/*
   Virtual MIDI Multitrack Recorder
   Copyright (c) 2006 MIDI Team

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU Lesser General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU Lesser  General Public License for more details.

   You should have received a copy of the GNU Lesser General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/

/**
   SysExMessage.cppile SysExMessage.cpp
   Charles Weld, David Wilson, James Brown, Jonathan Van Rossum, and Matthew Harrold
   @brief Declaration of class SysExMessage, part of Virtual MIDI Multitrack Recorder
*/

#include "SysExMessage.hpp"
#include "MessageTypes.hpp"

namespace MIDIToolkit
{
    MIDIMessage* SysExMessage::clone()
    {
        return NULL;
    }

    bool SysExMessage::isA(MessageType msgType)
    {
        return (msgType == MessageTypes::SYS_EX_MESSAGE || msgType==MessageTypes::MIDI_MESSAGE);
    }
}
