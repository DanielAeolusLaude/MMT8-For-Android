/*
   Virtual MIDI Multitrack Recorder
   Copyright (c) 2006 MIDI Team

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/

/**
   @file Exception.hpp
   @author Charles Weld
   @brief Declaration of class Exception, part of Virtual MIDI Multitrack Recorder
*/

#ifndef _EXCEPTION_H
#define _EXCEPTION_H

#include "MIDIToolkitPrerequisites.hpp"

// guard macros
#define VMMR_EXCEPT(id, desc) throw Exception(id, desc, "__FUNC__");

namespace MIDIToolkit
{
    /**
    @brief Represents a general Exception.

    @ingroup err
    */
    class Exception
    {
    public:

        /**
         @brief Create a new Exception.

         Create a new Exception.

         @param Exception id int value.
         @param Exception String description.
         @param xception String source.
         @return The created Exception.
        */
        Exception(int id, String description, String source);

        /**
         @brief Desctructor.

         Desctructor.
        */
        virtual ~Exception();

        /**
         @brief Get the description String of this Exception.

         Get the description String of this Exception.
        */
        virtual String getDescription();

        /**
         @brief Get the source String of this Exception.

         Get the source String of this Exception.
        */
        virtual String getSource();

        /**
         @brief Get the ID int value of this Exception.

         Get the ID int value of this Exception.
        */
        virtual int getID();

    private:
        String description;
        String source;
        int id;
    };

    /**
     * Guard.
     */
}

#endif  //_EXCEPTION_H
