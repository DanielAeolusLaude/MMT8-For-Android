/*
   Virtual MIDI Multitrack Recorder
   Copyright (c) 2006 MIDI Team

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/

/**
   ConfigurationManager.hppile ConfigurationManager.hpp
   Charles Weld, David Wilson, James Brown, Jonathan Van Rossum, and Matthew Harrold
   @brief Declaration of class ConfigurationManager, part of Virtual MIDI Multitrack Recorder
*/

#ifndef _CONFIGURATIONMANAGER_H
#define _CONFIGURATIONMANAGER_H

#include "Group.hpp"
#include "Entry.hpp"

namespace MIDIToolkit
{

/**
    @brief Provides management of configuration details.

    @ingroup config
*/
    class ConfigurationManager
    {
    public:
        /**
         @brief Get the singleton instance of ConfigurationManager.

         Get the singleton instance of ConfigurationManager.


         @return reference to singleton
        */
        static ConfigurationManager* getSingleton();

        /**
         @brief Gets the root group.

         Gets the root group.

         @return The root group.
        */
        Group& getRoot();

        /**
         @brief Finds the entry with a given name.

         Searches the Configuration for the first Entry with the
         specified name.

         @throw An Exception if no entry exists.

         @param name The name of the Entry to find.

         @return The found Entry.
        */
        Entry& findEntry(String name);

        /**
         @brief Finds a specific Entry in a Group with a given name.

         Finds a specific Entry in a Group with a given name.

         @param groupName of the Group to find.
         @param entryName of the Entry to find.
         @return The found Entry.
        */
        Entry& findEntry(String groupName, String entryName);

        /**
         @brief Finds a specific Group.

         Finds a specific Group.

         @param Name of the Group to find.
         @return reference to Entry.
        */
        Group& findGroup(Group name);

         /**
         @brief Removes all Groups and Entries from the configuration.

         Removes all Groups and Entries from the configuration.
        */
        void clear();

        /**
         @brief Loads a specific File.

         Loads a specific File.

         @param Name of the File to load.
         @return reference to filename.
        */
        bool load(String filename);

        /**
         @brief Saves a specific File.

         Saves a specific File.

         @param Name of the File to save.
         @return reference to filename.
        */
        void save(String filename);

    protected:
        ConfigurationManager();
        static ConfigurationManager singleton;
        Group root;
    };
}

#endif  //_CONFIGURATIONMANAGER_H
