#ifndef bzip2_h_
#define bzip2_h_

/*-----------------------------------------------------------*/
/*--- A block-sorting, lossless compressor        bzip2.c ---*/
/*-----------------------------------------------------------*/

/*--
  This file is a part of bzip2 and/or libbzip2, a program and
  library for lossless, block-sorting data compression.

  Copyright (C) 1996-2005 Julian R Seward.  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

  1. Redistributions of source code must retain the above copyright
     notice, this list of conditions and the following disclaimer.

  2. The origin of this software must not be misrepresented; you must
     not claim that you wrote the original software.  If you use this
     software in a product, an acknowledgment in the product
     documentation would be appreciated but is not required.

  3. Altered source versions must be plainly marked as such, and must
     not be misrepresented as being the original software.

  4. The name of the author may not be used to endorse or promote
     products derived from this software without specific prior written
     permission.

  THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS
  OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
  WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
  ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
  DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
  GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
  INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
  WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
  NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
  SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

  Julian Seward, Cambridge, UK.
  jseward@bzip.org
  bzip2/libbzip2 version 1.0 of 21 March 2000

  This program is based on (at least) the work of:
     Mike Burrows
     David Wheeler
     Peter Fenwick
     Alistair Moffat
     Radford Neal
     Ian H. Witten
     Robert Sedgewick
     Jon L. Bentley

  For more information on these sources, see the manual.
--*/


/*----------------------------------------------------*/
/*--- IMPORTANT                                    ---*/
/*----------------------------------------------------*/

/*--
   WARNING:
      This program and library (attempts to) compress data by
      performing several non-trivial transformations on it.
      Unless you are 100% familiar with *all* the algorithms
      contained herein, and with the consequences of modifying them,
      you should NOT meddle with the compression or decompression
      machinery.  Incorrect changes can and very likely *will*
      lead to disasterous loss of data.

   DISCLAIMER:
      I TAKE NO RESPONSIBILITY FOR ANY LOSS OF DATA ARISING FROM THE
      USE OF THIS PROGRAM, HOWSOEVER CAUSED.

      Every compression of a file implies an assumption that the
      compressed file can be decompressed to reproduce the original.
      Great efforts in design, coding and testing have been made to
      ensure that this program works correctly.  However, the
      complexity of the algorithms, and, in particular, the presence
      of various special cases in the code which occur with very low
      but non-zero probability make it impossible to rule out the
      possibility of bugs remaining in the program.  DO NOT COMPRESS
      ANY DATA WITH THIS PROGRAM AND/OR LIBRARY UNLESS YOU ARE PREPARED
      TO ACCEPT THE POSSIBILITY, HOWEVER SMALL, THAT THE DATA WILL
      NOT BE RECOVERABLE.

      That is not to say this program is inherently unreliable.
      Indeed, I very much hope the opposite is true.  bzip2/libbzip2
      has been carefully constructed and extensively tested.

   PATENTS:
      To the best of my knowledge, bzip2/libbzip2 does not use any
      patented algorithms.  However, I do not have the resources
      available to carry out a full patent search.  Therefore I cannot
      give any guarantee of the above statement.
--*/



/*----------------------------------------------------*/
/*--- and now for something much more pleasant :-) ---*/
/*----------------------------------------------------*/

#include <stdio.h>
#include "MIDIToolkitPrerequisites.hpp"
#include "Exception.hpp"
#include "Exceptions.hpp"

namespace MIDIToolkit
{

/**
    @brief Provides BZ2 compression services.

    @ingroup misc
*/
    class BZ2Compressor
    {
    public:
        BZ2Compressor();

        void compressStream ( FILE *stream, FILE *zStream );
        Bool uncompressStream ( FILE *zStream, FILE *stream );


    protected:

        /**
         @brief Used to simply throw ioErrors.

         Used to simply throw ioErrors..
        */
        void ioError ( void )
        {
            throw Exception(Exceptions::COMPRESSION_FAILED, "Compression failed due to an IO Error", "ioError()");
        }

        /**
         @brief Used to throw specific exception Error message.

         Used to throw specific exception Error message.

         @param Reference a char
         @return An exception.
        */
        void panic ( char* str )
        {
            throw Exception(Exceptions::COMPRESSION_FAILED, str, "panic()");
        }

        /**
         @brief Used to throw specific configError message.

         Used to throw specific configError message.
        */
        void configError( void )
        {
            throw Exception(Exceptions::COMPRESSION_FAILED, "Compression failed due to an config Error", "configError()");
        }

        /**
         @brief Used to throw specific crcError message.

         Used to throw specific crcError message.
        */
        void crcError( void )
        {
            throw Exception(Exceptions::COMPRESSION_FAILED, "Compression failed due to a CRC Error", "crcError()");
        }

        /**
         @brief Used to throw specific outOfMemoryError message.

         Used to throw specific outOfMemoryError message.
        */
        void outOfMemory( void )
        {
            throw Exception(Exceptions::COMPRESSION_FAILED, "Compression failed because we ran out of Memory.", "ioError()");
        }

        /**
         @brief Used to throw specific compressedStreamEOFError message.

         Used to throw specific compressedStreamEOFError message.
        */
        void compressedStreamEOF()
        {
            throw Exception(Exceptions::COMPRESSION_FAILED, "Compression failed because we came accross an unexpected EOF", "ioError()");
        }

    protected:
        // varibles
        UInt32 blockSize100k;
        UInt32 verbosity;
        UInt32 workFactor;
        UInt32 smallMode;
    };
}

/*-----------------------------------------------------------*/
/*--- end                                         bzip2.h ---*/
/*-----------------------------------------------------------*/

#endif
