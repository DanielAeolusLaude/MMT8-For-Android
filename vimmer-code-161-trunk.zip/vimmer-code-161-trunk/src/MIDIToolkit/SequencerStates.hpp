/*
   Virtual MIDI Multitrack Recorder
   Copyright (c) 2006 MIDI Team

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/

/**
   @file   SequencerStates.hpp
   @author Charles Weld
   @brief  Declaration of the enumeration SequencerState.
*/


#ifndef _SEQUENCERSTATES_H
#define _SEQUENCERSTATES_H

namespace MIDIToolkit
{
    /** @ingroup midiseq
     *  @brief  Contains the SequencerState enumeration.
     */
    namespace SequencerStates
    {
        /** @ingroup midiseq
         *  @brief Encapsulates the current state of the Sequencer.
         *
         *  This enumeration is returned by the Sequencer's getState() function,
         *  and represents its current status regarding playback and recording.
         *
         *  The following states are defined:
         *
         *      STOPPED   - Sequencer is stopped.
         *      PLAYING   - Sequencer is playing, record is disarmed.
         *      RECORDING - Sequencer is playing, record is armed.
         *
         */
        enum SequencerState
        {
            PLAYING,
            RECORDING,
            STOPPED
        };
    }

    //SequencerStates::SequencerState s = SequencerStates::PLAYING;

}

#endif  //_SEQUENCERSTATES_H
