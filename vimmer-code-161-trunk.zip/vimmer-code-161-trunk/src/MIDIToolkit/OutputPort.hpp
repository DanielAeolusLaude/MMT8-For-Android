/*
   Virtual MIDI Multitrack Recorder
   Copyright (c) 2006 MIDI Team

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU Lesser General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU Lesser  General Public License for more details.

   You should have received a copy of the GNU Lesser General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/

/**
   OutputPort.hppile OutputPort.hpp
   Charles Weld, David Wilson, James Brown, Jonathan Van Rossum, and Matthew Harrold
   @brief Declaration of class OutputPort, part of Virtual MIDI Multitrack Recorder
*/

#ifndef _OUTPUTPORT_H
#define _OUTPUTPORT_H

#include "MIDIToolkitPrerequisites.hpp"
#include "IOutputPort.hpp"
#include "ShortMessage.hpp"
#include "MIDIEvent.hpp"
#include "LogManager.hpp"

namespace MIDIToolkit
{
    /**
     * @brief Provides a more concrete Implementation of Output Port but still abastract enough to be cross platform independent.
     *
     * Provides a more concrete Implementation of Output Port but still abastract enough to be cross platform independent.
     * Basically this handles proccessing the MIDI Event but doesn't have any capability to actually send any MIDI Events.
     */
    /// @ingroup midiport
    class OutputPort : public IOutputPort
    {
    public:
        /**
         * @brief Destructor.
         *
         * Destructor.
         */
        virtual ~OutputPort();

        /**
         * @see IOutputPort::reset()
         */
        virtual void reset();

        /**
         * @brief Called when we receive a MIDI Event from an Generator.
         *
         * Called when we receive a MIDI Event from an Generator.
         * @param evt The Event Received.
         */
        virtual void receive(MIDIEvent* evt);

        /**
         * @see IOutputPort:getPortNumber()
         */
        virtual int getPortNumber();
    protected:
        /**
         * @brief
         *
         * Constructor.
         */
        OutputPort();

        /**
         * @brief This will be called when we need to send a short Message out the Output Port.
         *
         * This will be called when we need to send a short Message out the Output Port.
         * This is an abastract method since OutputPort doesn't know how to actually send
         * MIDI Events.
         * @param msg The Short Message to send.
         */
        virtual void send(ShortMessage* msg) = 0;

        int portID;
        LogManager* logger;
    };
}

#endif  //_OUTPUTPORT_H
