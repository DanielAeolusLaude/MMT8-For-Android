/*
   Virtual MIDI Multitrack Recorder
   Copyright (c) 2006 MIDI Team

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/

/**
   Log.hppile Log.hpp
   Charles Weld, David Wilson, James Brown, Jonathan Van Rossum, and Matthew Harrold
   @brief Declaration of class Log, part of Virtual MIDI Multitrack Recorder
*/

#ifndef _LOG_H
#define _LOG_H

#include <iostream>

#include "MIDIToolkitPrerequisites.hpp"
#include "LogLevels.hpp"

namespace MIDIToolkit
{

/**
    @brief Represents a Logger, Logger's output log messages to file.

    @ingroup log
*/
    class Log
    {
    public:
        /**
         * Creates a new Logger.
         * @param output The file to log to.
         */
        Log(std::ofstream* output);

        /**
         * Logs a message of a cirtain level to file.
         * If the level is bellow the current minimum level then the
         * message isn't logged.
         * @param msg The message to be logged.
         * @param level The level of the message (priority).
         */
        void log(String msg, int level=LogLevels::LEVEL_NORMAL);

        /**
         * Enables the logger.
         */
        void enable();

        /**
         * Disables the logger.
         */
        void disable();

        /**
         * Gets wether or not the logger is enabled.
         * @return True if the logger is enabled otherwise false.
         */
        bool isEnabled();

        /**
         * Sets the name of the logger.
         * @param name The name of logger.
         */
        void setName(String name);

        /**
         * Gets the name of the logger.
         */
        String getName();

        /**
         * Sets the minimum level.
         * @note If the user tries to log a message bellow this level the message
         * won't be logged.
         * @param lev The new Minumin log level.
         */
        void setMinLevel(int lev);

        /**
         * Gets the Minimum level.
         * @return the level.
         */
        int getMinLevel();
    private:
        std::ofstream* output;
        String name;
        bool enabled;
        int level;
    };
}

#endif  //_LOG_H
