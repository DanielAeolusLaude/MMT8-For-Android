/*
   Virtual MIDI Multitrack Recorder
   Copyright (c) 2006 MIDI Team

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU Lesser General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU Lesser  General Public License for more details.

   You should have received a copy of the GNU Lesser General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/

/**
   ChannelMessage.hppile ChannelMessage.hpp
   Charles Weld, David Wilson, James Brown, Jonathan Van Rossum, and Matthew Harrold
   @brief Declaration of class ChannelMessage, part of Virtual MIDI Multitrack Recorder
*/

#ifndef _CHANNELMESSAGE_H
#define _CHANNELMESSAGE_H

#include "ShortMessage.hpp"
#include "MIDIToolkitPrerequisites.hpp"

namespace MIDIToolkit
{
     /**
      *  Defines constants for ChannelMessage types.
      */
    /// @ingroup midimsg
    class ChannelCommands
    {
    public:
        //! Represents the note-off command type.
        static const unsigned long NoteOff = 0x80;

        //! Represents the note-on command type.
        static const unsigned long NoteOn = 0x90;

        //! Represents the poly pressure (aftertouch) command type.
        static const unsigned long PolyPressure = 0xA0;

        //! Represents the controller command type.
        static const unsigned long Controller = 0xB0;

        //! Represents the program change command type.
        static const unsigned long ProgramChange = 0xC0;

        //! Represents the channel pressure (aftertouch) command type.
        static const unsigned long ChannelPressure = 0xD0;

        //! Represents the pitch wheel command type.
        static const unsigned long PitchWheel = 0xE0;
    };

    //! Defines constants for controller types.
    /// @ingroup midimsg
    class ControllerTypes
    {
    public:
        //! The Bank Select coarse.
        static const unsigned long BankSelect = 0;

        //! The Modulation Wheel coarse.
        static const unsigned long ModulationWheel = 1;

        //! The Breath Control coarse.
        static const unsigned long BreathControl = 2;

        //! The Foot Pedal coarse.
        static const unsigned long FootPedal = 4;

        //! The Portamento Time coarse.
        static const unsigned long PortamentoTime = 5;

        //! The Data Entry Slider coarse.
        static const unsigned long DataEntrySlider = 6;

        //! The Volume coarse.
        static const unsigned long Volume = 7;

        //! The Balance coarse.
        static const unsigned long Balance = 8;

        //! The Pan position coarse.
        static const unsigned long Pan = 10;

        //! The Expression coarse.
        static const unsigned long Expression = 11;

        //! The Effect Control 1 coarse.
        static const unsigned long EffectControl1 = 12;

        //! The Effect Control 2 coarse.
        static const unsigned long EffectControl2 = 13;

        //! The General Puprose Slider 1
        static const unsigned long GeneralPurposeSlider1 = 16;

        //! The General Puprose Slider 2
        static const unsigned long GeneralPurposeSlider2 = 17;

        //! The General Puprose Slider 3
        static const unsigned long GeneralPurposeSlider3 = 18;

        //! The General Puprose Slider 4
        static const unsigned long GeneralPurposeSlider4 = 19;

        //! The Bank Select fine.
        static const unsigned long BankSelectFine = 32;

        //! The Modulation Wheel fine.
        static const unsigned long ModulationWheelFine = 33;

        //! The Breath Control fine.
        static const unsigned long BreathControlFine = 34;

        //! The Foot Pedal fine.
        static const unsigned long FootPedalFine = 36;

        //! The Portamento Time fine.
        static const unsigned long PortamentoTimeFine = 37;

        //! The Data Entry Slider fine.
        static const unsigned long DataEntrySliderFine = 38;

        //! The Volume fine.
        static const unsigned long VolumeFine = 39;

        //! The Balance fine.
        static const unsigned long BalanceFine = 40;

        //! The Pan position fine.
        static const unsigned long PanFine = 42;

        //! The Expression fine.
        static const unsigned long ExpressionFine = 43;

        //! The Effect Control 1 fine.
        static const unsigned long EffectControl1Fine = 44;

        //! The Effect Control 2 fine.
        static const unsigned long EffectControl2Fine = 45;

        //! The Hold Pedal 1.
        static const unsigned long HoldPedal1 = 64;

        //! The Portamento.
        static const unsigned long Portamento = 65;

        //! The Sustenuto Pedal.
        static const unsigned long SustenutoPedal = 66;

        //! The Soft Pedal.
        static const unsigned long SoftPedal = 67;

        //! The Legato Pedal.
        static const unsigned long LegatoPedal = 68;

        //! The Hold Pedal 2.
        static const unsigned long HoldPedal2 = 69;

        //! The Sound Variation.
        static const unsigned long SoundVariation = 70;

        //! The Sound Timbre.
        static const unsigned long SoundTimbre = 71;

        //! The Sound Release Time.
        static const unsigned long SoundReleaseTime = 72;

        //! The Sound Attack Time.
        static const unsigned long SoundAttackTime = 73;

        //! The Sound Brightness.
        static const unsigned long SoundBrightness = 74;

        //! The Sound Control 6.
        static const unsigned long SoundControl6 = 75;

        //! The Sound Control 7.
        static const unsigned long SoundControl7 = 76;

        //! The Sound Control 8.
        static const unsigned long SoundControl8 = 77;

        //! The Sound Control 9.
        static const unsigned long SoundControl9 = 78;

        //! The Sound Control 10.
        static const unsigned long SoundControl10 = 79;

        //! The General Purpose Button 1.
        static const unsigned long GeneralPurposeButton1 = 80;

        //! The General Purpose Button 2.
        static const unsigned long GeneralPurposeButton2 = 81;

        //! The General Purpose Button 3.
        static const unsigned long GeneralPurposeButton3 = 82;

        //! The General Purpose Button 4.
        static const unsigned long GeneralPurposeButton4 = 83;

        //! The Effects Level.
        static const unsigned long EffectsLevel = 91;

        //! The Tremelo Level.
        static const unsigned long TremeloLevel = 92;

        //! The Chorus Level.
        static const unsigned long ChorusLevel = 93;

        //! The Celeste Level.
        static const unsigned long CelesteLevel = 94;

        //! The Phaser Level.
        static const unsigned long PhaserLevel = 95;

        //! The Data Button Increment.
        static const unsigned long DataButtonIncrement = 96;

        //! The Data Button Decrement.
        static const unsigned long DataButtonDecrement = 97;

        //! The NonRegistered Parameter Fine.
        static const unsigned long NonRegisteredParameterFine = 98;

        //! The NonRegistered Parameter Coarse.
        static const unsigned long NonRegisteredParameterCoarse = 99;

        //! The Registered Parameter Fine.
        static const unsigned long RegisteredParameterFine = 100;

        //! The Registered Parameter Coarse.
        static const unsigned long RegisteredParameterCoarse = 101;

        //! The All Sound Off.
        static const unsigned long AllSoundOff = 120;

        //! The All Controllers Off.
        static const unsigned long AllControllersOff = 121;

        //! The Local Keyboard.
        static const unsigned long LocalKeyboard = 122;

        //! The All Notes Off.
        static const unsigned long AllNotesOff = 123;

        //! The Omni Mode Off.
        static const unsigned long OmniModeOff = 124;

        //! The Omni Mode On.
        static const unsigned long OmniModeOn = 125;

        //! The Mono Operation.
        static const unsigned long MonoOperation = 126;

        //! The Poly Operation.
        static const unsigned long PolyOperation = 127;
    };

    /**
     * Represents MIDI Channel Messages.
     */
    /// @ingroup midimsg
    class ChannelMessage : public ShortMessage
    {
    public:
        /**
         * Constructs a new instance of Channel Message with a specific command,
         * channel, and data 1 value.
         * @param command The command value.
         * @param midiChannel The channel value.
         * @param data1 The data 1 value.
         */
        ChannelMessage(ChannelCommand command, unsigned long midiChannel, unsigned long data1);

        /**
         * Constructs a new instance of a Channel Message with a specific command, channel,
         * data 1 value, and data 2 value.
         * @param command The command value.
         * @param midiChannel The channel value.
         * @param data1 The data 1 value.
         * @param data2 The data 1 value.
         */
        ChannelMessage(ChannelCommand command, unsigned long midiChannel, unsigned long data1, unsigned long data2);

        /**
         * Default destructor.
         */
        virtual ~ChannelMessage();

        /**
         * Clones this message.
         */
        virtual MIDIMessage* clone();

        // static packers/unpackers
        /**
         * Given a message unpacks the MIDI Channel component.
         * @return The MIDI Channel.
         */
        static unsigned long unpackChannel(unsigned long msg);

        /**
         * Packs the MIDI Channel into a message.
         * @param channel The MIDI Channel.
         */
        static unsigned long packChannel(unsigned long channel, unsigned long msg);

        /**
         * Unpacks the Command value from a MIDI message.
         * @return The Channel Command.
         */
        static ChannelCommand unpackCommand(unsigned long msg);

        /**
         * Packs the Command value into a MIDI Message.
         * @param command The channel command value.
         */
        virtual unsigned long packCommand(ChannelCommand command, unsigned long msg);

        /**
         * Gets the MIDI Channel.
         * @return The MIDI Channel.
         */
        virtual unsigned long getChannel();

        /**
         * Sets the MIDI Channel.
         * @param channel The MIDI Channel.
         */
        virtual void setChannel(unsigned long channel);

        /**
         * Gets the Command value.
         * @return The Channel Command.
         */
        virtual ChannelCommand getCommand();

        /**
         * Sets the Command value.
         * @param command The channel command value.
         */
        virtual void setCommand(ChannelCommand command);

        /**
         * Gets the data 1 value.
         * @return The data 1 value.
         */
        virtual unsigned long getData1();

        /**
         * Sets the data 1 value.
         * @param data The data 1 value.
         */
        virtual void setData1(unsigned long data);

        /**
         * Sets the data 2 value.
         * @return The data 2 value.
         */
        virtual unsigned long getData2();

        /**
         * Sets the data 2 value.
         * @param data The data 2 value.
         */
        virtual void setData2(unsigned long data);

        /**
         * Checks if this message is of type msgType.
         * @param msgType The type of message to check.
         * @return True if this message is of type msgType, otherwise false.
         */
        virtual bool isA(MessageType msgType);

        /**
         * Gets the number of byte in a channel command.
         * @param command The command to test.
         * @return The number of bytes that make up the message.
         */
        static int dataBytesPerType(ChannelCommand command);

        void print();

        //! MIDI Channel Mask.
        static const unsigned long MidiChannelMask = ~15;

        //! MIDI Command Mask.
        static const unsigned long CommandMask = ~240;
    protected:
        ChannelMessage(unsigned long msg);
    public:
        //! Max channel value.
        static const unsigned long MidiChannelMaxValue = 15;
    };
}

#endif  //_CHANNELMESSAGE_H
