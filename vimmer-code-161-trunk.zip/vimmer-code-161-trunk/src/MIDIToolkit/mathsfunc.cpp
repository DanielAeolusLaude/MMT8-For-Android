/***************************************************************************
 *   Copyright (C) 2004 by charles weld                                    *
 *   cweld_main@dodo.com.au                                                *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/
#include "mathsfunc.h"

namespace MIDIToolkit
{
    int max(int x, int y)
    {
        if(x>y)
            return x;
        else
            return y;
    }

    int min(int x, int y)
    {
        if(x<y)
            return x;
        else
            return y;
    }

    // functions (single) /////////////////////////////////////////////////////////////////
    inline float round(const float value, const int accuracy)
    {
        double integer, fraction;
        fraction = modf(value, &integer);  // get fraction and int components
        return(float(integer + (float(int(fraction*pow(10.0,accuracy)))) / pow(10.0, accuracy) ) );
    }

    float degToRad(float x)
    {
        return (x*PI)/180.0;
    }

    float radToDeg(float x)
    {
        return (x*180.0)/PI;
    }

    void zeroClamp(float& x)
    {
        if(EPSILON > fabs(x))
        {
            x=0.0;
        }
    }

    float sqr(float x)
    {
        return x*x;
    }

    void limitRange(float low, float& value, float high)
    {
        if(value<low)
        {
            value=low;
        }
        else if(value>high)
        {
            value=high;
        }
    }

    void swap(float &x, float &y)
    {
        float temp;
        temp = x;
        x = y;
        y = temp;
    }

    // set float to 0 if within tolerance
    bool equall(float x, float v)
    {
        return (((v) - EPSILON) < (x) && (x) < ((v) + EPSILON));
    }


    // functions (double) ///////////////////////////////////////////////////////////////////////////////
    double round(const double value, const int accuracy)
    {
        double integer, fraction;

        fraction = modf(value, &integer);  // get fraction and int components

        return(double(integer + (double(int(fraction*pow(10.0,accuracy)))) / pow(10.0, accuracy) ) );
    }

    double degToRad(double x)
    {
        return (x*PI)/180.0;
    }

    double radToDeg(double x)
    {
        return (x*180.0)/PI;
    }

    void zeroClamp(double& x)
    {
        if(EPSILON > fabs(x))
        {
            x=0.0;
        }
    }

    double sqr(double x)
    {
        return x*x;
    }

    void limitRange(double low, double& value, double high)
    {
        if(value<low)
        {
            value=low;
        }
        else if(value>high)
        {
            value=high;
        }
    }

    void swap(double &x, double &y)
    {
        double temp;
        temp = x;
        x = y;
        y = temp;
    }

    // set double to 0 if within tolerance

    bool equall(double x, double v)
    {
        return (((v) - EPSILON) < (x) && (x) < ((v) + EPSILON));
    }

}
