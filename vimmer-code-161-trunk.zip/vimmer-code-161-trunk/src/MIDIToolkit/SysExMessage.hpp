/*
   Virtual MIDI Multitrack Recorder
   Copyright (c) 2006 MIDI Team

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU Lesser General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU Lesser  General Public License for more details.

   You should have received a copy of the GNU Lesser General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/

/**
   SysExMessage.hppile SysExMessage.hpp
   Charles Weld, David Wilson, James Brown, Jonathan Van Rossum, and Matthew Harrold
   @brief Declaration of class SysExMessage, part of Virtual MIDI Multitrack Recorder
*/

#ifndef _SYSEXMESSAGE_H
#define _SYSEXMESSAGE_H

#include "MIDIMessage.hpp"

namespace MIDIToolkit
{
    /// @ingroup midimsg
    class SysExMessage : public MIDIMessage
    {
        /**
         * Clones this message.
         */
        virtual MIDIMessage* clone();

        /**
         * Checks if this message is of type msgType.
         * @param msgType The type of message to check.
         * @return True if this message is of type msgType, otherwise false.
         */
        virtual bool isA(MessageType msgType);
    };
}

#endif  //_SYSEXMESSAGE_H
