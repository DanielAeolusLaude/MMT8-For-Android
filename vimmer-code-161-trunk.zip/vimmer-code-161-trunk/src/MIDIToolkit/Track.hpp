/*
   Virtual MIDI Multitrack Recorder
   Copyright (c) 2006 MIDI Team

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU Lesser General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU Lesser  General Public License for more details.

   You should have received a copy of the GNU Lesser General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/

/**
   @file   Track.hpp
   @author Jonathan Van Rossum (jvr85@users.sourceforge.net)
   @brief  Declaration of the class Track.
*/


#ifndef _TRACK_H
#define _TRACK_H

#include "ChannelMessage.hpp"
#include "MIDIEvent.hpp"
#include "MIDIToolkitPrerequisites.hpp"

namespace MIDIToolkit
{
    /** @ingroup midiseq
     *  @brief  Passively stores MIDIEvents, and provides various editing functions.
     *
     *  STORAGE:
     *
     *  The Track class stores MIDI Event data. In other words, it stores MIDI
     *  messages that have been previously recorded (or imported from a file).
     *  Each MIDI message has an associated timestamp (in pulses, which is a
     *  subdivision of a beat). See MIDIEvent.
     *
     *  The Track uses a "List" structure to store the MIDIEvent data, instead of
     *  an array or a vector. This allows data to be quickly and easily inserted
     *  into or removed from the Track at any spot. The linear search time is not
     *  an issue, because access is typically sequential anyway.
     *
     *  NAVIGATION:
     *
     *  The Track creates "Iterators", so that other classes, such as Sequencer, can
     *  iterate through the events stored on this Track. The Track itself is passive,
     *  in that it has no memory of where the Sequencer (or any other class) is up
     *  to within the Track. This is the job of the iterator.
     *
     *  These iterators are used primarily by the Sequencer class during playback,
     *  and by the Exporters (which read data from a Track and write it to a file).
     *
     *  INSERTION:
     *
     *  The Track provides various insertion functions. These are used primarily
     *  by the Sequencer class (during recording), and by the Importers (which read
     *  track data from a file). These functions ensure that all data is sorted into
     *  the correct order, based on timestamp.
     *
     *  LENGTH:
     *
     *  The Track class has no knowledge of its musical length. This is defined
     *  by the MultiTrack class (see MultiTrack). The length of a Track is not
     *  defined by the timestamp of its last event, because a Track will nearly
     *  always have an amount of silence at the end.
     *
     *  The Track class does provide, however, a means to "force" its length to be
     *  within a particular number of beats. For example, if the user changes the
     *  Track's length to 200 beats, it is essential that no events remain on the
     *  Track that occur after this time. This is provided by the forceLength(...)
     *  function.
     *
     *  EDITING:
     *
     *  The Track provides several editing functions, which can operate on an
     *  individual event, over a range of events, or over the whole Track. These
     *  functions are typically called by the MultiTrack class, but can be used on
     *  individual Tracks too.
     *
     *  Editing functions include:
     *
     *      - ERASE:        Erase events from this Track.
     *      - COPY:         Copy events from another Track to this Track.
     *      - MERGE:        Merge events from another Track to this Track.
     *      - QUANTIZE:     Quantize event timing in this Track,
     *                        (usually to fix recorded musical errors).
     *      - TRANSPOSE:    Transpose (alter the pitch of) notes in this Track,
     *                        (typically to change key or octave).
     *
     *  Generally, the editing functions should not be used while the Sequencer is
     *  currently using the Track. See Sequencer.
     *
     *  MISCELLANEOUS:
     *
     *  Lists and iterators are defined by the Standard Template Library (STL).
     *  Information about STL, and its templates, can be found at:
     *
     *      - http://www.cprogramming.com/tutorial/stl/iterators.html
     *      - http://www.sgi.com/tech/stl/List.html
     *
     */
    class Track
    {
    public:

        /** @brief  Constructor for Track.
         */
        Track();


        /** @brief  Destructor for Track.
         */
        ~Track();

//--------------------------------------------------------------------------------
// Get Iterators at various positions
//--------------------------------------------------------------------------------

            /** @brief  Get an Iterator for this Track.
              * @return     The iterator.
             */
        MIDIEventIterator getIterator();

            /** @brief  Get an Iterator for the beginning of this Track.
              * @return     The iterator.
             */
        MIDIEventIterator getIterator_begin();

            /** @brief  Get an Iterator for the end of this Track.
              * @return     The iterator.
             */
        MIDIEventIterator getIterator_end();

            /** @brief  Get an Iterator for a particular timestamp.
              * @note   If the specified timestamp isn't found, the iterator
              *           points to the next message.
              * @note   If the several messages with the specified timestamp are
              *           found, the iterator points to the first one.
              * @param  absolute    Absolute timestamp value (in pulses) to find.
              * @return     The iterator.
             */
        MIDIEventIterator getIterator(unsigned long absolute);

            /** @brief  For a given NOTE ON event, find the corresponding NOTE OFF (if it exists).
              * @param  noteon      Iterator pointing to NOTE ON event.
              * @return     Iterator pointing to its next NOTE OFF (or getIterator_end() if it's not found).
             */
        MIDIEventIterator getIterator_noteoff(MIDIEventIterator* noteon);

            /** @brief  For a given NOTE OFF event, find the next corresponding NOTE ON (if it exists).
              * @param  noteoff     Iterator pointing to NOTE ON event.
              * @return     Iterator pointing to its previous NOTE ON (or getIterator_end() if it's not found).
             */
        MIDIEventIterator getIterator_noteon(MIDIEventIterator* noteon);

//--------------------------------------------------------------------------------
// EDIT FUNCTIONS:    INSERT
//--------------------------------------------------------------------------------

            /** @brief  Insert a message into this Track.
              * @note   ShortMessage is copied.
              * @param  absTime     Time of message (in pulses).
              * @param  msg         Pointer to the message itself.
              * @return (none).
             */
        void insert(unsigned long absTime, ShortMessage* msg);

            /** @brief  Insert a message into this Track.
              * @note   ShortMessage is copied.
              * @note   The iterator is a guide only, the insert()
              *         function itself will find the right spot.
              *         (Having a guide improves efficiency).
              * @param  absTime     Time of message (in pulses).
              * @param  msg         Pointer to the message itself.
              * @param  iterator    Use this iterator as a guid for where the message should go.
              * @return (none).
             */
        void insert(unsigned long absTime, ShortMessage* msg, MIDIEventIterator& iterator);

            /** @brief  Insert a MIDI Event into this Track.
              * @note   MIDIEvent is copied.
              * @note   The ShortMessage it contains is also copied.
              * @param  midi_event  Pointer to the MIDI Event to insert.
              * @return (none).
             */
        void insert(MIDIEvent* midi_event);

            /** @brief  Insert a MIDI Event into this Track.
              * @note   MIDIEvent is copied.
              * @note   The ShortMessage it contains is also copied.
              * @note   The iterator is a guide only, the insert()
              *         function itself will find the right spot.
              *         (Having a guide improves efficiency).
              * @param  midi_event  Pointer to the MIDI Event to insert.
              * @param  iterator    Use this iterator as a guid for where the message should go.
              * @return (none).
             */
        void insert(MIDIEvent* midi_event, MIDIEventIterator& iterator);

//--------------------------------------------------------------------------------
// EDIT FUNCTIONS:    NOTE DURATION (LENGH) & TIMESTAMPS
//--------------------------------------------------------------------------------

            /** @brief  Sets the timestamp of a MIDI Event
              * @param  location    Location of the event whose timestamp is to be modified.
              * @param  absolute    The timestamp (in pulses).
             */
        void timestamp(MIDIEventIterator& location, unsigned long absolute);

            /** @brief  Gets the duration of a NOTE ON event.
              * @param  location    Location of the NOTE ON event.
              * @return     The duration (in pulses)
             */
        unsigned long duration_pulses(MIDIEventIterator& location);

            /** @brief  Sets the duration of a NOTE ON Event.
              * @note   The duration can be changed either by moving the
              *         NOTE ON event or NOTE OFF event, and is controlled
              *         by the tail_fixed parameter, as follows:
              *            false -> adjust the NOTE OFF, keep the NOTE ON constant
              *            true  -> adjust the NOTE ON, keep the NOTE OFF constant
              * @param  location    Location of the NOTE ON event.
              * @param  duration    The duration of the note (in pulses).
              * @param  tail        Adjust the NOTE ON or NOTE OFF, default is NOTE OFF (false).
             */
        void duration_pulses(MIDIEventIterator& location, unsigned long duration, bool tail_fixed=false);

            /** @brief  Sets the duration of a NOTE ON Event.
              * @note   Valid values for interval are the same as for quantize,
              *         ie. 2, 4 (quarter-note), 6, 8, 12, 16, 24, 32, 48, 64.
              * @note   The duration can be changed either by moving the
              *         NOTE ON event or NOTE OFF event, and is controlled
              *         by the tail_fixed parameter, as follows:
              *             false -> adjust the NOTE OFF, keep the NOTE ON constant
              *             true  -> adjust the NOTE ON, keep the NOTE OFF constant
              * @param  location    Location of the NOTE ON event.
              * @param  interval    The interval of the note.
              * @param  tail        Adjust the NOTE ON or NOTE OFF, default is NOTE OFF (false).
             */
        void duration_interval(MIDIEventIterator& location, unsigned int interval, bool tail_fixed=false);

//--------------------------------------------------------------------------------
// EDIT FUNCTIONS:    ERASE
//--------------------------------------------------------------------------------

            /** @brief  ERASE all MIDIEvents from this Track.
             */
        void erase();

            /** @brief  ERASE MIDIEvent at iterator.
              * @note   If this is a NOTE ON or NOTE OFF message, its corresponding
              *         "other" will be erased too. If this is not desired, use
              *         remove(location) instead.
              * @param  location    The Iterator at which to erase.
             */
        void erase(MIDIEventIterator& location);

            /** @brief  ERASE all MIDIEvents between interval [begin,end).
              * @note   Begin is erased, but end is not.
              * @param  begin   The Iterator at which to begin erase.
              * @param  end     The Iterator at which to end erase.
             */
        void erase(MIDIEventIterator& begin, MIDIEventIterator& end);

            /** @brief  Clear (Erase) all MIDIEvents between interval [begin,end).
              * @note   Begin is erased, but end is not.
              * @param  begin   The absolute timestamp (pulses) at which to begin erase.
              * @param  end     The absolute timestamp (pulses) at which to end erase.
             */
        void erase(unsigned long begin, unsigned long end);

            /** @brief  ERASE MIDIEvent at iterator.
              * @note   If this message is one of a NOTE ON, NOTE OFF pair,
              *         the other of the pair will not be erased.
              * @param  location    The Iterator at which to erase.
             */
        void remove(MIDIEventIterator& location);

//--------------------------------------------------------------------------------
// EDIT FUNCTIONS:    TRANPOSE
//--------------------------------------------------------------------------------

            /** @brief  TRANSPOSE all MIDIEvents from this Track.
              * @param  semitones   Number of semitones (UP or DOWN) to transpose by.
             */
        void transpose(int semitones);

            /** @brief  TRANSPOSE MIDIEvent at iterator.
              * @note   Corresponding NOTE OFFs are automatically adjusted.
              * @param  location    The Iterator at which to transpose.
              * @param  semitones   Number of semitones (UP or DOWN) to transpose by.
             */
        void transpose(MIDIEventIterator& location, int semitones);

            /** @brief  TRANSPOSE all MIDIEvents between interval [begin,end).
              * @note   Begin is transposed, but end is not.
              * @note   Corresponding NOTE OFFs are automatically adjusted.
              * @param  begin       The Iterator at which to begin transpose.
              * @param  end         The Iterator at which to end transpose.
              * @param  semitones   Number of semitones (UP or DOWN) to transpose by.
             */
        void transpose(MIDIEventIterator& begin, MIDIEventIterator& end, int semitones);

            /** @brief  TRANSPOSE all MIDIEvents between interval [begin,end).
              * @note   Begin is transposed, but end is not.
              * @note   Corresponding NOTE OFFs are automatically adjusted.
              * @param  begin       The absolute timestamp (pulses) at which to begin transpose.
              * @param  end         The absolute timestamp (pulses) at which to end transpose.
              * @param  semitones   Number of semitones (UP or DOWN) to transpose by.
             */
        void transpose(unsigned long begin, unsigned long end, int semitones);

//--------------------------------------------------------------------------------
// EDIT FUNCTIONS:    QUANTIZE
//--------------------------------------------------------------------------------

            /** @brief  QUANTIZE all MIDIEvents from this Track.
              * @param  interval    Interval to quantize by.
              * @param  type        Type of quantize.
              * @note   Valid quantize types are:
              *             0 == "NOTE START"           Quantize NOTE ON events only.
              *             1 == "NOTE START & END"     Quantize NOTE ON and NOTE OFF events.
              *             2 == "NOTE END"             Quantize NOTE OFF events only.
              *             3 == "KEEP DURATION"        Quantize NOTE ON, but also adjust NOTE OFF
              *                                         to keep the same note duration.
             */
        void quantize(unsigned int interval, int type);

            /** @brief  QUANTIZE MIDIEvent at iterator.
              * @param  location    The Iterator at which to quantize.
              * @param  interval    Interval to quantize by.
             */
        void quantize(MIDIEventIterator& location, unsigned int interval);

            /** @brief  QUANTIZE all MIDIEvents between interval [begin,end).
              * @param  begin       The Iterator at which to begin quantize.
              * @param  end         The Iterator at which to end quantize.
              * @param  interval    Interval to quantize by.
              * @param  type        Type of quantize.
              * @note   Valid quantize types are:
              *             0 == "NOTE START"           Quantize NOTE ON events only.
              *             1 == "NOTE START & END"     Quantize NOTE ON and NOTE OFF events.
              *             2 == "NOTE END"             Quantize NOTE OFF events only.
              *             3 == "KEEP DURATION"        Quantize NOTE ON, but also adjust NOTE OFF
              *                                         to keep the same note duration.
             */
        void quantize(MIDIEventIterator& begin, MIDIEventIterator& end, unsigned int interval, int type);

            /** @brief  QUANTIZE all MIDIEvents between interval [begin,end).
              * @param  begin       The absolute timestamp (pulses) at which to begin quantize.
              * @param  end         The absolute timestamp (pulses) at which to end quantize.
              * @param  interval    Interval to quantize by.
              * @param  type        Type of quantize. valid values are:
              * @param  type        Type of quantize.
              * @note   Valid quantize types are:
              *             0 == "NOTE START"           Quantize NOTE ON events only.
              *             1 == "NOTE START & END"     Quantize NOTE ON and NOTE OFF events.
              *             2 == "NOTE END"             Quantize NOTE OFF events only.
              *             3 == "KEEP DURATION"        Quantize NOTE ON, but also adjust NOTE OFF
              *                                         to keep the same note duration.
             */
        void quantize(unsigned long begin, unsigned long end, unsigned int interval, int type);

//--------------------------------------------------------------------------------
// EDIT FUNCTIONS:    MERGE
//--------------------------------------------------------------------------------

            /** @brief  MERGE all MIDIEvents from another Track with this. Current contents are preserved.
              * @param  source_track    Track to copy events from.
             */
        void merge(Track* source_track);

//--------------------------------------------------------------------------------
// EDIT FUNCTIONS:    COPY
//--------------------------------------------------------------------------------

            /** @brief  COPY all MIDIEvents from another Track to this. Current contents are erased.
              * @param  source_track    Track to copy events from.
              * @todo   Change the behaviour to imitate the MMT-8 "COPY" command.
             */
        void copy(Track* source_track);

//--------------------------------------------------------------------------------
// MISCELLANEOUS
//--------------------------------------------------------------------------------

            /** @brief  Check if the Track is empty.
             *  @return     Returns true if the Track is empty, false otherwise.
             */
        bool empty();

            /** @brief  Set the Length of this Track.
              * @note   Any events beyond this new length are erased.
              * @param  beats   The length of this track (in beats).
             */
        void forceLength(int beats);

//--------------------------------------------------------------------------------
// DEBUGGING
//--------------------------------------------------------------------------------

            /** @brief  DEBUGGING: Print this track's data to std::cout.
              * @param  indent  Number of spaces to put in front of each line.
             */
    void print(int indent);

//--------------------------------------------------------------------------------
// STATIC CONSTANTS
//--------------------------------------------------------------------------------

    protected:

        /// @brief  The MIDIEvent data stored in this Track.
        std::list<MIDIEvent*> messages;
        std::list<MIDIEvent*>::iterator last_pos;

    };
}

#endif  //_TRACK_H
