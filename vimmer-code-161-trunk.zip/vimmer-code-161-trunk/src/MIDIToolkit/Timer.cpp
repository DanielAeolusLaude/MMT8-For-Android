/*
   Virtual MIDI Multitrack Recorder
   Copyright (c) 2006 MIDI Team

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU Lesser General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU Lesser  General Public License for more details.

   You should have received a copy of the GNU Lesser General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/

/**
   @file Timer.cpp
   Charles Weld, David Wilson, James Brown, Jonathan Van Rossum, and Matthew Harrold
   @brief Declaration of class Timer, part of Virtual MIDI Multitrack Recorder
*/

#include "Timer.hpp"
#include <windows.h>

namespace MIDIToolkit
{
    bool Timer::init = false;
    __int64 Timer::frequency = 0;
    bool Timer::performanceCounter = false;

    Timer::Timer() :
        offset(0),pauseStart(0)
    {
        if(Timer::init == false)
        {
            //Initializing some static variables dependent on the system just once
            _LARGE_INTEGER liFreq;
            if(QueryPerformanceFrequency(&liFreq) == TRUE)
            {
                //Only if the system is supporting High Performance
                Timer::frequency = ((__int64)liFreq.HighPart << 32) + (__int64)liFreq.LowPart;
                Timer::performanceCounter = true;
            }
            else
            {
                Timer::performanceCounter = false;
            }

            Timer::init = true;
        }
    }

    Timer::~Timer()
    {
        //dtor
    }

    void Timer::reset()
    {

        if(Timer::performanceCounter)
        {
            _LARGE_INTEGER liCount;
            QueryPerformanceCounter(&liCount);
            startTime = ((__int64)liCount.HighPart << 32) + (__int64)liCount.LowPart;
            //Transform in microseconds
            (startTime *= 1000000) /= frequency;

        }
        else
        {
            //Transform milliseconds to microseconds
            startTime = (__int64)GetTickCount() * 1000;
        }
        offset = 0;
        pauseStart = 0;
        paused = false;
    }

    void Timer::pause()
    {
        // calculate what time it is now.
        __int64 now;
        if(Timer::performanceCounter)
        {
            _LARGE_INTEGER liCount;
            QueryPerformanceCounter(&liCount);
            now = ((__int64)liCount.HighPart << 32) + (__int64)liCount.LowPart;

            //Transform in microseconds
            (now  *= 1000000) /= frequency;
        }
        else
        {
            //Transform milliseconds to microseconds
            now = (__int64)GetTickCount() * 1000;
        }
        now -= startTime;

        if ( paused )
        {
            // the timer is paused -> calculate new offset and unpause the timer.
            offset += (now - pauseStart);
            paused = false;
        }
        else
        {
            // the timer is not paused -> update pause start and pause timer.
            pauseStart = now;
            paused = true;
        }
    }

    __int64 Timer::getElapsedTime()
    {
        __int64 result;
        if( !paused )
        {
            if(Timer::performanceCounter)
            {
                _LARGE_INTEGER liCount;
                QueryPerformanceCounter(&liCount);
                result = ((__int64)liCount.HighPart << 32) + (__int64)liCount.LowPart;

                //Transform in microseconds
                (result *= 1000000) /= frequency;
            }
            else
            {
                //Transform milliseconds to microseconds
                result = (__int64)GetTickCount() * 1000;
            }
            result -= (startTime + offset);
        }
        else
        {
            result = pauseStart - offset;
        }
        return result;
    }

    String Timer::toString()
    {
        __int64 eTime = getElapsedTime();
        char szBuff[100];
        _i64toa(eTime, szBuff, 10);

        return String(szBuff);
    }
}
