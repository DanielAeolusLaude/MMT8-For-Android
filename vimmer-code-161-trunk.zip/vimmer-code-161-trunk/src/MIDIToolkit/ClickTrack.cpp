/**
  * @ Project : ViMMeR - Virtual MIDI Multitrack Recorder
  * @ File Name : Filter.cpp
  * @ Date : 28/04/2006
  * @ Author : Charles, Dave, Jimi, Jon, and Matt.
  *
  * This program is free software; you can redistribute it and/or modify
  * it under the terms of the GNU General Public License as published by
  * the Free Software Foundation; either version 2 of the License, or
  * (at your option) any later version.
  *
  * This program is distributed in the hope that it will be useful,
  * but WITHOUT ANY WARRANTY; without even the implied warranty of
  * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  * GNU General Public License for more details.
  *
  * You should have received a copy of the GNU General Public License
  * along with this program; if not, write to the Free Software
  * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
  *
  */

/**
   @file   ClickTrack.cpp
   @author Charles Weld
   @brief  Implementation of the class ClickTrack.
*/

#include "ClickTrack.hpp"
#include <windows.h>
#include <iostream>
using namespace std;

namespace MIDIToolkit
{
    /**
     * Default constructor.
     */
    ClickTrack::ClickTrack()
    {
        played = false;
        lastBeat = 0;
        clickInterval = 4;
    }

    /**
     * Destructor.
     */
    ClickTrack::~ClickTrack()
    {
    }

    void ClickTrack::play(ULong32 pulse)
    {
        unsigned int gap = (int)(PULSES_PER_BEAT/(float(clickInterval)/4));
        unsigned int beatNum = pulse%gap;

        if( beatNum < lastBeat )
        {
            Beep((pulse<gap)?880:440, 5);
        }
        lastBeat = beatNum;
    }

    void ClickTrack::setClickInterval(int interval)
    {
        clickInterval = interval;
    }

    int ClickTrack::getClickInterval()
    {
        return clickInterval;
    }

    int ClickTrack::getInterval(int click_id)
    {
        switch (click_id)
        {
            case 0:
                return 2;
            case 1:
                return 4;
            case 2:
                return 6;
            case 3:
                return 8;
            case 4:
                return 12;
            case 5:
                return 16;
            case 6:
                return 24;
            case 7:
                return 32;
            case 8:
                return 48;
            case 9:
                return 64;
        }
        return 1;
    }

    int ClickTrack::getClickID(int click_interval)
    {
        switch (click_interval)
        {
            case 2:
                return 0;
            case 4:
                return 1;
            case 6:
                return 2;
            case 8:
                return 3;
            case 12:
                return 4;
            case 16:
                return 5;
            case 24:
                return 6;
            case 32:
                return 7;
            case 48:
                return 8;
            case 64:
                return 9;
        }
        return 1;
    }
}
