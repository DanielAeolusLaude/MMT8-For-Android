/*
   Virtual MIDI Multitrack Recorder
   Copyright (c) 2006 MIDI Team

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/

/**
   Observable.cppile Observable.cpp
   Charles Weld, David Wilson, James Brown, Jonathan Van Rossum, and Matthew Harrold
   @brief Declaration of class Observable, part of Virtual MIDI Multitrack Recorder
*/

#include "Observable.hpp"
#include "Observer.hpp"

namespace MIDIToolkit
{
    Observer::~Observer()
    {
        /*std::list<Observable*>::iterator iter = observables.begin();
        while(iter != observables.end())
        {
            Observable* o = *iter;
            iter++;
            o->removeObserver(this);
        }
        observables.clear();*/
    }

    void Observer::addObservable(Observable* obs)
    {
        // make sure this one doesn't exist
        //observables.push_back(obs);
    }

    void Observer::removeObservable(Observable* obs)
    {
        //observables.remove(obs);
    }
}
