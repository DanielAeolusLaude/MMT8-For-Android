/*
   Virtual MIDI Multitrack Recorder
   Copyright (c) 2006 MIDI Team

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/

/**
   @file Observer.hpp
   Charles Weld, David Wilson, James Brown, Jonathan Van Rossum, and Matthew Harrold
   @brief Declaration of class Observer, part of Virtual MIDI Multitrack Recorder
*/

#ifndef _OBSERVER_H
#define _OBSERVER_H

#include <list>

namespace MIDIToolkit
{


    class Observable;

    /**
	    @brief A Observer provides the ability to receive Events from an Observer.
	    @ingroup events.
	*/
    class Observer
    {
    public:
        Observer()
        {
            m_On = true;
        }


        /**
         @brief Destructor.

         Destructor.
        */
        virtual ~Observer();


        /**
         @brief Create a new Event listener.

         Create a new Event listener.

         @param Create Event listener.
         @return The Event id.
         @return A reference to parameters.
        */
        virtual void onEvent(int id, void* params) = 0;

        /**
         @brief Enable activation of Events

		 Enable activation of Events

		 @param Enable Event activation.
         @return The Event id.
         @return A reference to params.
        */
        virtual void fireEvent(int id, void* params=NULL)
        {
            if(isObserverEnabled())
                onEvent(id, params);
        }

        /**
         @brief Enable Observer

		 Enable Observer
        */
        void enableObserver()
        {
            m_On=true;
        }

        /**
         @brief Disable Observer

		 Disable Observer
        */
        void disableObserver()
        {
            m_On=false;
        }

        /**
         @brief Activates an Observer query

		 Activates an Observer query
        */
        bool isObserverEnabled()
        {
            return m_On;
        }

        /**
         @brief Automatic connection to observer

		 Automatic connection to observer

		 @param Enable observer connection.
         @return The connected observer.
        */
        void addObservable(Observable* obs);

        /**
         @brief Automatic disconnection from observer

		 Auto disconnect from observer when deleted

		 @param Disable observer connection..
         @return Observerto disconnect.
        */
        void removeObservable(Observable* obs);

    protected:
        bool m_On;
        //std::list<Observable*> observables;
    };
}

#endif  //_OBSERVER_H

