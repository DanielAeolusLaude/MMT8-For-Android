/*
   Virtual MIDI Multitrack Recorder
   Copyright (c) 2006 MIDI Team

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU Lesser General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU Lesser  General Public License for more details.

   You should have received a copy of the GNU Lesser General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/

/**
   @file   Sequencer.hpp
   @author Jonathan Van Rossum (jvr85@users.sourceforge.net)
   @brief  Declaration of the class Sequencer.
*/


#ifndef _SEQUENCER_H
#define _SEQUENCER_H


#include "MIDIToolkitPrerequisites.hpp"

#include "MultiTrackLink.hpp"
#include "Clock.hpp"
#include "ClickTrack.hpp"
#include "MIDIEvent.hpp"
#include "SequencerStates.hpp"

// INHERIT
#include "Observer.hpp"
#include "Modulator.hpp"

namespace MIDIToolkit
{
    /** @ingroup midiseq
     *  @brief  Provides the basic MIDI sequencing functionality of VMM-R.
     *
     *  OVERVIEW:
     *
     *  The Sequencer combines the functionality of many different classes to
     *  sequence MIDI messages. It is responsible for reading individual stored
     *  messages from each Track, and sending them out at the right time. It is also
     *  responsible for writing messages it receives onto the Track, with the correct
     *  timestamp information.
     *
     *  The Sequencer handles transport within the current MultiTrack. It maintains
     *  its own current position, and its own current playing and recording status.
     *
     *  The Sequencer is only concerned with its current MultiTrack. It has no
     *  knowledge of Parts, Songs, or even the concept of looping. The Sequencer is
     *  controlled by other "higher level" sequencers, which handle these more advanced
     *  functions. (See Vimmer::PartSequencer and Vimmer::SongSequencer classes).
     *  They know and control the state of the Sequencer, but the Sequencer has no
     *  knowledge of them.
     *
     *  DEVICE:
     *
     *  The Sequencer communicates with the Device class. At the right time, it sends
     *  MIDIMessages to the Device class, which in turn forwards them to its various
     *  output ports. The Sequencer sends messages to the Device through the
     *  Sequencer's own distributeMessage(...) function. (See Observable class).
     *
     *  The Sequencer receives messages from the Device via it's own receive(...)
     *  function. (See Observer class).
     *
     *  TRACK:
     *
     *  To read MIDIEvent data from each Track, the Sequencer gets an "iterator" from
     *  the Track. The iterator maintains the Sequencer's position within each Track.
     *  At the right time, the MIDIEvent pointed to by the iterator will be sent out,
     *  and the iterator will be advanced to the next MIDIEvent.
     *
     *  To write data to the Track, the Sequencer uses the Track's insert(...)
     *  function. This ensures the data remains in the correct order, based on the
     *  event's timestamp. Note that recording is permitted anywhere within the middle
     *  of the Track, not just at the end. (See Track class).
     *
     *  CLOCK:
     *
     *  The Sequencer relies upon the services provided by the Clock class. The Clock
     *  provides a "tick event" every 5 milliseconds or so, and reports the elapsed
     *  time to an accuracy of microseconds. The Sequencer uses the timestamp provided
     *  by the Clock to record when a MIDIMessage was received (for recording), and to
     *  determine when it has to send out the next MIDIMessage stored on each Track
     *  (for playback).
     *
     *  The Clock "ticks over" the Sequencer by calling the Sequencer's onEvent(...)
     *  function, (see Observer class), about every 5ms. The Sequencer can check the
     *  current timestamp of the clock at any time. (See Clock class).
     *
     *  MULTI-TRACK-LINK:
     *
     *  The Sequencer is usually "connected" to a particular MultiTrackLink. This
     *  object links to the current MultiTrack being played by the Sequencer. From
     *  this class, the Sequencer also obtains the current status information for each
     *  Track.
     *
     *  CURRENT PULSE:
     *
     *  The Sequencer maintains its current position by storing its "current pulse"
     *  number, and the microsecond timestamp at which this pulse occurred.
     *  (Note: A pulse is a fraction of a beat, typically 1/96th or 1/384th).
     *
     *  The (microsecond) time between pulses is calculated based on the current tempo.
     *  When this time finally elapses, the pulse is advanced by one. The Sequencer
     *  checks each Track one by one, and sends out any MIDIEvents that are waiting
     *  for this pulse. (The timestamp for each MIDIEvent is also stored in pulses).
     *
     *  The tempo is stored internally as the number of microseconds between each
     *  pulse. This means that the tempo can be adjusted at any time, even during
     *  playback and recording, and the Sequencer will respond immediately and
     *  correctly.
     *
     *  RECORDING, AND "RECORD ARMED":
     *
     *  The Sequencer maintains a state of record armed or disarmed. If the Sequencer
     *  receives a MIDIEvent while it is playing, it checks the record status. If
     *  record is "armed" (enabled), the MIDIEvent is recorded. If record is
     *  "disarmed", the event is ignored.
     *
     *  If the Sequencer receives a MIDIEvent while it is stopped, it is always
     *  ignored. Record "armed" has no meaning when stopped, except that record
     *  stays "armed" if the user the presses play.
     *
     *  Record can be enabled and disabled at any time during playback.
     *
     *  TRACK STATE:
     *
     *  Before playing a particular MIDIEvent from a Track, the Sequencer checks if
     *  that track is enabled or disabled. If enabled, the message is sent. If
     *  disabled (muted), the message is skipped over.
     *
     *  The Sequencer maintains the position of each iterator within its track,
     *  regardless of whether the track is actually playing. This means that the
     *  each track can be enabled and disabled any time throughout playback,
     *  completely at the whim of the user.
     *
     *  The same approach applies to recording. Before writing a MIDIEvent to each
     *  Track, the Sequencer checks if the Track is enabled for recording. If so, the
     *  event is written to the Track via the Track's insert(...) function, and the
     *  next track is also tried. If not, that Track is skipped, and the next Track is
     *  tried regardless.
     *
     *  The Sequencer theoretically allows writing to multiple Tracks, and also allows
     *  recording to no Tracks (with recording still armed). However, VMM-R's GUI
     *  prevents this, and thus it hasn't been tested.
     *
     *  Track states are stored in the MultiTrackLink that the Sequencer is currently
     *  connected to. (See MultiTrackLink class).
     *
     *  TRACK CHANNELIZE:
     *
     *  The Sequencer supports playback channelization of MIDIEvents on a Track by
     *  Track basis. During playback, when the Sequencer reads a MIDIEvent from a
     *  Track, it checks the channelize setting for that Track. If the setting is
     *  "no channelize", the MIDIEvent is played without change, as per normal.
     *  If the setting is a MIDI channel (1-16), the MIDIEvent is converted to that
     *  MIDI channel, and then sent out.
     *
     *  Channelize doesn't affect the original MIDIEvent stored on the Track. It only
     *  changes the temporary event as it is sent out.
     *
     *  Channelize settings are read dynamically for each Track, each time a message
     *  is sent out. Therefore, the channelize settings can be changed at any time,
     *  including during playback and record, (though channelize only affects playback
     *  only, not record).
     *
     *  Track channelize settings are stored in the MultiTrackLink that the Sequencer
     *  is currently connected to. (See MultiTrackLink class).
     *
     */
    class Sequencer : public MIDIToolkit::Modulator, public MIDIToolkit::Observer, public MIDIToolkit::Observable
    {
    public:

        /** @brief Constructor for Sequencer.
         */
        Sequencer();


        /** @brief Destructor for Sequencer.
         */
        ~Sequencer();


        /** @brief  Play from current position.
         */
        void play();


        /** @brief  Set record to be ARMED from current position.
          * @note   This is equivalent to setRecordArmed(true).
         */
        void record();


        /** @brief  Stop playing, and leave at current position (don't reset).
         */
        void stop();


        /** @brief  Jump to a particular beat.
          * @param  beat    The beat to jump to.
         */
        void jump(unsigned int beat);

        /** @brief  Get the current BEAT.
          * @return The current beat.
         */
        unsigned int getBeat();

        /** @brief  Get the current PULSE.
          * @return The current pulse.
         */
        unsigned long getPulse();


        /** @brief Return the state of the sequencer (in regards to playing and recording).
          * @note  The state is represented by an (int), defined in SequencerStates.
          *             STOPPED   - Sequencer is stopped.
          *             PLAYING   - Sequencer is playing, with record disarmed.
          *             RECORDING - Sequencer is playing, with record armed.
          * @return The state of the sequencer
         */
        SequencerStates::SequencerState getState();

        /** @brief  Associates the Sequencer with a particular MultiTrackLink.
          * @note   The MultiTrackLink represents which part the sequencer is currently
          *           playing, as well as the current state of the tracks.
          * @note   The sequencer can be disconnected from the MultiTrack by
          *           passing in a null pointer.
          * @note   The sequencer expects that the MultiTrackLink will not be linked
          *           to a different MultiTrack, and that the MultiTrack itself will not
          *           have any MIDIEvents removed from its Tracks. Otherwise, disconnect
          *           the MultiTrackLink beforehand.
          * @param  multitracklink  Pointer to the MultiTrackLink to use (or null).
          * @return (none)
         */
        void setMultiTrackLink(MultiTrackLink* multitracklink);

        /** @brief  Gets the MultiTrack associated with this sequencer.
          * @param  multitracklink  Pointer to the MultiTrackLink in use (or null if none).
          * @return (none)
         */
        MultiTrackLink* getMultiTrackLink();

        /** @brief  Sets RECORDING status.
          * @param  b   Recording status (true=armed, false=disarmed).
          * @return (none)
         */
        void setRecordArmed(bool b);

        /** @brief  Gets RECORDING status.
          * @return True if recording is armed otherwise false.
         */
        bool isRecordArmed();


        /** @brief  Sets the current tempo.
          * @note   The new tempo takes effect immediately, even if playing or recording.
          * @param  tempo   New tempo to use (beats per minute).
         */
        void setTempo(unsigned int tempo);


        /** @brief  Gets the current tempo.
          * @return     The tempo currently being used (beats per minute).
         */
        unsigned int getTempo();


        /** @brief  Receive a MIDI event (RECORD).
          * @note   This function should only be called by the Device class (Generator).
          *         If the sequencer is not recording, this MIDI message is ignored.
          *         If the sequencer is recording, this MIDI message is stored onto
          *         any recording tracks.
          * @param  evt     The event to receive.
          * @return (none)
         */
        void receive(MIDIEvent* evt);


        /** @brief  Receive an Event (typically a Clock tick). (PLAYBACK).
          *     This function should only be called by the Clock class (Observable).
          *     If the event is a Clock Tick Event:
          *         If the sequencer is playing, the Sequencer updates its
          *         current pulse, and sends out any MIDI messages for that time.
          *     All other Events are currently ignored.
          * @param  id      The ID of the event being received.
          * @param  params  Pointer to additional parameters for this event.
          * @return (none)
         */
        virtual void onEvent(int id, void* params);


        /** @brief  Send ALL NOTES OFF message to each channel.
         */
        void all_notes_off();


        /** @brief  Send ALL SOUND OFF message to each channel.
         */
        void all_sound_off();


        /** @brief  Set click (metronome) state for when playing.
         *  @param  s   click state (true=enabled, false=disabled).
         */
        void setClickPlay(bool s);

        /** @brief  Get click (metronome) state for when playing.
         *  @return Click state (true=enabled, false=disabled).
         */
        bool getClickPlay();

        /** @brief  Set click (metronome) state for when recording.
         *  @param  s   click state (true=enabled, false=disabled).
         */
        void setClickRecord(bool r);

        /** @brief  Get click (metronome) state for when recording.
         *  @return Click state (true=enabled, false=disabled).
         */
        bool getClickRecord();

        /** @brief  Set Click (metronome) interval.
         *  @param  interval    Click interval (2, 4, 6, 8, 12, 16, 24, 32, 48, 64).
         */
        void setClickInterval(int interval);

        /** @brief  Get Click (metronome) interval.
         *  @return     Click interval (2, 4, 6, 8, 12, 16, 24, 32, 48, 64).
         */
        int getClickInterval();

    protected:

        // These are used internally by send_event()
        static const int EVENT_STOPPED = 0;
        static const int EVENT_PLAYING = 1;
        static const int EVENT_MULTITRACK_END = 2;
        static const int EVENT_BEAT_UPDATE = 3;
        static const int EVENT_ACTIVITY_MIDI_IN = 4;
        static const int EVENT_ACTIVITY_MIDI_OUT = 5;

        //-------------------------------------------------------
        // These must be updated when the current part changes.
        //-------------------------------------------------------

        // CURRENT PART
        MultiTrackLink* multitracklink;             ///< LINK: The MultiTrackLink currently linked to.
        std::vector<MIDIEventIterator> iterators;   ///< LINK: Track Iterators (maintains current position within each Track).
        unsigned int number_of_tracks;              ///< LINK: Number of tracks in current MultiTrack.

        // LOCATION
        unsigned long current_pulse;                ///< LOCATION: The current pulse (at the last onEvent(TICK))
        unsigned long current_pulse_timestamp;      ///< LOCATION: The timestamp at the "current pulse", NOT the same as the current timestamp.

        // LENGTH
        unsigned long multitrack_length_pulses;     ///< LENGTH: Length of the currently linked MultiTrack (in pulses).

        //-------------------------------------------------------

        /// CLOCK
        Clock clock;                            ///< CLOCK: Maintains timing within the sequencer. Accurate to microseconds.

        // Click Stuff
        //! Click Track (handles CLICK)
        ClickTrack click;
        bool clickState;
        bool clickRecordState;
        ULong32 current_pulse_click;
        ULong32 current_pulse_click_timestamp;
        int count_in;
        // Click Stuff End

        // STATE
        bool record_armed;                      ///< STATE: Record armed (doesn't necessarily imply playing though)
        bool playing;                           ///< STATE: Playing

        // TIMING
        unsigned int tempo;                     ///< TEMPO: Current tempo (beats per minute).
        unsigned long microseconds_per_pulse;   ///< TEMPO: Current tempo (microseconds per pulse).

        //-------------------------------------------------------

        /** @brief  Advance to the next pulse(s).
          *     This function updates the current pulse. It also dispatches any
          *     waiting events.
          * @param  timestamp   The new timestamp, as returned by Clock "clock".
          * @return (none)
         */
        virtual void advance_pulse(unsigned long timestamp);

        /** @brief  Advance to the next click(s).
          *     This function updates the current click pulse. It also dispatches any
          *     waiting events.
          * @param  timestamp   The new timestamp, as returned by Clock "clock".
          * @return (none)
         */
        virtual void advance_click(unsigned long timestamp);

        /** @brief  A convenient function for sending events to anyone who cares.
          * @param  id      The (internal) ID of the event being sent.
          * @param  param1  First integer parameter.
          * @param  param2  Second integer parameter.
          * @return (none)
         */
        virtual void send_event(int id, int param1, int param2);

    };
}

#endif  //_SEQUENCER_H
