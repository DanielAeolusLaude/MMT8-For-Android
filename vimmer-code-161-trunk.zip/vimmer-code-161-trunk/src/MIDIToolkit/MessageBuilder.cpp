/*
   Virtual MIDI Multitrack Recorder
   Copyright (c) 2006 MIDI Team

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU Lesser General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU Lesser  General Public License for more details.

   You should have received a copy of the GNU Lesser General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/

/**
   MessageBuilder.cppile MessageBuilder.cpp
   Charles Weld, David Wilson, James Brown, Jonathan Van Rossum, and Matthew Harrold
   @brief Declaration of class MessageBuilder, part of Virtual MIDI Multitrack Recorder
*/

#include "MessageBuilder.hpp"
#include "MessageTypes.hpp"
#include "ShortMessage.hpp"
#include "ChannelMessage.hpp"
#include "SysCommonMessage.hpp"
#include "SysRealtimeMessage.hpp"

#include <iostream>
using namespace std;
namespace MIDIToolkit
{
    ShortMessage* MessageBuilder::buildMessage(int msg)
    {
        // get the command bit
        unsigned long command = ChannelMessage::unpackCommand(msg);
        // Do we have a channel message.
        if(command >= 0x80 && command <= 0xE0)
        {
            unsigned long channel = ChannelMessage::unpackChannel(msg);
            unsigned long data1 = ChannelMessage::unpackData1(msg);
            unsigned long data2 = ChannelMessage::unpackData2(msg);
            return new ChannelMessage(command, channel, data1, data2);
        }
        else
        {
            return NULL;
        }
    }

    ShortMessage* MessageBuilder::buildMessage(int status, int data1, int data2)
    {
        int msg = 0;
        msg = ShortMessage::packStatus(status, msg);
        msg = ShortMessage::packData1(data1, msg);
        msg = ShortMessage::packData2(data2, msg);

        return MessageBuilder::buildMessage(msg);
    }
}
