/*
   Virtual MIDI Multitrack Recorder
   Copyright (c) 2006 MIDI Team

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/

/**
   Observable.cppile Observable.cpp
   Charles Weld, David Wilson, James Brown, Jonathan Van Rossum, and Matthew Harrold
   @brief Declaration of class Observable, part of Virtual MIDI Multitrack Recorder
*/

#include "Observable.hpp"
#include "Observer.hpp"

namespace MIDIToolkit
{
    void Observable::addObserver(Observer *observer)
    {
        observers.remove(observer);
        observers.push_back(observer);
        //observer->addObservable(this);
    }

    void Observable::raiseEvent(int id, void* params)
    {
        if(isObservableEnabled())
        {
            for(ObserverIterator iter = observers.begin(); iter != observers.end(); iter++)
            {
                (*iter)->fireEvent(id, params);
            }
        }
    }

    void Observable::removeObserver(Observer *observer)
    {
        observers.remove(observer);
        //observer->removeObservable(this);
    }

    void Observable::removeAll()
    {
//        for(ObserverIterator iter = observers.begin(); iter != observers.end(); iter++)
//        {
//            (*iter)->removeObservable(this);
//        }

        observers.clear();
    }

    Observable::Observable()
    {
        m_On = true;
    }

    Observable::~Observable()
    {
        //removeAll();
    }
}
