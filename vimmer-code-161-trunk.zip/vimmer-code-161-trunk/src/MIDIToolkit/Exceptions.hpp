/*
   Virtual MIDI Multitrack Recorder
   Copyright (c) 2006 MIDI Team

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/

/**
   Exceptions.hppile Exceptions.hpp
   Charles Weld, David Wilson, James Brown, Jonathan Van Rossum, and Matthew Harrold
   @brief Declaration of class Exceptions, part of Virtual MIDI Multitrack Recorder
*/

#ifndef _EXCEPTIONS_H
#define _EXCEPTIONS_H


namespace MIDIToolkit
{
    /**
      @brief A list of Exception types.

      A list of Exception types.

      @ingroup err.
    */

    namespace Exceptions
    {
        /**
         @brief Defines a list standard Exceptions.

         Defines a list standard Exceptions.
        */
        enum
        {
            MIDI,
            CONVERSION_FAILED,
            XML_LOAD_FAILED,
            XML_SAVE_FAILED,
            COMPRESSION_FAILED,
            SEQUENCER_FAIL
        };
    }
}

#endif  //_EXCEPTIONS_H
