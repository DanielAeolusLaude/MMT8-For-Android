/*
   Virtual MIDI Multitrack Recorder
   Copyright (c) 2006 MIDI Team

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU Lesser General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU Lesser  General Public License for more details.

   You should have received a copy of the GNU Lesser General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/

/**
   @file InputFilter.hpp
   @author Charles Weld
   @brief Declaration of class InputFilter, part of Virtual MIDI Multitrack Recorder
*/

#ifndef _INPUTFILTER_H
#define _INPUTFILTER_H

#include "Modulator.hpp"
#include "MIDIEvent.hpp"
#include "Observable.hpp"
#include "ChannelMessage.hpp"

namespace MIDIToolkit
{

    /// @brief An Input Filter is used to filter MIDI Messages.
    /**
     * An Input Filter is used to filter MIDI Messages.
     * Basically what this means is that when it receives an incomming message, this message
     * must past a test for it to be passed on.
     * @ingroup mididev
     */
    class InputFilter : public Modulator, public Observable
    {
    public:

        /// @brief Default Constructor.
        /**
         * Default Constructor.
         */
        InputFilter();

        /// @brief Default Constructor.
        /**
         * Default Constructor.
         */
        virtual ~InputFilter();

        /// @brief This is called when the Analyser receives a MIDI Event and thus a message.
        /**
         * This is called when the Analyser receives a MIDI Event and thus a message.
         * When the InputFilter receives a MIDIEvent it has to pass a test @see InputFilter::filter
         * if so it will be passed onto any connected Analyser or Modulator.
         *
         * @param evt The MIDI Event.
         */
        virtual void receive(MIDIEvent* evt);

        /// @brief Sets whether or not the filter will allow Note On/Off events to pass through.
        /**
         * Sets whether or not the filter will allow Note On/Off events to pass through.
         * @param s True means it will forward notes, False means it won't.
         */
        void setNoteState(bool s);

        /// @brief Gets whether or not the filter will allow Note On/Off events to pass through.
        /**
         * Gets whether or not the filter will allow Note On/Off events to pass through.
         * @return True if it will forward notes, False means it won't.
         */
        bool getNoteState();

        /// @brief Sets whether or not the filter will allow Pitch Bend Events to pass.
        /**
         * Sets whether or not the filter will allow Pitch Bend Events to pass.
         * @param s True means that it will forward on the events, False means it won't.
         */
        void setPitchBendState(bool s);

        /// @brief Gets whether or not the filter will allow Pitch Bend Events to pass through.
        /**
         * Gets whether or not the filter will allow Pitch Bend Events to pass through.
         * @return True if it will forward the events, False means it won't.
         */
        bool getPitchBendState();

        /// @brief Sets whether or not the filter will allow After Touch Events to pass.
        /**
         * Sets whether or not the filter will allow After Touch Events to pass.
         * @param s True means that it will forward on the events, False means it won't.
         */
        void setAfterTouchState(bool s);

        /// @brief Gets whether or not the filter will allow After Touch Events to pass through.
        /**
         * Gets whether or not the filter will allow After Touch Events to pass through.
         * @return True if it will forward the events, False means it won't.
         */
        bool getAfterTouchState();

        /// @brief Sets whether or not the filter will allow Controller Events to pass.
        /**
         * Sets whether or not the filter will allow Controller Events to pass.
         * @param s True means that it will forward on the events, False means it won't.
         */
        void setControllerState(bool s);

        /// @brief Gets whether or not the filter will allow Controller Events to pass through.
        /**
         * Gets whether or not the filter will allow Controller Events to pass through.
         * @return True if it will forward the events, False means it won't.
         */
        bool getControllerState();

        /// @brief Sets whether or not the filter will allow Program Change Events to pass.
        /**
         * Sets whether or not the filter will allow Program Change Events to pass.
         * @param s True means that it will forward on the events, False means it won't.
         */
        void setProgramChangeState(bool s);

        /// @brief Gets whether or not the filter will allow Program Change Events to pass through.
        /**
         * Gets whether or not the filter will allow Program Change Events to pass through.
         * @return True if it will forward the events, False means it won't.
         */
        bool getProgramChangeState();

        /// @brief Sets what Channel Events the filter will allow to pass.
        /**
         * Sets what Channel Events the filter will allow to pass.
         * @param c The channel to allow (-1 means ALL).
         */
        void setChannel(unsigned int c);

        /// @brief Gets the channel that's allowed past the filter.
        /**
         * Gets the channel that's allowed past the filter.
         * @note A channel of -1 means ALL channels are allowed to pass.
         * @return The channel.
         */
        unsigned int getChannel();

    protected:
        /**
         * Deturmines whether or not a channel message passes through the filter.
         * @param msg The Channel Message to filter.
         * @return whether or not the @see msg made it through the filter.
         */
        bool filter(ChannelMessage* msg);

        // state vars
        bool m_NoteState;
        bool m_PitchBend;
        bool m_AfterTouch;
        bool m_Controllers;
        bool m_ProgramChange;
        unsigned int m_Channel;
    };
}

#endif  //_INPUTFILTER_H
