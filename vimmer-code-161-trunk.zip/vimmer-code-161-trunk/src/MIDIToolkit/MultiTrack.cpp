/*
   Virtual MIDI Multitrack Recorder
   Copyright (c) 2006 MIDI Team

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU Lesser General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU Lesser  General Public License for more details.

   You should have received a copy of the GNU Lesser General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/

/**
   @file   MultiTrack.cpp
   @author Jonathan Van Rossum (jvr85@users.sourceforge.net)
   @brief  Implementation of the class MultiTrack.
*/

#include "MultiTrack.hpp"
#include "Track.hpp"
#include "Events.hpp"

// DEBUGGING ONLY
#include <iostream>


namespace MIDIToolkit
{

    MultiTrack::MultiTrack()
    {
        //number_of_tracks = 16;
        multitrack_length = 0;

    }

    MultiTrack::~MultiTrack()
    {
    }

    unsigned int MultiTrack::count()
    {
        return NUMBER_OF_TRACKS;
    }

    Track* MultiTrack::getTrack(unsigned int i)
    {
        // Check that track is in range.
        if (i >= 0 && i < NUMBER_OF_TRACKS)
        {
            return &(tracks[i]);
        }
        else
        {
            return 0;
        }
    }

    void MultiTrack::setLength(int beats)
    {
        multitrack_length = beats;

        if (multitrack_length >= 0)
        {
            for (unsigned int i=0; i<NUMBER_OF_TRACKS; i++)
            {
                tracks[i].forceLength(multitrack_length);
            }
        }

        raiseEvent(Events::PART_CONTENT_CHANGED);
    }

    int MultiTrack::getLength()
    {
        return multitrack_length;
    }

    void MultiTrack::erase()
    {
        for (unsigned int i=0; i<NUMBER_OF_TRACKS; i++)
        {
            erase(i);
        }
    }

    void MultiTrack::erase(unsigned int tracknumber)
    {
        Track* track = getTrack(tracknumber);
        if (track != NULL)
        {
            track->erase();
        }
    }

    void MultiTrack::copy(unsigned int source, unsigned int dest)
    {
        Track* source_track = getTrack(source);
        Track* dest_track   = getTrack(dest);

        if (source_track != NULL && dest_track != NULL)
        {
            dest_track->copy(dest_track);
        }
    }

    void MultiTrack::merge(unsigned int source, unsigned int dest)
    {
        Track* source_track = getTrack(source);
        Track* dest_track   = getTrack(dest);

        if (source_track != NULL && dest_track != NULL)
        {
            dest_track->merge(dest_track);
        }
    }


    void MultiTrack::print()
    {
        std::cout << "MULTITRACK: size(" << count() << "):\n";
        for (unsigned int i=0; i<count(); i++)
        {
            std::cout << "  T[" << i << "]: \n";
            getTrack(i)->print(4);
        }
    }

}
