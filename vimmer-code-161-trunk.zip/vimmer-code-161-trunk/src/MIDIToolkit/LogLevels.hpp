/*
   Virtual MIDI Multitrack Recorder
   Copyright (c) 2006 MIDI Team

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/

/**
   LogLevels.hppile LogLevels.hpp
   Charles Weld, David Wilson, James Brown, Jonathan Van Rossum, and Matthew Harrold
   @brief Declaration of class LogLevels, part of Virtual MIDI Multitrack Recorder
*/

#ifndef _LOGLEVELS_H
#define _LOGLEVELS_H


namespace MIDIToolkit
{
    /**
    @brief Defines the different Log Levels.

    @ingroup log
    */
    class LogLevels
    {
       /** @brief Defines a list of LogLevels as basic int's.

        Defines a list of LogLevels as basic int's.
         */
    public:
        static const int LEVEL_TRACE = 0;
        static const int LEVEL_DEBUG = 1;
        static const int LEVEL_NORMAL = 2;
        static const int LEVEL_ERROR = 3;
        static const int LEVEL_FATAL = 4;
    };
}

#endif  //_LOGLEVELS_H
