/***************************************************************************
 *   Copyright (C) 2004 by charles weld                                    *
 *   cweld_main@dodo.com.au                                                *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/
#ifndef __MATHSFUNC_H_
#define __MATHSFUNC_H_

#include <math.h>

namespace MIDIToolkit
{

/**
    @class mathsfunc

    @ingroup 

    @todo Declares a series of int types for timing purposes.
*/

    // int
    int max(int x, int y);
    int min(int x, int y);

    // single (float)
    float degToRad(float x);
    float radToDeg(float x);
    void limitRange(float low, float& value, float high);
    void swap(float &x, float &y);
    void zeroClamp(float& x);
    bool equall(float x, float v);
    float round(const float value, const float accuracy);
    float sqr(float x);

    // double
    double degToRad(double x);
    double radToDeg(double x);
    void limitRange(double low, double& value, double high);
    void swap(double &x, double &y);
    void zeroClamp(double& x);
    bool equall(double x, double v);
    double round(const double value, const double accuracy);
    double sqr(double x);

    // constants
    const double PI       =  3.14159265358979323846f;
    const double EPSILON = 0.00005f;  // error tolerance for check
    const int FLOAT_DECIMAL_TOLERANCE = 3; // decimal places for double rounding


}


#endif

