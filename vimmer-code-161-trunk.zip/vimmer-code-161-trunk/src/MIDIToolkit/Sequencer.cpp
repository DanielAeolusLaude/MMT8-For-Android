/*
   Virtual MIDI Multitrack Recorder
   Copyright (c) 2006 MIDI Team

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU Lesser General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU Lesser  General Public License for more details.

   You should have received a copy of the GNU Lesser General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/

/**
   @file   Sequencer.cpp
   @author Jonathan Van Rossum (jvr85@users.sourceforge.net)
   @brief  Implementation of the class Sequencer.
*/


#include "Sequencer.hpp"

#include "MessageTypes.hpp"
#include "ChannelMessage.hpp"
#include "MultiTrack.hpp"
#include "Part.hpp"

#include "Events.hpp"

// DEBUGGING ONLY
#include <iostream>
using namespace std;

namespace MIDIToolkit
{
    Sequencer::Sequencer() : Modulator(), Observer(), Observable()
    {
        // STATE
        playing = false;
        record_armed = false;
        setClickPlay(false);
        setClickRecord(false);

        // CURRENT PART
        setMultiTrackLink(0);

        // LOCATION
        current_pulse = 0;
        current_pulse_timestamp = 0;
        current_pulse_click = 0;
        current_pulse_click_timestamp = 0;

        // TIMING (Default 120 beats per minute).
        setTempo(120);

        // CLOCK
        clock.addObserver(this);
    }

    Sequencer::~Sequencer()
    {
        if (playing)
        {
            playing = false;
            record_armed = false;
            clock.stop();
        }
    }

//----------------------------------------------------------------------------------------
    void Sequencer::setMultiTrackLink(MultiTrackLink* mtl)
    {
        // LOCATION
        clock.stop();
        current_pulse = 0;
        current_pulse_timestamp = 0;
        current_pulse_click = 0;
        current_pulse_click_timestamp = 0;
        playing = false;

        // CURRENT PART
        multitracklink = mtl;
        iterators.clear();
        number_of_tracks = 0;

        // LENGTH
        multitrack_length_pulses = 0;

        if (multitracklink!=NULL && multitracklink->getLink()!=NULL)
        {
            MultiTrack* mt = multitracklink->getLink();

            // Number of Tracks
            number_of_tracks = mt->count();

            // Track Iterators
            iterators.clear();
            for (unsigned int i=0; i < number_of_tracks; i++)
            {
                Track* t = mt->getTrack(i);
                if (t!=0)
                {
                    iterators.push_back(t->getIterator_begin());
                }
            }

            // LENGTH
            multitrack_length_pulses = mt->getLength() * MIDIToolkit::PULSES_PER_BEAT;
        }

        jump(0);

        raiseEvent(Events::SEQUENCER_MULTITRACK_CHANGED);
    }

    MultiTrackLink* Sequencer::getMultiTrackLink()
    {
        return multitracklink;
    }

//----------------------------------------------------------------------------------------
    void Sequencer::play()
    {
        if (!playing)
        {
            playing = true;
            current_pulse_timestamp = 0;
            current_pulse_click_timestamp = 0;
            clock.start();

            send_event(EVENT_PLAYING, 0, 0);

            // BEAT 0
            onEvent(213, 0);
        }
    }

//----------------------------------------------------------------------------------------
    void Sequencer::record()
    {
        setRecordArmed(true);
    }

//----------------------------------------------------------------------------------------
    void Sequencer::setRecordArmed(bool b)
    {
        record_armed = b;
        raiseEvent(Events::SEQUENCER_STATE_CHANGED);
    }

//----------------------------------------------------------------------------------------
    void Sequencer::stop()
    {
        if (playing)
        {
            playing = false;
            clock.stop();

            // If this is our first recording onto this multitrack.
            if (multitrack_length_pulses==0)
            {
                if (multitracklink != NULL && multitracklink->getLink() != NULL)
                {
                    MultiTrack* multitrack = multitracklink->getLink();

                    // Round current_pulse to the next whole beat.
                    if (current_pulse % MIDIToolkit::PULSES_PER_BEAT != 0)
                    {
                        current_pulse += MIDIToolkit::PULSES_PER_BEAT - (current_pulse % MIDIToolkit::PULSES_PER_BEAT);
                        current_pulse_click += MIDIToolkit::PULSES_PER_BEAT - (current_pulse_click % MIDIToolkit::PULSES_PER_BEAT);
                    }

                    multitrack_length_pulses = current_pulse;
                    multitrack->setLength(multitrack_length_pulses / MIDIToolkit::PULSES_PER_BEAT);

                    jump(0);
                }
            }

            // Automatically turn off recording.
            //record_armed = false;

            all_notes_off();

            send_event(EVENT_STOPPED, 0, 0);
        }
    }

//----------------------------------------------------------------------------------------
    void Sequencer::jump(unsigned int beat)
    {
        MultiTrack* mt;
        if (multitracklink!=0 && (mt = multitracklink->getLink())!=NULL)
        {
            // LOCATION
            current_pulse = beat * MIDIToolkit::PULSES_PER_BEAT;
            current_pulse_click = beat * MIDIToolkit::PULSES_PER_BEAT;

            // TRACK ITERATORS
            for (unsigned int i=0; i<number_of_tracks; i++)
            {
                Track* t = mt->getTrack(i);
                MIDIEventIterator track_begin = t->getIterator_begin();
                MIDIEventIterator track_end   = t->getIterator_end();

                if (beat == 0)
                {
                    // This special case is for efficiency only.
                    iterators[i] = track_begin;
                }
                else if (beat >= multitrack_length_pulses * MIDIToolkit::PULSES_PER_BEAT)
                {
                    // ... And so is this one.
                    iterators[i] = track_end;
                }
                else
                {
                    // Check track is not empty
                    if (t->empty())
                    {
                        iterators[i] = track_begin;
                    }
                    else
                    {
                        MIDIEventIterator* it = &iterators[i];

                        // Moving FORWARD
                        while ((*it)!=track_end && (**it)->absolute < current_pulse)
                        {
                            // Next message
                            (*it)++;
                        }

                        // Moving BACKWARD
                        while ((*it)!=track_begin && (**it)->absolute >= current_pulse)
                        {
                            // It's possible that there could be a string of messages
                            // with the same timestamp (that we want).
                            // We want to get all of them, so we have to find the first one.
                            if ((**it)->absolute == current_pulse)
                            {
                                // Temporary copy of this iterator, and peek at the previous message.
                                MIDIEventIterator temp = *it;
                                temp--;

                                if ((*temp)->absolute < current_pulse)
                                {
                                    // Stop here
                                    break;
                                }
                                else
                                {
                                    // The previous message has the same timestamp,
                                    // so keep going back.
                                    (*it)--;
                                    continue;
                                }
                            }
                            else
                            {
                                (*it)--;
                            }
                        }
                    }
                }
            }
        }

        send_event(EVENT_BEAT_UPDATE, (current_pulse/MIDIToolkit::PULSES_PER_BEAT), 0);
    }
//----------------------------------------------------------------------------------------
    unsigned int Sequencer::getBeat()
    {
        return (current_pulse / MIDIToolkit::PULSES_PER_BEAT);
    }

//----------------------------------------------------------------------------------------
    unsigned long Sequencer::getPulse()
    {
        return current_pulse;
    }

//----------------------------------------------------------------------------------------
    SequencerStates::SequencerState Sequencer::getState()
    {
        if(playing && record_armed)
        {
            return SequencerStates::RECORDING;
        }
        else if(playing && !record_armed)
        {
            return SequencerStates::PLAYING;
        }
        else
        {
            return SequencerStates::STOPPED;
        }
    }


//----------------------------------------------------------------------------------------
    void Sequencer::setTempo(unsigned int t)
    {
        if (t>0)
        {
            unsigned int tmp = tempo;
            // Human-readable tempo, beats per minute
            tempo = t;

            // Sequencer-readable tempo, microseconds per pulse
            microseconds_per_pulse = (60*1000*1000)/MIDIToolkit::PULSES_PER_BEAT/((long)tempo);

            if(tmp != tempo)
            {
                raiseEvent(Events::SEQUENCER_TEMPO_CHANGED);
            }
        }
    }

//----------------------------------------------------------------------------------------
    unsigned int Sequencer::getTempo()
    {
        return tempo;
    }

    bool Sequencer::isRecordArmed()
    {
        return record_armed;
    }

//----------------------------------------------------------------------------------------
// RECORDING
    void Sequencer::receive(MIDIEvent* evt)
    {
        // Hardware Activity IN
        //send_event(EVENT_ACTIVITY_MIDI_IN, 0, 0);
std::cout << "A";
        // Only process this message if we are playing and recording.
        if (record_armed && playing)
        {
std::cout << "B";
            // Error Checking
            if (evt!=0 && multitracklink != NULL && multitracklink->getLink() != NULL)
            {
std::cout << "C";

                // MIDI MESSAGE
                MIDIMessage*  midi_message;
                ChannelMessage* midi_channel_message;

                // Only process CHANNEL MESSAGES
                midi_message = evt->getMessage();
                if (midi_message->isA(MessageTypes::CHANNEL_MESSAGE))
                {
std::cout << "D";
                    midi_channel_message = (ChannelMessage*)(midi_message);

                    // RECORD data onto track.
                    if (multitracklink != NULL && multitracklink->getLink() != NULL)
                    {
std::cout << "E";
                        MultiTrack* multitrack = multitracklink->getLink();
                        for (unsigned int i=0; i<number_of_tracks; i++)
                        {
std::cout << "F";
                            Track* track = multitrack->getTrack(i);
                            if (track!=NULL && multitracklink->isRecording(i))
                            {
std::cout << "G";
                                // RECORD
                                track->insert(current_pulse, (ShortMessage*)midi_channel_message);
                            }
                        }
                    }
                }
            }
        }
    }

//----------------------------------------------------------------------------------------
    // PLAYING
    void Sequencer::onEvent(int id, void* params)
    {
        unsigned long timestamp = clock.getElapsedTime();

        // Respond to TICK EVENT
        // This id==213 was taken directly out of Clock.cpp.
        if (id==213 && playing && multitracklink!=0 && multitracklink->getLink())
        {
            // Decide if the next pulse has ticked over.
            if (timestamp >= current_pulse_timestamp + microseconds_per_pulse)
            {
                // Update the current pulse
                advance_pulse(timestamp);

                // update the current click pulse
                advance_click(timestamp);
            }

            // Stop at the end of the current part.
            //cout << "CP " << current_pulse << " ML " << multitrack_length_pulses << endl;
            if (multitrack_length_pulses!=0 && current_pulse>multitrack_length_pulses-1)
            {
                stop();
                send_event(EVENT_MULTITRACK_END, 0, 0);
            }

        }
    }
//----------------------------------------------------------------------------------------
    void Sequencer::advance_click(unsigned long timestamp)
    {
        // Just in case multiple pulses have ticked over.
        while (timestamp >= current_pulse_click_timestamp + microseconds_per_pulse)
        {
            current_pulse_click++;
            current_pulse_click_timestamp += microseconds_per_pulse;
        }

        // play click (note there is a hack here as were converting multitrack to a part to see if it's actually a count in bit.
        if((static_cast<Vimmer::Part*>(multitracklink->getLink())->getID() == -1) || (!record_armed && clickState) || (record_armed && clickRecordState))
        {
            click.play(current_pulse_click);
        }
    }

//----------------------------------------------------------------------------------------
    void Sequencer::advance_pulse(unsigned long timestamp)
    {
        // Just in case multiple pulses have ticked over.
        while (timestamp >= current_pulse_timestamp + microseconds_per_pulse)
        {
            // Check we haven't exceed the length of the multitrack.
            if (multitrack_length_pulses!=0 && current_pulse > multitrack_length_pulses - 1)
            {
                break;
            }

            current_pulse++;
            current_pulse_timestamp += microseconds_per_pulse;

            // Check if new beat has ticked over.
            if (current_pulse % MIDIToolkit::PULSES_PER_BEAT == 0)
            {
                // Update current beat.
                send_event(EVENT_BEAT_UPDATE, (current_pulse/MIDIToolkit::PULSES_PER_BEAT), 0);
            }
        }

        MultiTrack* mt = multitracklink->getLink();

        // Search each track for MIDI Events ready to send.
        for (unsigned int i=0; i<number_of_tracks; i++)
        {
            if (mt->getTrack(i) != 0)
            {
                MIDIEventIterator track_end = mt->getTrack(i)->getIterator_end();
                while (iterators[i] != track_end && (*iterators[i])->absolute <= current_pulse)
                {
                    MIDIEvent midi_event;
                    midi_event = *(*iterators[i]);

                    // CHECK PLAYING: Only play if this track is selected (unmuted).
                    if (multitracklink->isPlaying(i) && midi_event.getMessage() != NULL)
                    {
                        // Make our own copy.
                        MIDIMessage* midi_message = midi_event.getMessage();
                        if (midi_message != NULL)
                        {

                            // CHANNELIZE
                            if (midi_message->isA(MessageTypes::CHANNEL_MESSAGE))
                            {
                                ChannelMessage* midi_channel_message = (ChannelMessage*) midi_message;
                                int new_channel_number = multitracklink->getTrackChannel(i);
                                if (new_channel_number != MultiTrackLink::TRACK_CHANNEL_NOCHANNELIZE)
                                {
                                    // Convert to this channel
                                    midi_channel_message->setChannel(new_channel_number - 1);
                                }
                            }

                            // DISTRIBUTE
                            distributeMessage(&midi_event);
                        }
                    }

                    // Next MIDI Event
                    iterators[i]++;
                }
            }
        }
    }

//----------------------------------------------------------------------------------------
// INTERNAL USE ONLY

/*
        // These are used by send_event()
        static const int EVENT_STOPPED = 0;
        static const int EVENT_PLAYING = 1;
        static const int EVENT_MULTITRACK_END = 2;
        static const int EVENT_BEAT_UPDATE = 3;
        static const int EVENT_ACTIVITY_MIDI_IN = 4;
        static const int EVENT_ACTIVITY_MIDI_OUT = 5;
*/

    void Sequencer::send_event(int id, int param1, int param2)
    {
        int current_beat = (int)(current_pulse / MIDIToolkit::PULSES_PER_BEAT);

        switch (id)
        {
            case EVENT_STOPPED:
            {
                raiseEvent(Events::SEQUENCER_STOPPED, &current_beat);
                break;
            }
            case EVENT_PLAYING:
            {
                raiseEvent(Events::SEQUENCER_PLAYING, &current_beat);
                break;
            }
            case EVENT_MULTITRACK_END:
            {
                raiseEvent(Events::SEQUENCER_MULTITRACK_END, &current_beat);
                break;
            }
            case EVENT_BEAT_UPDATE:
            {
                raiseEvent(Events::SEQUENCER_BEAT_UPDATE, &current_beat);
                break;
            }
            case EVENT_ACTIVITY_MIDI_IN:
            {
                raiseEvent(Events::SEQUENCER_ACTIVITY_MIDI_IN, &current_beat);
                break;
            }
            case EVENT_ACTIVITY_MIDI_OUT:
            {
                raiseEvent(Events::SEQUENCER_ACTIVITY_MIDI_OUT, &current_beat);
                break;
            }
            default:
            {
                break;
            }
        }
    }

    void Sequencer::all_notes_off()
    {
        for (int i=0; i<16; i++)
        {
            MIDIEvent e(new ChannelMessage(ChannelCommands::Controller, i, ControllerTypes::AllNotesOff , 0));
            distributeMessage(&e);
        }
    }

    void Sequencer::all_sound_off()
    {
        for (int i=0; i<16; i++)
        {
            MIDIEvent e(new ChannelMessage(ChannelCommands::Controller, i, ControllerTypes::AllSoundOff , 0));
            distributeMessage(&e);
        }
    }

    void Sequencer::setClickPlay(bool s)
    {
        clickState = s;
    }

    bool Sequencer::getClickPlay()
    {
        return clickState;
    }

    void Sequencer::setClickRecord(bool s)
    {
        clickRecordState = s;
    }

    bool Sequencer::getClickRecord()
    {
        return clickRecordState;
    }

    void Sequencer::setClickInterval(int interval)
    {
        click.setClickInterval(interval);
    }

    int Sequencer::getClickInterval()
    {
        return click.getClickInterval();
    }

}
