/*
   Virtual MIDI Multitrack Recorder
   Copyright (c) 2006 MIDI Team

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU Lesser General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU Lesser  General Public License for more details.

   You should have received a copy of the GNU Lesser General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/

/**
   SysCommonMessage.hppile SysCommonMessage.hpp
   Charles Weld, David Wilson, James Brown, Jonathan Van Rossum, and Matthew Harrold
   @brief Declaration of class SysCommonMessage, part of Virtual MIDI Multitrack Recorder
*/

#ifndef _SYSCOMMONMESSAGE_H
#define _SYSCOMMONMESSAGE_H

#include "ShortMessage.hpp"

namespace MIDIToolkit
{
    /**
     * Defines constants representing the various system common message types.
     */
    /// @ingroup midimsg
    namespace SysCommonTypes
    {
        /// @ingroup midimsg
        enum
        {
            //! Represents the MTC system common message type.
            MidiTimeCode = 0xF1,

            //! Represents the song position pointer type.
            SongPositionPointer,

            //! Represents the song select type.
            SongSelect,

            //! Represents the tune request type.
            TuneRequest = 0xF6
        };
    }

    //! System common types.
    /// @ingroup midimsg
    typedef int SysCommonType;

    /**
     * Represents MIDI system common messages.
     */
    /// @ingroup midimsg
    class SysCommonMessage : public ShortMessage
    {
    public:
        /**
         * Initializes a new instance of the SysCommonMessage class with the spacified type.
         * @param type The type of SysCommonMessage.
         */
        SysCommonMessage(SysCommonType type);

        /**
         * Initializes a new instance of the SysCommonMessage class with the spacified type and first data value.
         * @param type The type of SysCommonMessage.
         * @param data1 The first data value.
         */
        SysCommonMessage(SysCommonType type, int data1);

        /**
         * Initializes a new instance of the SysCommonMessage class with the spacified type, first data value, and second data value.
         * @param type The type of SysCommonMessage.
         * @param data1 The first data value.
         * @param data2 The second data value.
         */
        SysCommonMessage(SysCommonType type, int data1, int data2);

        /**
         * Default destructor.
         */
        ~SysCommonMessage();

        /**
         * Gets the type of System Common Message.
         * @return The type of System Common Message.
         */
        virtual int getSysCommonType();

        /**
         * Sets the type of System Common Message.
         * @param type The new type of System Common Message.
         */
        virtual void setSysCommonType(int type);

        /**
         * Gets the first data value.
         * @return The first data value.
         */
        virtual int getData1();

        /**
         * Sets the first data value.
         * @param data The first data value.
         */
        virtual void setData1(int data);

        /**
         * Gets the second data value.
         * @return The second data value.
         */
        virtual int getData2();

        /**
         * Sets the second data value.
         * @param data The second data value.
         */
        virtual void setData2(int data);

        /**
         * Clones this message.
         */
        virtual MIDIMessage* clone();

        /**
         * Checks if this message is of type msgType.
         * @param msgType The type of message to check.
         * @return True if this message is of type msgType, otherwise false.
         */
        virtual bool isA(MessageType msgType);
    };
}

#endif  //_SYSCOMMONMESSAGE_H
