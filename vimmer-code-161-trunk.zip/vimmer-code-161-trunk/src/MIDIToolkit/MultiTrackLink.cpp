/*
   Virtual MIDI Multitrack Recorder
   Copyright (c) 2006 MIDI Team

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU Lesser General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU Lesser  General Public License for more details.

   You should have received a copy of the GNU Lesser General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/

/**
   @file   MultiTrackLink.cpp
   @author Jonathan Van Rossum (jvr85@users.sourceforge.net)
   @brief  Implementation of the class MultiTrackLink.
*/

#include "MultiTrackLink.hpp"
#include "MultiTrack.hpp"
#include "Events.hpp"
// DEBUGGING
#include <iostream>

namespace MIDIToolkit
{

    MultiTrackLink::MultiTrackLink()
    {
        link = NULL;
        number_of_tracks = 0;
    }

    MultiTrackLink::MultiTrackLink(const MultiTrackLink& mtl)
    {
        link = mtl.link;
        number_of_tracks = mtl.number_of_tracks;

        track_state.clear();
        track_channel.clear();
        if(link!=NULL)
        {
            // Initialise the TRACK STATE
            number_of_tracks = link->count();
            for(unsigned int i=0; i<number_of_tracks; i++)
            {
                // Clear each track
                track_state.push_back(mtl.getTrackState(i));
                track_channel.push_back(mtl.getTrackChannel(i));
            }
        }
    }

    MultiTrackLink& MultiTrackLink::operator = (const MultiTrackLink& mtl)
    {
        if(this != &mtl)
        {
            link = mtl.link;
            number_of_tracks = mtl.number_of_tracks;

            track_state.clear();
            track_channel.clear();
            if(link!=NULL)
            {
                // Initialise the TRACK STATE
                number_of_tracks = link->count();
                for(unsigned int i=0; i<number_of_tracks; i++)
                {
                    // Clear each track
                    track_state.push_back(mtl.getTrackState(i));
                    track_channel.push_back(mtl.getTrackChannel(i));
                }
            }
        }
        return *this;
    }



    MultiTrackLink::~MultiTrackLink()
    {
        // DEBUGGING
        //std::cout << "Destroying MultiTrackLink... ";

        // DEBUGGING
        //std::cout << "done." << std::endl;
    }

    void MultiTrackLink::setLink(MultiTrack* l)
    {
        link = l;

        // For some reason, these don't work a few lines down. !!!
        int temp1 = TRACK_STATE_CLEAR;
        int temp2 = TRACK_CHANNEL_NOCHANNELIZE;

        // Recreate the STATE and CHANNEL vectors
        if(l->count()!=number_of_tracks)
        {
            track_state.clear();
            track_channel.clear();
            if(l!=NULL)
            {
                // Initialise the TRACK STATE
                number_of_tracks = link->count();
                for(unsigned int i=0; i<number_of_tracks; i++)
                {
                    // Clear each track
                    track_state.push_back(temp1);
                    track_channel.push_back(temp2);
                }
            }
        }
    }

    MultiTrack* MultiTrackLink::getLink()
    {
        return link;
    }

    unsigned int MultiTrackLink::trackCount() const
    {
        return number_of_tracks;
    }

    int MultiTrackLink::getTrackState(unsigned int tracknumber) const
    {
        // Bounds checking
        if (tracknumber < number_of_tracks)
        {
            return track_state[tracknumber];
        }
        else
        {
            return TRACK_STATE_INVALID_TRACK;
        }
    }

    void MultiTrackLink::setTrackState(unsigned int tracknumber, int s)
    {
        // Bounds checking, and check state is valid.
        if (tracknumber<number_of_tracks && validateTrackState(s))
        {
            track_state[tracknumber] = s;
            this->raiseEvent(Events::TRACK_STATE_CHANGED);
        }
    }

    bool MultiTrackLink::isPlaying(unsigned int tracknumber) const
    {
        int s = getTrackState(tracknumber);
        return (s==TRACK_STATE_PLAY || s==TRACK_STATE_PLAY_AND_RECORD);
    }

    bool MultiTrackLink::isRecording(unsigned int tracknumber) const
    {
        int s = getTrackState(tracknumber);
        return (s==TRACK_STATE_RECORD || s==TRACK_STATE_PLAY_AND_RECORD);
    }

    void MultiTrackLink::setTrackStateAll(int s)
    {
        for (unsigned int i=0; i<number_of_tracks; i++)
        {
            setTrackState(i, s);
        }
    }

    int MultiTrackLink::getTrackChannel(unsigned int tracknumber) const
    {
        // Bounds checking
        if (tracknumber < number_of_tracks)
        {
            return track_channel[tracknumber];
        }
        else
        {
            return TRACK_CHANNEL_INVALID_TRACK;
        }
    }

    void MultiTrackLink::setTrackChannel(unsigned int tracknumber, int c)
    {
        // Bounds checking, and check state is valid.
        if (tracknumber<number_of_tracks && validateTrackChannel(c))
        {
            track_channel[tracknumber] = c;
        }
    }

    void MultiTrackLink::setTrackChannelAll(int c)
    {
        // Bounds checking, and check state is valid.
        for (unsigned int i=0; i<number_of_tracks; i++)
        {
            setTrackChannel(i, c);
        }
    }

    bool MultiTrackLink::validateTrackState(int s)
    {
        // Don't yet allow the user to set simultaneous playing and recording.
        //return (s==TRACK_STATE_CLEAR || s==TRACK_STATE_PLAY || s==TRACK_STATE_RECORD || s==TRACK_STATE_PLAY_AND_RECORD);

        return (s==TRACK_STATE_CLEAR || s==TRACK_STATE_PLAY || s==TRACK_STATE_RECORD);
    }

    bool MultiTrackLink::validateTrackChannel(int c)
    {
        return (c==TRACK_CHANNEL_NOCHANNELIZE || (c>=1 && c<=16));
    }



}
