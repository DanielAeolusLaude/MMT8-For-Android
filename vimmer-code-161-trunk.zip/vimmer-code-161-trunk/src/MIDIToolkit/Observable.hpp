/*
   Virtual MIDI Multitrack Recorder
   Copyright (c) 2006 MIDI Team

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/

/**
   Observable.hppile Observable.hpp
   Charles Weld, David Wilson, James Brown, Jonathan Van Rossum, and Matthew Harrold
   @brief Declaration of class Observable, part of Virtual MIDI Multitrack Recorder
*/

#ifndef _OBSERVABLE_H
#define _OBSERVABLE_H

#include "MIDIToolkitPrerequisites.hpp"

namespace MIDIToolkit
{

	class Observer;

    /**
	    @brief A Observable class provides the capability to generate Events.
	    @ingroup events.
	*/
    class Observable
    {
    public:

        /**
         @brief Destructor

         Destructor
        */
        virtual ~Observable();

        /**
         @brief Add a new Observer to this Observer.

         Add a new Observer to this Observer.

         @param Add this Observer.
         @return The Observer to add.
        */
        virtual void addObserver(Observer *observer);

        /**
         @brief Remove a new Observer from this Observer.

         Remove a new Observer from this Observer.

         @param Remove this Observer.
         @return The Observer to remove.
        */
        virtual void removeObserver(Observer *observer);

        /**
         @brief Remove all Observers.

         Remove all Observers.
        */
        virtual void removeAll();


        /**
         @brief Enable Observerable.

         Enable Observerable.
        */
        void enableObservable()
        {
            m_On=true;
        }

        /**
         @brief Disable Observerable.

         Disable Observerable.
        */
        void disableObservable()
        {
            m_On=false;
        }

        /**
         @brief Check Observerable status.

         Check Observerable status.
        */
        bool isObservableEnabled()
        {
            return m_On;
        }

    protected:
        ObserverList observers;
        bool m_On;
    protected:
        Observable();

        virtual void raiseEvent(int id, void* params=NULL);
    };
}

#endif  //_OBSERVABLE_H
