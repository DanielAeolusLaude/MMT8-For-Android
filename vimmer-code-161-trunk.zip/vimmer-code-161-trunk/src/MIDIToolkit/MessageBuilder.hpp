/*
   Virtual MIDI Multitrack Recorder
   Copyright (c) 2006 MIDI Team

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU Lesser General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU Lesser  General Public License for more details.

   You should have received a copy of the GNU Lesser General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/

/**
   MessageBuilder.hppile MessageBuilder.hpp
   Charles Weld, David Wilson, James Brown, Jonathan Van Rossum, and Matthew Harrold
   @brief Declaration of class MessageBuilder, part of Virtual MIDI Multitrack Recorder
*/

#ifndef _MESSAGEBUILDER_H
#define _MESSAGEBUILDER_H

#include "ShortMessage.hpp"

namespace MIDIToolkit
{
    /**
     * Provides a number of services that allow the user to build MIDI Messages given the input data.
     */
    /// @ingroup midimsg
    class MessageBuilder
    {
    public:
        /**
         * Builds a message from the original message bytes.
         * @param msg The original message bytes.
         * @return The constructed message.
         */
        static ShortMessage* buildMessage(int msg);

        /**
         * Builds a message from the original message bytes.
         * @param status The status byte.
         * @param data1 The data 1 byte.
         * @param data2 The data 2 byte.
         * @return The constructed message.
         */
        static ShortMessage* buildMessage(int status, int data1, int data2);
    };
}

#endif  //_MessageBuilder_H
