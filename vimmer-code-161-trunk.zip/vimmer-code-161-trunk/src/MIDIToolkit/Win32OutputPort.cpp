/*
   Virtual MIDI Multitrack Recorder
   Copyright (c) 2006 MIDI Team

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU Lesser General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU Lesser  General Public License for more details.

   You should have received a copy of the GNU Lesser General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/

/**
   @file Win32OutputPort.cpp
   Charles Weld, David Wilson, James Brown, Jonathan Van Rossum, and Matthew Harrold
   @brief Declaration of class Win32OutputPort, part of Virtual MIDI Multitrack Recorder
*/

#include "Win32OutputPort.hpp"
#include "OutputPort.hpp"
#include <windows.h>
#include "Exception.hpp"
#include "Exceptions.hpp"
#include "LogLevels.hpp"

#include <sstream>

namespace MIDIToolkit
{
    Win32OutputPort::Win32OutputPort():
        OutputPort()
    {
        handle = 0;
    }

    Win32OutputPort::Win32OutputPort(int port_id):
        OutputPort()
    {
        handle = 0;
        open(port_id);
    }

    Win32OutputPort::~Win32OutputPort()
    {
        close();
    }

    void Win32OutputPort::open(int port_id)
    {
        if(handle)
                close();

        portID = port_id;

        if(port_id != -1)
        {
            /* Open the MIDI Device */
            unsigned long result;

            result = midiOutOpen(&handle, (UINT)port_id, 0, 0, CALLBACK_WINDOW);
            if (result)
            {
               std::stringstream msg;
               msg << "There was an error opening the output port (" << port_id << ").";
               throw Exception(Exceptions::MIDI, msg.str(), "void Win32OutputPort::open(int port_id)");
            }
        }
    }

    void Win32OutputPort::close()
    {
        if(handle)
        {
            midiOutClose(handle);
            handle = NULL;
        }
        else
        {
            logger->log("Can't close a closed port.", LogLevels::LEVEL_ERROR);
        }
    }

    String Win32OutputPort::getPortName(int port)
    {
        MIDIOUTCAPS moc;
        String portName;
        if (!midiOutGetDevCaps(port, &moc, sizeof(MIDIOUTCAPS)))
        {
            /* Display its Device ID and name */
            portName = moc.szPname;
        }
        else
        {
            throw Exception(Exceptions::MIDI, "Failed to get output port details", "String Win32OutputPort::getPortName(int port)");
        }

        return portName;
    }

    int Win32OutputPort::getNumPorts()
    {
        return midiOutGetNumDevs();
    }

    void Win32OutputPort::send(ShortMessage* msg)
    {
        if(handle)
        {
            midiOutShortMsg(handle, msg->getMessage());
        }
        else
        {
            logger->log("Tried to send a message to an unopened port", LogLevels::LEVEL_ERROR);
        }
    }

}
