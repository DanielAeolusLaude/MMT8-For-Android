/*
   Virtual MIDI Multitrack Recorder
   Copyright (c) 2006 MIDI Team

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU Lesser General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU Lesser  General Public License for more details.

   You should have received a copy of the GNU Lesser General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/

/**
   ShortMessage.hppile ShortMessage.hpp
   Charles Weld, David Wilson, James Brown, Jonathan Van Rossum, and Matthew Harrold
   @brief Declaration of class ShortMessage, part of Virtual MIDI Multitrack Recorder
*/

#ifndef _SHORTMESSAGE_H
#define _SHORTMESSAGE_H

#include "MIDIMessage.hpp"

namespace MIDIToolkit
{
	//! Represents the basic class for all MIDI short messages.
	/**
	 * MIDI short messages represent all MIDI messages except meta messages
     * and system exclusive messages. This includes channel messages, system
     * realtime messages, and system common messages.
     */
    /// @ingroup midimsg
    class ShortMessage : public MIDIMessage
    {
    public:
        /**
         * Gets the status value of the message.
         * @return The status value.
         */
        virtual unsigned long getStatus();

        /**
         * Gets the message.
         * @return The message.
         */
        virtual unsigned long getMessage();

        /**
         * Gets the status value of a message.
         * @return The status value.
         */
        static unsigned long unpackStatus(unsigned long msg);

        /**
         * Sets the status of a message.
         * @param status The status value.
         */
        static unsigned long packStatus(unsigned long status, unsigned long msg);

        /**
         * Gets the packaged data 1 value.
         * @return The data1 value.
         */
        static unsigned long unpackData1(unsigned long msg);

        /**
         * Sets the data 1 value of the message.
         * @param data1 The data1 value.
         */
        static unsigned long packData1(unsigned long data1, unsigned long msg);

        /**
         * Gets the data 2 value of the message.
         * @return The data 2 value.
         */
        static unsigned long unpackData2(unsigned long msg);

        /**
         * Sets the data 2 value of the message.
         * @param data2 The data 2 value.
         */
        static unsigned long packData2(unsigned long data2, unsigned long msg);

        void print();

        /**
         * Checks if this message is of type msgType.
         * @param msgType The type of message to check.
         * @return True if this message is of type msgType, otherwise false.
         */
        virtual bool isA(MessageType msgType);

        /**
         * Short Message Contructor.
         */
        ShortMessage();

        /**
         * Default destructor.
         */
        virtual ~ShortMessage();

        /**
         * Sets the status of the message.
         * @param status The status value.
         */
        virtual void setStatus(unsigned long status);

        /**
         * Gets the packaged data 1 value.
         * @return The data1 value.
         */
        virtual unsigned long getPackageData1();

        /**
         * Sets the data 1 value of the message.
         * @param data1 The data1 value.
         */
        virtual void setPackageData1(unsigned long data1);

        /**
         * Gets the data 2 value of the message.
         * @return The data 2 value.
         */
        virtual unsigned long getPackageData2();

        /**
         * Sets the data 2 value of the message.
         * @param data2 The data 2 value.
         */
        virtual void setPackageData2(unsigned long data2);

    // varibles
    public:
        //! Data's max value (for checking the data bytes)
        static const unsigned long DataMaxValue = 127;

        //! Status's max value (for checking the status byte).
        static const unsigned long StatusMaxValue = 255;

    private:
        //! The status mask (used to get the status code)
        static const unsigned long StatusMask = ~255;

    protected:
         //! The data mask (ie channel number)
        static const unsigned long DataMask = ~StatusMask;

    private:
        //! The Data 1 mask (used to get the data1 byte).
        static const unsigned long Data1Mask = ~65280;

        //! The Data 2 mask (used to get the data2 byte).
        static const unsigned long Data2Mask = ~Data1Mask + DataMask;


        //! Used in the data packaging ops.
        static const unsigned long Shift = 8;

    protected:
        //! The midi message
        unsigned long message;
    };
}

#endif  //_SHORTMESSAGE_H
