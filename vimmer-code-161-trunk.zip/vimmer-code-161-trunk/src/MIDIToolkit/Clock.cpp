/*
   Virtual MIDI Multitrack Recorder
   Copyright (c) 2006 MIDI Team

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU Lesser General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU Lesser  General Public License for more details.

   You should have received a copy of the GNU Lesser General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/

/**
   Clock.cppile Clock.cpp
   Charles Weld, David Wilson, James Brown, Jonathan Van Rossum, and Matthew Harrold
   @brief Declaration of class Clock, part of Virtual MIDI Multitrack Recorder
*/

#include "Clock.hpp"
#include "ClockStatus.hpp"
#include "mathsfunc.h"


namespace MIDIToolkit
{
    DWORD Clock::resolution = 0;

    void CALLBACK TimeProc(UINT uID, UINT uMsg, DWORD dwUser, DWORD dw1, DWORD dw2)
    {
        Clock* c = (Clock*)dwUser;
        c->tick();
    }

    Clock::Clock()
    {
        this->interval = 5;
        status = 1;

        if(Clock::resolution == 0)
        {
            TIMECAPS tc;
            if(timeGetDevCaps(&tc, sizeof(tc)) != TIMERR_NOERROR)
            {

            }
            Clock::resolution = min(max(tc.wPeriodMin,0),tc.wPeriodMax);
        }
    }

    Clock::~Clock()
    {
        if(status != ClockStatus::STOPPED)
        {
            stop();
        }
    }

    void Clock::start()
    {
       if(status != ClockStatus::STOPPED)
       {
           stop();
       }

       timeBeginPeriod(Clock::resolution);

        // create the timer
        idEvent = timeSetEvent(
            interval,
            Clock::resolution,
            TimeProc,
            (DWORD)this,
            TIME_PERIODIC);

        status = 0;

        timer.reset();
    }

    void Clock::stop()
    {
        //ASSERT (status != ClockStatus::STOPPED, "Clock must be active to stop");
        // destroy the timer
        timeKillEvent(idEvent);

        // reset the timer
        timeEndPeriod (interval);

        status = 1;
    }

    void Clock::pause()
    {
        //ASSERT (status != ClockStatus::STOPPED, "Clock must be active to pause.")

        if(status == 0)
        {
            timer.pause();
            status = 2;
        }
        else
        {
            timer.pause();
            status = 0;
        }

    }

    void Clock::setTickInterval(UINT interval)
    {
        this->interval = interval;
    }

    UINT Clock::getTickInterval()
    {
        return this->interval;
    }

    void Clock::tick()
    {
        if(status == ClockStatus::PLAYING)
        {
            // todo use event id
            int elapsedTime = timer.getElapsedTime();

            raiseEvent(213, &elapsedTime);
        }
    }

    __int64 Clock::getElapsedTime()
    {
        return timer.getElapsedTime();
    }

    int Clock::getStatus()
    {
        return status;
    }
}
