/*
   Virtual MIDI Multitrack Recorder
   Copyright (c) 2006 MIDI Team

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU Lesser General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU Lesser  General Public License for more details.

   You should have received a copy of the GNU Lesser General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/

/**
   Modulator.hppile Modulator.hpp
   Charles Weld, David Wilson, James Brown, Jonathan Van Rossum, and Matthew Harrold
   @brief Declaration of class Modulator, part of Virtual MIDI Multitrack Recorder
*/

#ifndef _MODULATOR_H
#define _MODULATOR_H

#include "Generator.hpp"
#include "Analyser.hpp"

namespace MIDIToolkit
{
    /// @brief A Modulator is a combination of a Generator and Analyser, ie it can process MIDI Events and Generate them.
    /**
     * A Modulator is a combination of a Generator and Analyser as it has the capability to both analyze incoming MIDI Events
     * and also Generate new MIDI Events a good example of a Modulator would be an OutputFilter.
     *
     * @ingroup midicom
     */
    class Modulator : public Generator, public Analyser
    {
    public:
        /**
         * @brief Destructor.
         */
        virtual ~Modulator(){}
    };
}

#endif  //_MODULATOR_H
