/*
   Virtual MIDI Multitrack Recorder
   Copyright (c) 2006 MIDI Team

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/

/**
   LogManager.hppile LogManager.hpp
   Charles Weld, David Wilson, James Brown, Jonathan Van Rossum, and Matthew Harrold
   @brief Declaration of class LogManager, part of Virtual MIDI Multitrack Recorder
*/

#ifndef _LOGMANAGER_H
#define _LOGMANAGER_H

#include <iostream>

#include "Log.hpp"
#include "MIDIToolkitPrerequisites.hpp"

namespace MIDIToolkit
{

/**
    @brief The LogManager provides Log Management services.

    @ingroup log
*/
    class LogManager
    {
    public:
        /**
         * Destructor.
         */
        ~LogManager();

        /**
         * Gets an instance of log manager.
         * @return The log manager.
         */
        static LogManager* getSingleton();

        /**
         * Logs a message of a cirtain level to file.
         * If the level is bellow the current minimum level then the
         * message isn't logged.
         * @param msg The message to be logged.
         * @param level The level of the message (priority).
         */
        void log(String msg, int level=LogLevels::LEVEL_NORMAL);

        /**
         * Add's a log with a given name to the logger.
         */
        void addLog(String name);

        /**
         * Remove's a log with a given name from the logger.
         */
        void removeLog(String name);

        /**
         * Get's a logger given it's name.
         * @param name The name of the logger to get.
         */
        Log* getLog(String name);

        /**
         * Check if a logger exists.
         */
        bool logExists(String name);
    private:
        LogManager();
        std::ofstream* m_Output;
        LogMap logs;
        static LogManager* m_Instance;
    };
}

#endif  //_LOGMANAGER_H
