/*
   Virtual MIDI Multitrack Recorder
   Copyright (c) 2006 MIDI Team

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU Lesser General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU Lesser  General Public License for more details.

   You should have received a copy of the GNU Lesser General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/

/**
   MIDIMessage.hppile MIDIMessage.hpp
   Charles Weld, David Wilson, James Brown, Jonathan Van Rossum, and Matthew Harrold
   @brief Declaration of class MIDIMessage, part of Virtual MIDI Multitrack Recorder
*/

#ifndef _MIDIMESSAGE_H
#define _MIDIMESSAGE_H

#include "MIDIToolkitPrerequisites.hpp"

namespace MIDIToolkit
{
    /**
     * Represents any type of MIDI Message.
     */
    /// @ingroup midimsg
    class MIDIMessage
    {
    public:
        /**
         * Gets the type of MIDI Message.
         * @return The Message Type.
         */
        virtual MessageType getType();

        /**
         * Destructor.
         */
        virtual ~MIDIMessage();

        /**
         * Clones the MIDI Message.
         */
        virtual MIDIMessage* clone() = 0;

        /**
         * Checks if this message is of type msgType.
         * @param msgType The type of message to check.
         * @return True if this message is of type msgType, otherwise false.
         */
        virtual bool isA(MessageType msgType);

        /**
         * Prints the MIDI Message to console (debugging).
         */
        virtual void print();
    protected:

        /**
         * Destructor.
         */
        MIDIMessage();

    protected:
        MessageType type;
    };
}

#endif  //_MIDIMESSAGE_H
