/*
   Virtual MIDI Multitrack Recorder
   Copyright (c) 2006 MIDI Team

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/

/**
   LogManager.cppile LogManager.cpp
   Charles Weld, David Wilson, James Brown, Jonathan Van Rossum, and Matthew Harrold
   @brief Declaration of class LogManager, part of Virtual MIDI Multitrack Recorder
*/

#include "LogManager.hpp"
#include "Log.hpp"

#include <iostream>
#include <fstream>

namespace MIDIToolkit
{
    LogManager* LogManager::m_Instance = NULL;

    LogManager::LogManager()
    {
        m_Output = new std::ofstream("log.txt",std::ios::out);
        if (!(*m_Output)) // Always test file open
        {
            // throw exception.
        }
        logs["default"] = new Log(m_Output);
    }

    LogManager::~LogManager()
    {
        // iterate though logs and delete them all.
        for(LogMap::iterator iter = logs.begin();iter!=logs.end();iter++)
        {
            delete iter->second;
        }
        m_Output->close();
        delete m_Output;
    }

    LogManager* LogManager::getSingleton()
    {
        if(m_Instance == NULL)
            m_Instance = new LogManager();

        return m_Instance;
    }

    void LogManager::log(String msg, int level)
    {
        logs["default"]->log(msg, level);
    }

    void LogManager::addLog(String name)
    {
        if(!logExists(name))
        {
            logs[name] = new Log(m_Output);
        }
    }

    bool LogManager::logExists(String name)
    {
        if(logs.find(name) == logs.end())
        {
            return false;
        }
        else
        {
            return true;
        }
    }

    void LogManager::removeLog(String name)
    {
        if(logExists(name))
        {
            delete logs[name];
            logs.erase(name);
        }
    }

    Log* LogManager::getLog(String name)
    {
        if(logExists(name))
        {
            return logs[name];
        }
        else
        {
            // throw exception
        }
        return NULL;
    }

}
