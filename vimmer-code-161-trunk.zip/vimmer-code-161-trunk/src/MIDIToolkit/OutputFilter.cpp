/*
   Virtual MIDI Multitrack Recorder
   Copyright (c) 2006 MIDI Team

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU Lesser General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU Lesser  General Public License for more details.

   You should have received a copy of the GNU Lesser General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/

/**
   @file OutputFilter.cpp
   Charles Weld, David Wilson, James Brown, Jonathan Van Rossum, and Matthew Harrold
   @brief Declaration of class OutputFilter, part of Virtual MIDI Multitrack Recorder
*/

#include "OutputFilter.hpp"
#include "MIDIEvent.hpp"
#include "MessageTypes.hpp"
#include "ChannelMessage.hpp"
#include "MIDIToolkitMessage.hpp"
#include "Events.hpp"

namespace MIDIToolkit
{

    OutputFilter::OutputFilter()
    {
        logger = LogManager::getSingleton();
        for(int i=0;i<127;++i)
        {
            m_Notes[i] = false;
        }
    }

    OutputFilter::~OutputFilter()
    {
    }

    void OutputFilter::receive(MIDIEvent* evt)
    {
        raiseEvent(Events::SEQUENCER_ACTIVITY_MIDI_OUT);

        // if we past the test forward on the message.
        //if(check(evt))
        {
            this->distrubuteMessage(evt);
        }
    }

    bool OutputFilter::check(MIDIEvent* evt)
    {
        // check if it's a channel message.
        if(evt->getMessage()!=NULL)
        {
            // if message is a channel message
            if(evt->getMessage()->isA(MessageTypes::CHANNEL_MESSAGE))
            {
                ChannelMessage* msg = static_cast<ChannelMessage*> (evt->getMessage());
                // if message is a note on message and the note is currently off then turn it on an let the message pass.
                if(msg->getCommand() == ChannelCommands::NoteOn && !m_Notes[msg->getData1()])
                {
                    m_Notes[msg->getData1()] = true;
                    return true;
                }
                // if message is a note on message and the note is currently on then don't let the message pass.
                else if(msg->getCommand() == ChannelCommands::NoteOn && m_Notes[msg->getData1()])
                {
                    logger->log("Message failed filter because the note was already on (it was a note on message).");
                    return false;
                }
                // if message is a note off message and the note is currently on then mark it as off and and let the message pass.
                else if(msg->getCommand() == ChannelCommands::NoteOff && m_Notes[msg->getData1()])
                {
                    m_Notes[msg->getData1()] = false;
                    return true;
                }
                // if message is a note off message and the note is currently off then don't let the message pass.
                else if(msg->getCommand() == ChannelCommands::NoteOff && !m_Notes[msg->getData1()])
                {
                    logger->log("Message failed filter because the note was already off.");
                    return false;
                }
                // for all other channel messages just let it pass.
                else
                {
                    return true;
                }
            }
            // if the message is a MIDIToolkit Message.
            if(evt->getMessage()->isA(MessageTypes::MIDITOOLKIT_MESSAGE))
            {
                MIDIToolkitMessage* msg = static_cast<MIDIToolkitMessage*> (evt->getMessage());

                // if the message is a All Notes Off Message Then turn all notes off with a volume of 40
                if(msg->getMessageType() == MTMessageTypes::ALL_NOTES_OFF)
                {
                    for(int i=0;i<127;++i)
                    {
                        // if note is on.
                        if(m_Notes[i])
                        {
                            MIDIEvent tmp(new ChannelMessage(ChannelCommands::NoteOff, i, 40));
                            distrubuteMessage(&tmp);
                        }
                    }
                }

                // never forward a MIDIToolkit Message
                logger->log("Message failed filter because we never send MIDIToolkit Messages.");
                return false;
            }
            // all other messages are forwarded  on.
            else
            {
                return true;
            }
        }
        else
        {
            logger->log("Message failed filter because there was no message (an empty event).");
            return false;
        }
    }

}
