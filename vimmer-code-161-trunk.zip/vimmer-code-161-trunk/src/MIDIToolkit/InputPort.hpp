/*
   Virtual MIDI Multitrack Recorder
   Copyright (c) 2006 MIDI Team

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU Lesser General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU Lesser  General Public License for more details.

   You should have received a copy of the GNU Lesser General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/

/**
   InputPort.hppile InputPort.hpp
   Charles Weld, David Wilson, James Brown, Jonathan Van Rossum, and Matthew Harrold
   @brief Declaration of class InputPort, part of Virtual MIDI Multitrack Recorder
*/

#ifndef _INPUTPORT_H
#define _INPUTPORT_H

#include "MIDIToolkitPrerequisites.hpp"
#include "IInputPort.hpp"
#include "LogManager.hpp"

namespace MIDIToolkit
{
    /**
     * @brief Provides a more concrete Implementation of Input Port but still abastract enough to be cross platform independent.
     *
     * Provides a more concrete Implementation of Input Port but still abastract enough to be cross platform independent.
     * Basically this handles proccessing the MIDI Event but doesn't have any capability to actually receive any MIDI Events.
     */
    /// @ingroup midiport
    class InputPort : public IInputPort
    {
    public:
        /**
         * @brief Constructor.
         *
         * Constructor.
         */
        InputPort();

        /**
         * @brief Destructor.
         *
         * Destructor.
         */
        virtual ~InputPort();

        /**
         * @see IInputPort::getPortNumber()
         */
        virtual int getPortNumber();
    protected:
        /**
         * @brief Procces a Short Message, into a MIDI Event and distributes it.
         *
         * Procces a Short Message, into a MIDI Event and distributes it.
         * @param timestamp When the Message was received.
         * @param msg The actual short Message.
         */
        virtual void processShortMsg(unsigned long timestamp, unsigned long msg);
    protected:
        int portID;
        LogManager* logger;
    };
}

#endif  //_INPUTPORT_H
