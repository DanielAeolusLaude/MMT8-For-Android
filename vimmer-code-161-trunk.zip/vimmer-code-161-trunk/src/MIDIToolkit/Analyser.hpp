/*
   Virtual MIDI Multitrack Recorder
   Copyright (c) 2006 MIDI Team

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU Lesser General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU Lesser  General Public License for more details.

   You should have received a copy of the GNU Lesser General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/

/**
   @file Analyser.hpp
   @author Charles Weld
   @brief Declaration of class Analyser, part of Virtual MIDI Multitrack Recorder
*/

#ifndef _ANALYSER_H
#define _ANALYSER_H

#include <list>
#include "MIDIEvent.hpp"

namespace MIDIToolkit
{
    // forward defs
    class Generator;

    /// @brief An Analyser is a component that accepts messages.
    /**
     * An Analyser is a component that accepts messages and analyses them, but doesn't pass then on.
     * A good example would be an Output Port.
     * @ingroup midicom
     */
    class Analyser
    {
    public:
        /**
         * @brief Cleans up the Analyser.
         */
        virtual ~Analyser();

        /**
         * @brief This is called when the Analyser receives a MIDI Event and thus a message.
         *
         * When an Analyser receives an incoming MIDIEvent it's receive method will be called,
         * with the incoming MIDIEvent. This allows the Analyser to handle the MIDIEvent as
         * it chooses.
         *
         * @param evt The MIDI Event.
         */
        virtual void receive(MIDIEvent* evt) = 0;

        /**
         * @brief This is used to maintian the Generator and Analyser linkage.
         *
         * This should called when a generator connects to this analyser and
         * allows the analyser to disconnect from the generator when it's destroyed.
         *
         * @note Don't call this method it's used only to maintain the Analyser's and Generators.
         *
         * @param g The generator to add.
         */
        virtual void addGenerator(Generator* g);

        /**
         * @brief This is used to maintian the Generator and Analyser linkage.
         *
         * This should be called when a generator disconnects to this analyser.
         * This allows the analyser to disconnect from the generator when it's destroyed.
         *
         * @note Don't call this method it's used only to maintain the Analyser's and Generators.
         *
         * @param g The generator to remove.
         */
        virtual void removeGenerator(Generator* g);
    private:
        std::list<Generator*> gens;
    };
}

#endif  //_ANALYSER_H
