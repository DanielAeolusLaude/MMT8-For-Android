/*
   Virtual MIDI Multitrack Recorder
   Copyright (c) 2006 MIDI Team

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU Lesser General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU Lesser  General Public License for more details.

   You should have received a copy of the GNU Lesser General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/

/**
   @file   Track.cpp
   @author Jonathan Van Rossum (jvr85@users.sourceforge.net)
   @brief  Implementation of the class Track.
*/


#include "Track.hpp"

#include "MessageTypes.hpp"
#include "ChannelMessage.hpp"

// DEBUGGING ONLY
#include <iostream>
//using namespace std;

// C STANDARD TEMPLATE LIBRARY:
//     - http://www.sgi.com/tech/stl/List.html
//     - http://www.cprogramming.com/tutorial/stl/iterators.html

namespace MIDIToolkit
{
    Track::Track()
    {
        messages.clear();
        last_pos = messages.begin();
    }

    Track::~Track()
    {
    }

//----------------------------------------------------------------------------------------
    MIDIEventIterator Track::getIterator()
    {
        return messages.begin();
    }

//----------------------------------------------------------------------------------------
    MIDIEventIterator Track::getIterator_begin()
    {
        return messages.begin();
    }

//----------------------------------------------------------------------------------------
    MIDIEventIterator Track::getIterator_end()
    {
        return messages.end();
    }

//----------------------------------------------------------------------------------------
    MIDIEventIterator Track::getIterator(unsigned long absolute)
    {
        MIDIEventIterator i = messages.begin();
        while (i != messages.end() && (*i)!=NULL && (*i)->absolute < absolute)
        {
            i++;
        }
        return i;
    }
//----------------------------------------------------------------------------------------
    MIDIEventIterator Track::getIterator_noteoff(MIDIEventIterator* noteon)
    {
        MIDIEventIterator i = *noteon;
        if (i!=NULL && i!=messages.end() && (*i)!=NULL && (*i)->getMessage()!=NULL)
        {
            MIDIMessage* m = (*i)->getMessage();
            if (m->isA(MessageTypes::CHANNEL_MESSAGE))
            {
                ChannelMessage* chm = (ChannelMessage*)m;
                unsigned long noteon_data1 = chm->getData1();       // NOTE ON:  Note Value
                unsigned long noteon_channel = chm->getChannel();   // NOTE ON:  MIDI Channel
                while (i != messages.end())
                {
                    MIDIEvent* n = (*i);
                    if (n!=NULL && n->getMessage()!=NULL && n->getMessage()->isA(MessageTypes::CHANNEL_MESSAGE))
                    {
                        ChannelMessage* c = (ChannelMessage*)(n->getMessage());;
                        unsigned long command = c->getCommand();
                        unsigned long channel = c->getChannel();
                        unsigned long data1 = c->getData1();
                        unsigned long data2 = c->getData2();

                        // Is this our note?
                        if (channel == noteon_channel && data1 == noteon_data1)
                        {
                            // Is it a NOTE OFF?
                            if (command==ChannelCommands::NoteOff || (command==ChannelCommands::NoteOn && data2==0))
                            {
                                return i;
                            }
                        }
                    }

                    // Next MIDI Event.
                    i++;
                }

                // NOTE OFF not found.
                return messages.end();
            }
            else
            {
                // Error: Not a Channel Message.
                return messages.end();
            }
        }
        else
        {
            // Error: parameter was invalid.
            return messages.end();
        }
    }

//----------------------------------------------------------------------------------------
    MIDIEventIterator Track::getIterator_noteon(MIDIEventIterator* noteoff)
    {
        MIDIEventIterator i = *noteoff;
        if (i!=NULL && i!=messages.end() && (*i)!=NULL && (*i)->getMessage()!=NULL)
        {
            MIDIMessage* m = (*i)->getMessage();
            if (m->isA(MessageTypes::CHANNEL_MESSAGE))
            {
                ChannelMessage* chm = (ChannelMessage*)m;
                unsigned long noteoff_data1 = chm->getData1();      // NOTE OFF: Note Value
                unsigned long noteoff_channel = chm->getChannel();  // NOTE OFF: MIDI Channel
                while (i != messages.end() && i != messages.begin())
                {
                    MIDIEvent* n = (*i);
                    if (n!=NULL && n->getMessage()!=NULL && n->getMessage()->isA(MessageTypes::CHANNEL_MESSAGE))
                    {
                        ChannelMessage* c = (ChannelMessage*)(n->getMessage());;
                        unsigned long command = c->getCommand();
                        unsigned long channel = c->getChannel();
                        unsigned long data1 = c->getData1();

                        // Is this our note?
                        if (channel == noteoff_channel && data1 == noteoff_data1)
                        {
                            // Is it a NOTE ON?
                            if (command==ChannelCommands::NoteOn)
                            {
                                return i;
                            }
                        }
                    }

                    // Previous MIDI Event.
                    i--;
                }

                // NOTE OFF not found.
                return messages.end();
            }
            else
            {
                // Error: Not a Channel Message.
                return messages.end();
            }
        }
        else
        {
            // Error: parameter was invalid.
            return messages.end();
        }
    }

//----------------------------------------------------------------------------------------
// INSERT
//----------------------------------------------------------------------------------------

    void Track::insert(unsigned long absolute, ShortMessage* sm, MIDIEventIterator& i)
    {
        if (sm!=NULL && sm->isA(MessageTypes::CHANNEL_MESSAGE))
        {
            // Make our own copy
            ShortMessage* msg = (ShortMessage*)sm->clone();

            // Scan forward, if we need to.
            while(i!=messages.end() && (*i)!=NULL && (*i)->absolute < absolute)
            {
                i++;
            }

            // Scan backward, if we need to.
            while(i!=messages.begin())
            {
                MIDIEventIterator previous;
                previous = i;
                previous--;
                if (previous != messages.end() && (*previous)!=NULL && (*previous)->absolute > absolute)
                {
                    i--;
                }
                else
                {
                    break;
                }
            }

            // Insert
            MIDIEvent* evt;
            evt = new MIDIEvent(msg, absolute, 0);
            messages.insert(i, evt);
            last_pos = i;
        }
    }

//----------------------------------------------------------------------------------------
    void Track::insert(unsigned long absolute, ShortMessage* msg)
    {
        insert(absolute, msg, last_pos);
    }

//----------------------------------------------------------------------------------------
    void Track::insert(MIDIEvent* midi_event, MIDIEventIterator& iterator)
    {
        insert(midi_event->absolute, (ShortMessage*)(midi_event->getMessage()), iterator);
    }

//----------------------------------------------------------------------------------------
    void Track::insert(MIDIEvent* midi_event)
    {
        insert(midi_event->absolute, (ShortMessage*)(midi_event->getMessage()));
    }

//----------------------------------------------------------------------------------------
// DURATION AND TIMESTAMP
//----------------------------------------------------------------------------------------

        void Track::timestamp(MIDIEventIterator& location, unsigned long absolute)
        {
            MIDIEvent* e = *location;
            if (e != NULL)
            {
                messages.erase(location);
                e->absolute = absolute;
                insert(e);
                delete e;
                location = messages.begin();
            }
        }

        unsigned long Track::duration_pulses(MIDIEventIterator& noteon)
        {
            MIDIEventIterator noteoff;
            noteoff = getIterator_noteoff(&noteon);

            if (noteon!=getIterator_end() && noteoff!=getIterator_end() && (*noteon)!=NULL && (*noteoff)!=NULL)
            {
                unsigned long absolute_on  = (*noteon)->absolute;
                unsigned long absolute_off = (*noteoff)->absolute;
                unsigned long duration = absolute_off - absolute_on;
                return duration;
            }
            else
            {
                return 0;
            }
        }

        void Track::duration_pulses(MIDIEventIterator& location, unsigned long duration, bool tail_fixed)
        {
            if (location != messages.end())
            {
                MIDIEvent* e = *location;
                if (e != NULL)
                {
                    MIDIMessage* m = e->getMessage();
                    if (m != NULL & m->isA(MessageTypes::CHANNEL_MESSAGE))
                    {
                        ChannelMessage* chm = (ChannelMessage*)m;
                        MIDIEventIterator noteon;
                        MIDIEventIterator noteoff;

                        // Find the other of the NOTE ON ~ NOTE OFF pair.
                        if (chm->getCommand() == ChannelCommands::NoteOn)
                        {
                            noteon = location;
                            noteoff = getIterator_noteoff(&location);
                        }
                        else if (chm->getCommand() == ChannelCommands::NoteOff)
                        {
                            noteoff = location;
                            noteon = getIterator_noteon(&location);
                        }
                        else
                        {
                            // Error: Not a NOTE ON or NOTE OFF.
                            //     =>  Ignore.
                            return;
                        }

                        // Check these are valid.
                        if (noteon!=messages.end() && noteoff!=messages.end() && (*noteon)!=NULL && (*noteoff)!=NULL)
                        {
                            unsigned long absolute_noteon  = (*noteon)->absolute;
                            unsigned long absolute_noteoff = (*noteoff)->absolute;

                            // Adjust one of the pair.
                            if (tail_fixed)
                            {
                                // Adjust NOTE ON value.
                                timestamp(noteon, absolute_noteoff - duration);
                            }
                            else
                            {
                                // Adjust NOTE OFF value.
                                timestamp(noteoff, absolute_noteon + duration);
                            }
                        }

                    }
                }
            }
        }

        void Track::duration_interval(MIDIEventIterator& location, unsigned int q, bool tail_fixed)
        {
            if (q==2 || q==4 || q==6 || q==8 || q==12 || q==16 || q==24 || q==32 || q==48 || q==64)
            {
                unsigned long multiple = 4 * (MIDIToolkit::PULSES_PER_BEAT) / q;
                duration_pulses(location, multiple, tail_fixed);
            }
        }

//----------------------------------------------------------------------------------------
// ERASE
//----------------------------------------------------------------------------------------
    void Track::erase()
    {
        MIDIEventIterator begin = messages.begin();
        MIDIEventIterator end = messages.end();
        erase(begin, end);
    }

//----------------------------------------------------------------------------------------
    void Track::erase(MIDIEventIterator& loc)
    {
        delete *loc;
        messages.erase(loc);
    }

//----------------------------------------------------------------------------------------
    void Track::erase(MIDIEventIterator& begin, MIDIEventIterator& end)
    {
        MIDIEventIterator i;
        i = begin;
        while (i != messages.end() && i != end )
        {
            if ((*i)!=NULL) delete (*i);
            i++;
        }
        messages.erase(begin, end);
    }

//----------------------------------------------------------------------------------------
    void Track::erase(unsigned long absolute_begin, unsigned long absolute_end)
    {
        MIDIEventIterator iterator_begin = getIterator(absolute_begin);
        MIDIEventIterator iterator_end   = getIterator(absolute_end);
        erase(iterator_begin, iterator_end);
    }

//----------------------------------------------------------------------------------------
    void Track::remove(MIDIEventIterator& loc)
    {
        delete *loc;
        messages.erase(loc);
    }

//----------------------------------------------------------------------------------------
// TRANSPOSE
//----------------------------------------------------------------------------------------
    void Track::transpose(int semitones)
    {
        MIDIEventIterator b = messages.begin();
        MIDIEventIterator e = messages.end();
        transpose(b, e, semitones);
    }

    void Track::transpose(MIDIEventIterator& location, int semitones)
    {
        MIDIEventIterator i = location;
        if (i!=messages.end() && (*i) != NULL)
        {
            MIDIMessage* m = (*i)->getMessage();
            if (m != NULL && m->isA(MessageTypes::CHANNEL_MESSAGE))
            {
                ChannelMessage* chm_noteon = (ChannelMessage*)m;
                if (chm_noteon->getCommand() == ChannelCommands::NoteOn)
                {
                    MIDIEventIterator noteoff = getIterator_noteoff(&i);

                    // Calculate the new pitch, ensure it is in range.
                    int newpitch = chm_noteon->getData1() + semitones;
                    while (newpitch < 0)    newpitch += 12;             // Up one octave
                    while (newpitch > 127)  newpitch -= 12;             // Down one octave

                    // Transpose NOTE ON.
                    chm_noteon->setData1(newpitch);

                    if (noteoff != messages.end() && (*noteoff) != NULL)
                    {
                        MIDIMessage* m = (*noteoff)->getMessage();
                        if (m!=NULL && m->isA(MessageTypes::CHANNEL_MESSAGE))
                        {
                            ChannelMessage* chm_noteoff = (ChannelMessage*)m;
                            chm_noteoff->setData1(newpitch);
                        }
                    }
                }
            }
        }
    }

    void Track::transpose(MIDIEventIterator& begin, MIDIEventIterator& end, int semitones)
    {
        MIDIEventIterator i = begin;
        while (i != end && i != messages.end())
        {
            if ((*i) != NULL)
            {
                MIDIMessage* m = (*i)->getMessage();
                if (m != NULL && m->isA(MessageTypes::CHANNEL_MESSAGE))
                {
                    ChannelMessage* chm = (ChannelMessage*)m;
                    if (chm->getCommand() == ChannelCommands::NoteOn)
                    {
                        transpose(i, semitones);
                    }
                }
            }
            i++;
        }
    }

    void Track::transpose(unsigned long begin, unsigned long end, int semitones)
    {
        MIDIEventIterator b = getIterator(begin);
        MIDIEventIterator e = getIterator(end);
        transpose(b, e, semitones);
    }

//----------------------------------------------------------------------------------------
// QUANTIZE
//----------------------------------------------------------------------------------------

        void Track::quantize(unsigned int interval, int type)
        {
            MIDIEventIterator b = getIterator_begin();
            MIDIEventIterator e = getIterator_end();
            quantize(b, e, interval, type);
        }

        void Track::quantize(MIDIEventIterator& location, unsigned int q_id)
        {
            if (location != messages.end() && (*location) != NULL)
            {
                unsigned int q;
                switch (q_id)
                {
                    case 0: q =  2; break;
                    case 1: q =  4; break;
                    case 2: q =  6; break;
                    case 3: q =  8; break;
                    case 4: q = 12; break;
                    case 5: q = 16; break;
                    case 6: q = 24; break;
                    case 7: q = 32; break;
                    case 8: q = 48; break;
                    case 9: q = 64; break;
                    default: q = 64; break;
                }

                if (q==2 || q==4 || q==6 || q==8 || q==12 || q==16 || q==24 || q==32 || q==48 || q==64)
                {
                    unsigned long absolute = (*location)->absolute;

                    unsigned long multiple = 4 * (MIDIToolkit::PULSES_PER_BEAT) / q;

                    unsigned long lower = absolute - (absolute % multiple);
                    unsigned long upper = absolute - (absolute % multiple) + multiple;

                    if (upper - absolute > absolute - lower)
                    {
                        // Round it down.
                        (*location)->absolute = lower;
                    }
                    else
                    {
                        // Round it up.
                        (*location)->absolute = upper;
                    }
                }
            }
        }

        void Track::quantize(MIDIEventIterator& begin, MIDIEventIterator& end, unsigned int interval, int type)
        {
/*
switch(qt){
                    case 0:qts="NOTE START";break;
                    case 1:qts="NOTE START & END";break;
                    case 2:qts="NOTE END";break;
                    case 3:qts="KEEP DURATION";break;

                }
*/


            MIDIEventIterator i = begin;
            while (i != end && i != messages.end())
            {
                MIDIEvent* e = (*i);
                if (e != NULL)
                {
                    MIDIMessage* m = e->getMessage();
                    if (m != NULL && m->isA(MessageTypes::CHANNEL_MESSAGE))
                    {
                        ChannelMessage* chm = (ChannelMessage*)m;
                        bool is_note_on  = (chm->getCommand() == ChannelCommands::NoteOn);
                        bool is_note_off = (chm->getCommand() == ChannelCommands::NoteOff);

                        switch (type)
                        {
                            case 0:
                            {
                                if (is_note_on)                 quantize(i, interval);
                                break;
                            }
                            case 1:
                            {
                                if (is_note_on || is_note_off)  quantize(i, interval);
                                break;
                            }
                            case 2:
                            {
                                if (is_note_off)                quantize(i, interval);
                                break;
                            }
                            case 3:
                            {
                                if (is_note_on)
                                {
                                    MIDIEventIterator i_noteoff = getIterator_noteoff(&i);
                                    if (i_noteoff != messages.end() && *i_noteoff != NULL)
                                    {
                                        unsigned long absolute_noteon  = (*i)->absolute;
                                        unsigned long absolute_noteoff = (*i_noteoff)->absolute;
                                        unsigned long duration = absolute_noteoff - absolute_noteon;

                                        // Quantize the NOTE ON
                                        quantize(i, interval);

                                        // Modify duration
                                        duration_pulses(i, duration, false);
                                    }

                                }
                                break;
                            }
                        }
                        quantize(i, interval);
                        i++;
                    }
                }
            }
        }

        void Track::quantize(unsigned long begin, unsigned long end, unsigned int interval, int type)
        {
            MIDIEventIterator b = getIterator(begin);
            MIDIEventIterator e = getIterator(end);
            quantize(b, e, interval, type);
        }

//--------------------------------------------------------------------------------
// MERGE
//--------------------------------------------------------------------------------

    void Track::merge(Track* source_track)
    {
        if (source_track != NULL)
        {
            std::cout << "size: " << source_track->messages.size() << std::endl;
            MIDIEventIterator it = source_track->getIterator_begin();
            //int i=0;
            while (it != source_track->getIterator_end())
            {
                if (*it != NULL)
                {
                    insert(*it);
                }
                it++;
            }
        }
    }

//--------------------------------------------------------------------------------
// COPY
//--------------------------------------------------------------------------------

    void Track::copy(Track* source_track)
    {
        if (source_track != NULL)
        {
            erase();
            merge(source_track);
        }
    }

//----------------------------------------------------------------------------------------
// MISCELLANEOUS
//----------------------------------------------------------------------------------------

    bool Track::empty()
    {
        return messages.empty();
    }

//----------------------------------------------------------------------------------------
    void Track::forceLength(int beats)
    {
        unsigned long absolute = beats * MIDIToolkit::PULSES_PER_BEAT;
        MIDIEventIterator i;
        MIDIEventIterator e;
        i = getIterator(absolute);
        e = getIterator_end();
        erase(i, e);
    }



//----------------------------------------------------------------------------------------
// DEBUGGING
//----------------------------------------------------------------------------------------

    void Track::print(int indent)
    {
        if (messages.empty())
        {
            for (int i=0; i<indent; i++){std::cout << " ";}
            std::cout << "TRACK: (empty)\n";
        }
        else
        {
            MIDIEventIterator iterator = messages.begin();

            for (int i=0; i<indent; i++){std::cout << " ";}
            std::cout << "TRACK:   (" << messages.size() << " elements).\n";

            while (iterator!=messages.end())
            {
                if (*iterator != NULL)
                {
                    (*iterator)->print(indent + 2);
                }
                iterator++;
            }
        }
    }



//----------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------
//----------------------------------------------------------------------------------------

}
