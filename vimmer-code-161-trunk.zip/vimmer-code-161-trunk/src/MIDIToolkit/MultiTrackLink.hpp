/*
   Virtual MIDI Multitrack Recorder
   Copyright (c) 2006 MIDI Team

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU Lesser General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU Lesser  General Public License for more details.

   You should have received a copy of the GNU Lesser General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/

/**
   @file   MultiTrackLink.hpp
   @author Jonathan Van Rossum (jvr85@users.sourceforge.net)
   @brief  Declaration of the class MultiTrackLink.
*/


#ifndef _MULTITRACKLINK_H
#define _MULTITRACKLINK_H

#include "MultiTrack.hpp"
#include "Observable.hpp"

namespace MIDIToolkit
{
    /** @ingroup midiseq
     *  @brief  Links to an individual MultiTrack, and provides status information
     *          about each Track.
     *
     *  OVERVIEW:
     *
     *  The MultiTrack class stores a group of simultaneous Tracks, but has no
     *  knowledge of the current status of each Track. Such knowledge is provided
     *  by this class, the MultiTrackLink.
     *
     *  The MultiTrackLink is really a "wrapper" around a MultiTrack. It holds a
     *  pointer to a particular MultiTrack, and defines several vectors, each element
     *  of which represents the state of a particular track. (See below for the
     *  different track information that is stored).
     *
     *  USES:
     *
     *  Primarily, the MultiTrackLink is used by the Sequencer class. It continually
     *  reads the state of each track during playback (and recording).
     *
     *  Secondarily, the MultiTrackLink represents a "step" within a song. Each
     *  step holds a different Part (MultiTrack), and also contains track state
     *  information. The SongStep class inherits directly from the MultiTrackLink
     *  class. (See Vimmer::SongStep).
     *
     *  TRACK STATUS:
     *
     *  Each Track can be independently "play" enabled or disabled (muted).
     *  Additionally, each Track can be "record" enabled or disabled. Playing and
     *  recording status can be changed independently of each other, and for each Track
     *  independently of every other Track.
     *
     *  Thus each track has one of four possible states:
     *
     *      TRACK_STATE_CLEAR           == (record disabled, play disabled)
     *      TRACK_STATE_PLAY            == (record disabled, play  enabled)
     *      TRACK_STATE_RECORD          == (record  enabled, play disabled)
     *      TRACK_STATE_PLAY_AND_RECORD == (record  enabled, play  enabled)
     *
     *  Note that VMM-R only allows recording to one Track at a time. Both this class
     *  and the Sequencer class should theoretically support simultaneous recording
     *  to any number of Tracks, however this has not been tested.
     *
     *  TRACK CHANNELIZE:
     *
     *  Each Track can be set to use a different MIDI channel (channels 1-16), or
     *  to use whatever channel the MIDIEvents were recorded as ("no channelize").
     *
     *  The MultiTrackLink doesn't handle any of the actual channelizing, it merely
     *  records what the channelize setting should be. The actual channelizing is
     *  performed by the Sequencer class (see Sequencer).
     *
     *  VOLATILITY:
     *
     *  This class is used mostly by the Sequencer class. The Sequencer holds a
     *  pointer to a MultiTrackLink object, and manages its own internal state based
     *  on this object. While it is "connected" to a particular MultiTrackLink, there
     *  are only certain changes that MUST NOT be made to it.
     *
     *  Particularly, the "linked to" MultiTrack must NOT change. Specifically, the
     *  Sequencer must be disconnected from the MultiTrackLink before the setLink(...)
     *  function is called. The Sequencer expects the "link" variable never to change,
     *  because it creates its own iterators into each of the Tracks.
     *
     *  The track states and track channelize, however, can be changed at any time;
     *  even when the Sequencer is playing or recording. For example, when the user
     *  presses a track button on the VMM-R GUI, the corresponding track state in this
     *  class is changed. The Sequencer reads this information dynamically, and is
     *  quite happy for it to change without warning.
     *
     */
    class MultiTrackLink : public Observable
    {
    public:

        static const int TRACK_STATE_INVALID_TRACK = -1;
        static const int TRACK_STATE_CLEAR = 0;
        static const int TRACK_STATE_PLAY = 1;
        static const int TRACK_STATE_RECORD = 2;
        static const int TRACK_STATE_PLAY_AND_RECORD = 3;

        static const int TRACK_CHANNEL_INVALID_TRACK = -1;
        static const int TRACK_CHANNEL_NOCHANNELIZE = 0;

        /** @brief  Constructor for MultiTrackLink.
         */
        MultiTrackLink();

        /** @brief  Copy Constructor for MultiTrackLink.
         */
        MultiTrackLink(const MultiTrackLink& mtl);

        /** @brief  Destructor for MultiTrackLink.
         */
        virtual ~MultiTrackLink();

        /** @brief  Assignment operator.
         */
        virtual MultiTrackLink& operator = (const MultiTrackLink& mtl);

        /** @brief  Link to a particular MultiTrack.
          * @param  l   The MultiTrack to link to.
         */
        virtual void setLink(MultiTrack* l);

        /** @brief  Get the MultiTrack being linked to.
          * @return     The MultiTrack.
         */
        virtual MultiTrack* getLink();

        /** @brief  Get the number of tracks in this MultiTrackLink.
          * @return     Number of Tracks.
         */
        virtual unsigned int trackCount() const;

        /** @brief  Get STATUS of a track.
          * @param  tracknumber     Track number (0-based).
          * @return     The state of the track; See setTrackState(int, int) for valid states.
         */
        virtual int getTrackState(unsigned int tracknumber) const;

        /** @brief  Set STATUS of a track.
          * @param  tracknumber     Track number (0-based).
          * @param  state   State (Valid states are: TRACK_STATE_CLEARED, ~_PLAY, or ~_RECORD).
          * @return (none)
         */
        virtual void setTrackState(unsigned int tracknumber, int state);

        /** @brief  Set STATUS of all tracks.
          * @param  state   State (Valid states are: TRACK_STATE_CLEARED, ~_PLAY, or ~_RECORD).
          * @return (none)
         */
        virtual void setTrackStateAll(int state);

        /** @brief  Gets PLAYING status of a track.
          * @param  tracknumber     Track number (0-based).
          * @return     (true = this track is enabled, false otherwise).
         */
        virtual bool isPlaying(unsigned int tracknumber) const;

        /** @brief  Gets RECORDING status of a track.
          * @param  tracknumber     Track number (0-based).
          * @return     (true = this track is enabled, false otherwise).
         */
        virtual bool isRecording(unsigned int tracknumber) const;

        /** @brief  Gets Channelization of track.
          * @param  tracknumber     Track number (0-based).
          * @return         Channel number (1-16, or TRACK_CHANNEL_NOCHANNELIZE for none).
         */
        virtual int getTrackChannel(unsigned int tracknumber) const;

        /** @brief  Sets Channelization of track.
          * @param  tracknumber     Track number (0-based).
          * @param  channel         Channel number (1-16, or TRACK_CHANNEL_NOCHANNELIZE for none).
          * @return (none)
         */
        virtual void setTrackChannel(unsigned int tracknumber, int channel);

        /** @brief  Sets Channelization of track.
          * @param  channel Channel number (1-16, or TRACK_CHANNEL_NOCHANNELIZE for none).
          * @return (none)
         */
        virtual void setTrackChannelAll(int channel);

    protected:


        /// MultiTrack that is being linked to.
        MultiTrack* link;

        /// Number of Tracks in the MultiTrack linked to.
        unsigned int number_of_tracks;

        /// Track Status (includes playing and recording).
        std::vector<int> track_state;

        /// Track Channelize (0 => no channelize).
        std::vector<int> track_channel;

        /** @brief  Determine if this is a valid Track State.
          * @param  state       Track state.
          * @return             True if state is valid, false otherwise.
         */
        bool validateTrackState(int state);

        /** @brief  Determine if this is a valid Track Channel.
          * @param  channel     Channel number (1-16, 0 for no channelize).
          * @return             True if channel is valid, false otherwise.
         */
        bool validateTrackChannel(int channel);

    };
}

#endif  //_MULTITRACKLINK_H
