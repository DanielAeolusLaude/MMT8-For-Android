/*
   Virtual MIDI Multitrack Recorder
   Copyright (c) 2006 MIDI Team

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU Lesser General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU Lesser  General Public License for more details.

   You should have received a copy of the GNU Lesser General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/

/**
  @file OutputFilter.hpp
   @author Charles Weld
   @brief Declaration of class OutputFilter, part of Virtual MIDI Multitrack Recorder
*/

#ifndef _OUTPUTFILTER_H
#define _OUTPUTFILTER_H

#include "Modulator.hpp"
#include "MIDIEvent.hpp"
#include "LogManager.hpp"
#include "Observable.hpp"

namespace MIDIToolkit
{
    /// @brief An Output Filter is used to filter MIDI Messages.
    /**
     * An Output Filter is used to filter MIDI Messages.
     * Basically what this means is that when it receives an incomming message, this message
     * must pass a test for it to be passed onto any connected Analyser or Modulator.
     *
     * @ingroup mididev
     */
    class OutputFilter : public Modulator, public Observable
    {
    public:
        /// @brief Default Constructor.
        /**
         * Default Constructor.
         */
        OutputFilter();

        /// @brief Default Destructor.
        /**
         * Default Destructor.
         */
        virtual ~OutputFilter();

        /// @brief This is called when the Analyser receives a MIDI Event and thus a message.
        /**
         * This is called when the Analyser receives a MIDI Event and thus a message.
         * If the MIDIEvent passes the filter it will be passed onto all connected
         * Analysers and Modulators.
         *
         * @param evt The MIDI Event.
         */
        void receive(MIDIEvent* evt);

    protected:
        /// @brief Checks if this MIDI Event is allowed to pass throw the filter.
        /**
         * Checks if this MIDI Event is allowed to pass throw the filter.
         *
         * @param evt The MIDI Event.
         * @return True if the MIDI Event is allowed past the filter, otherwise false.
         */
        bool check(MIDIEvent* evt);

        //! note on/off stack
        bool m_Notes[127];

        //! The logger
        LogManager* logger;
    };
}

#endif  //_OUTPUTFILTER_H
