/*
   Virtual MIDI Multitrack Recorder
   Copyright (c) 2006 MIDI Team

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU Lesser General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU Lesser  General Public License for more details.

   You should have received a copy of the GNU Lesser General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/

/**
   SysRealtimeMessage.hppile SysRealtimeMessage.hpp
   Charles Weld, David Wilson, James Brown, Jonathan Van Rossum, and Matthew Harrold
   @brief Declaration of class SysRealtimeMessage, part of Virtual MIDI Multitrack Recorder
*/

#ifndef _SYSREALTIMEMESSAGE_H
#define _SYSREALTIMEMESSAGE_H

#include "ShortMessage.hpp"

namespace MIDIToolkit
{
    /**
     * Defines constants representing the various system realtime message types.
     */
    /// @ingroup midimsg
    namespace SysRealtimeTypes
    {
        /// @ingroup midimsg
        enum
        {
            /// Represents the clock system realtime type.
            Clock = 0xF8,

            /// Represents the tick system realtime type.
            Tick,

            /// Represents the start system realtime type.
            Start,

            /// Represents the continue system realtime type.
            Continue,

            /// Represents the stop system realtime type.
            Stop,

            /// Represents the active sense system realtime type.
            ActiveSense = 0xFE,

            /// Represents the reset system realtime type.
            Reset
        };
    }

    //! The System Realtime Type.
    /// @ingroup midimsg
    typedef int SysRealtimeType;

    //! Represents MIDI System Realtime Messages.
    /**
     * System realtime messages are MIDI messages that are primarily concerned with
     * controlling and synchronizing MIDI devices.
     */
    /// @ingroup midimsg
    class SysRealtimeMessage : public ShortMessage
    {
    public:
        /**
         * Constructs a System Realtime Message with a specified type.
         * @param type The type of System Realtime Message.
         */
        SysRealtimeMessage(SysRealtimeType type);

        /**
         * Default Destructor.
         */
        ~SysRealtimeMessage();

        /**
         * Sets the System Realtime Type.
         * @param type The System Realtime Type.
         */
        virtual void setSysRealtimeType(SysRealtimeType type);

        /**
         * Gets the System Realtime Type.
         * @return The System Realtime Type.
         */
        virtual SysRealtimeType getSysRealtimeType();

        /**
         * Checks if this message is of type msgType.
         * @param msgType The type of message to check.
         * @return True if this message is of type msgType, otherwise false.
         */
        virtual bool isA(MessageType msgType);

        /**
         * Clones this message.
         */
        virtual MIDIMessage* clone();
    };
}

#endif  //_SYSREALTIMEMESSAGE_H
