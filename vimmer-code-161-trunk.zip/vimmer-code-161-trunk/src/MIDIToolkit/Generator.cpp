/*
   Virtual MIDI Multitrack Recorder
   Copyright (c) 2006 MIDI Team

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU Lesser General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU Lesser  General Public License for more details.

   You should have received a copy of the GNU Lesser General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/

/**
   Generator.cppile Generator.cpp
   Charles Weld, David Wilson, James Brown, Jonathan Van Rossum, and Matthew Harrold
   @brief Declaration of class Generator, part of Virtual MIDI Multitrack Recorder
*/

#include "Generator.hpp"
#include "Analyser.hpp"
#include "MIDIEvent.hpp"

namespace MIDIToolkit
{
    Generator::Generator()
    {
    }

    Generator::~Generator()
    {
        disconnectAll();
    }

    void Generator::connect(Analyser* a)
    {
        analysers.remove(a);
        analysers.push_back(a);
        a->addGenerator(this);
    }

    void Generator::disconnect(Analyser* a)
    {
        analysers.remove(a);
        a->removeGenerator(this);
    }

    void Generator::disconnectAll()
    {
        AnalyserIterator iter = analysers.begin();
        while(iter != analysers.end())
        {
            (*iter)->removeGenerator(this);
            iter++;
        }
        analysers.clear();
    }

    void Generator::distrubuteMessage(MIDIEvent* evt)
    {
        distributeMessage(evt);
    }

    void Generator::distributeMessage(MIDIEvent* evt)
    {
        AnalyserIterator iter = analysers.begin();
        while(iter != analysers.end())
        {
            (*iter)->receive(evt);
            iter++;
        }
    }

}
