/*
   Virtual MIDI Multitrack Recorder
   Copyright (c) 2006 MIDI Team

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/

/**
   Events.hppile Events.hpp
   Charles Weld, David Wilson, James Brown, Jonathan Van Rossum, and Matthew Harrold
   @brief Declaration of class Events, part of Virtual MIDI Multitrack Recorder
*/

#ifndef _EVENTS_H
#define _EVENTS_H


namespace MIDIToolkit
{
    namespace Events
    {

    /**
      @brief Enumerator of functional events list.

      Enumerator of functional events list.

      @ingroup ???.
    */

        enum
        {
	        /**
	         @brief List of specific functions.

	         List of specific functions.
	        */
            SEQUENCER_STOPPED,
            SEQUENCER_PLAYING,
            SEQUENCER_BEAT_UPDATE,
            SEQUENCER_MULTITRACK_END,
            SEQUENCER_MULTITRACK_CHANGED,
            SEQUENCER_ACTIVITY_MIDI_IN,
            SEQUENCER_ACTIVITY_MIDI_OUT,

	        /**
	         @brief List of Cew function states.

	         List of Cew function states.
	        */
            ACTIVE_PART_CHANGED,
            INIT_VIMMER,
            SEQUENCER_STATE_CHANGED,
            SEQUENCER_TEMPO_CHANGED,
            SEQUENCER_MODE_CHANGED,
            SONG_CONTENT_CHANGED,
            SEQUENCER_LOOP_CHANGED,
            PART_SEQUENCER_OVERDUB_CHANGED,

	        /**
	         @brief List of Store function states.

	         List of Store function states.
	        */
            ACTIVE_SONG_CHANGED,
            SONG_NAME_CHANGED,

	        /**
	         @brief List of Track function states.

	         List of Track function states.
	        */
            TRACK_STATE_CHANGED,
            THRU_STATE_CHANGED,

	        /**
	         @brief List of Part function states.

	         List of Part function states.
	        */
            PART_CONTENT_CHANGED
        };
    }
}

#endif  //_EVENTS_H
