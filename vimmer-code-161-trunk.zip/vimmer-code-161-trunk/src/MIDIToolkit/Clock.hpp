/*
   Virtual MIDI Multitrack Recorder
   Copyright (c) 2006 MIDI Team

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU Lesser General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU Lesser  General Public License for more details.

   You should have received a copy of the GNU Lesser General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/

/**
   @file Clock.hpp
   Charles Weld, David Wilson, James Brown, Jonathan Van Rossum, and Matthew Harrold
   @brief Declaration of class Clock, part of Virtual MIDI Multitrack Recorder
*/

#ifndef _CLOCK_H
#define _CLOCK_H

#include "MIDIToolkitPrerequisites.hpp"
#include "Observable.hpp"
#include "Timer.hpp"

#include <windows.h>
#include <mmsystem.h>

namespace MIDIToolkit
{

/**
    @brief The Clock provides tick generation services and uses Timer to keep track of the current time.

    @ingroup timing

    @todo
*/
    class Clock : public Observable
    {
    public:
        /**
         * Create's a new clock.
         */
        Clock();

        /**
         * Destroy's a clock.
         */
        ~Clock();

        /**
         * @brief Starts the clock / timer.
         *
         * This causes the clock to start firing of Tick Received Events at
         * a predeturmined interval (default interval is 5 milliseconds).
         *
         * @note That the clock will be reset when this function is called.
         */
        void start();

        /**
         * @brief Stops the clock / timer.
         *
         * This causes the clock to stop firing of Tick Received Events at
         * a cirtain time interval.
         */
        void stop();

        /**
         * Resets the timer in the clock.
         */
        void reset();

        /**
         * @brief Pauses the clock.
         *
         * If the clock is playing and the pause function is called the clock
         * will stop sending Tick Received Events, but will not be reset so
         * that when pause is called again the clock will continue to send
         * Tick Events as if the clock hadn't been paused.
         */
        void pause();

        /**
         * Sets the interval between ticks.
         *
         * @param interval The tick interval.
         */
        void setTickInterval(UINT interval);

        /**
         * Gets the interval between ticks.
         *
         * @return The tick interval.
         */
        UINT getTickInterval();

        /**
         * The function that is called every tick interval.
         *
         * @note Never call this function as it should be internal but can't be
         * due to the fact you can't have protected callbacks.
         */
        void tick();

        /**
         * Gets the status of the clock.
         *
         * @return The clock status.
         */
        int getStatus();

        /**
         * Gets the elapsed time.
         *
         * @return The elapsed time.
         */
        __int64 getElapsedTime();

    private:
        /**
         * The interval between ticks.
         */
        UINT interval;

        /**
         * Timer's ID
         */
        MMRESULT idEvent;

        /**
         * Keeps track of what the clock is doing.
         *
         * @note 0 = Playing, 1 = Stopped and 2 = Paused.
         */
        int status;

        /**
         * The clocks timer is used to get the elapsed time in micro seconds.
         */
        Timer timer;

        //! The clocks resolution (same for all clocks).
        static DWORD resolution;
    };

    inline void Clock::reset()
    {
        timer.reset();
    }
}

#endif  //_CLOCK_H
