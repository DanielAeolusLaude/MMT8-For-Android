/*
   Virtual MIDI Multitrack Recorder
   Copyright (c) 2006 MIDI Team

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/

/**
   ConfigurationManager.cppile ConfigurationManager.cpp
   Charles Weld, David Wilson, James Brown, Jonathan Van Rossum, and Matthew Harrold
   @brief Declaration of class ConfigurationManager, part of Virtual MIDI Multitrack Recorder
*/

#include "ConfigurationManager.hpp"
#include "Group.hpp"
#include "Entry.hpp"


// http://www.sgi.com/tech/stl/List.html
// http://www.cprogramming.com/tutorial/stl/iterators.html


/*

These are defined in MIDIToolkitPrerequisites.hpp

    typedef std::map<String,Group> GroupMap;
    typedef std::map<String,Entry> EntryMap;

    typedef std::map<String,Group>::iterator GroupMapIterator;
    typedef std::map<String,Entry>::iterator EntryMapIterator;

*/

namespace MIDIToolkit
{
    ConfigurationManager ConfigurationManager::singleton;

    ConfigurationManager::ConfigurationManager(): root("root")
    {
    }

    ConfigurationManager* ConfigurationManager::getSingleton()
    {
        return &singleton;
    }

    Group& ConfigurationManager::getRoot()
    {
        return root;
    }

    Entry& ConfigurationManager::findEntry(String name)
    {
        return root.getEntry(name);
    }

    Entry& ConfigurationManager::findEntry(String groupName, String entryName)
    {
        Group g = root.getGroup(groupName);
        return g.getEntry(entryName);
    }

    Group& ConfigurationManager::findGroup(Group g)
    {
        return root.getGroup(g.getName());
    }

    void ConfigurationManager::clear()
    {
        root.clear();
    }

    bool ConfigurationManager::load(String filename)
    {
        TiXmlDocument* xdoc = new TiXmlDocument();
        bool loadOkay = xdoc->LoadFile(filename);
        if (loadOkay)
        {
            root.clear();
            // load vimmer element
            TiXmlElement *xVimmer = xdoc->FirstChildElement("config");

            TiXmlElement* xRoot = xVimmer->FirstChildElement("group");
            root.setXML(xRoot);
        }
        else
        {
            return false;
        }

        // clean up
        xdoc->Clear();
        delete xdoc;

        return true;
    }

    void ConfigurationManager::save(String filename)
    {
        TiXmlDocument *xmlDoc = new TiXmlDocument();

        // parse doc
        TiXmlElement* xVimmer = new TiXmlElement("config");

        xVimmer->LinkEndChild( root.getXML() );

        xmlDoc->LinkEndChild(xVimmer);
        // save
        xmlDoc->SaveFile(filename);

        // Clean up
        xmlDoc->Clear();
        delete xmlDoc;
    }

}
