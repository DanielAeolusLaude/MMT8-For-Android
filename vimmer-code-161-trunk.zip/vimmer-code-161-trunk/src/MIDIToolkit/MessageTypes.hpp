/*
   Virtual MIDI Multitrack Recorder
   Copyright (c) 2006 MIDI Team

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU Lesser General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU Lesser  General Public License for more details.

   You should have received a copy of the GNU Lesser General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/

/**
   @file MessageTypes.hpp
   Charles Weld, David Wilson, James Brown, Jonathan Van Rossum, and Matthew Harrold
   @brief Declaration of class MIDIMessage, part of Virtual MIDI Multitrack Recorder
*/

#ifndef _MESSAGETYPES_H
#define _MESSAGETYPES_H

#include "MIDIToolkitPrerequisites.hpp"

namespace MIDIToolkit
{
    /// @ingroup midimsg
    class MessageTypes
    {
    public:
        static const MessageType MIDI_MESSAGE = 0;
        static const MessageType SHORT_MESSAGE = 1;
        static const MessageType CHANNEL_MESSAGE = 2;
        static const MessageType SYS_REALTIME_MESSAGE = 3;
        static const MessageType SYS_COMMON_MESSAGE = 4;
        static const MessageType SYS_EX_MESSAGE = 5;
        static const MessageType META_MESSAGE = 6;
        static const MessageType MIDITOOLKIT_MESSAGE = 7;
    };
}

#endif  //_MIDIMESSAGE_H
