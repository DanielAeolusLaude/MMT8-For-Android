/*
   Virtual MIDI Multitrack Recorder
   Copyright (c) 2006 MIDI Team

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU Lesser General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU Lesser  General Public License for more details.

   You should have received a copy of the GNU Lesser General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/

/**
   @file Timer.hpp
   Charles Weld, David Wilson, James Brown, Jonathan Van Rossum, and Matthew Harrold
   @brief Declaration of class Timer, part of Virtual MIDI Multitrack Recorder
*/

#ifndef _TIMER_H
#define _TIMER_H

// includes
#include "MIDIToolkitPrerequisites.hpp"

namespace MIDIToolkit
{
    /**
     @brief Absolute timing mechansim that maintains realtive timing.

     @ingroup timing
    */

    class Timer
    {
        public:
            /**
             * Creates a new timer.
             */
            Timer();

            /**
             * Cleans up the timer.
             */
            virtual ~Timer();

            /**
             * reset the timer.
             */
            virtual void reset();

            /**
             * pauses the timer.
             */
            virtual void pause();

            /**
             * Gets the number of elapsed micro seconds.
             *
             * @return The number of elasped micro seconds.
             */
            virtual __int64 getElapsedTime();

            /**
             * Gets the elapsed time and returns it as a string.
             *
             * @return The elapsed time as a string.
             */
             virtual String toString();

        protected:
        private:
            /**
             * The time since reset was last called.
             */
            __int64 startTime;

            /**
             * To take into acount pausing the timer.
             */
            __int64 offset;

            /**
             * When the timer was paused (last).
             */
            __int64 pauseStart;

            /**
             * If the timer is paused or not.
             */
            bool paused;

            /**
             * Does the timer support hi percision.
             */
            static bool performanceCounter;

            /**
             * The timer's frequency.
             */
            static __int64 frequency;

            /**
             * Keeps track of if the class has been initalized yet.
             */
            static bool init;
    };
}

#endif  //_TIMER_H
