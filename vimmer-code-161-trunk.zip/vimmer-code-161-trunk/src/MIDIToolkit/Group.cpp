/*
   Virtual MIDI Multitrack Recorder
   Copyright (c) 2006 MIDI Team

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/

/**
   Group.cppile Group.cpp
   Charles Weld, David Wilson, James Brown, Jonathan Van Rossum, and Matthew Harrold
   @brief Declaration of class Group, part of Virtual MIDI Multitrack Recorder
*/

#include "Group.hpp"
#include "Entry.hpp"

namespace MIDIToolkit
{

    Group::Group(String n)
    {
        name = n;
    }

    void Group::add(Group& group)
    {
        groups[group.getName()] = group;
    }

    void Group::add(Entry& entry)
    {
        entrys[entry.getName()] = entry;
    }

    void Group::removeGroup(String name)
    {
        groups.erase(name);
    }

    void Group::addGroup(String name)
    {
        Group g(name);
        groups[name] = g;
    }

    void Group::addEntry(String name, String value)
    {
         Entry e(name);
         e.setValue(value);
         entrys[name] = e;
    }

    void Group::addEntry(String name, int value)
    {
         Entry e(name);
         e.setValue(value);
         entrys[name] = e;
    }

    void Group::addEntry(String name, bool value)
    {
         Entry e(name);
         e.setValue(value);
         entrys[name] = e;
    }

    void Group::removeEntry(String name)
    {
        entrys.erase(name);
    }

    void Group::clear()
    {
        groups.clear();
    }

    Group& Group::getGroup(String name)
    {
        return groups[name];
    }

    Entry& Group::getEntry(String name)
    {
        return entrys[name];
    }

    GroupMapIterator Group::getGroupIterator()
    {
        return groups.begin();
    }

    EntryMapIterator Group::getEntryIterator()
    {
        return entrys.begin();
    }

    /**
     * Saves this group and all sub groups/entries to elem.
     *
     * @note XML File Format.
     *  <group name="">
     *      <group name="">
     *          <element name="" value="" />
     *      </group>
     *  </group>
     */
    TiXmlElement* Group::getXML()
    {
        TiXmlElement* xGroup = new TiXmlElement("group");
        xGroup->SetAttribute("name", getName());

        // add sub groups
        for(GroupMap::iterator iter=groups.begin();iter!=groups.end();iter++)
        {
            TiXmlElement* xSubGroup = iter->second.getXML();
            xGroup->LinkEndChild(xSubGroup);
        }

        // add sub elements
        for(EntryMap::iterator iter=entrys.begin();iter!=entrys.end();iter++)
        {
            TiXmlElement* xEntry = iter->second.getXML();
            xGroup->LinkEndChild(xEntry);
        }

        return xGroup;

    }

    void Group::setXML(TiXmlElement* elem)
    {
        setName(elem->Attribute("name"));

        // load sub groups
        TiXmlElement* xSubGroup = elem->FirstChildElement("group");

        // Loop through each group in the part
        while(xSubGroup)
        {
            Group gp;
            gp.setXML(xSubGroup);
            add(gp);

            // move to the next element
            xSubGroup = xSubGroup->NextSiblingElement("group");
        }

        // load sub elements
        TiXmlElement* xEntry = elem->FirstChildElement("entry");

        // Loop through each group in the part
        while(xEntry)
        {
            Entry e;
            e.setXML(xEntry);
            add(e);

            // move to the next element
            xEntry = xEntry->NextSiblingElement("entry");
        }
    }

}
