#include "bzip2.h"


/*----------------------------------------------------*/
/*--- and now for something much more pleasant :-) ---*/
/*----------------------------------------------------*/

/*---------------------------------------------*/
/*--
  Place a 1 beside your platform, and 0 elsewhere.
--*/

/*--
  Generic 32-bit Unix.
  Also works on 64-bit Unix boxes.
  This is the default.
--*/
#define BZ_UNIX      1

/*--
  Win32, as seen by Jacob Navia's excellent
  port of (Chris Fraser & David Hanson)'s excellent
  lcc compiler.  Or with MS Visual C.
  This is selected automatically if compiled by a compiler which
  defines _WIN32, not including the Cygwin GCC.
--*/
#define BZ_LCCWIN32  0

#if defined(_WIN32) && !defined(__CYGWIN__)
#undef  BZ_LCCWIN32
#define BZ_LCCWIN32 1
#undef  BZ_UNIX
#define BZ_UNIX 0
#endif


/*---------------------------------------------*/
/*--
  Some stuff for all platforms.
--*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <math.h>
#include <errno.h>
#include <ctype.h>
#include "bzlib.h"

// debugging
#include <iostream>

#define ERROR_IF_EOF(i)       { if ((i) == EOF)  ioError(); }
#define ERROR_IF_NOT_ZERO(i)  { if ((i) != 0)    ioError(); }
#define ERROR_IF_MINUS_ONE(i) { if ((i) == (-1)) ioError(); }


/*---------------------------------------------*/
/*--
   Platform-specific stuff.
--*/

#if BZ_UNIX
#   include <fcntl.h>
#   include <sys/types.h>
#   include <utime.h>
#   include <unistd.h>
#   include <sys/stat.h>
#   include <sys/times.h>

#   define PATH_SEP    '/'
#   define MY_LSTAT    lstat
#   define MY_STAT     stat
#   define MY_S_ISREG  S_ISREG
#   define MY_S_ISDIR  S_ISDIR

#   define APPEND_FILESPEC(root, name) \
      root=snocString((root), (name))

#   define APPEND_FLAG(root, name) \
      root=snocString((root), (name))

#   define SET_BINARY_MODE(fd) /**/

#   ifdef __GNUC__
#      define NORETURN __attribute__ ((noreturn))
#   else
#      define NORETURN /**/
#   endif

#   ifdef __DJGPP__
#     include <io.h>
#     include <fcntl.h>
#     undef MY_LSTAT
#     undef MY_STAT
#     define MY_LSTAT stat
#     define MY_STAT stat
#     undef SET_BINARY_MODE
#     define SET_BINARY_MODE(fd)                        \
        do {                                            \
           int retVal = setmode ( fileno ( fd ),        \
                                  O_BINARY );           \
           ERROR_IF_MINUS_ONE ( retVal );               \
        } while ( 0 )
#   endif

#   ifdef __CYGWIN__
#     include <io.h>
#     include <fcntl.h>
#     undef SET_BINARY_MODE
#     define SET_BINARY_MODE(fd)                        \
        do {                                            \
           int retVal = setmode ( fileno ( fd ),        \
                                  O_BINARY );           \
           ERROR_IF_MINUS_ONE ( retVal );               \
        } while ( 0 )
#   endif
#endif /* BZ_UNIX */



#if BZ_LCCWIN32
#   include <io.h>
#   include <fcntl.h>
#   include <sys\stat.h>

#   define NORETURN       /**/
#   define PATH_SEP       '\\'
#   define MY_LSTAT       _stat
#   define MY_STAT        _stat
#   define MY_S_ISREG(x)  ((x) & _S_IFREG)
#   define MY_S_ISDIR(x)  ((x) & _S_IFDIR)

#   define APPEND_FLAG(root, name) \
      root=snocString((root), (name))

#   define APPEND_FILESPEC(root, name)                \
      root = snocString ((root), (name))

#   define SET_BINARY_MODE(fd)                        \
      do {                                            \
         int retVal = setmode ( fileno ( fd ),        \
                                O_BINARY );           \
         ERROR_IF_MINUS_ONE ( retVal );               \
      } while ( 0 )

#endif /* BZ_LCCWIN32 */

namespace MIDIToolkit
{


    /*---------------------------------------------------*/
    /*--- An implementation of 64-bit ints.  Sigh.    ---*/
    /*--- Roll on widespread deployment of ANSI C9X ! ---*/
    /*---------------------------------------------------*/

    typedef
       struct { UChar b[8]; }
       UInt64;

    Bool myfeof ( FILE* f )
    {
       Int32 c = fgetc ( f );
       if (c == EOF) return True;
       ungetc ( c, f );
       return False;
    }


    // BZ2Compressor class def start

    BZ2Compressor::BZ2Compressor()
    {
        blockSize100k = 9;
        verbosity = 0;
        workFactor = 30;
        smallMode = 0;
    }


    /*---------------------------------------------------*/
    /*--- Processing of complete files and streams    ---*/
    /*---------------------------------------------------*/

    /*---------------------------------------------*/
    void BZ2Compressor::compressStream ( FILE *stream, FILE *zStream )
    {
       BZFILE* bzf = NULL;
       UChar   ibuf[5001];
       Int32   nIbuf;
       UInt32  nbytes_in_lo32, nbytes_in_hi32;
       UInt32  nbytes_out_lo32, nbytes_out_hi32;
       Int32   bzerr, bzerr_dummy, ret;

       SET_BINARY_MODE(stream);
       SET_BINARY_MODE(zStream);

       if (ferror(stream)) goto errhandler_io;
       if (ferror(zStream)) goto errhandler_io;

       bzf = BZ2_bzWriteOpen ( &bzerr, zStream,
                               blockSize100k, verbosity, workFactor );
       if (bzerr != BZ_OK) goto errhandler;

       if (verbosity >= 2) fprintf ( stderr, "\n" );

       while (True)
       {
          if (myfeof(stream)) {break;}
          nIbuf = fread ( ibuf, sizeof(UChar), 5000, stream );
          if (ferror(stream)){goto errhandler_io;}
          if (nIbuf > 0) BZ2_bzWrite ( &bzerr, bzf, (void*)ibuf, nIbuf );
          if (bzerr != BZ_OK){goto errhandler;}
       }

       BZ2_bzWriteClose64 ( &bzerr, bzf, 0,
                            &nbytes_in_lo32, &nbytes_in_hi32,
                            &nbytes_out_lo32, &nbytes_out_hi32 );


       if (bzerr != BZ_OK) goto errhandler;

       if (ferror(zStream)) goto errhandler_io;
       ret = fflush ( zStream );

       if (ret == EOF) goto errhandler_io;

       if (zStream != stdout) {
          ret = fclose ( zStream );
          if (ret == EOF) goto errhandler_io;
       }
       if (ferror(stream)) goto errhandler_io;
       ret = fclose ( stream );
       if (ret == EOF) goto errhandler_io;

       return;

       // error handler
       errhandler:
       BZ2_bzWriteClose64 ( &bzerr_dummy, bzf, 1,
                            &nbytes_in_lo32, &nbytes_in_hi32,
                            &nbytes_out_lo32, &nbytes_out_hi32 );

       // add exception generating functions here
        switch (bzerr)
        {
            case BZ_CONFIG_ERROR:
                configError();
                break;
            case BZ_MEM_ERROR:
                outOfMemory ();
                break;
            case BZ_IO_ERROR:
                errhandler_io:
                ioError();
                break;
            default:
                panic ( "compress:unexpected error" );
                break;
        }

        panic ( "compress:end" );
    }



    /*---------------------------------------------*/
    Bool BZ2Compressor::uncompressStream ( FILE *zStream, FILE *stream )
    {
       BZFILE* bzf = NULL;
       Int32   bzerr, bzerr_dummy, ret, nread, streamNo, i;
       UChar   obuf[5000];
       UChar   unused[BZ_MAX_UNUSED];
       Int32   nUnused;
       void*   unusedTmpV;
       UChar*  unusedTmp;

       nUnused = 0;
       streamNo = 0;

       SET_BINARY_MODE(stream);
       SET_BINARY_MODE(zStream);

       if (ferror(stream)) goto errhandler_io;
       if (ferror(zStream)) goto errhandler_io;

       while (True) {

          bzf = BZ2_bzReadOpen (
                   &bzerr, zStream, verbosity,
                   (int)smallMode, unused, nUnused
                );
          if (bzf == NULL || bzerr != BZ_OK) goto errhandler;
          streamNo++;

          while (bzerr == BZ_OK) {
             nread = BZ2_bzRead ( &bzerr, bzf, obuf, 5000 );
             if (bzerr == BZ_DATA_ERROR_MAGIC) goto errhandler;
             if ((bzerr == BZ_OK || bzerr == BZ_STREAM_END) && nread > 0)
                fwrite ( obuf, sizeof(UChar), nread, stream );
             if (ferror(stream)) goto errhandler_io;
          }
          if (bzerr != BZ_STREAM_END) goto errhandler;

          BZ2_bzReadGetUnused ( &bzerr, bzf, &unusedTmpV, &nUnused );
          if (bzerr != BZ_OK) panic ( "decompress:bzReadGetUnused" );

          unusedTmp = (UChar*)unusedTmpV;
          for (i = 0; i < nUnused; i++) unused[i] = unusedTmp[i];

          BZ2_bzReadClose ( &bzerr, bzf );
          if (bzerr != BZ_OK) panic ( "decompress:bzReadGetUnused" );

          if (nUnused == 0 && myfeof(zStream)) break;
       }

       if (ferror(zStream)) goto errhandler_io;
       ret = fclose ( zStream );
       if (ret == EOF) goto errhandler_io;

       if (ferror(stream)) goto errhandler_io;
       ret = fflush ( stream );
       if (ret != 0) goto errhandler_io;
       if (stream != stdout) {
          ret = fclose ( stream );
          if (ret == EOF) goto errhandler_io;
       }
       return True;

       errhandler:
       BZ2_bzReadClose ( &bzerr_dummy, bzf );
       switch (bzerr) {
          case BZ_CONFIG_ERROR:
             configError();
             break;
          case BZ_IO_ERROR:
             errhandler_io:
             ioError();
             break;
          case BZ_DATA_ERROR:
             crcError();
             break;
          case BZ_MEM_ERROR:
             outOfMemory();
             break;
          case BZ_UNEXPECTED_EOF:
             compressedStreamEOF();
             break;
          case BZ_DATA_ERROR_MAGIC:
             if (zStream != stdin) fclose(zStream);
             if (stream != stdout) fclose(stream);
             break;
          default:
             panic ( "decompress:unexpected error" );
       }

       panic ( "decompress:end" );
       return True; /*notreached*/
    }
}

