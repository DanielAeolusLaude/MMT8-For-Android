/*
   Virtual MIDI Multitrack Recorder
   Copyright (c) 2006 MIDI Team

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU Lesser General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU Lesser  General Public License for more details.

   You should have received a copy of the GNU Lesser General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/

/**
   IOutputPort.hppile IOutputPort.hpp
   Charles Weld, David Wilson, James Brown, Jonathan Van Rossum, and Matthew Harrold
   @brief Declaration of class IOutputPort, part of Virtual MIDI Multitrack Recorder
*/

#ifndef _IOUTPUTPORT_H
#define _IOUTPUTPORT_H

#include "MIDIToolkitPrerequisites.hpp"
#include "Analyser.hpp"

namespace MIDIToolkit
{
    /**
     * Defines the interface that all Output Port's must inherit.
     * An Output Port is a MIDI Device that allows the user to send MIDI Events.
     */
    /// @ingroup midiport
    class IOutputPort : public Analyser
    {
    public:
        /**
         * Destructor.
         */
        virtual ~IOutputPort(){}

        /**
         * @brief
         *
         * Opens the Output Port identified by id.
         * @param port_id The port id.
         */
        virtual void open(int port_id) = 0;

        /**
         * @brief Closes the Output Port.
         *
         * Closes the Output Port.
         */
        virtual void close() = 0;

        /**
         * @brief Resets the Output Port.
         *
         * Resets the Output Port.
         */
        virtual void reset() = 0;

        /**
         * @brief  Get's the name of a specific port.
         *
         * Get's the name of a specific port.
         * @param port The id of the port.
         * @return The name of the port identified by @see id.
         */
        virtual String getPortName(int port) = 0;

        /**
         * @brief Get's the number of Output Ports.
         *
         * Get's the number of Output Ports.
         * @return The number of Output Ports.
         */
        virtual int getNumPorts() = 0;

        /**
         * @brief Get's the id of this port.
         *
         * Get's the id of this port.
         * @return The port's id.
         */
        virtual int getPortNumber() = 0;
    };
}

#endif  //_IOUTPUTPORT_H
