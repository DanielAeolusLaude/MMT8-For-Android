/*
   Virtual MIDI Multitrack Recorder
   Copyright (c) 2006 MIDI Team

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU Lesser General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU Lesser  General Public License for more details.

   You should have received a copy of the GNU Lesser General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/

/**
   @file Win32OutputPort.hpp
   Charles Weld, David Wilson, James Brown, Jonathan Van Rossum, and Matthew Harrold
   @brief Declaration of class Win32OutputPort, part of Virtual MIDI Multitrack Recorder
*/

#ifndef _WIN32OUTPUTPORT_H
#define _WIN32OUTPUTPORT_H

#include <windows.h>

#include "MIDIToolkitPrerequisites.hpp"
#include "OutputPort.hpp"
#include "ShortMessage.hpp"

namespace MIDIToolkit
{
    /**
     * The Win32OutputPort class provides Windows32 Support for Output Ports.
     */
    /// @ingroup midiport
    class Win32OutputPort : public OutputPort
    {
    public:
        /**
         * @brief Creates a new closed Output Port.
         *
         * Creates a new closed Output Port.
         * Note that this Output Port isn't open,
         * and therefore no send any MIDI Events.
         */
        Win32OutputPort();

        /**
         * @brief Creates a new open Output Port.
         *
         * Creates a new open Output Port.
         * @param port_id The id of the Win32 Port to open.
         */
        Win32OutputPort(int port_id);

        /**
         * @brief Destructor.
         *
         * Destructor.
         */
        virtual ~Win32OutputPort();

        /**
         * @brief Opens a Win32 Output Port identified by port_id.
         *
         * Opens a Win32 Output Port identified by port_id.
         * @param port_id The id of the Win32 Port to open.
         */
        virtual void open(int port_id);

        /**
         * @see IOutputPort::close()
         */
        virtual void close();

        /**
         * @see IOutputPort::getPortName(int)
         */
        virtual String getPortName(int port);

        /**
         * @see IOutputPort::getNumPorts()
         */
        virtual int getNumPorts();
    protected:
        /**
         * @brief When called actually sends the Short Message.
         *
         * When called actually sends the Short Message
         * out the open Win32 Port.
         */
        virtual void send(ShortMessage* msg);

        HMIDIOUT handle;
    };
}

#endif  //_OUTPUTPORT_H
