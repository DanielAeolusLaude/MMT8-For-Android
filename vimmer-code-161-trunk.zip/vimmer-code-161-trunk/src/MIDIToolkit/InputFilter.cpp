/*
   Virtual MIDI Multitrack Recorder
   Copyright (c) 2006 MIDI Team

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU Lesser General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU Lesser  General Public License for more details.

   You should have received a copy of the GNU Lesser General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/

/**
   @file InputFilter.cpp
   Charles Weld, David Wilson, James Brown, Jonathan Van Rossum, and Matthew Harrold
   @brief Declaration of class InputFilter, part of Virtual MIDI Multitrack Recorder
*/

#include "InputFilter.hpp"
#include "MIDIEvent.hpp"
#include "Events.hpp"
#include "MessageTypes.hpp"
#include <iostream>

using namespace std;

namespace MIDIToolkit
{
    InputFilter::InputFilter()
    {
        // init
        m_NoteState = true;
        m_PitchBend = true;
        m_AfterTouch = true;
        m_Controllers = true;
        m_ProgramChange = true;
        m_Channel = 0;
    }

    InputFilter::~InputFilter()
    {
    }

    void InputFilter::receive(MIDIEvent* evt)
    {
        raiseEvent(Events::SEQUENCER_ACTIVITY_MIDI_IN);

        // we only allow channel messages that pass our filter.
        if(evt->getMessage()->isA(MessageTypes::CHANNEL_MESSAGE) && filter(static_cast<ChannelMessage*>(evt->getMessage())))
        {
            this->distrubuteMessage(evt);
        }
    }

    bool InputFilter::filter(ChannelMessage* msg)
    {
        unsigned int command = msg->getCommand();
        // note case
        if(!m_NoteState && (command==ChannelCommands::NoteOn || command==ChannelCommands::NoteOff))
        {
            return false;
        }

        if(!m_PitchBend && command==ChannelCommands::PitchWheel)
        {
            return false;
        }

        if(!m_AfterTouch && command==ChannelCommands::PolyPressure)
        {
            return false;
        }

        if(!m_Controllers && command==ChannelCommands::Controller)
        {
            return false;
        }

        if(!m_ProgramChange && command==ChannelCommands::ProgramChange)
        {
            return false;
        }

        if (m_Channel != 0 && (m_Channel-1) != msg->getChannel())
        {
            return false;
        }

        return true;
    }

    void InputFilter::setNoteState(bool s)
    {
        m_NoteState = s;
    }

    bool InputFilter::getNoteState()
    {
        return m_NoteState;
    }

    void InputFilter::setPitchBendState(bool s)
    {
        m_PitchBend = s;
    }

    bool InputFilter::getPitchBendState()
    {
        return m_PitchBend;
    }

    void InputFilter::setAfterTouchState(bool s)
    {
        m_AfterTouch = s;
    }

    bool InputFilter::getAfterTouchState()
    {
        return m_AfterTouch;
    }

    void InputFilter::setControllerState(bool s)
    {
        m_Controllers = s;
    }

    bool InputFilter::getControllerState()
    {
        return m_Controllers;
    }

    void InputFilter::setProgramChangeState(bool s)
    {
        m_ProgramChange = s;
    }

    bool InputFilter::getProgramChangeState()
    {
        return m_ProgramChange;
    }

    void InputFilter::setChannel(unsigned int c)
    {
        m_Channel = c;
    }

    unsigned int InputFilter::getChannel()
    {
        return m_Channel;
    }

}
