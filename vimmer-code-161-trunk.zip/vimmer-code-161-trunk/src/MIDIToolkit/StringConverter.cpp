/*
   Virtual MIDI Multitrack Recorder
   Copyright (c) 2006 MIDI Team

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/

/**
   @file StringConverter.cpp
   @author Charles Weld
   @brief Declaration of class StringConverter, part of Virtual MIDI Multitrack Recorder
*/
#include "StringConverter.hpp"
#include <sstream>
#include "Exception.hpp"
#include "Exceptions.hpp"
#include <iostream>
namespace MIDIToolkit
{
    String StringConverter::intToString(int num)
    {
        std::stringstream ss;
        std::string str;
        ss << num;
        ss >> str;
        return str;
    }

    String StringConverter::floatToString(float num)
    {
        std::stringstream ss;
        std::string str;
        ss << num;
        ss >> str;
        return str;
    }

    String StringConverter::intToHexString(int num)
    {
        std::ostringstream stm;
        stm << std::hex;
        stm << num;
        return stm.str();
    }

    int StringConverter::stringToInt(String num)
    {
        int number=0;
        std::istringstream iss(num);

        if(  (iss >> number >> std::dec).fail() )
        {
            throw Exception(Exceptions::CONVERSION_FAILED, _T("Failed to convert string \"") + num + _T("\" to int."), "int StringConverter::stringToInt(String num)");
        }

        return number;
    }

    float StringConverter::stringToFloat(String num)
    {
        float number=0;
        std::istringstream iss(num);
        if( (iss >> number >> std::dec).fail() )
        {
            throw Exception(Exceptions::CONVERSION_FAILED, "Failed to convert string to float.", "int StringConverter::stringToInt(String num)");
        }

        return number;
    }

    int StringConverter::hexStringToInt(String num)
    {
        int number=0;
        std::istringstream iss(num);
        if(  (iss >> std::hex >> number >> std::hex).fail() )
        {
            throw Exception(Exceptions::CONVERSION_FAILED, "Failed to convert string to int.", "int StringConverter::stringToInt(String num)");
        }

        return number;
    }
}
