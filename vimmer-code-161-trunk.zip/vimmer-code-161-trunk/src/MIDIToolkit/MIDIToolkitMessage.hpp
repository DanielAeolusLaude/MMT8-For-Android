/*
   Virtual MIDI Multitrack Recorder
   Copyright (c) 2006 MIDI Team

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU Lesser General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU Lesser  General Public License for more details.

   You should have received a copy of the GNU Lesser General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/

/**
   @file MIDIToolkitMessage.hpp
   @author Charles Weld
   @brief Declaration of class MIDIToolkitMessage, part of Virtual MIDI Multitrack Recorder
*/

#ifndef _MIDITOOLKITMESSAGE_H
#define _MIDITOOLKITMESSAGE_H

#include "MIDIMessage.hpp"

namespace MIDIToolkit
{
    namespace MTMessageTypes
    {
        /// @ingroup midimsg
        enum
        {
            //! Turns all notes off.
            ALL_NOTES_OFF
        };
    }
    /// @ingroup midimsg
    typedef int MTMessageType;

    /// @ingroup midimsg
    class MIDIToolkitMessage : public MIDIMessage
    {
    public:
        /**
         * Initializes a new instance of the MIDIToolkitMessage class with the spacified type.
         * @param type The type of MIDIToolkitMessage.
         */
        MIDIToolkitMessage(MTMessageType type);

        /**
         * Default Constructor.
         */
        virtual ~MIDIToolkitMessage();

        /**
         * Clones this message.
         */
        virtual MIDIMessage* clone();

        /**
         * Checks if this message is of type msgType.
         * @param msgType The type of message to check.
         * @return True if this message is of type msgType, otherwise false.
         */
        virtual bool isA(MTMessageType msgType);

        /**
         * Gets the type of MIDIToolkit Message.
         * @return The type of MIDIToolkit Message.
         */
        virtual MTMessageType getMessageType();

        /**
         * Sets the type of MIDIToolkit Message.
         * @param type The MIDITookit Message Type value.
         */
        virtual void setMessageType(MTMessageType type);
    private:
        MTMessageType m_MTType;
    };
}

#endif  //_MIDIToolkitMessage_H
