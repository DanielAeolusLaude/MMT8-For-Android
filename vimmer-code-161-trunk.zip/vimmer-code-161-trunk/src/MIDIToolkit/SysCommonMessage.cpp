/*
   Virtual MIDI Multitrack Recorder
   Copyright (c) 2006 MIDI Team

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU Lesser General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU Lesser  General Public License for more details.

   You should have received a copy of the GNU Lesser General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/

/**
   SysCommonMessage.cppile SysCommonMessage.cpp
   Charles Weld, David Wilson, James Brown, Jonathan Van Rossum, and Matthew Harrold
   @brief Declaration of class SysCommonMessage, part of Virtual MIDI Multitrack Recorder
*/

#include "SysCommonMessage.hpp"
#include "MessageTypes.hpp"

namespace MIDIToolkit
{
    SysCommonMessage::SysCommonMessage(SysCommonType type)
        : ShortMessage::ShortMessage()
    {
       this->type = MessageTypes::SYS_COMMON_MESSAGE;
       setSysCommonType(type);

       // ensure
    }

    SysCommonMessage::SysCommonMessage(SysCommonType type, int data1)
        : ShortMessage::ShortMessage()
    {
        this->type = MessageTypes::SYS_COMMON_MESSAGE;
        setSysCommonType(type);
        setData1(data1);

        // ensure
    }

    SysCommonMessage::SysCommonMessage(SysCommonType type, int data1, int data2)
        : ShortMessage::ShortMessage()
    {
        this->type = MessageTypes::SYS_COMMON_MESSAGE;
        setSysCommonType(type);
        setData1(data1);
        setData2(data2);

        // ensure
    }

    SysCommonMessage::~SysCommonMessage()
    {
    }

    int SysCommonMessage::getSysCommonType()
    {
        return getStatus();
    }

    void SysCommonMessage::setSysCommonType(int type)
    {
        setStatus(type);
    }

    int SysCommonMessage::getData1()
    {
        return getPackageData1();
    }

    void SysCommonMessage::setData1(int data)
    {
        setPackageData1(data);
    }

    int SysCommonMessage::getData2()
    {
        return getPackageData2();
    }

    void SysCommonMessage::setData2(int data)
    {
        setPackageData2(data);
    }

    MIDIMessage* SysCommonMessage::clone()
    {
        SysCommonMessage* msg = new SysCommonMessage(getSysCommonType(), getData1(), getData2());
        return msg;
    }

    bool SysCommonMessage::isA(MessageType msgType)
    {
        return (msgType == MessageTypes::SYS_COMMON_MESSAGE || msgType==MessageTypes::SHORT_MESSAGE || msgType==MessageTypes::MIDI_MESSAGE);
    }

}
