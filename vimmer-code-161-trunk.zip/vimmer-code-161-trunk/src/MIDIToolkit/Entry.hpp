/*
   Virtual MIDI Multitrack Recorder
   Copyright (c) 2006 MIDI Team

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/

/**
   @file Entry.hpp
   @author David Wilson
   @brief Declaration of class Entry, part of Virtual MIDI Multitrack Recorder
*/

#ifndef _ENTRY_H
#define _ENTRY_H

#include "Node.hpp"
#include "LogManager.hpp"

namespace MIDIToolkit
{
    /**
      @brief An Entry in the configuration.

      An Entry in the configuration.

      @ingroup config.
    */
    class Entry : public Node
    {
    public:

        /**
         @brief Initialises an Entry with a specific Name and Value.

         Initialises an Entry with a specific Name and Value.

         @param Name of Configuration Entry.
         @param Value of Configuration Entry.
        */
        Entry(String name="", String value="");

        /**
         @brief Sets the value of the Entry.

         Sets the value of Entry.

         @param Value of string.
        */
        void setValue(String val);

        /**
         @brief Gets the value of the Entry in String format.

         Gets the value of the Entry in String format.
        */
        String getStringValue();

        /**
         @brief Sets the value of the Entry in int format.

         Sets the value of the Entry in int format.

         @param Value of int.
         @return The set int value.
        */
        void setValue(int val);

        /**
         @brief Gets the value of the Entry in int format.

         Gets the value of the Entry in int format.

         @param Value of int.
        */
        int getIntValue();

        /**
         @brief Sets the value of the Entry in float format.

         Sets the value of the Entry in float format.

         @param Value of float.
         @return The float set value.
        */
        void setValue(float val);

        /**
         @brief Gets the value of the Entry in Float format.

         Gets the value of the Entry in Float format.
        */
        float getFloatValue();

        /**
         @brief Sets the value of the Entry in boolean format.

         Sets the value of the Entry in boolean format.

         @param val The new value.
        */
        void setValue(bool val);

        /**
         @brief Gets the value of the Entry in Boolean format.

         Gets the value of the Entry in Boolean format.
        */
        bool getBoolValue();

        /**
         @brief Gets a specific element from an XML file

         Gets a specific element from an XML file
        */
        TiXmlElement* getXML();

        /**
         @brief Sets a specific element to an XML file

         Sets a specific element to an XML file

         @param Reference to an XML Element
         @return The referenced element
        */
        void setXML(TiXmlElement* elem);

    private:
        String value;
        LogManager* logger;
    };
}

#endif  //_ENTRY_H
