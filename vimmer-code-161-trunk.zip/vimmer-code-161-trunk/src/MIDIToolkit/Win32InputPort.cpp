/*
   Virtual MIDI Multitrack Recorder
   Copyright (c) 2006 MIDI Team

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU Lesser General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU Lesser  General Public License for more details.

   You should have received a copy of the GNU Lesser General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/

/**
   @file Win32InputPort.cpp
   Charles Weld, David Wilson, James Brown, Jonathan Van Rossum, and Matthew Harrold
   @brief Declaration of class Win32InputPort, part of Virtual MIDI Multitrack Recorder
*/

#include "Win32InputPort.hpp"
#include <windows.h>
#include "Exception.hpp"
#include "Exceptions.hpp"
#include "LogLevels.hpp"
#include "StringConverter.hpp"
#include <sstream>
#include <iostream>
using namespace std;
namespace MIDIToolkit
{
    void CALLBACK MIDICallback(HMIDIIN handle, UINT uMsg, DWORD dwInstance, DWORD dwParam1, DWORD dwParam2)
    {
        Win32InputPort* port = (Win32InputPort*)dwInstance;
        port->midiCallback(handle, uMsg, dwParam1, dwParam2);
    }

    Win32InputPort::Win32InputPort():
        InputPort()
    {
        handle = NULL;
    }

    Win32InputPort::Win32InputPort(int port_id):
        InputPort()
    {
        open(port_id);
    }

    Win32InputPort::~Win32InputPort()
    {
        close();
    }

    void Win32InputPort::midiCallback(HMIDIIN handle, UINT uMsg, DWORD dwParam1, DWORD dwParam2)
    {
        /* Determine why Windows called me */
        switch (uMsg)
        {
            /* Received some regular MIDI message */
            case MIM_DATA:
            {
                this->processShortMsg(dwParam2, dwParam1);
                break;
            }
            case MIM_LONGDATA:
            {
                logger->log("SYS-EX Messages aren't supported yet.", LogLevels::LEVEL_ERROR);
                break;
            }
            case MIM_OPEN:
            {
                logger->log("Device Opened.");
                break;
            }
            case MIM_CLOSE:
            {
                logger->log("Device Closed");
                break;
            }
            case MIM_ERROR:
            {
                logger->log("MIDI Error has occured");
                break;
            }
            case MIM_LONGERROR:
            {
                logger->log("SYS-EX Message Error has occured");
                break;
            }
            case MIM_MOREDATA:
            {
                logger->log("Data loss due to not processing MIDI data fast enough.");
                break;
            }
        }
    }

    void Win32InputPort::open(int port_id)
    {
        if(handle)
                close();

        portID = port_id;
        if(port_id != -1)
        {
            unsigned long err;

            /* Open MIDI In device */
            err = midiInOpen(&handle, port_id, (DWORD)MIDICallback, (DWORD)this, CALLBACK_FUNCTION);
            if (!(err))
            {
                /// TODO add sys ex init stuff here.
                logger->log(_T("Opened Input port (") + StringConverter::intToString(port_id) + _T(")."));
            }
            else
            {
                std::stringstream msg;
                msg << "There was an error opening the inputput port (" << port_id << ").";
                logger->log(msg.str());
                throw Exception(Exceptions::MIDI, msg.str(), "void Win32InputPort::open(int port_id)");
            }
        }
    }

    void Win32InputPort::close()
    {
        if(handle)
        {
            // first stop recording (if it is)
            stop();

            // now close the midi port.
            unsigned long err;
            while ((err = midiInClose(handle)) == MIDIERR_STILLPLAYING) Sleep(0);
            if(err)
            {
                throw Exception(Exceptions::MIDI, "Failed to close the input port.", "void Win32InputPort::close()");
            }

            handle=NULL;
        }
        else
        {
            logger->log("Can't close a closed port!");
        }
    }

    void Win32InputPort::start()
    {
        if(handle && portID!=-1)
        {
            unsigned long err;
            if((err = midiInStart(handle)))
            {
                throw Exception(Exceptions::MIDI, "Failed to start the input port.", "void Win32InputPort::start()");
            }
            else
            {
                logger->log("Input Port Started.");
            }
        }
        else
        {
            logger->log("Can't start an unopened port!");
        }
    }

    void Win32InputPort::stop()
    {
        midiInStop(handle);
        logger->log("Input Port Stopped.");
    }

    void Win32InputPort::reset()
    {
        midiInReset(handle);
        logger->log("Input Port Reset.");
    }

    String Win32InputPort::getPortName(int port)
    {
        MIDIINCAPS     mic;
        String name;
        /* Get info about the port */
        if (!midiInGetDevCaps(port, &mic, sizeof(MIDIINCAPS)))
        {
           name = mic.szPname;
        }
        else
        {
            throw Exception(Exceptions::MIDI, "Failed to get input port details", "String Win32InputPort::getPortName(int port)");
        }

        return name;
    }

    int Win32InputPort::getNumPorts()
    {
        return midiInGetNumDevs();
    }

}
