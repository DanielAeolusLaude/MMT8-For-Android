/*
   Virtual MIDI Multitrack Recorder
   Copyright (c) 2006 MIDI Team

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU Lesser General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU Lesser  General Public License for more details.

   You should have received a copy of the GNU Lesser General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/

/**
   @file Generator.hpp
   @author Charles Weld
   @brief Declaration of class Generator, part of Virtual MIDI Multitrack Recorder
*/

#ifndef _GENERATOR_H
#define _GENERATOR_H

#include "Analyser.hpp"
#include "MIDIEvent.hpp"
#include "MIDIToolkitPrerequisites.hpp"

namespace MIDIToolkit
{
    /// @brief The Generator provides the ability to generate messages.
    /**
     * The Generator provides the ability to generate messages.
     * these messages are then passed to the next component which must be either a Modulator or Analyser.
     * A good example of a Generator would be an Input Port.
     *
     * @ingroup midicom
     */
    class Generator
    {
    public:
        /**
         * @brief Default Constructor.
         */
        Generator();

        /**
         * @brief Default Destructor.
         */
        virtual ~Generator();

        /**
         * @brief Connects an Analyser to this Generator.
         *
         * For an Analyser or  to receive MIDIEvents from a Generator it must
         * first be connected to the Generator. This is accomplished by calling this function.
         *
         * @param a The Analyser to connect.
         */
        virtual void connect(Analyser* a);

        /**
         * @brief Disconnects a particular Analyser from this Generator.
         *
         * Disconnects a connected Analyser from this Generator, this means that
         * the Analyser a will no longer receive MIDIEvents from this Generator.
         *
         * @param a The Analyser to disconnect.
         */
        virtual void disconnect(Analyser* a);

        /**
         * @brief Disconnects all analysers from this generator.
         */
        virtual void disconnectAll();
    protected:

        /**
         * @brief Allows the generator to distribute message events to all
         * connected analyers.
         *
         * This will distribute a specific MIDIEvent to all connected analysers.
         *
         * @param evt The message event to distribute.
         */
        virtual void distributeMessage(MIDIEvent* evt);

        /**
         *  DO NOT USE
         *  (Use the correct spelling).
         */
        virtual void distrubuteMessage(MIDIEvent* evt);

    // varibles
    protected:
        //! The analysers.
        AnalyserList analysers;
    };
}

#endif  //_GENERATOR_H
