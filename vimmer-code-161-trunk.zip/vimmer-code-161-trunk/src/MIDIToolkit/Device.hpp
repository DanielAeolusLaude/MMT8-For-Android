/*
   Virtual MIDI Multitrack Recorder
   Copyright (c) 2006 MIDI Team

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU Lesser General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU Lesser  General Public License for more details.

   You should have received a copy of the GNU Lesser General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/

/**
   @file Device.hpp
   @author Charles Weld
   @brief Declaration of class Device, part of Virtual MIDI Multitrack Recorder
*/

#ifndef _DEVICE_H
#define _DEVICE_H

#include "Modulator.hpp"
#include "InputFilter.hpp"
#include "OutputFilter.hpp"
#include "Through.hpp"
#include "IInputPort.hpp"
#include "IOutputPort.hpp"
#include "LogManager.hpp"
#include "Observable.hpp"
#include "Observer.hpp"

namespace MIDIToolkit
{
    // typedefs
    typedef std::vector<String> PortVector;

    /**
     * @brief A Device is basically an advanced Modulator in that it has one Input Port and one Output Port.
     *
     * A Device also has a number of internal components such as an Input Filter that filters all the
     * messages from the input port, a through that allows messages to be passed straight through to the
     * output filter, and an output filter that filters MIDI Messages before they are sent out the Output
     * Port.
     *
     * @ingroup mididev
     */
    class Device : public Modulator, public Observable
    {
    public:
        /**
         * @brief Creates a new device with no open ports.
         *
         * The default constructor creates a device with no Input Ports or Output Ports.
         */
        Device();

        /**
         * @brief Destructor.
         *
         * Cleans up the device.
         */
        virtual ~Device();

        /// @brief Sets what InputPort to use based on id.
        /**
         * Sets the input port to use. The input port is identified
         * by an id, since every MIDI Port available for use by the user
         * has a unique id, for example almost all Windows 32 based PC's have
         * a General Synthesizer which is represented by id of 0.
         *
         * @param id The input port's new id.
         */
        virtual void setInput(int id);

        /// @brief Gets the id of the Input Port.
        /**
         * Gets the id of the InputPort.
         *
         * @return The Input Port's id.
         *
         * @see IInputPort::getPortNumber()
         */
        virtual int getInput();

        /// @brief Sets what output port is used based on id.
        /**
         * Sets what output port is used based on id.
         * The id is used to uniquly identify the
         * physical MIDI Device. A example of a
         * MIDI Output on Window 32 would be the
         * General Synthesizer which is usually identified
         * by the id 0.
         *
         * @param id The output port's new id.
         *
         * @see IOutputPort::open(int)
         */
        virtual void setOutput(int id);

        /// @brief Gets the id of the Output Port.
        /**
         * Gets the id of the Output Port.
         *
         * @return The Output Port's id.
         *
         * @see IOutputPort::getPortNumber()
         */
        virtual int getOutput();

        /// @brief Gets the name of the Input Port.
        /**
         * Gets the name of the Input Port.
         *
         * @return The Input Port's name.
         */
        virtual String getInputName();

        /// @brief Gets the name of the Output Port.
        /**
         * Gets the name of the Output Port.
         * @return The Output Port's name.
         */
        virtual String getOutputName();

        /// @brief Gets the number of Input Ports available for use.
        /**
         * Gets the number of Input Ports available for use.
         *
         * @return Number of Input Ports.
         */
        virtual int getInputCount();

        /// @brief Gets the number of Output Ports available for use.
        /**
         * Gets the number of Output Ports available for use.
         *
         * @return Number of Output Ports.
         */
        virtual int getOutputCount();

        /// @brief Get's a list of all the names of all available input ports.
        /**
         * Get's a list of all the names of all available input ports.
         *
         * @return A list of Input Port names.
         */
        virtual PortVector getInputs();

        /// @brief Get's a list of all the names of all available output ports.
        /**
         * Get's a list of all the names of all available output ports.
         *
         * @return A list of Output Port names.
         */
        virtual PortVector getOutputs();

        /// @brief Start's the device.
        /**
         * Start's the device, this allows us to start receiving messages.
         */
        virtual void start();

        /// @brief Stop's the device.
        /**
         * Stop's the device, this stops us from receiving messages.
         */
        virtual void stop();

        /// @brief Reset's the device.
        /**
         * Reset's the device.
         */
        virtual void reset();

        /// @brief This is called when the Analyser receives a MIDI Event and thus a message.
        /**
         * This is called when the Analyser receives a MIDI Event and thus a message.
         * When the Device receives a MIDIEvent from a Generator it is sent onto
         * the OutputFilter which will inturn pass it onto the OutputPort assuming
         * it passes the OutputFilter's test.
         *
         * @param evt The MIDI Event.
         */
        virtual void receive(MIDIEvent* evt);

        /// @brief Connects an Analyser to this Device.
        /**
         * Connects an Analyser to this Device.
         *
         * @param a The Analyser to connect.
         */
        void connect(Analyser* a);

        /// @brief Disconnects a particular Analyser from this Device.
        /**
         * Disconnects a particular Analyser from this Device.
         * @param a The Analyser to disconnect.
         */
        void disconnect(Analyser* a);

        /// @brief Disconnects all Analysers from this Generator.
        /**
         * Disconnects all Analysers from this Generator.
         */
        void disconnectAll();

        /// @brief Enables Through.
        /**
         * Enables Through, When Through is enabled
         * all MIDI Events that make it pass the InputFilter
         * are forwarded to the OutputFilter.
         */
        void enableThru();

        /// @brief Disables Through.
        /**
         * Disables Through, When Through is enabled
         * all MIDI Events that make it pass the InputFilter
         * are forwarded to the OutputFilter.
         */
        void disableThru();

        /// @brief Gets Through's state.
        /**
         * Gets Through's state.
         * @return True if through is enabled, otherwise false.
         */
        bool isThruEnabled();

        /**
         * @see Observable::addObserver
         */
        void addObserver(Observer* o);

        /// @brief Gets a pointer to the Input Filter.
        /**
         * Gets a pointer to the Input Filter.
         * @return The Input Filter.
         */
        InputFilter* getInputFilter();

    protected:
        InputFilter* m_InputFilter;
        OutputFilter* m_OutputFilter;
        Through* m_Through;
        IInputPort* m_InputPort;
        IOutputPort* m_OutputPort;
        LogManager* logger;
    };
}

#endif  //_DEVICE_H
