/*
   Virtual MIDI Multitrack Recorder
   Copyright (c) 2006 MIDI Team

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU Lesser General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU Lesser  General Public License for more details.

   You should have received a copy of the GNU Lesser General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/

/**
   @file   MultiTrack.hpp
   @author Jonathan Van Rossum (jvr85@users.sourceforge.net)
   @brief  Declaration of the class MultiTrack.
*/

#ifndef _MULTITRACK_H
#define _MULTITRACK_H

#include "Track.hpp"
#include "Observable.hpp"

namespace MIDIToolkit
{
    /** @ingroup midiseq
     *  @brief  Holds a collection of parallel Tracks.
     *
     *  OVERVIEW:
     *
     *  The Sequencer supports the playback of multiple tracks simultaneously.
     *  Each track is represented by the Track class. The group of Tracks that play
     *  simultaneously is represented by this class, the MultiTrack.
     *
     *  The MultiTrack class also provides convenient functions for editing the
     *  Tracks, but there is nothing provided that can't be done directly on the
     *  Tracks themselves.
     *
     *  The MultiTrack class is used mainly by the Sequencer class. A MultiTrack is
     *  roughly equivalent to a "Part". In fact, the Part class inherits directly
     *  from this class, and provides extra functionality that isn't required by the
     *  Sequencer. (See Vimmer::Part).
     *
     *  STORAGE:
     *
     *  Like the Track class, the MultiTrack is passive. It has no knowledge of
     *  whether or not it is currently being played, where the Sequencer is up to,
     *  and what the playing (muted or not) status of any of its Tracks are.
     *  (For a description of these issues, refer to the Sequencer class).
     *
     *  NUMBER OF TRACKS:
     *
     *  The number of tracks stored by the MultiTrack is defined statically,
     *  and the Tracks are stored in an array. This class could easily be modified
     *  to store a variable number of Tracks (using a list or vector), so that the
     *  number of tracks is defined dynamically on creation. This was not considered
     *  necessary, though.
     *
     *  Note that the Sequencer class determines the number of tracks dynamically,
     *  by calling this class' count() function. However, VMM-R's GUI will currently
     *  show only the first 8 tracks.
     *
     *  Why play multiple Tracks simultaneously? ...
     *
     *  Each Track is used to represent a different instrument, allowing the user
     *  independent control over several instruments that play at the same time.
     *  While it is possible to store data for several instruments on the one Track,
     *  this is usually awkward and inconvenient.
     *
     *  GET TRACK:
     *
     *  The MultiTrack allows free access to any of its Tracks, via the getTrack(i)
     *  function. The Tracks cannot be "set", however. To change the contents of
     *  a Track, the caller must either use the various editing functions provided,
     *  or manually perform these operations directly on the Track itself.
     *
     *  LENGTH:
     *
     *  The MultiTrack also defines the (musical) "length" of the Tracks. Since they
     *  all play simultaneously, each Track has the same length. The length of a Track
     *  is not defined by the last event in each Track, as it is common for -all-
     *  Tracks to have silence at the end. In the case that another MultiTrack is
     *  to follow after this one, it must swap over at the right (musical) time.
     *
     *  EDITING:
     *
     *  The MultiTrack provides various editing functions. These can apply to either
     *  an individual Track, or all of its Tracks together. All editing operations
     *  can be performed directly on the Tracks themselves, without the use of these
     *  functions - the edit functions provided by MultiTrack are for convenience
     *  only. In fact, these functions simply call the corresponding functions
     *  provided by the Track class.
     *
     *  Generally, editing operations should not be done when the Sequencer is reading
     *  from or writing to any Track within the MultiTrack.
     *
     */
    class MultiTrack: public Observable
    {
    public:

            /** @brief  Constructor for MultiTrack.
             */
        MultiTrack();

            /** @brief  Destructor for MultiTrack.
             */
        ~MultiTrack();

            /** @brief  Get the number of Tracks in this MultiTrack.
              * @return     Number of Tracks.
             */
        unsigned int count();

            /** @brief  Get pointer to a particular Track.
              * @param  ind     The track number to get (0-based).
              * @return Pointer to the Track (or null for invalid).
             */
        Track* getTrack(unsigned int ind);

            /** @brief  Set the Length of this MultiTrack.
              * @note   Any events beyond this new length are erased.
              * @param  beats   The length (in beats).
             */
        void setLength(int beats);

            /** @brief  Get the Length of this MultiTrack.
              * @return     The length (in beats).
             */
        int getLength();

            /** @brief  ERASE this whole MultiTrack.
             */
        void erase();

            /** @brief  ERASE a Track.
              * @param  tracknumber Track number (0-based).
             */
        void erase(unsigned int tracknumber);

            /** @brief  COPY a Track to another.
              * @param  source  Source track number (0-based).
              * @param  dest    Destination track number (0-based).
             */
        void copy(unsigned int source, unsigned int dest);

            /** @brief  MERGE a Track into another.
              * @param  source  Source track number (0-based).
              * @param  dest    Destination track number (0-based).
             */
        void merge(unsigned int source, unsigned int dest);


            /** @brief  DEBUGGING ONLY.
              *
              *     Print a human-readable string representation of this MultiTrack.
              *     The output is to std::cout.
             */
        void print();


    protected:

        /// @brief  Fixed number of Tracks.
        static const unsigned int NUMBER_OF_TRACKS = 8;

        /// @brief  Array of Tracks.
        Track tracks[NUMBER_OF_TRACKS];

        /// @brief  The length of the multitrack (in beats).
        int multitrack_length;

    };
}

#endif  //_MULTITRACK_H
