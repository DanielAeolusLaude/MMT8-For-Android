/*
   Virtual MIDI Multitrack Recorder
   Copyright (c) 2006 MIDI Team

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/

/**
   @file Node.hpp
   @author David Wilson, and Charles Weld
   @brief Declaration of class Node, part of Virtual MIDI Multitrack Recorder
*/

#ifndef _NODE_H
#define _NODE_H

#include "MIDIToolkitPrerequisites.hpp"
#include "tinyxml.h"

namespace MIDIToolkit
{

/**
    @brief Represents a configuration Node which is either a Group or Entry.
    @ingroup midibase
*/
    class Node
    {
    public:

        /**
         @brief Destuctor.

         Destuctor.
        */
        virtual ~Node(){}

        /**
         @brief Sets the Name of this node.

         Sets the Name of this node.

         @param Set Node name.
         @return The node Name to set.
        */
        void setName(String name);

        /**
         @brief Gets the Name of this node.

         Gets the Name of this node.

         @param Get Node name.
         @return The node Name to get.
        */
        String getName();

        /**
         @brief Reference to get this XML element.

         Reference to get this XML element.

         @param Get XML element.
         @return The XML element to get.
        */
        virtual TiXmlElement* getXML() = 0;

        /**
         @brief Reference to set this XML element.

         Reference to set this XML element.

         @param Set XML element.
         @return XML element to set.
        */
        virtual void setXML(TiXmlElement* elem) = 0;

    protected:
        String name;
    };
}


#endif  //_NODE_H
