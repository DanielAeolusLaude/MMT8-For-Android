/*
   Virtual MIDI Multitrack Recorder
   Copyright (c) 2006 MIDI Team

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU Lesser General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU Lesser  General Public License for more details.

   You should have received a copy of the GNU Lesser General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/

/**
   @file MIDIEvent.cpp
   Charles Weld, David Wilson, James Brown, Jonathan Van Rossum, and Matthew Harrold
   @brief Declaration of class MIDIEvent, part of Virtual MIDI Multitrack Recorder
*/

#include "MIDIEvent.hpp"

// DEBUGGING ONLY
#include <iostream>

namespace MIDIToolkit
{
    MIDIEvent::MIDIEvent(MIDIMessage* msg, int absolute, int delta)
    {
        this->absolute = absolute;
        this->delta = delta;
        this->msg = msg;
    }

    MIDIEvent::MIDIEvent(const MIDIEvent& evt)
    {
        this->absolute = absolute;
        this->delta = delta;
        this->msg = msg->clone();
    }

    MIDIEvent& MIDIEvent::operator = (const MIDIEvent& evt)
    {
        if (this != &evt)
        {
            this->absolute = absolute;
            this->delta = delta;

            // delete this msg
            delete msg;

            this->msg = evt.msg->clone();
        }
        return *this;
    }

    MIDIEvent::~MIDIEvent()
    {
        delete msg;
    }

    void MIDIEvent::print(int indent)
    {
        for (int i=0; i<indent; i++){std::cout << " ";}
        std::cout << "MIDIEvent: A(" << absolute << ") D(" << delta << ") Msg: ";
        if (msg!=NULL)
        {
            msg->print();
        }
        std::cout << "\n";
    }

    MIDIMessage* MIDIEvent::getMessage()
    {
        return msg;
    }


}
