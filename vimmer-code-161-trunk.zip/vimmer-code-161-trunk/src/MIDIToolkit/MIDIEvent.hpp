/*
   Virtual MIDI Multitrack Recorder
   Copyright (c) 2006 MIDI Team

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU Lesser General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU Lesser  General Public License for more details.

   You should have received a copy of the GNU Lesser General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/

/**
   MIDIEvent.hppile MIDIEvent.hpp
   Charles Weld, David Wilson, James Brown, Jonathan Van Rossum, and Matthew Harrold
   @brief Declaration of class MIDIEvent, part of Virtual MIDI Multitrack Recorder
*/

#ifndef _MIDIEVENT_H
#define _MIDIEVENT_H

#include "MIDIMessage.hpp"

namespace MIDIToolkit
{
    //! The MIDI Event is used to pass MIDI Messages around.
    /**
     * The MIDI Event is used to pass MIDI Messages around, and also contains
     * a few addtional fields apart from the actual message, these are absolute
     * and delta time fields.
     */
    /// @ingroup midimsg
    class MIDIEvent
    {
    public:
        /**
         * Constructs a new MIDI Event with a given msg, absolute, and delta.
         * @param msg The Message that this event contains.
         * @param absolute The absolute time for the event.
         * @param delta The time difference between this event and the last event.
         */
        MIDIEvent(MIDIMessage* msg=0, int absolute=0, int delta=0);

        /**
         * Constructs a new MIDI Event from an existing MIDI Event.
         * @param evt The event to clone.
         */
        MIDIEvent(const MIDIEvent& evt);

        /**
         * Destructor.
         */
        ~MIDIEvent();

        /**
         * Prints the MIDI Event (debuging purposes).
         */
        void print(int indent);

        /**
         * Assignment opperation.
         */
        MIDIEvent& operator = (const MIDIEvent& evt);

        /**
         * Gets the Message contained in the MIDIEvent.
         * @return The MIDI Message.
         */
        MIDIMessage* getMessage();

        //! The absolute time field represents the absolute time, ie from when we started recording.
        unsigned long absolute;

        //! The delta value represents the relative time, ie the time between this message and the last message.
        unsigned long delta;
    private:
        //! The midi message.
        MIDIMessage* msg;
    };
}

#endif  //_MIDIEVENT_H
