#include "MIDIToolkitPrerequisites.hpp"
#include "VimmerPrerequisites.hpp"

using namespace Vimmer;
using namespace MIDIToolkit;

/**
  @mainpage VMM-R Developers Manual

  <img src="main.png" width="400" height="280" alt="Virtual MIDI Multitrack Recorder (VMM-R)" border="0"></img>
*/

/**
  @defgroup intro Introduction

  <p><strong>Team:</strong>
    <ul>
      <li>Charles Weld</li>
      <li>David Wilson</li>
      <li>Matthew Harrold</li>
      <li>James Brown</li>
      <li>Jonathon Van Rossum</li>
    </ul>
  </p>

  <p>

  This technical document outlines the inner workings of the
  VMM-R: Virtual MIDI Multitrack Recorder. This project represents the partial
  implementation of a software MIDI sequencer, and this document is guide to
  completing this project.

  </p>

  <p>

  To obtain the source code, an installation package, if you are interested
  in finding out more about VMM-R, or just want to learn
  how to use it, please go to <a href="http://www.sourceforge.net">http://www.sourceforge.net</a>.

  </p>

  <p>

  The bulk of this document is automatically generated from inline comments
  maintained within the source code. All contributors are encouraged to
  update this inline documentation as modifications are made to the sources.

  </p>

  <p>

  To begin reading this document, you are referred to the list of
  <a href="modules.html">Modules</a>.
  Each of these contain detailed information about a particular aspect of the program.

  </p>
*/


/**
    @defgroup license License

    VMM-R 0.2
    Virtual MIDI Multitrack Recorder
    Copyright (c) 2006 MIDI Team

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software Foundation,
    Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/

/**
    @defgroup overview Overview of VMM-R
    @brief VMM-R is a stand alone executable program running on the Windows platform.

    VMM-R (pronounced "Vimmer") is a software MIDI sequencer and recorder. It
is heavily based upon a hardware sequencer, known as the Alesis MMT-8.

VMM-R provides an affordable (free) alternative to expensive professional
MIDI sequencing equipment. It runs on an ordinary home PC, requiring only
Windows XP and a standard sound card. It is also intended to be suited to
the music professional, able to be used for live performance on stage.

For the professional, VMM-R can communicate with any device that attaches
to the MIDI port of the sound card. Such devices include synthesizers,
musical keyboards, and even other sequencers (including the original MMT-8).

The ordinary home user, on the other hand, won't have any of these
devices. However, they can still make user of VMM-R. Most modern sound
cards have their own built-in synthesizer, so they can hear the music
through their computer speakers. Instead of attaching a musical keyboard,
there are many free third-party programs available that will imitate one
using a window on the screen. Some of these are mentioned on the Tools page.


Musical Instrument Digital Interface (MIDI)

MIDI is a serial communications protocol for exchanging musical data
between devices. It has been developed since the 1980s. Each note played
is represented a pair of 3-byte "messages", detailing which note it is
and various other information.

To record music, a MIDI recorder needs to store each of these messages,
along with a timestamp of when that message was received. To play music,
the sequencer needs to send these messages back out again, at the exact
right time (typically about 5-millisecond accuracy). VMM-R is both a MIDI
sequencer and recorder.
*/

/**

    @defgroup tools Language and tools
    @ingroup overview

    @brief describes the chosen development language and tools

    The VMMR project required a series of tools that were able to produce and
exceed the original hardware design and comply with the high demands of
the timing elements a sequencer whilst enabling extensibility and
modularisation which would allow for certain elements of the program to
be replaced with more customisable detail (the GUI for instance).
*/

/**
    @defgroup cb Code::Blocks (http://www.codeblocks.org/)
    @ingroup tools


Code::Blocks is a popular open source Integrated Development Environment
(IDE). Code::Blocks
provided the tools used to write the sequencer. This IDE was chosen
because of its
extensiblility, thanks to its built in plugin architecture.

*/


/**
   @defgroup fltki FLTK (http://www.fltk.org/)
   @ingroup tools

FLTK is a C++ GUI toolkit. This was used to create several testing GUI's
as well as our final
product interface. FLTK was chosen because of the features it offers as
well as its ease of
use and small size.
*/

/**
  @defgroup doxygen Doxygen (http://www.doxygen.org/)
  @ingroup tools

Doxygen is used to create API style documentation (often in html format),
and works by parsing
the programs source and extracting comments made about different
functions. This was utilised
because of both the assistance these documents provide when writing
manuals for the sequencer,
and to ensure all developers properly comment their code.


*/

/**
  @defgroup staruml StarUML (http://www.staruml.org/)
  @ingroup tools


StarUML is a freely available, open source UML Editor. It was used to
create all our UML diagrams, and was particularly useful in the
development of the class, package, and sequence diagrams. This was chosen
for two main reasons; because it is open source, and because the team has
experience with this particular editor.

*/

/**
  @defgroup diagd Diagram Designer
  @ingroup tools

Diagram Designer is an open source vector based image editor. This was
used to create the code
structure for several prototypes. It was utilised in order to seperate
the code into
meaningful classes which would assist in the development of the sequencer.
*/

/**
  @defgroup svn TortoiseSVN
  @ingroup tools


TortoiseSVN is version control system that aids in the development of a
complex program that
has multiple programmers. It does this by saving any changes that are
made during the
development life cycle, thus allowing developers to restore a previous
version should the need
arise.
*/

/**
  @defgroup midiox MIDI-OX
  @ingroup tools


MIDI-OX is a freeware MIDI program that provides a number of features. It
was utilised here to
avoid the need to have a MIDI keyboard during the testing stage. Another
product that was used
from the MIDI-OX team is MIDI-Yoke. MIDI-Yoke is a freeware driver that
provides a number of
virtual MIDI ports. This allows the user to connect different MIDI
programs together for
testing purposes.
*/

/**
  @defgroup inkscape Inkscape (http://www.inkscape.org/)
  @ingroup tools


Inkscape is an Open Source vector graphics editor. It was used to create
prototype GUI's.
Inkscape was used because of its extensive abilities, and also because it
offers the W3C
standard Scalable Vector Graphics (SVG) file format.
*/

/**
  @defgroup mingw MinGW (http://www.mingw.org/)
  @ingroup tools


MinGW is a collection of freely available and freely distributable
Windows specific header
files and import libraries combined with GNU toolsets. This was used
because it allows the
user to produce native Windows programs that do not rely on any 3rd-party
C runtime DLLs.
*/

/**
  @defgroup pdn Paint.NET
  @ingroup tools

Paint.NET is an open source image editor. It was also used in the
creation of several
prototype interfaces. This program was used due to its ease of use and
the useful features it
provides.
*/

/**
    @defgroup structure General structure
    @ingroup overview

    VMM-R is a complicated project, and source is split into several sections
and subsections. These are summarized below, please check the relevant
pages for more detail.


<h2>BACKEND</h2>


<h3>Common</h3>

Subsystems:

	- Configuration
	- Event System
	- Exception handling
	- Logging
	- Timing
	- Other miscellaneous

Common provides useful facilities to the Core MIDI and VMM-R Sequencing
sections. Its most useful facilities relate to the distribution of
commands and events between the major sections of the program.

Common also provides a wrapper for the Win32 Timing API; handles general
errors and exceptions; and stores VMM-R configuration settings and user
preferences.


<h3>Core MIDI</h3>

Subsystems:

	- Communication
	- Device
	- Port
	- MIDI messages
	- Sequencing (low-level)

Core MIDI handles the low-level movement and storage of MIDI data. It
provides a convenient way of representing MIDI messages in C++; provides
a wrapper for the Win32 API that deals with sending to and receiving from
MIDI devices; and provides low-level facilities for storing MIDI data
onto a track, reading from it, and editing it.

Core MIDI also handles the low-level sequencing of MIDI events (ie. the
actual playing and recording), and deals with all of the timing issues
associated with it.


<h3>VMM-R Sequencing</h3>

Subsystems:

	- Base classes
	- Sequencing (high-level)
	- Storage (high-level)

VMM-R Sequencing handles the higher-level sequencing. Instead of
controlling devices and dealing with tracks and MIDI messages, it
controls the low-level MIDI sequencer itself, and deals with parts and songs.

VMM-R Sequencing also handles the high-level storage of parts and songs,
and deals with various types of files.


<h2>FRONTEND (GUI)</h2>


<h3>Basic Widgets</h3>

Basic Widgets handles the individual controls that appear on the main
window. Controls are things such as buttons, LEDs, and the main LCD
display. Basic Widgets also handles the status of each control, and the
various styles that apply to it in each case.

The classes in this section are wrappers (ie. inherit from) various other
FLTK Widgets.


<h3>Windows and Messaging</h3>

Windows and Messaging handles the main window itself, and its layout. It
also handles the communication between it and all of the widgets
(controls) that appear on it. Windows and Messaging also handles
communication with the backend (specifically, the VMM-R sequencer).


<h3>MMT-8 Replica GUI</h3>

VMM-R is a sequencer that imitates the hadrware Alesis MMT-8 sequencer.
The behaviours of the GUI that imitate the MMT-8 are controlled by this
section. A programmer who doesn't like how the MMT-8 behaves (shock,
horror) could modify or re-write this section.

*/


/**
    @defgroup flow Flow of control
    @ingroup overview
    <img src="flow_of_control.png" alt="flow of control" />

    The flow of control refers to the general layout and operation of VMM-R.
    There are five main compoents that are needed to explain the operation of
    VMM-R and these are MIDI Input, Sequencer, MIDI Output, Store, and GUI.
    The high level operation of VMM-R is is described bellow.

    -# MIDI Input receives a MIDI Event and pass it onto the Sequencer.
    -# If Sequencer is recording the inbound event is saved to the Store.
    -# The Sequencer retrieves (loads) MIDI Events from the store.
    -# If Sequencer is playing it will sends the events to MIDI Output.
    -# GUI sends commands to the Sequencer to tell it what to do.
    -# GUI is updated when it receives events from the Sequencer.
*/


/**
    @defgroup sourceforge Contributing to the project
    @ingroup overview
    @brief How to get the sources, ...
    VMMR is an open source, community based project.  This means that anyone
with a genuine interest can contribute by adding working fragments of
code to the existing structure and any useful documentation to the
SourceForge project (https://sourceforge.net/projects/vimmer).  If you
have a contribution to make or just interested in helping out, please
read on and see the different ways you can utilise and improve the VMMR
SourceForge project.

How to Contribute

Contributing to the project is fairly easy. You can add code and
documentation, review existing material and works-in-progress, or help
organize and clean up existing code and documentation. In addition, old
material should be constantly revisited to make sure it is still relevant
and accurate.

Here are more ways to help:
When you learn something about the project and would like to add to the
source code, consider writing a document describing what you've learned
or expand on the in-code comments to make it clearer. Other people will
probably have the same questions that you did.

Post your findings to the VMM-R newsgroup
(code4all@users.sourceforge.net) and get some feedback. When you're ready
to publish your additions on SourceForge ask for help getting your work
checked in � there is a submission procedure that requires authentication
by an administrator.

Check for errors in the existing project and report them or better yet,
fix them!  If you discover that there is no code or documentation to
cover something you would like to or have already added, or have observed
an outstanding problem, file a report describing the issues.

Track the newsgroups for information updates. Sometimes you might find an
explanation that should be added to an existing document. If you notice
the same questions being asked repeatedly, get them to contact the
administrators to add them to a FAQ section.  Check the list of open
source bugs and pick something interesting to help fix.


Tracking Progress

Most project work is tracked with SourcForge. Progress on the project is
tracked by SourceForge and any additions, updates or problems to code or
documentation are logged and filed automatically.  There are many levels
of access to the project, but have greater acceptance by the project team
or enable higher level access to the project you must become a developer.
Some of the ways you can assist with the development of VMM-R:


Developer

This may be seen as the most useful position in the team as developers
actually work with the VMM-R code itself.  Some of the work may include
adding, updating and editing existing code and creating specifications
for user and reference manuals that document the specifics of VMMR. This
component may also include comments in source code.


User

This is a more advisory role � basically this position would involve
users who would like to be involved and are not yet authorised as a
developer or members of the VMM-R team who have no need to access source
materials but can add valuable and important observations or assistance
to the project


Style Guide

If you are writing code or documentation for the VMM-R project, try to
follow our Style Guide. Many people read our site precisely because they
can't yet use SourceForge, so make sure your document is readable in
content and compatible.


SourceForge

SourceForge is used to manage the entire VMM-R project on a web site. To
submit changes to the project (must have developer access) you can use
SourceForge to check out the source from the SourceForge by clicking
download VMM-R.

Once you have the source code and documentation, submit the file to the
owner of the document by sending a report and asking the owner to review
(and check in the changes, too, if you don't have access).

As with the source code, if you establish a track record of good work
then you may be granted access to the repository, especially if you
contribute documents and become their official owner and maintainer.
*/


/**
    @defgroup codeblocks Setting up CodeBlocks
    @ingroup overview
    @brief Placeholder for introduction to CodeBlocks
    @todo complete CodeBlocks group documentation

    VMM-R uses Code::Blocks with GCC 3.42 as it's primary IDE. Here is a step by step set of instructions
    to install Code::Blocks and the nessisary libraries.

    -# Download Code:Blocks RC2 from ""
    -# Install Code::Blocks RC2.
    -# Download latest Nightly build from ""
    -# Extract the Nightly build files into the Code::Blocks directory (remove share directory first)
    -# Install all required libaries as described in their specific modules or download and extract
    this file into the Code::Blocks directory (contains all libraries).

    @note That you will need to configure Code::Block's compiler (under Settings->Compiler and Debugger)
    so that it knows where to find the libraries this basically involves adding the include and lib
    directories to the list of directories that CodeBlock's compiler and linker searches when it's looking
    for the header files and libaries.

    For more information about CodeBlocks please visit the Code::Blocks site/forums.
*/


/**
    \defgroup fltk Fast Light Tool Kit
    \ingroup codeblocks
    @brief Information on FLTK2
    <p>
    VMM-R uses the FLTK Fast Light Tool Kit for most graphical components. One advantage of
    this approach is that FLTK is cross platform, but the main reason for using FLTK is the
    massive reduction in complexity when interacting with a GUI at the code level. VMM-R statically links
    FLTK2 against our executable, which means we don't rely on any .dll files and can release a standalone
    executable (single .exe file).
    </p>

    <h2>Using FLTK</h2>
    <p>Firstly, obtain a copy of FLTK2, and unzip it somewhere you can remember. Then you
    need to add the appropriate pieces of information to your favourite IDE project file.
    <ol>
      <li>Add PATH_TO_FLTK2_HEADERS to list of directories that contain source files for your project.</li>
      <li>Add PATH_TO_FLTK2_LIBS to list of directories containing libraries to link your executable against.</li>
      <li>Add the following compiler flags to the options passed to your compiler from the IDE:
        <br/>
        <code>WIN32_EXTRA_LEAN -DWIN32 -W -D_MSC_DLL -fno-exceptions -g -O0 -D_DEBUG -D_WIN32</code>
      </li>
      <li>Add the following linker flags to the options passed to your linker from the IDE:
        <br/>
        <code>-lfltk2_images -lfltk2 -lfltk2_png -lfltk2_z -lwsock32 -lkernel32 -luser32 -lgdi32 -lwinspool -lcomdlg32 -ladvapi32 -lshell32 -lole32 -loleaut32 -luuid -lmsimg32</code>
      </li>
    </ol>
    </p>
*/

/**
    \defgroup bz2 BZ2
    \ingroup codeblocks
    @brief Information on BZ2.

    VMM-R uses the BZip2 library (static version) to compress the XML files. The main advantages of using
    BZip2 was that it has good documentation (compared to other free libraries), and has a good compression
    ratio.

    Using BZ2
    -# Add PATH_TO_BZ2_HEADERS to list of directories that contain source file for your project.
    -# Add PATH_TO_BZ2_LIBS to list of directories that contain the static BZ2 library for your project.
*/


/**
    @defgroup source VMM-R Factory Tour
    @brief the source code explained

    This section is designed to give a detailed explanation of the relational
aspects as well as a functional overview of the VMM-R program.  Each
section will begin with a general overview and filter into finer grained
detail within each sub-section.  The desired outcome will be to give the
reader a thorough and much greater understanding of the technical aspects
of VMM-R much like that of a factory tour.

*/

/**
    @defgroup backend The backend
    @ingroup source
    @brief Explains the engine, backend, grunt, and behind-the-scenes.
*/

/**
    @defgroup core Core classes and common facilities
    @ingroup backend
	@brief Provides a set of common services that are usefull to many programs.
*/

/**
    @defgroup config Configuration
    @ingroup core
	@brief Provides configuration management services.

	Configuration Management is the process of maintaining the configuration
	of the system persistently. There are three major services provided by
	Configuration Management to accomplish this, these services are storing the
	configuration for real-time access, saving the configuration to disk and
	loading the configuration to disk.

	@see ConfigurationManager for more details.
*/

/**
    @defgroup events Event system
    @ingroup  core
	@brief Provides event handling and generating services.

	The Event system is an implementation of the Observer/Observable
	pattern to handle generating and handling events. There are two
	component which are Observable and Observer. The Observable
	component is used to generate events. The Observer component is used
	to listen to a Observable and receive it's events.
*/

/**
    @defgroup err Exception handling
    @ingroup  core
	@brief Provides Exception generation and handling services.

	The Exception generation and handling services are provided
	by the Exception Handling Package. There are two component
	which are Exception and Exception Handler.

	The Exception compoent defines the standard Exception class
	used to throw exception. The Exception class has a unique
	ID that is used to represent the different types of exceptions
	instead of using a subclass approach.

	The Exception Handling component provides a standard way
	to handle Exceptions that can't be explicidly handled by
	the program such as unexpected exceptions.
*/

/**
    @defgroup log Logging
    @ingroup core
	@brief Provides Logging services.

	The Logging package provides a easy way to log program information
	to file for later analysis, such as debugging the program. There
	are two compoents two Logging these are the Log and LogManager.

	A Log is used to log the messages to file and has a number of capablilities such
	as supporting enabling/disabling of logs and message log levels. When the log
	is disabled the Log will ignore all messages. All Logs have a log level which
	basically means that the Log will ignore all message of a lower level such
	as Debug messages.

	The Log Manager is used to manage the individual Logs, but can also
	send a log message to the default logger. This makes it possible
	for each package of a program to have it's own log that has it's own unique
	settings for example a Log in one section could be set to output all
	log messages, while a log in another section could be set to only output
	messages of Error status or higher.
*/

/**
    @defgroup timing Timing
    @ingroup core
	@brief Provides Timing services.

    The Timing section of MIDIToolkit is there to provide Timing functionality required for
    real-time playback of MIDI data. This section consists of two main classes these are the
    Timer and Clock classes.

    The Timer class provides the ability to obtain a relative time from the last time its reset
    method was called, and also has the ability to be paused, much like a stop watch.

    The Clock class is observable, and fires off a Tick event at regular intervals. This class
    also makes use of the Timer class to provide timing functionality. This means that the class
    also inherits the ability to be paused, started, and stopped.

*/

/**
    @defgroup misc Misc utilities and classes
    @ingroup core
	@brief Misc utilities and services.

	This package provides a number of misulanious services such as common math functions,
	string functions, and bzip2 compression.

	The main notable topics here are the StringConverter and BZ2Compressor. The StringConverter
	provides a number of functions to conviently convert strings to numbers and numbers to strings.
	While the BZ2Compressor provides a number of functions that allow the user to easily compress
	a file (given by a FILE pointer).
*/

/**
    @defgroup midi Core MIDI facilities
    @ingroup backend
    @brief Provides MIDI related services to application.

    Core MIDI provides a number of MIDI services these services
    can be broken down into four sections which are MIDI Communication,
    MIDI Ports, MIDI Devices, and MIDI Messaging.
*/

/**
    @defgroup midicom MIDI Communication Classes
    @ingroup midi
    @brief Provides communication services to MIDI components.

    <p>
    The MIDI Communication classes provide communication abilities to MIDI Devices that
    allow inter device communication. The basic idea is that there are three different
    types of components these are Analyser, Generator, and Modulator.
    </p>

    <p>
    An Analyser accepts MIDI Events from Generators or Modulators and analyses them.
    A good example of an Analyser would be an OutputPort.
    </p>

    <p>
    A Generator is used to generate MIDI Events and pass them onto either a Analyser or
    Modulator for further processing. A good example of a Generator would be a InputPort.
    </p>

    <p>
    A Modulator is a combination of an Analyser and Modulator in that it can both receive
    MIDI Events from Analysers or Modulators and send MIDI Events to Analysers or Modulators. A good example
    of a Modulator would be a InputFilter, since it can both receive and send MIDI Events.
    </p>

    <p>
    These three components are used together to link together all the other components in
    the system in a safe but flexible manner. For example you can chain together multiple
    components such as an InputPort -> Through -> OutputPort.
    This simple chain actually accomplishes a lot in that it allows the user to accept incoming MIDI Events and forwards
    them on to an OutputPort if Through is enabled.
    </p>
*/

/**
    @defgroup mididev MIDI Device Classes
    @ingroup midi
    @brief Provides MIDI Device support to applications.

    <p>
    The MIDI Device classes provide MIDI Device support to applications. A MIDI Device consists of six
    components these are Device, IInputPort, InputFilter, Through,
    OutputFilter, and IOutputPort.
    </p>

    <img src="devices.png" alt="Device Layout" border="0"/>

    <p>
    The Device provides the actual services required by the users and is essentially a facade. A Device
    has five components these are the IInputPort, InputFilter, Through, OutputFilter, IOutputPort. The basic idea
    is that IInputPort receives MIDI Events from a MIDI Device such as a keyboard. These Messages are then passed
    onto the InputFilter which will only allow curtain events past. If the MIDI Event passes the Input Filter�s
    test it will be past on to Through which if enabled will pass the Event onto OutputFilter. Should the MIDI Event
    pass Output Filter�s test it will finally be passed onto OutputPort which will send the MIDI Event onto whatever
    MIDI Devices are listening to that port such as a synthesizer.
    </p>

    @note
    That a Device is also a Modulator which means that a Device will also send any MIDI Events that make it past
    the Input Filter to any connected Analyser or Modulator, and will send any received MIDI Event (say from
    a sequencer) to it's OutputFilter for dispersal.

*/

/**
    @defgroup midiport MIDI Port Classes
    @ingroup midi
    @brief Provides the ability to send and receive MIDI Events from MIDI Devices.

    The MIDI Port classes provide services that allow MIDIToolkit to send and receive MIDI Events from MIDI Devices
    such as a keyboard or synthesizer. There are two different types of ports these are IInputPort which defines
    how to receive MIDI Events and IOutputPort which defines how to send MIDI Events.

    <img src="ports.png" alt="MIDI Port class heirachy" border="0" />

    @par Input Ports
    Input Ports provides MIDIToolkit with the ability to recieve MIDI Events from an external or internal source such
    as a MIDI Keyboard. This functionality is defined in three classes these are IInputPort, InputPort, and Win32InputPort.
    Having this structure is advantageous as to add support for MacOs X create a MacOsXInputPort class that extends InputPort.

    @par Output Ports
    Output Ports provides MIDIToolkit with the ability to send MIDI Events to a external or internal MIDI device such
    as a synthesizer. This functionality is defined in three classes these are IOutputPort, OuputPort, and Win32OuputPort.
    Having this structure is advantageous as to add support for MacOs X all one needs to create a MacOsXOuputPort class
    that extends OuputPort.

*/


/**
    @defgroup midimsg MIDI Message Classes
    @ingroup midi
    @brief Provides support for different MIDI Messages.

    The MIDI Message Stack is a collection of classes that model the different MIDI Messages available.
    There are numerous ways of modeling this stack. One approach is too create two or three classes
    that model the general MIDI Message classes; For example, having one class for short messages and
    one for long messages (SYS-EX) The second approach is to have a class for every different type of MIDI
    message supported. For example Channel messages, which have many different variants such as; Note-on,
    Note-Off, and Program Change messages, there would need to be a class for each of these message types.
    This results in a massive class hierarchy that is difficult to maintain. MIDIToolkit uses a middle
    ground between these two approaches, in order to keep the class hierarchy light weight and manageable.

    In this approach we still have the two categories of messages which are Short Messages, and Long Messages (SYS-EX).
    However unlike the first approach Short Messages also have a number of child classes which provide a easier way to
    manipulate the messages.
*/


/**
    @defgroup midiseq MIDI sequencing classes
    @ingroup midi
    @brief Provides MIDI sequencing capabilities.

    MIDI Sequencing handles the low-level MIDI storage onto a track. It also handles the actual sequencing of MIDI messages (playing and recording), and deals with all the timing issues associated with this.

    MIDI Sequencing handles the low-level MIDI storage onto a track. It also
handles the actual sequencing of MIDI messages (playing and recording),
and deals with all the timing issues associated with this.

<h2>Track</h2>

Track class provides ordered storage of MIDI messages, and their
associated timing information. Track also provides various functions for
editing the individual messages, and editing all messages on the track
collectively.

<h2>MultiTrack</h2>

MultiTrack class represents the low-level aspects of a "part". It
contains a number of Tracks in parallel, and provides functions to access
these tracks. It also provides various editing functions for individual
tracks, and for the multitrack as a whole.

<h2>MultiTrackLink</h2>

MultiTrackLink class links to a particular MultiTrack, and provides
various dynamic information to the Sequencer class. The enabled \
disabled (muted) status of each track is controlled by this
MultiTrackLink, and so is the channelize setting for each track.

<h2>Sequencer</h2>

Sequencer class provides the low-level sequencing of MIDI messages. It
keeps its own internal timing (using the Clock class), and keeps track of
where it is within the multitrack (and within each track). It distributes
messages to and receives messages from the Device class.

<h2>Click Track</h2>

ClickTrack class provides support for the click (metronome). The
Sequencer class calls it every pulse, and the ClickTrack decides whether
or not to "click". The click is created by the PC speaker, not through MIDI.

    <h2>Track</h2>
    Track class provides ordered storage of MIDI messages, and their associated timing information. Track also provides various functions for editing the individual messages, and editing all messages on the track collectively.

    <h2>MultiTrack</h2>
    MultiTrack class represents the low-level aspects of a "part". It contains a number of Tracks in parallel, and provides functions to access these tracks. It also provides various editing functions for individual tracks, and for the multitrack as a whole.

    <h2>MultiTrackLink</h2>
    MultiTrackLink class links to a particular MultiTrack, and provides various dynamic information to the Sequencer class. The enabled \ disabled (muted) status of each track is controlled by this MultiTrackLink, and so is the channelize setting for each track.

    <h2>Sequencer</h2>
    Sequencer class provides the low-level sequencing of MIDI messages. It keeps its own internal timing (using the Clock class), and keeps track of where it is within the multitrack (and within each track). It distributes messages to and receives messages from the Device class.

    <h2>Click Track</h2>
    ClickTrack class provides support for the click (metronome). The Sequencer class calls it every pulse, and the ClickTrack decides whether or not to "click". The click is created by the PC speaker, not through MIDI.
*/


/**
    @defgroup seq VMM-R Sequencer
    @ingroup backend
    @brief Provides MMT-8 like functionality.
*/

/**

    @defgroup sequencer Sequencing classes
    @ingroup seq
    @brief Provides support for MMT-8 like sequencing.

    The Sequencing class of the VMM-R package provides sequencing services to the application that work in
    a manner similar to the original MMT-8 Sequencer. To accomplish this there is two sequencers a Song Sequencer
    and a Part Sequencer. The Song Sequencer is used to handle playing back of songs, while the Part Sequencer
    is used to handle the playback and recording of parts. There is also a third component that manages these
    two sequencers which is called the Sequencer Manager. Sequencer Manager's main purpose is the to route incoming
    commands such as play onto the correct sequencer depending on what mode we're in.
*/

/**
    @defgroup storage Sequencer storage
    @ingroup seq
    @brief Provides File Management and Storage functionality.
*/

/**
    @defgroup files File management
    @ingroup storage
    @brief Provides File Management functionality.

    File Management provides support for loading (importing) and saving (exporting) the
    store to external files. This can apply to individual parts, individual songs, or
    entire store. The File Management consists of "Importers" and "Exporters", each of
    which is responsible for a different format (file type).

    These formats are supported:

        - (.xml) = XML
        - (.syx) = Native MMT-8 SYSEX
        - (.mid) = Standard MIDI (formats 0, 1, 2)
*/

/**
    @defgroup store The store
    @ingroup storage
    @brief Provides Storage functionality.

    Ths Store system enables the capability to organise the storage of Parts
(including there respective tracks) and Songs (including there respective
parts) into a structure within memory.
*/














/**
    @defgroup frontend The frontend
    @ingroup source
    @brief The user interface for VMM-R

    <p>This GUI was developed with a couple of goals in mind ... firstly it had to look
    and behave in a similar manner to a hardware MMT-8 sequencer. Secondly, tired of
    maintaining counltess static callbacks, was to develop a GUI that was primarily built
    to a specification provided by data values, NOT hardcoded in proprietary calls to
    some toolkit.</p>

    <p>The frontend tour begins with the basics, the individual Widgets that make up
    the hardware panel replica.</p>
*/


/**
    \defgroup widgets Basic widgets
    \ingroup frontend
    @brief Various widget used in GUI

    Working around FLTK2 limitations required subclassing each required Widget. This opened
    an opportunity to implement variable styles, and retrofit some Plugin action.

    The basic widgets include a gui::Button, gui::Led, and gui::Lcd, the essential components
    of the hardware interface. These software versions behave in a similar
    manner to the hardware ones.

    There are also a series of classes (gui::Keyboard, gui::Key, gui::HotKey) that
    make light work of Keyboard event management (in the absence of a working FLTK2 implementation).

    The last two classes are gui::Page, and gui::Style, which encapsulate their respective concepts.
*/


/**
    \defgroup win Windows and messaging
    \ingroup frontend
    @brief The base Window class and behaviour model

    The Window class inherits from Plugin, and provides a multitude of features. A great deal of the
    interaction between the user and the gui is managed from Window, and also provides a container
    for all the Widgets, and low level event handling by way of Trigger, HotKey, ButtonKey, and trigger() method.

*/

/**
    @defgroup replica MMT-8 Replica GUI
    @ingroup frontend
    @brief Imitating the original hardware sequencer front panel.

    The main VMM-R gui window is implemented in terms of two classes: gui::Window, and gui::View.
    All the features that might be worth re-using are implemented in Window, whilst
    the application specific features of VMM-R are implemented in View. View inherits from
    Window, so you only have to deal with the View class to extend VMM-R behaviour.
*/


/**
    @defgroup todo Things to do
    @brief Completing and extending VMM-R
*/

/**
    @defgroup api API Reference
    @brief VMM-R API reference in detail
*/

