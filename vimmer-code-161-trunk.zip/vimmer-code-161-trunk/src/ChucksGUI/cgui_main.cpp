#include <iostream>

#include "Device.hpp"
#include "VimmerSequencer.hpp"
#include "XMLExporter.hpp"
#include "XMLImporter.hpp"
#include "ModernSequencer.hpp"
#include "StringCompress.hpp"
#include "cgui.hpp"
#include "Exceptions.hpp"
#include "Exception.hpp"
#include "ExceptionHandler.hpp"
#include <iostream>

using namespace std;
using namespace Vimmer;
using namespace MIDIToolkit;

#define EXCEPT2(s, d) throw Exception(s, d, __LINE__);
void func3()
{
     //EXCEPT2(0, "KILLING ME");
}

void func2()
{
    func3();
}

void func1()
{
    func2();
}

int main(int argc, char** argv)
{
    /*
    try
    {
        func1();
    }
    catch (Exception e)
    {
        cout << "source: " << e.getSource() << endl;
    }

    */
    //try
    //{
        // list output ports
        ModernSequencer* ms = new ModernSequencer(0,0);
        // load GUI

        // setup multi threading

        Fl::lock();
        VimmerUI* vimmerUI = new VimmerUI(ms);



        vimmerUI->show(argc, argv);
        ms->init();
        Fl::run();

        delete vimmerUI;
        delete ms;
    //}
    //catch (Exception e)
    //{
    //    ExceptionHandler eh;
    //    eh.handle(e);
   // }

    // cleanup log manager
    delete (LogManager::getSingleton());

	return 0;
}
