/*
    VMM-R 0.2
    Virtual MIDI Multitrack Recorder
    Copyright (c) 2006 MIDI Team

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software Foundation,
    Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/
/**
  @file led.cpp
  @brief Implementation of Led class
*/
#include "led.h"
#include <iostream>
#include <fltk/run.h>
#include <fltk/events.h>
using namespace std;

namespace gui{

Led::Led(int x,int y,int w,int h,int i):
fltk::Widget(x,y,w,h,0)
{
    vars.id=i;
    vars.use_blinker=false;
    vars.blinking=false;
    vars.blink_time_on=0.15;
    vars.blink_time_off=0.15;
    box(fltk::FLAT_BOX);
    off();
}

Led::~Led()
{
    //dtor
}

void Led::on(){
    vars.on=true;
    color(fltk::RED);
    redraw();
}

void Led::off(){
    vars.on=false;
    this->color(fltk::GRAY40);
    redraw();
    //cout << "OFF" << endl;
}

void Led::call(int command,void* arguments){
    switch(command){
        case Led::ON:
             vars.blinking=false;
             vars.use_blinker=false;
            on();
            break;

        case Led::OFF:
            vars.blinking=false;
            vars.use_blinker=false;
            off();
            break;

        case Led::STOP_BLINKING:
            vars.blinking=false;
            vars.use_blinker=false;
            break;

        case Led::BLINK_ONCE:
            // Turn on now.
            on();

            // Turn off continuous blinking.
            vars.blinking = false;
            vars.use_blinker=true;


            // fix this to include param
            add_timeout(vars.blink_time_on);
            //this->react(Events::LED_BLINK_ONCE,params);
            break;

        case Led::BLINK_CONTINUOUS:
            // Blinking continuously
            vars.blinking =true;//(bool)arguments;
            vars.use_blinker=true;
            if (vars.blinking)
            {
                // Start blinking, from the OFF state.
                off();
                add_timeout(vars.blink_time_off);
            }
            break;
    }
}

int Led::handle(int event){
    if (event==fltk::TIMEOUT)
    {
        //cout << "Timeout" << endl;
        if (vars.blinking)
        {
            // This is a CONTINUOUS blink.
            if (vars.on)
            {
                // Turn OFF LED now.
                off();
                add_timeout(vars.blink_time_off);
            }
            else
            {
                // Turn ON LED now.
                on();
                add_timeout(vars.blink_time_on);
            }
        }
        else
        {
            // This was a ONE-OFF blink. Turn the LED off now.
            if (vars.use_blinker){
                off();
                //cout << "off2" << endl;
            }
            else{
                //cout << "off1" << endl;
                return Widget::handle(event);
            }
        }

        // In case Widget class also uses this event.
        Widget::handle(event);

        // handle() must return nonzero if it used this event.
        return -1;
    }
    else
    {
        // This event has nothing to do with Blinking. Let Widget class handle it.
        return Widget::handle(event);
    }
}

} // namespace gui
