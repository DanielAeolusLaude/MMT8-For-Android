/*
    VMM-R 0.2
    Virtual MIDI Multitrack Recorder
    Copyright (c) 2006 MIDI Team

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software Foundation,
    Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/
/**
  @file view_init.cpp
  @brief Implementation of View::init method
*/
#include "view.h"

namespace gui{

void View::init(){

    Style* s=new Style(Style::OUT_OFF,1);
    s->add(Style::BG_COLOR,(void*)fltk::GRAY75);
    s->add(Style::BOX,(void*)fltk::THIN_UP_BOX);
    s->add(Style::LABEL_COLOR,(void*)fltk::BLACK);
    s->add(Style::LABEL_BOLD,(void*)false);
    call(Window::ADD_STYLE,s);

    s=new Style(Style::OUT_ON,1);
    s->add(Style::BG_COLOR,(void*)fltk::GRAY75);
    s->add(Style::BOX,(void*)fltk::THIN_DOWN_BOX);
    s->add(Style::LABEL_COLOR,(void*)fltk::BLACK);
    s->add(Style::LABEL_BOLD,(void*)false);
    call(Window::ADD_STYLE,s);

    s=new Style(Style::OVER_OFF,1);
    s->add(Style::BG_COLOR,(void*)fltk::GRAY75);
    s->add(Style::BOX,(void*)fltk::UP_BOX);
    s->add(Style::LABEL_COLOR,(void*)fltk::BLUE);
    s->add(Style::LABEL_BOLD,(void*)true);
    call(Window::ADD_STYLE,s);

    s=new Style(Style::OVER_ON,1);
    s->add(Style::BG_COLOR,(void*)fltk::GRAY75);
    s->add(Style::BOX,(void*)fltk::THIN_DOWN_BOX);
    s->add(Style::LABEL_COLOR,(void*)fltk::BLUE);
    s->add(Style::LABEL_BOLD,(void*)true);
    call(Window::ADD_STYLE,s);

    s=new Style(Style::DOWN_OFF,1);
    s->add(Style::BG_COLOR,(void*)fltk::GRAY75);
    s->add(Style::BOX,(void*)fltk::DOWN_BOX);
    s->add(Style::LABEL_COLOR,(void*)fltk::BLUE);
    s->add(Style::LABEL_BOLD,(void*)true);
    call(Window::ADD_STYLE,s);

    s=new Style(Style::DOWN_ON,1);
    s->add(Style::BG_COLOR,(void*)fltk::YELLOW);
    s->add(Style::BOX,(void*)fltk::DOWN_BOX);
    s->add(Style::LABEL_COLOR,(void*)fltk::BLUE);
    s->add(Style::LABEL_BOLD,(void*)true);
    call(Window::ADD_STYLE,s);


    Keyboard* kbd=(Keyboard*)get(WindowProperties::KEYBOARD);


    call(Window::ADD_HOTKEY,new Hotkey(fltk::F10Key,fltk::SHIFT,Window::TOGGLE_TOPMOST));
    call(Window::ADD_HOTKEY,new Hotkey(fltk::F11Key,fltk::SHIFT,Window::TOGGLE_FULLSCREEN));

    call(Window::ADD_PAGE,new Page(Pages::POWER_ON,"* VMM-R        *\n* VERSION 0.20 *"));
    pages[Pages::POWER_ON]->add("* VMM-R        *\n* By MIDI Team *");
    pages[Pages::POWER_ON]->add("Check out VMM-R \n* @SourceForge *");
    pages[Pages::POWER_ON]->add("* VMM-R        *\n* Happy Easter *");
    call(Window::ADD_PAGE,new Page(Pages::NOT_DONE_YET,"*  ...SORRY... *\n* NOT DONE YET *"));
    call(Window::ADD_PAGE,new Page(Pages::NOT_WHILE_PLAYING,"NOT WHILE PLAYING\nPLEASE STOP FIRST"));
    call(Window::ADD_PAGE,new Page(Pages::NOT_WHILE_RECORDING,"NOT WHILE RECORDING\nPLEASE STOP FIRST"));

    int lw=22;
    int lh=7;
    int i;
    int ix;

    // add the leds
    call(Window::ADD_LED,new Led(210,303,lw,lh,Leds::PART));
    call(Window::ADD_LED,new Led(210,336,lw,lh,Leds::EDIT));
    call(Window::ADD_LED,new Led(210,370,lw,lh,Leds::SONG));
    call(Window::ADD_LED,new Led(535,303,lw,lh,Leds::LOOP));
    call(Window::ADD_LED,new Led(535,336,lw,lh,Leds::ECHO));
    call(Window::ADD_LED,new Led(394,699,lw,lh,Leds::PLAY));
    call(Window::ADD_LED,new Led(553,699,lw,lh,Leds::RECORD));
    for(i=0,ix=78;i<8;i++,ix+=79){
       call(Window::ADD_LED,new Led(ix,583,lw,lh,Leds::TRACK1+i));

    }
    call(Window::ADD_LED,new Led(40,20,lw,lh,Leds::IN));
    call(Window::ADD_LED,new Led(670,20,lw,lh,Leds::OUT));

    this->button(627,40,30,20," ? ",Buttons::ABOUT,
    "Display a bit of information about VMM-R.",
    '/',Button::MOMENTARY,Pages::POWER_ON);

    this->button(34,40,30,20," IN ",Buttons::IN,
    "Provides access to available MIDI Input devices,\nfor selecting a different MIDI input",
    'i',Button::SHIFT_STICKY);

    call(Window::ADD_PAGE,new Page(Pages::IN,"MIDI IN@C0x0 \n\"%s\"",Queries::IN));

    this->button(668,40,30,20,"OUT",Buttons::OUT,
    "Provides access to available MIDI output devices,\nfor selecting a different MIDI output",
    'o',Button::SHIFT_STICKY);
    call(Window::ADD_PAGE,new Page(Pages::OUT,"MIDI OUT@C0c0 \n\"%s\"",Queries::OUT));

    this->button(68,298,34,23,"QUANT",Buttons::QUANT,
    "Quantize to adjust timing,\nalso various options affecting quantize behaviour",
    'q',Button::SHIFT_STICKY);
    call(Window::ADD_PAGE,new Page(Pages::QUANTIZE,"QUANTIZE TO@C0x0 %s@n\n%s",Queries::QUANTIZE_INTERVAL));
    pages[Pages::QUANTIZE]->add("QUANTIZE TO %s@C0c0\n%s@n",Queries::QUANTIZE_TYPE);
    call(Window::ADD_PAGE,new Page(Pages::QUANTIZED,"  QUANTIZE DONE\n"));
    call(Window::ADD_PAGE,new Page(Pages::OFFSETS,"SHIFT TRACK TIME\n@C0x0 %02d@n /384th NOTES",Queries::TRACK_OFFSET));
    this->button(68,332,34,23,"COPY",Buttons::COPY,
    "Access to VMM-R part and song copying features.\nPress Page UP/DOWN for more options",
    0,Button::SHIFT_STICKY);
    call(Window::ADD_PAGE,new Page(Pages::COPY," COPY FROM PART\n %02d TO PART %02d",Queries::COPY_TRACKS));
    call(Window::ADD_PAGE,new Page(Pages::COPIED," COPY COMPLETE\n"));

    this->button(68,366,34,23,"TRANS",Buttons::TRANS,
    "Change the pitch of notes on one or more tracks.\nAdjust desired interval and direction.",
    'r',Button::SHIFT_STICKY);
    call(Window::ADD_PAGE,new Page(Pages::TRANSPOSE," TRANSPOSE\n@C0c0 %02d@n SEMITONES",Queries::TRANSPOSE_INTERVAL));
    //pages[Pages::TRANSPOSE]->add(" TRANSPOSE DOWN\n@C0c0 %02d@n SEMITONES",Queries::TRANSPOSE_INTERVAL);
    call(Window::ADD_PAGE,new Page(Pages::TRANSPOSED,"  TRANSPOSE DONE\n"));

    this->button(68,400,34,23,"ERASE",Buttons::ERASE,
    "Erase one or more tracks, or the whole Part.\nPress Page up/down for more options",
    fltk::DeleteKey,Button::SHIFT_STICKY);
    call(Window::ADD_PAGE,new Page(Pages::ERASE," ERASE PART  %02d\n",Queries::SELECTION));
    call(Window::ADD_PAGE,new Page(Pages::ERASED," ERASE COMPLETE\n"));

    this->button(115,298,34,23,"LENGTH",Buttons::LENGTH,
    "Display and/or change the current part length.\nChange values with Keypad.",
    'k',Button::SHIFT_STICKY);

    call(Window::ADD_PAGE,new Page(Pages::LENGTH,"  PART %02d\nLENGTH@C0x0 %02d@n  BEATS",Queries::PART_LENGTH));
    call(Window::ADD_PAGE,new Page(Pages::LENGTH_CHANGED," LENGTH CHANGED\n"));

    this->button(115,332,34,23,"NAME",Buttons::NAME,
    "Rename the current part or song.\nPress this button to launch rename dialog",
    'n');

    this->button(115,366,34,23,"MERGE",Buttons::MERGE,
    "Access to VMM-R track merging features.\nPress page up/down for more options.",
    'm',Button::SHIFT_STICKY);
    call(Window::ADD_PAGE,new Page(Pages::MERGE," SELECT 2 TRACKS\n TO BE MERGED",Queries::MERGE_TRACKS));
    call(Window::ADD_PAGE,new Page(Pages::MERGED,"TRACKS MERGED TO\n HIGHEST TRACK"));

    this->button(115,400,34,23,"TAPE",Buttons::TAPE,
    "Access to VMM-R memory features.\nPress to access memory features.",
    0,Button::SHIFT_STICKY);


    call(Window::ADD_PAGE,new Page(Pages::TAPE,"SAVE ALL PARTS &\n SONGS TO@C0x0  %s",Queries::FORMAT));
    pages[Pages::TAPE]->add("SAVE %s@C0x0 %02d @n \n     TO  %s",Queries::SELECTION);
    pages[Pages::TAPE]->add("SAVE %s %02d \n     TO @C0x0 %s",Queries::FORMAT);
    pages[Pages::TAPE]->add("LOAD ALL PARTS &\nSONGS FROM@C0x0  %s",Queries::FORMAT);
    pages[Pages::TAPE]->add("LOAD %s@C0x0 %02d @n \n   FROM  %s",Queries::SELECTION);
    pages[Pages::TAPE]->add("LOAD %s %02d \n   FROM @C0x0 %s",Queries::FORMAT);

    this->button(163,298,34,23,"PART",Buttons::PART,
    "Mode button selects Part mode.\nThe other mode is Song mode.",
    'p',Button::SHIFT_STICKY);
    call(Window::ADD_PAGE,new Page(Pages::PART," SELECT PART@C0x0 %02d@n\n\"%s\"",Queries::PART_NUMBER));

    call(Window::ADD_TRIGGER,new Trigger(Buttons::PART,View::PARTMODE,NULL,true,true,fltk::LeftButton,false));

    call(Window::ADD_PAGE,new Page(Pages::PART_POSITION,"%s PART %02d\nPOSITION @C0x0 %03d@n  BEATS",Queries::PART_NUMBER));

    call(Window::ADD_PAGE,new Page(Pages::COUNTING,"%s %s %02d\nCOUNT DOWN - %02d"));

    call(Window::ADD_PAGE,new Page(Pages::SONG_POSITION,"  PLAYING SONG %02d\nPOSITION @C0x0 %03d@n  BEATS",Queries::SONG_NUMBER));

    this->button(163,332,34,23,"EDIT",Buttons::EDIT,
    "Edit the current Part or Song.\nPress page up/down for more options.",
    fltk::F10Key);

    //call(Window::ADD_TRIGGER,new Trigger(Buttons::EDIT,View::EDIT,NULL,true,true,fltk::LeftButton,false));

    this->button(163,366,34,23,"SONG",Buttons::SONG,
    "Mode button selects Song mode.\nThe other mode is Part mode.",
    's',Button::SHIFT_STICKY);
    call(Window::ADD_PAGE,new Page(Pages::SONG," SELECT SONG@C0x0 %02d@n\n\"%s\"",Queries::SONG_NUMBER));

    call(Window::ADD_TRIGGER,new Trigger(Buttons::SONG,View::SONGMODE,NULL,true,true,fltk::LeftButton,false));

    this->button(163,400,34,23,"CHAN",Buttons::CHAN,
    "Track channel assignments,\npress to change a Track MIDI channel.",
    0,Button::SHIFT_STICKY);
    call(Window::ADD_PAGE,new Page(Pages::CHANNEL,"SET MIDI CHANNEL@C0x0\n%s@n",Queries::TRACK_CHANNEL));

    this->button(573,298,34,23,"LOOP",Buttons::LOOP,
    "Toggle loop feature, \nwhich repeats the current Part forever.",
    'l',Button::MOMENTARY);


    this->button(573,332,34,23,"ECHO",Buttons::ECHO,
    "Toggle MIDI echo on/off,\n passing MIDI input to output.",
    'e',Button::MOMENTARY);

    this->button(573,366,34,23,"FILTER",Buttons::FILTER,
    "Global MIDI filter setup,\n press page up/down for more options.",
    'f',Button::SHIFT_STICKY,Pages::FILTER);
    call(Window::ADD_PAGE,new Page(Pages::FILTER,"RECORD MIDI\nNOTES:@C0x0       %s",Queries::RECORD_NOTES));
    pages[Pages::FILTER]->add("RECORD MIDI\nPITCH BEND:@C0x0  %s",Queries::RECORD_PITCHBEND);
    pages[Pages::FILTER]->add("RECORD MIDI\nAFTER TOUCH:@C0x0 %s",Queries::RECORD_AFTERTOUCH);
    pages[Pages::FILTER]->add("RECORD MIDI\nCONTROLLERS:@C0x0 %s",Queries::RECORD_CONTROLLERS);
    pages[Pages::FILTER]->add("RECORD MIDI\nPROG CHANGE:@C0x0 %s",Queries::RECORD_PROGCHANGE);
    pages[Pages::FILTER]->add("RECORD MIDI\nSYSTEM EXCL:@C0x0 %s",Queries::RECORD_SYSEX);
    pages[Pages::FILTER]->add("RECORD ON MIDI\n  CHANNEL:@C0x0   %s",Queries::RECORD_CHANNEL);

    this->button(573,400,34,23,"CLOCK",Buttons::CLOCK,
    "Options for MIDI Clock input/ouptut.\nPress page up/down for more options.",
    'v',Button::SHIFT_STICKY,Pages::CLOCK);
    call(Window::ADD_PAGE,new Page(Pages::CLOCK,"CLOCK SOURCE:@C0x0\n%s",Queries::CLOCK_SOURCE));
    pages[Pages::CLOCK]->add("MIDI CLOCK OUT\nENABLE:@C0x0 %s",Queries::CLOCK_MIDI_OUT);
    pages[Pages::CLOCK]->add("AUTO START\nENABLE:@C0x0 %s",Queries::CLOCK_AUTO_START);

    this->button(573,434,34,23,"CLICK",Buttons::CLICK,
    "Metronome control includes countdown,\n and playback/recording switches.",
    'c',Button::SHIFT_STICKY,Pages::CLICK);
    call(Window::ADD_PAGE,new Page(Pages::CLICK,"CLICK VALUE@C0x0 %s@n\nRECORD CLICK %s",Queries::CLICK_INTERVAL));
    pages[Pages::CLICK]->add("CLICK VALUE %s\nRECORD CLICK@C0x0 %s@n",Queries::CLICK_RECORD);
    pages[Pages::CLICK]->add("PLAY CLICK@C0x0 %s@n\nCOUNT DOWN: %02d",Queries::CLICK_PLAY);
    pages[Pages::CLICK]->add("PLAY CLICK %s\nCOUNT DOWN:@C0x0 %02d@n",Queries::COUNT_DOWN);

    this->button(573,468,34,23,"TEMPO",Buttons::TEMPO,
    "Adjust the sequencer tempo,\n in beats per minute.",
    't',Button::SHIFT_STICKY);

    call(Window::ADD_PAGE,new Page(Pages::TEMPO,"  TEMPO =@C0x0 %03d@n\nBEATS PER MINUTE",Queries::TEMPO));
    call(Window::ADD_PAGE,new Page(Pages::TEMPO_SAVED,"SONG TEMPO SAVED\n  "));


    this->button(64,470,60,20,"PG UP",Buttons::UP,
    "Use this button to scroll up through\nmore pages (if any).",
    fltk::PageUpKey);
    call(Window::ADD_TRIGGER,new Trigger(Buttons::UP,Window::PAGE_UP,NULL,true,true,fltk::LeftButton,false));


    this->button(135,470,60,20,"PG DOWN",Buttons::DOWN,
    "Use this button to scroll down through\nmore pages (if any).",
    fltk::PageDownKey);
    call(Window::ADD_TRIGGER,new Trigger(Buttons::DOWN,Window::PAGE_DOWN,NULL,true,true,fltk::LeftButton,false));

    this->button(450,468,29,22," + ",Buttons::PLUS,
    "Keypad \"+\" increments the current value,\nor scrolls through a list.",
    '=',Button::MOMENTARY);
    call(Window::ADD_TRIGGER,new Trigger(Buttons::PLUS,View::BUTTON_FOR_KEYPAD,NULL,true,true,fltk::LeftButton,false));
    kbd->get('=')->repeat=true;

    this->button(283,468,29,22," - ",Buttons::MINUS,
    "Keypad \"-\" decrements the current value,\nor scrolls through a list.",
    '-',Button::MOMENTARY);
    call(Window::ADD_TRIGGER,new Trigger(Buttons::MINUS,View::BUTTON_FOR_KEYPAD,NULL,true,true,fltk::LeftButton,false));
    kbd->get('-')->repeat=true;

    this->button(283,400,29,22," 1 ",Buttons::NUM1,
    "Keypad \"1\" enters the number 1,\nor selects the first choice.",
    '1',Button::MOMENTARY);
    call(Window::ADD_TRIGGER,new Trigger(Buttons::NUM1,View::BUTTON_FOR_KEYPAD,NULL,true,true,fltk::LeftButton,false));

    this->button(325,400,29,22," 2 ",Buttons::NUM2,
    "Keypad \"2\" enters the number 2,\nor selects the second choice.",
    '2',Button::MOMENTARY);
    call(Window::ADD_TRIGGER,new Trigger(Buttons::NUM2,View::BUTTON_FOR_KEYPAD,NULL,true,true,fltk::LeftButton,false));

    this->button(367,400,29,22," 3 ",Buttons::NUM3,
    "Keypad \"3\" enters the number 3,\nor selects the third choice.",
    '3',Button::MOMENTARY);
    call(Window::ADD_TRIGGER,new Trigger(Buttons::NUM3,View::BUTTON_FOR_KEYPAD,NULL,true,true,fltk::LeftButton,false));

    this->button(409,400,29,22," 4 ",Buttons::NUM4,
    "Keypad \"4\" enters the number 4,\nor selects the fourth choice.",
    '4',Button::MOMENTARY);
    call(Window::ADD_TRIGGER,new Trigger(Buttons::NUM4,View::BUTTON_FOR_KEYPAD,NULL,true,true,fltk::LeftButton,false));

    this->button(451,400,29,22," 5 ",Buttons::NUM5,
    "Keypad \"5\" enters the number 5,\nor selects the fifth choice.",
    '5',Button::MOMENTARY);
    call(Window::ADD_TRIGGER,new Trigger(Buttons::NUM5,View::BUTTON_FOR_KEYPAD,NULL,true,true,fltk::LeftButton,false));

    this->button(283,434,29,22," 6 ",Buttons::NUM6,
    "Keypad \"6\" enters the number 6,\nor selects the sixth choice.",
    '6',Button::MOMENTARY);
    call(Window::ADD_TRIGGER,new Trigger(Buttons::NUM6,View::BUTTON_FOR_KEYPAD,NULL,true,true,fltk::LeftButton,false));

    this->button(325,434,29,22," 7 ",Buttons::NUM7,
    "Keypad \"7\" enters the number 7,\nor selects the seventh choice.",
    '7',Button::MOMENTARY);
    call(Window::ADD_TRIGGER,new Trigger(Buttons::NUM7,View::BUTTON_FOR_KEYPAD,NULL,true,true,fltk::LeftButton,false));

    this->button(367,434,29,22, " 8 " ,Buttons::NUM8,
    "Keypad \"8\" enters the number 8,\nor selects the eighth choice.",
    '8',Button::MOMENTARY);
    call(Window::ADD_TRIGGER,new Trigger(Buttons::NUM8,View::BUTTON_FOR_KEYPAD,NULL,true,true,fltk::LeftButton,false));

    this->button(409,434,29,22," 9 ",Buttons::NUM9,
    "Keypad \"9\" enters the number 9,\nor selects the ninth choice.",
    '9',Button::MOMENTARY);
    call(Window::ADD_TRIGGER,new Trigger(Buttons::NUM9,View::BUTTON_FOR_KEYPAD,NULL,true,true,fltk::LeftButton,false));

    this->button(451,434,29,22," 0 ",Buttons::NUM0,
    "Keypad \"0\" enters the number 0,\nor selects the tenth choice.",
    '0',Button::MOMENTARY);
    call(Window::ADD_TRIGGER,new Trigger(Buttons::NUM0,View::BUTTON_FOR_KEYPAD,NULL,true,true,fltk::LeftButton,false));

    this->button(64,595,60,20,"TRK 1",Buttons::TRACK1,
    "Track 1: toggle to mute/unmute\nthe first track.",
    fltk::F1Key,Button::MOMENTARY);
    call(Window::ADD_TRIGGER,new Trigger(Buttons::TRACK1,View::BUTTON_FOR_TRACKS,NULL,true,true,fltk::LeftButton,false));

    this->button(142,595,60,20,"TRK 2",Buttons::TRACK2,
    "Track 2: toggle to mute/unmute\nthe second track.",
    fltk::F2Key,Button::MOMENTARY);
    call(Window::ADD_TRIGGER,new Trigger(Buttons::TRACK2,View::BUTTON_FOR_TRACKS,NULL,true,true,fltk::LeftButton,false));

    this->button(221,595,60,20,"TRK 3",Buttons::TRACK3,
    "Track 3: toggle to mute/unmute\nthe third track.",
    fltk::F3Key,Button::MOMENTARY);
    call(Window::ADD_TRIGGER,new Trigger(Buttons::TRACK3,View::BUTTON_FOR_TRACKS,NULL,true,true,fltk::LeftButton,false));

    this->button(299,595,60,20,"TRK 4",Buttons::TRACK4,
    "Track 4: toggle to mute/unmute\nthe fourth track.",
    fltk::F4Key,Button::MOMENTARY);
    call(Window::ADD_TRIGGER,new Trigger(Buttons::TRACK4,View::BUTTON_FOR_TRACKS,NULL,true,true,fltk::LeftButton,false));

    this->button(377,595,60,20,"TRK 5",Buttons::TRACK5,
    "Track 5: toggle to mute/unmute\nthe fifth track.",
    fltk::F5Key,Button::MOMENTARY);
    call(Window::ADD_TRIGGER,new Trigger(Buttons::TRACK5,View::BUTTON_FOR_TRACKS,NULL,true,true,fltk::LeftButton,false));

    this->button(454,595,60,20,"TRK 6",Buttons::TRACK6,
    "Track 6: toggle to mute/unmute\nthe sixth track.",
    fltk::F6Key,Button::MOMENTARY);
    call(Window::ADD_TRIGGER,new Trigger(Buttons::TRACK6,View::BUTTON_FOR_TRACKS,NULL,true,true,fltk::LeftButton,false));

    this->button(532,595,60,20,"TRK 7",Buttons::TRACK7,
    "Track 7: toggle to mute/unmute\nthe seventh track.",
    fltk::F7Key,Button::MOMENTARY);
    call(Window::ADD_TRIGGER,new Trigger(Buttons::TRACK7,View::BUTTON_FOR_TRACKS,NULL,true,true,fltk::LeftButton,false));

    this->button(64+78+468,595,60,20,"TRK 8",Buttons::TRACK8,
    "Track 8: toggle to mute/unmute\nthe eighth track.",
    fltk::F8Key,Button::MOMENTARY);
    call(Window::ADD_TRIGGER,new Trigger(Buttons::TRACK8,View::BUTTON_FOR_TRACKS,NULL,true,true,fltk::LeftButton,false));

    this->button(140,711,60,20,"  <<  ",Buttons::REWIND,
    "Rewind the current Part or Song\nback by one beat.",
    '[');
    call(Window::ADD_TRIGGER,new Trigger(Buttons::REWIND,View::TRANSPORT,NULL,true,true,fltk::LeftButton,false));

    kbd->get('[')->repeat=true;


    this->button(218,711,60,20,"  >>  ",Buttons::FORWARD,
    "Advance the current Part or Song\nforward by one beat.",
    ']');
    call(Window::ADD_TRIGGER,new Trigger(Buttons::FORWARD,View::TRANSPORT,NULL,true,true,fltk::LeftButton,false));

    kbd->get(']')->repeat=true;


    this->button(380,711,50,30,"PLAY",Buttons::PLAY,
    "Play the current Part or Song\from the beginning.",
    fltk::ReturnKey,Button::MOMENTARY);
    call(Window::ADD_TRIGGER,new Trigger(Buttons::PLAY,View::TRANSPORT,NULL,true,true,fltk::LeftButton,false));

    this->button(457,711,50,30,"STOP",Buttons::STOP,
    "Stop or continue the Part or Song\n from the current position.",
    fltk::SpaceKey);
    call(Window::ADD_TRIGGER,new Trigger(Buttons::STOP,View::TRANSPORT,NULL,true,true,fltk::LeftButton,false));

    this->button(539,711,50,30,"REC",Buttons::RECORD,
    "Arm MIDI input recording,\nor confirm an editing operation.",
    fltk::F12Key,Button::MOMENTARY);
    call(Window::ADD_TRIGGER,new Trigger(Buttons::RECORD,View::TRANSPORT,NULL,true,true,fltk::LeftButton,false));


}

} // namespace gui
