/*
    VMM-R 0.2
    Virtual MIDI Multitrack Recorder
    Copyright (c) 2006 MIDI Team

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software Foundation,
    Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/
/**
  @file view_get.cpp
  @brief Implementation of View::get method
*/
#include "view.h"
#include "SequencerModes.hpp"

namespace gui{


void* View::get(int property,void* arguments){
    void* r = 0;
    switch(property){

        case Queries::FORMAT:
             r=(void*)db.fileformat;
             break;


        case Queries::EDIT_BEAT:
             r=(void*)db.edit_beat;
             break;

        case Queries::EDIT_PULSE:
             r=(void*)db.edit_pulse;
             break;

        case Queries::IN:
            DBG_ECHO("View::get(IN)");
            db.midi_in=m_Sequencer->getDevice()->getInput();
            DBG_ECHO("View::get(IN) = " << db.midi_in);
             r=(void*)db.midi_in;
             break;

        case Queries::OUT:
            db.midi_out=m_Sequencer->getDevice()->getOutput();
             r=(void*)db.midi_out;
             break;

        case Queries::ECHO:
             r=(void*)m_Sequencer->getDevice()->isThruEnabled();
             break;

        case Queries::IN_NAME:
            //if(db.midi_in==-1){
            //    DBG_ECHO("No device present");
            //    sprintf(db.midi_name,"%s","No Device");
            //}
           // else{
                sprintf(db.midi_name,"%s",m_Sequencer->getDevice()->getInputName().substr(0, 16).c_str());
            //}

             r=(void*)db.midi_name;
             break;

        case Queries::OUT_NAME:
             sprintf(db.midi_name,"%s",m_Sequencer->getDevice()->getOutputName().substr(0, 16).c_str());
             r=(void*)db.midi_name;
             break;

        case Queries::MEMORY_LOAD_ERROR_PART:
             r = (void*) 666;
             break;

        case Queries::MEMORY_FREE:
             r = (void*) 50;
             break;

        case Queries::CLICK_RECORD:
            db.click_record=m_Sequencer->getSequencer()->getClickRecord();
            r = (void*) db.click_record;
            break;

        case Queries::CLICK_PLAY:
            db.click_play=m_Sequencer->getSequencer()->getClickPlay();
            r = (void*) db.click_play;
            break;

        case Queries::CLICK_INTERVAL:
            {
                int temp =m_Sequencer->getSequencer()->getClickInterval();
                db.click_interval=ClickTrack::getClickID(temp);
                //DBG_ECHO("Click interval = 1/" << temp);
                r = (void*) db.click_interval;
            }
            break;

        case Queries::COUNT_DOWN:
            db.count_down =m_Sequencer->getSequencer()->getCountin();
            r = (void*) db.count_down;
            break;

        case Queries::COUNT_BEAT:
            db.count_beat = m_Sequencer->getSequencer()->getBeat();
             r = (void*) db.count_beat;
             break;

        case Queries::CLOCK_SOURCE:
             r = (void*) db.clock_source;
             break;

        case Queries::CLOCK_MIDI_OUT:
             r = (void*) db.clock_midi_out;
             break;

        case Queries::CLOCK_AUTO_START:
             r = (void*) db.clock_auto_start;
             break;

        case Queries::LOOP:
            db.loop=m_Sequencer->getSequencer()->getLoop();
            r = (void*) db.loop;
            break;

        case Queries::MODE:
             r = (void*) db.mode_part;
             break;

        case Queries::EDIT:
             r = (void*) db.mode_edit;
             break;

        case Queries::ARMED:
            db.armed=m_Sequencer->getSequencer()->isRecordArmed();
            r = (void*) db.armed;
            break;

        case Queries::PLAYING:
            db.playing=(m_Sequencer->getSequencer()->getState()!=SequencerStates::STOPPED);
             r = (void*) db.playing;
             break;

        case Queries::POSITION:
             db.count_beat = m_Sequencer->getSequencer()->getBeat();
             r = (void*) db.position;
             break;

        case Queries::SELECTION:
             r = (void*) db.selected;
             break;

        case Queries::TRACK_ON:
             if (db.mode_part){
                 if (m_Sequencer->getSequencer()->getState()!=SequencerStates::RECORDING)
                 {
                    r = (void*) (m_Sequencer->getSequencer()->getActiveStep().getTrackState((int)arguments - 1) != SongStep::TRACK_STATE_CLEAR);
                 }
                 else
                {
                    r = (void*) (db.p_trk[(int)arguments]==false);
                }
             }
             else
                 r = (void*)(m_Sequencer->getSequencer()->getActiveStep().getTrackState((int)arguments - 1) != SongStep::TRACK_STATE_CLEAR);
             break;

        case Queries::TRACK_OFF:
             if (db.mode_part){
                 if (m_Sequencer->getSequencer()->getState()!=SequencerStates::RECORDING)
                 {
                    r = (void*) (m_Sequencer->getSequencer()->getActiveStep().getTrackState((int)arguments) == SongStep::TRACK_STATE_CLEAR);
                 }
                 else
                {
                    r = (void*) (db.p_trk[(int)arguments]==false);
                }
             }
             else{
                 r = (void*) (db.s_trk[(int)arguments]==false);
             }
             break;

        case Queries::TEMPO:
            //if (db.mode_part){
                db.p_tempo = m_Sequencer->getSequencer()->getTempo();
                r = (void*) db.p_tempo;
            //}
            //else{
            //    db.s_tempo_temporary = m_Sequencer->getSequencer()->getTempo();
            //   r = (void*) db.s_tempo_temporary;
            //}
            break;

        case Queries::PART_NUMBER:
            db.p_num = m_Sequencer->getSequencer()->getPartSequencer()->getActiveStep().getPart()->getID();
             r = (void*) db.p_num;
             break;

        case Queries::PART_LENGTH:
            if (!db.p_len_flag){
               db.p_len = m_Sequencer->getSequencer()->getPartSequencer()->getActiveStep().getPart()->getLength();
            }
            r = (void*) db.p_len;
            break;

        case Queries::PART_NAME:
             sprintf(db.p_nam ,m_Sequencer->getSequencer()->getPartSequencer()->getActiveStep().getPart()->getName().c_str());
             r = (void*) db.p_nam;
             break;

        case Queries::TRANSPOSE_INTERVAL:
             r = (void*) db.transpose_interval;
             break;

        case Queries::QUANTIZE_INTERVAL:
             r = (void*) db.quantize_interval;
             break;

        case Queries::QUANTIZE_TYPE:
             r = (void*) db.quantize_type;
             break;

        case Queries::TRACK_OFFSET:
             r = (void*) db.o_trk[policy.track];
             break;

        case Queries::TRACK_CHANNEL:
            {
                if(m_Sequencer->getSequencer()->getMode()==SequencerModes::SONG_MODE || (m_Sequencer->getSequencer()->getMode()==SequencerModes::SONG_MODE && !m_Sequencer->getSequencer()->getSongSequencer()->getSong()->isEmpty()))
                {
                    SongStep* step = &m_Sequencer->getSequencer()->getActiveStep();
                    db.ch_trk[policy.track] = step->getTrackChannel(policy.track-1);
                }
                r = (void*) db.ch_trk[policy.track];
            }
            break;

        case Queries::SONG_NUMBER:
             db.s_num = m_Sequencer->getSequencer()->getSongSequencer()->getSong()->getID();
             r = (void*) db.s_num;
             break;

        case Queries::SONG_NAME:
             sprintf(db.s_nam, m_Sequencer->getSequencer()->getSongSequencer()->getSong()->getName().c_str());
             r = (void*) db.s_nam;
             break;

        case Queries::SONG_PART:
             r = (void*) 3;
             break;

        case Queries::SONG_STEP:
             r = (void*) 6;
             break;

        case Queries::RECORD_NOTES:
             db.record_notes = m_Sequencer->getDevice()->getInputFilter()->getNoteState();
             r = (void*) db.record_notes;
             break;

        case Queries::RECORD_PITCHBEND:
             db.record_pitchbend = m_Sequencer->getDevice()->getInputFilter()->getPitchBendState();
             r = (void*) db.record_pitchbend;
             break;

        case Queries::RECORD_AFTERTOUCH:
             db.record_aftertouch = m_Sequencer->getDevice()->getInputFilter()->getAfterTouchState();
             r = (void*) db.record_aftertouch;
             break;

        case Queries::RECORD_CONTROLLERS:
             db.record_controllers = m_Sequencer->getDevice()->getInputFilter()->getControllerState();
             r = (void*) db.record_controllers;
             break;

        case Queries::RECORD_PROGCHANGE:
             db.record_progchange = m_Sequencer->getDevice()->getInputFilter()->getProgramChangeState();
             r = (void*) db.record_progchange;
             break;

        case Queries::RECORD_SYSEX:
             r = (void*) db.record_sysex;
             break;

        case Queries::RECORD_CHANNEL:
             db.record_channel = m_Sequencer->getDevice()->getInputFilter()->getChannel();
             r = (void*) db.record_channel;
             break;

        default:
            r=this->Window::get(property,arguments);
            break;
    }
    return r;

}

}// namespace gui
