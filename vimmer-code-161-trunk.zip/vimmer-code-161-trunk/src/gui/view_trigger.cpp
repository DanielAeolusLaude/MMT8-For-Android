/*
    VMM-R 0.2
    Virtual MIDI Multitrack Recorder
    Copyright (c) 2006 MIDI Team

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software Foundation,
    Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/
/**
  @file view_trigger.cpp
  @brief Implementation of View::trigger method
*/
#include "view.h"
#include <fltk/ask.h>

namespace gui{

void View::trigger(int id,bool down,bool active,int button,bool modifier){
    bool is_on=(down && active);
    bool is_off=(!down && !active);
    switch(id){


        case Buttons::IN:

            if(is_on){
                on(Window::SHOW_PAGE,(void*)Pages::IN);
                policy.property=page->variable();
            }
            else if (is_off){
                on(REFRESH_CURRENT_MODE);
            }

            break;

        case Buttons::OUT:

            if(is_on){
                on(Window::SHOW_PAGE,(void*)Pages::OUT);
                policy.property=page->variable();
            }
            else if (is_off){
                on(REFRESH_CURRENT_MODE);
            }

            break;

        case Buttons::NAME:
            if(is_on){
                int q=(db.mode_part)?Queries::PART_NAME:Queries::SONG_NAME;
                const char* t = fltk::input("New name:",(const char*)get(q));
                if (t!=0){
                    set(q,(void*)t);
                    page->refresh();
                    lcd->label(page->value());
                    lcd->highlight(false);
                    lcd->redraw();
                }
                on(Window::APPLY_STYLE,(void*)Style::OUT_OFF,Buttons::NAME);
            }
            break;

        case Buttons::TAPE:

            if(is_on){
                if (db.playing){
                    on(Window::SHOW_PAGE,(void*)Pages::NOT_WHILE_PLAYING);
                }
                else{
                    on(Window::SHOW_PAGE,(void*)Pages::TAPE);
                    policy.transport=View::TRANSPORT_ALT;
                    policy.property=page->variable();
                }

            }
            else if (is_off){
                if (db.playing){
                    on(Window::SHOW_PAGE,(void*)((db.mode_part)?Pages::PART_POSITION:Pages::SONG_POSITION));
                }
                else{
                    policy.transport=View::TRANSPORT;
                    on(REFRESH_CURRENT_MODE);
                }
            }

            break;

        case Buttons::LOOP:
            {
                if(down){
                    bool v=((bool)get(Queries::LOOP));
                    set(Queries::LOOP,(void*)!v);
                    on(((bool)get(Queries::LOOP))?Led::ON:Led::OFF,NULL,Leds::LOOP);
                }

            }
            break;

        case Buttons::ECHO:
            {
                if(down){
                    bool v=((bool)get(Queries::ECHO));
                    v=!v;
                    set(Queries::ECHO,(void*)v);
                    on((v)?Led::ON:Led::OFF,NULL,Leds::ECHO);
                }

            }
            break;

        case Buttons::CHAN:

            if (!db.mode_part) return;
            if(is_on){
                on(View::TRACKS_POLICY,NULL,View::TRACKS_SINGLE);
                on(Window::SHOW_PAGE,(void*)Pages::CHANNEL);
                policy.property=page->variable();
            }
            else if (is_off){
                on(View::PARTMODE);
            }

            break;

        case Buttons::LENGTH:

            if (!db.mode_part) return;
            if(is_on){
                if(db.playing){
                    on(Window::SHOW_PAGE,(void*)Pages::LENGTH);
                    db.p_len_flag=false;
                }
                else{
                    policy.transport=View::TRANSPORT_ALT;
                    db.p_len=(int)get(Queries::PART_LENGTH);
                    db.p_len_flag=true;
                    on(Window::SHOW_PAGE,(void*)Pages::LENGTH);
                    policy.property=page->variable();
                }
            }
            else if (is_off){
                if(db.playing){
                    db.p_len_flag=false;
                    on(Window::SHOW_PAGE,(void*)Pages::PART_POSITION);
                }
                else{
                    db.p_len_flag=false;
                    policy.transport=View::TRANSPORT;
                    on(Window::SHOW_PAGE,(void*)Pages::PART);
                }
                policy.property=page->variable();
                //on(View::PARTMODE);

            }

            break;

        case Buttons::TRANS:

            if (!db.mode_part) return;
            if(is_on){
                policy.transport=View::TRANSPORT_ALT;
                on(View::TRACKS_POLICY,NULL,View::TRACKS_MULTI);
                on(Window::SHOW_PAGE,(void*)Pages::TRANSPOSE);
                policy.property=page->variable();
            }
            else if (is_off){
                on(View::PARTMODE);
            }

            break;

        case Buttons::QUANT:

            if(db.mode_part){
                if(is_on){
                    policy.transport=View::TRANSPORT_ALT;
                    on(View::TRACKS_POLICY,NULL,View::TRACKS_MULTI);
                    on(Window::SHOW_PAGE,(void*)Pages::QUANTIZE);
                    policy.property=page->variable();
                }
                else if (is_off){
                    on(View::PARTMODE);
                }
            }
            else{
                if(is_on){
                    policy.transport=View::TRANSPORT_ALT;

                    on(View::TRACKS_POLICY,NULL,View::TRACKS_SINGLE);
                    on(Window::SHOW_PAGE,(void*)Pages::OFFSETS);
                    policy.property=page->variable();
                }
                else if (is_off){
                    on(View::SONGMODE);
                }
            }
            break;

        case Buttons::TEMPO:

            if(is_on){
                on(Window::SHOW_PAGE,(void*)Pages::TEMPO);
                policy.property=page->variable();
            }
            else if (is_off){
                if (db.playing){
                    on(Window::SHOW_PAGE,(void*)((db.mode_part)?Pages::PART_POSITION:Pages::SONG_POSITION));
                }
                else{
                    on(REFRESH_CURRENT_MODE);
                }
            }

            break;

        case Buttons::ERASE:
            {
                if (is_off){
                    on(REFRESH_CURRENT_MODE);
                    return;
                }

                if(db.mode_part){
                    policy.transport=View::TRANSPORT_ALT;
                    on(View::TRACKS_POLICY,NULL,View::TRACKS_MULTI);
                    on(Window::SHOW_PAGE,(void*)Pages::ERASE);
                    policy.property=Buttons::ERASE;
                }
                else{


                }
            }
            break;

        case Buttons::COPY:
            {
                if (is_off){
                    on(REFRESH_CURRENT_MODE);
                    return;
                }

                if(db.mode_part){
                    policy.transport=View::TRANSPORT_ALT;
                    on(View::TRACKS_POLICY,NULL,View::TRACKS_MULTI);
                    on(Window::SHOW_PAGE,(void*)Pages::COPY);
                    policy.property=page->variable();
                }
                else{


                }
            }
            break;

        case Buttons::MERGE:
            {
                if (is_off){
                    on(REFRESH_CURRENT_MODE);
                    return;
                }

                if(db.mode_part){
                    policy.transport=View::TRANSPORT_ALT;
                    on(View::TRACKS_POLICY,NULL,View::TRACKS_MULTI);
                    on(Window::SHOW_PAGE,(void*)Pages::MERGE);
                    policy.property=page->variable();
                }
                else{


                }
            }
            break;

        case Buttons::EDIT:
            if(!db.mode_part)
            {
                if (is_off) return;
                m_SongEditor.show_window();
            }
            else{
                if(is_on){
                    on(Window::SHOW_PAGE,(void*)Pages::NOT_DONE_YET);
                }
                else{
                    on(Window::SHOW_PAGE,(void*)Pages::PART);
                }
            }
            break;
    }
}

} // namespace gui
