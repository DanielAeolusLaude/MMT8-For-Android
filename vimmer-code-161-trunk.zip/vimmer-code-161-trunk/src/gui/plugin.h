/*
    VMM-R 0.2
    Virtual MIDI Multitrack Recorder
    Copyright (c) 2006 MIDI Team

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software Foundation,
    Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/
/**
  @file plugin.h
  @brief Declaration of Plugin class
*/

#ifndef VMMR_GUI_PLUGIN_H
#define VMMR_GUI_PLUGIN_H

namespace gui{

/**
  @class Plugin
  @ingroup win
  @brief An identifiable object and series of communication points
*/
class Plugin
{

  public:

    /**
      @brief construct a Plugin with given identifier and optional parent Plugin
      @param i identifier for this Plugin
      @param p optional pointer to Plugin considered the 'parent'
    */
    Plugin(int i=0,Plugin* p=0);


    virtual ~Plugin();
    virtual void call(int command,void* arguments=0)=0;
    virtual void* get(int property,void* arguments=0)=0;
    virtual void set(int property,void* value)=0;
    virtual void on(int event,void* arguments=0,int identifier=0)=0;
    inline int id(){return plugin.id;}
  protected:
    struct{
        int id;
        Plugin* parent;
    } plugin;
};

} // namespace gui
#endif // VMMR_GUI_PLUGIN_H
