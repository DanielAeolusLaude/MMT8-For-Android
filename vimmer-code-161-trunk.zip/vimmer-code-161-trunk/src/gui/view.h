/*
    VMM-R 0.2
    Virtual MIDI Multitrack Recorder
    Copyright (c) 2006 MIDI Team

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software Foundation,
    Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/
/**
  @file view.h
  @brief Declaration of View class
*/
#ifndef VMMR_GUI_VIEW_H
#define VMMR_GUI_VIEW_H

#include "shared.h"
#include "window.h"
#include "keyboard.h"
#include "style.h"
#include "file_params.h"

#include "Observer.hpp"
#include "MIDIToolkitPrerequisites.hpp"

// my stuff
#include "mattsguii.h"
#include "ModernSequencer.hpp"
#include "Song.hpp"
#include <iostream>
using namespace std;
using namespace Vimmer;
using namespace MIDIToolkit;

namespace gui{


/**
  @class View
  @ingroup replica
  @brief Main sequencer window

  The View class builds on basic Window capabilities, adding
  the specific requirements of the VMM-R interface.

  If our seperation has been factored correctly, the entire GUI
  implementation is effectively contained within the View class.

  @note There is one nasty exception, the Page::refresh() method
  contains VMM-R specific Page rendering code, which would ideally
  be passed as data in a Page constuctor.

  The intention with View (and the underlying Window design) is to provide a data
  driven GUI, without the ugly baggage of static callbacks, signals and slots, and
  all the miniscule methods usually required.
*/
class View : public Window, public Observer
{
  public:

    enum{
        BUTTON_FOR_KEYPAD=1900,   ///< Keypad button category
        BUTTON_FOR_TRACKS,        ///< Track buttons category
        KEYPAD_TIMEOUT,           ///< Event when keypad timeout is required
        KEYPAD_SEND,              ///< Signal when keypad sends a value
        TRACKS_POLICY,            ///< Signal when a different track policy is required
        TRACKS_FREE,              ///< Signal for free (direct) track selection
        TRACKS_SINGLE,            ///< Signal for single track selection (deferred)
        TRACKS_MULTI,             ///< Signal for multi track selection (deferred)
        TRACKS_RECORD,            ///< Signal for auto-track selection for recording
        TRANSPORT,                ///< Transport button category AND signal for default Transport behaviour
        TRANSPORT_ALT,            ///< Signal for alternative Transport behaviour (record=confirm)
        PARTMODE,                 ///< Signal used to switch into Part mode
        SONGMODE,                 ///< Signal used to switch into Song mode
        REFRESH_CURRENT_MODE,     ///< Signal used to refresh current mode
    };

    /**
      @brief simple utility function wraps an integer value to within given range
      @param v the input value (possibly out of range)
      @param min the minimum legal value to return
      @param max the maximum legal value to return
      @return (possibly) corrected value

      This function will 'wrap around' when out of range, unlike a clamp.
    */
    static int wrap(int v,int min,int max){
        if(v<min)v=max;
        if(v>max)v=min;
        return v;
    }

    /**
      @brief lookup method translates track number to Led identifier
      @param n track number (1 based)
      @return identifier of associated Led
    */
    static int track_2_led(int n){
        switch(n){
        case 1:return Leds::TRACK1;break;
        case 2:return Leds::TRACK2;break;
        case 3:return Leds::TRACK3;break;
        case 4:return Leds::TRACK4;break;
        case 5:return Leds::TRACK5;break;
        case 6:return Leds::TRACK6;break;
        case 7:return Leds::TRACK7;break;
        case 8:return Leds::TRACK8;break;

        }
        return 0;
    }

    /**
      @brief lookup method translates track number to Button identifier
      @param n track number (1 based)
      @return identifier of associated Button
    */
    static int track_2_button(int n){
        switch(n){
        case 1:return Buttons::TRACK1;break;
        case 2:return Buttons::TRACK2;break;
        case 3:return Buttons::TRACK3;break;
        case 4:return Buttons::TRACK4;break;
        case 5:return Buttons::TRACK5;break;
        case 6:return Buttons::TRACK6;break;
        case 7:return Buttons::TRACK7;break;
        case 8:return Buttons::TRACK8;break;

        }
        return 0;
    }

    /**
      @brief lookup method translates Button identifier to track number
      @param n Button id
      @return Track number associated with Button (1 based)
    */
    static int button_2_track(int n){
        switch(n){
        case Buttons::TRACK1: return 1;break;
        case Buttons::TRACK2: return 2;break;
        case Buttons::TRACK3: return 3;break;
        case Buttons::TRACK4: return 4;break;
        case Buttons::TRACK5: return 5;break;
        case Buttons::TRACK6: return 6;break;
        case Buttons::TRACK7: return 7;break;
        case Buttons::TRACK8: return 8;break;

        }
        return 0;
    }

    /**
      @brief callback used by fltk when keypad has waited too long for input
      @param p instance of View class that controls the keypad
    */
    static void keypad_timeout(void* p){
        View* v=(View*)p;
        v->on(View::KEYPAD_TIMEOUT);
    }


    /**
      @brief constructs a View window
      @param p WindowParams instance to pass to Window constructor
      @param mm pointer to sequencer backend View is to represent

      This constuctor initialises all variables but does not
      create the actual GUI, just the blank Window. This is done in the init() method.
    */
    View(WindowParams& p, ModernSequencer* mm);

    /**
      @brief allows proper cleanup
    */
    virtual ~View();

    /**
      @brief show the View with given size, and run the gui thread
      @param w width of window
      @param h height of Window
      @return return value passed by fltk::run()

      This method launches the gui thread, and therefore this
      method does not return until the gui is closed.
    */
    int run(int w,int h);

    /**
      @brief run a small piece of identified functionality
      @param command identifier to be interpreted as a command
      @param arguments any arguments required for command

      This method seems a little ad-hoc, but it is intended that
      most application specific functionality be 'hidden' behind
      the predefined Plugin interface methods.
    */
    virtual void call(int command,void* arguments=0);

    /**
      @brief get a small piece of identified information available to the gui
      @param property identity of data to get
      @param arguments any required arguments to query
      @return value cast to a void pointer

      The purpose of this method is to be the one-stop shop for any
      piece of information that the gui SHOULD know about. If you can't
      get it here, it shouldn't be in the View class.
    */
    virtual void* get(int property,void* arguments=0);

    /**
      @brief set or change some data value or switch available to the gui
      @param property identity of property to set
      @param value cast as a void pointer

      Method intention is to provide a single means of changing values
      available to the gui. A slightly messy issue is whether a feature
      is simply a data property or a 'call'. Most properties are changed
      directly here, but some are only changed as the result of a 'call'.

      Some other features may only change in 'response' to other events.
      These are manipulated directly in the 'on' method. An ideal design
      would only change values in THIS method.
    */
    virtual void set(int property,void* value);

    /**
      @brief react or respond to an event
      @param event identifier of event that has occurred
      @param arguments any required arguments to this even
      @param identifier specifies the source of the event (eg Button identifier)

      This is where the View reacts to the various fluid aspects
      of the program. Most View functionality is achieved in response
      to various signals created and raised within program, and caught here.

      Much of the low level gui code is neatly implemented in the Window::on() method,
      which is delegated to when functionalty doesn't require customising.

    */
    virtual void on(int event,void* arguments=0,int identifier=0);

    /**
      @brief This is the 'generic' button/hotkey method called by Window when the event is NOT used in a Trigger instance.
      @param id identifier of Button triggered
      @param down true if Button is currently down
      @param active true if Button is considered 'ON' at the moment
      @param button mouse button used to trigger event (always LEFT when a Hotkey)
      @param modifier bit mask of CONTROL, SHIFT, and ALT keys pressed during event

      Any feature that wasn't implemented as an automatic trigger is implemented here.
    */
    virtual void trigger(int id,bool down,bool active,int button,bool modifier);

    /**
      @brief This method is the backend callback, we are Observing backend events here
      @param id event identifier
      @param params any parameters passed with event

      @note this is functionally identical to the on() method, but only contains
      reactions to events coming from the backend, NOT the gui.
    */
    virtual void onEvent(int id, void* params);

    /**
      @brief add a Button instance to this View
    */
    void button(
    int x,                          ///< left position of Button
    int y,                          ///< top position of Button
    int w = Button::DEFAULT_WIDTH,  ///< width of Button
    int h = Button::DEFAULT_HEIGHT, ///< height of Button
    const char* t = 0,              ///< label for Button
    int i = 0,                      ///< identifier for this Button
    const char* tt = 0,             ///< tooltip for this Button
    unsigned int hk=0,             ///< hotkey for this Button
    int b=Button::MOMENTARY,        ///< behaviour for this Button
    int pg=0);                      ///< optional Page trigger identifier

    /**
      @brief convenience method refreshes the current page
    */
    void refresh_page();

  protected:

    /**
      @brief initialise the gui View

      Here is where all the Led, Lcd, Button, Trigger, and Style instances
      are created. In a perfect world, this method would also contain ...

      - Page rendering code represented as data instead of being hard coded in Page::refresh()
      - More flexible trigger mechanism so all the hard coded behaviour could be put here instead of in on() and call().

    */
    void init();


    struct{
        int transport;    ///< stores which transport policy to use (TRANSPORT or TRANSPORT_ALT)
        int tracks;       ///< stores which track policy to use (free,single,multi,record,...)
        int track;        ///< stores the single selected track in TRACKS_SINGLE behaviour
        int rec_track;    ///< stores the lowest empty track in TRACKS_RECORD behaviour
        bool first_pick;  ///< flag indicates whether a choice has been made in TRACKS_MULTI behaviour
        bool selected[9]; ///< stores track mutes in TRACKS_FREE behaviour
        int property;     ///< variable bound to keypad and sent when Record button pressed in TRANSPORT_ALT behaviour
    }policy; ///< stores gui behaviour variables

    struct{
        bool enabled;
        bool direct;
        int position;
        int variable;
        int value;
        int input[3];
    } keypad;

    FileParams* file;

    struct{

        bool mode_part; // false= song_mode
        bool mode_edit;


        bool armed;
        bool playing;
        bool stopped;
        int position;
        bool counting;
        bool loop;
        int selected;


        int p_num;
        char p_nam[32];
        bool p_trk[9];
        int p_len;
        bool p_len_flag;
        int p_tempo;

        int s_num;
        char s_nam[32];
        bool s_trk[9];
        int s_tempo;
        int s_tempo_temporary;

        int transpose_interval;

        int quantize_interval;
        int quantize_type;
        int o_trk[9];
        int ch_trk[9];

        int count_beat; // current count in beat (4,3,2,1)
        int count_down; // number of beats in countdown

        bool click_record;
        bool click_play;
        int click_interval;

        int clock_source;
        bool clock_midi_out;
        bool clock_auto_start;

        bool record_notes;
        bool record_pitchbend;
        bool record_aftertouch;
        bool record_controllers;
        bool record_progchange;
        bool record_sysex;
        int record_channel;

        int midi_in;
        int midi_out;
        int midi_echo;
        char midi_name[64];

        int edit_beat; // current beat for edit operations
        int edit_pulse; // current pulse for edit operations

        int fileformat;
    } db;

    private:
        ModernSequencer* m_Sequencer;
        SongEditor m_SongEditor;
};

} // namespace gui

#endif // VMMR_GUI_VIEW_H
