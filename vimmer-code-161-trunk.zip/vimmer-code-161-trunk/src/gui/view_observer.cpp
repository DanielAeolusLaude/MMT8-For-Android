/*
    VMM-R 0.2
    Virtual MIDI Multitrack Recorder
    Copyright (c) 2006 MIDI Team

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software Foundation,
    Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/
/**
  @file view_observer.cpp
  @brief Implementation of View::onEvent method
*/
#include "view.h"
#include "Events.hpp"
#include "SequencerModes.hpp"
#include "SequencerStates.hpp"
#include "StringConverter.hpp"
#include <fltk/run.h>

namespace gui{

void View::onEvent(int id, void* params)
{
    fltk::lock();
    switch (id)
    {
        case Events::SEQUENCER_ACTIVITY_MIDI_IN:
        {
            on(Led::BLINK_ONCE,NULL,Leds::IN);
            break;
        }
        case Events::SEQUENCER_ACTIVITY_MIDI_OUT:
        {
            on(Led::BLINK_ONCE,NULL,Leds::OUT);
            break;
        }
        case Events::SEQUENCER_STATE_CHANGED:
        {
            if(m_Sequencer->getSequencer()->getMode() == SequencerModes::PART_MODE)
            {
                int x=m_Sequencer->getSequencer()->getState();
                switch(x){
                    case SequencerStates::STOPPED:
                        db.playing=false;
                        //db.stopped=true;
                        db.armed=false;
                        on(Led::OFF,NULL,Leds::PLAY);
                        on(Led::OFF,NULL,Leds::RECORD);
                        on(Window::SHOW_PAGE,(void*)Pages::PART);
                        on(View::TRACKS_POLICY,NULL,View::TRACKS_FREE);
                        cout << "STOPPED!" << endl;

                    break;
                    case SequencerStates::PLAYING:
                            db.playing=true;
                            on(Led::ON,NULL,Leds::PLAY);
                            on(Led::OFF,NULL,Leds::RECORD);
                            on(View::TRACKS_POLICY,NULL,View::TRACKS_FREE);
                            cout << "PLAYING!" << endl;
                        //}

                    break;
                    case SequencerStates::RECORDING:
                        db.playing=true;
                        db.armed=true;
                        DBG_ECHO("Damn right I am really recording");
                        on(Led::ON,NULL,Leds::PLAY);
                        on(Led::ON,NULL,Leds::RECORD);
                        //on(Window::SHOW_PAGE,(void*)Pages::PART_POSITION);
                        cout << "RECORDING!" << endl;
                    break;

                }
            }
            else
            {
                int x=m_Sequencer->getSequencer()->getState();
                switch(x){
                    case SequencerStates::STOPPED:
                        db.playing=false;
                        //db.stopped=true;
                        db.armed=false;
                        on(Led::OFF,NULL,Leds::PLAY);
                        on(Led::OFF,NULL,Leds::RECORD);
                        on(Window::SHOW_PAGE,(void*)Pages::SONG);
                        on(View::TRACKS_POLICY,NULL,View::TRACKS_FREE);
                        cout << "STOPPED!" << endl;

                    break;
                    case SequencerStates::PLAYING:
                            db.playing=true;
                            on(Led::ON,NULL,Leds::PLAY);
                            on(Led::OFF,NULL,Leds::RECORD);
                            on(View::TRACKS_POLICY,NULL,View::TRACKS_FREE);
                            cout << "PLAYING!" << endl;
                    break;
                }
            }
            break;
        }
        case Events::SEQUENCER_BEAT_UPDATE:
        {
            db.position= *static_cast<int*>(params);
            db.position++;
            //int pos=(int)the.host->get(Queries::POSITION);
            if (m_Sequencer->getSequencer()->isCountin()){
                DBG_ECHO("POS: " << db.position);
                int r=db.count_down-db.position+1;
                DBG_ECHO("COUNT " << r);
                if (r==1){
                    call(Pages::COUNTING);
                }
            }
            else{
                DBG_ECHO("BEAT " << db.position);
            }
            refresh_page();
            break;
        }
        case Events::SONG_CONTENT_CHANGED:
        {
            DBG_ECHO("Song Content Changed!");
            Song* song = static_cast<Song*>(params);
            if(song == m_Sequencer->getStore()->getSongSystem()->getActive())
            {
                // update song steps
                m_SongEditor.m_SongParts->clear();

                // iterate over the steps
                SongStepIterator iter = song->getIteratorBegin();
                int activeSongStep = 0;
                int i = 0;
                while(iter!=song->getIteratorEnd())
                {
                    if(*iter == &m_Sequencer->getSequencer()->getSongSequencer()->getActiveStep())
                    {
                        activeSongStep = i;
                    }
                    m_SongEditor.m_SongParts->add((*iter)->getPart()->getName().c_str());
                    iter++;
                    i++;
                }
                // update selected
                m_SongEditor.m_SongParts->value(activeSongStep);
            }

            // length
            String len = StringConverter::intToString(m_Sequencer->getSequencer()->getSongSequencer()->getLength());
            m_SongEditor.m_SongLength->value(len.c_str());
        }
        case Events::TRACK_STATE_CHANGED:
        {
            if(m_Sequencer->getSequencer()->getMode()==SequencerModes::SONG_MODE && !m_Sequencer->getSequencer()->getSongSequencer()->getSong()->isEmpty())
            {
                for(int i=1;i<9;i++){
                    //DBG_ECHO("Track[" << i << "]=" << (m_Sequencer->getSequencer()->getActiveStep().getTrackState(i-1) != SongStep::TRACK_STATE_CLEAR));
                    on((m_Sequencer->getSequencer()->getSongSequencer()->getActiveStep().getTrackState(i-1) != SongStep::TRACK_STATE_CLEAR)?Led::ON:Led::OFF,NULL,track_2_led(i));
                }
                //DBG_ECHO("Track State Changed End");
            }
            break;
        }
        case Events::PART_CONTENT_CHANGED:
        {
            Song* song = m_Sequencer->getStore()->getSongSystem()->getActive();
            if(song == m_Sequencer->getStore()->getSongSystem()->getActive())
            {
                // update song steps
                m_SongEditor.m_SongParts->clear();

                // iterate over the steps
                SongStepIterator iter = song->getIteratorBegin();
                int activeSongStep = 0;
                int i = 0;
                while(iter!=song->getIteratorEnd())
                {
                    if(*iter == &m_Sequencer->getSequencer()->getSongSequencer()->getActiveStep())
                    {
                        activeSongStep = i;
                    }
                    m_SongEditor.m_SongParts->add((*iter)->getPart()->getName().c_str());
                    iter++;
                    i++;
                }
                // update selected
                m_SongEditor.m_SongParts->value(activeSongStep);
            }

            // length
            cout << "Length: " << m_Sequencer->getSequencer()->getSongSequencer()->getLength() << endl;
            String len = StringConverter::intToString(m_Sequencer->getSequencer()->getSongSequencer()->getLength());
            m_SongEditor.m_SongLength->value(len.c_str());
            break;
        }
        case Events::ACTIVE_SONG_CHANGED:
        {
            Song* song = m_Sequencer->getStore()->getSongSystem()->getActive();

            // update name
            m_SongEditor.m_SongName->value(song->getName().c_str());
            refresh_page();
            // update parts
        }
        case Events::SONG_NAME_CHANGED:
        {
            Song* song = static_cast<Song*>(params);
            if(song == m_Sequencer->getStore()->getSongSystem()->getActive())
            {
                // update name
                m_SongEditor.m_SongName->value(song->getName().c_str());
            }
            refresh_page();
        }
        default:
        {
        }
    }
    fltk::check();
    fltk::unlock();
}

} // namespace gui
