/*
    VMM-R 0.2
    Virtual MIDI Multitrack Recorder
    Copyright (c) 2006 MIDI Team

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software Foundation,
    Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/
/**
  @file button_key_params.h
  @brief Declaration of ButtonKeyParams class
*/
#ifndef VMMR_GUI_BUTTON_KEY_PARAMS_H
#define VMMR_GUI_BUTTON_KEY_PARAMS_H

#include "shared.h"

namespace gui{

/**
  @class ButtonKeyParams
  @ingroup widgets
  @brief A simple integer pair representing a Key and Button identifier to link together.
*/
class ButtonKeyParams{
  public:
    int button; ///< Button identifier
    int key;    ///< Key identifier

    /**
      @brief create a ButtonKeyParams instance sith supplied parameters
      @param k Key identifier
      @param b Button identifier
    */
    ButtonKeyParams(int k,int b){key=k;button=b;}
};     // class ButtonKeyParams
}      // namespace gui
#endif // VMMR_GUI_BUTTON_KEY_PARAMS_H
