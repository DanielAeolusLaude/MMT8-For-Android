/*
    VMM-R 0.2
    Virtual MIDI Multitrack Recorder
    Copyright (c) 2006 MIDI Team

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software Foundation,
    Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/
/**
  @file led.h
  @brief Declaration of Led class
*/
#ifndef VMMR_GUI_LED_H
#define VMMR_GUI_LED_H

#include "shared.h"
#include <fltk/Widget.h>

namespace gui{

/**
  @class Led
  @ingroup widgets
  @brief Represents a LED light indicator
*/
class Led : public fltk::Widget
{
  public:

    static const int DEFAULT_WIDTH = 24;      ///< default width for Led
    static const int DEFAULT_HEIGHT = 6;      ///< default height for Led

    enum{
        OFF = 1500,       ///< turn Led off - call identifier
        ON,               ///< turn Led on - call identifier
        STOP_BLINKING,    ///< stop the Led blinking - call identifier
        BLINK_ONCE,       ///< flash the Led once - call identifier
        BLINK_CONTINUOUS  ///< flash the Led continuously - call identifier
    };

    /**
      @brief create a Led widget with given dimensions and identifier
      @param x left position
      @param y top position
      @param w optional width in pixels
      @param h optional height in pixels
      @param i optional identifier for Led
    */
    Led(int x,int y,int w=DEFAULT_WIDTH,int h=DEFAULT_HEIGHT,int i=0);


    virtual ~Led(); /// keeping the compiler happy

    /**
      @brief getter for Led identifier
      @return Led identifier
    */
    inline int id(){return vars.id;}

    /**
      @brief handle a fltk::event
      @param e event identifier
      @return 0 if ignored, otherwise non-zero
    */
    int handle(int e);

    /**
      @brief make a function 'call' on this Led
      @param command identifier of 'call'
      @param arguments any optional arguments expected for this call
    */
    void call(int command,void* arguments=0);

  protected:


    void on();                ///< used internally to turn Led on
    void off();               ///< used internally to turn Led off


    struct{
        int id;               ///< identifier for this Led
        bool on;              ///< indicates current state of Led
        bool use_blinker;     ///< flag for blinking facility
        bool blinking;        ///< flag for continuous blinking
        float blink_time_on;  ///< seconds for 'on' blink
        float blink_time_off; ///< seconds for 'off' blink
    }vars;
};     // class Led
}      // namespace gui
#endif // VMMR_GUI_LED_H
