/*
    VMM-R 0.2
    Virtual MIDI Multitrack Recorder
    Copyright (c) 2006 MIDI Team

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software Foundation,
    Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/
/**
  @file page_refresh.cpp
  @brief Implementation of Page::refresh() method
*/
#include "shared.h"
#include "page.h"

namespace gui{

void Page::refresh(){
    switch(the.id){
        case Pages::IN:
            {
                sprintf(the.value,format(),(const char*)the.host->get(Queries::IN_NAME));
            }
            break;

        case Pages::OUT:
            {
                sprintf(the.value,format(),(const char*)the.host->get(Queries::OUT_NAME));
            }
            break;

        case Pages::QUANTIZE:
            {
                int qi=(int)the.host->get(Queries::QUANTIZE_INTERVAL);
                int qt=(int)the.host->get(Queries::QUANTIZE_TYPE);
                const char* qts;
                switch(qt){
                    case 0:qts="NOTE START";break;
                    case 1:qts="NOTE START & END";break;
                    case 2:qts="NOTE END";break;
                    case 3:qts="KEEP DURATION";break;
                }
                sprintf(the.value,format(),print_interval(qi),qts);
            }
            break;

        case Pages::TRANSPOSE:
            {
               sprintf(the.value,format(),
                  (int)the.host->get(Queries::TRANSPOSE_INTERVAL));

            }
            break;

        case Pages::PART:
            {
               sprintf(the.value,format(),
                  (int)the.host->get(Queries::PART_NUMBER),
                  (const char*)the.host->get(Queries::PART_NAME));

            }

            break;

        case Pages::PART_POSITION:
        {
            const char* act=((bool)the.host->get(Queries::ARMED))?"RECORDING":"  PLAYING";
            sprintf(the.value,format(),
                  act,
                  (int)the.host->get(Queries::PART_NUMBER),
                  (int)the.host->get(Queries::POSITION));
                break;
        }

        case Pages::COUNTING:
        {
            int pos=(int)the.host->get(Queries::POSITION);
            int ci=(int)the.host->get(Queries::COUNT_DOWN);
            int r=ci-pos+1;
            /*if (r==1){
                the.host->call(Pages::COUNTING,(void*)false);
                return;
            }*/
            const char* act=((bool)the.host->get(Queries::ARMED))?"RECORDING":"  PLAYING";
            bool pm = (bool)the.host->get(Queries::MODE);
            const char* md = (pm)?"PART":"SONG";
            int q=(pm)?Queries::PART_NUMBER:Queries::SONG_NUMBER;
            sprintf(the.value,format(),act,md,(int)the.host->get(q),r);

            break;
        }

        case Pages::SONG_POSITION:
        {
            sprintf(the.value,format(),
                  (int)the.host->get(Queries::SONG_NUMBER),
                  (int)the.host->get(Queries::POSITION));
                break;
        }


        case Pages::LENGTH:
            {
               sprintf(the.value,format(),
                  (int)the.host->get(Queries::PART_NUMBER),
                  (int)the.host->get(Queries::PART_LENGTH));

            }

            break;

        case Pages::SONG:
            {
               sprintf(the.value,format(),
                  (int)the.host->get(Queries::SONG_NUMBER),
                  (const char*)the.host->get(Queries::SONG_NAME));

            }

            break;

        case Pages::OFFSETS:
            {

                sprintf(the.value,format(),
                   (int)the.host->get(Queries::TRACK_OFFSET));
            }

            break;

        case Pages::COPY:
            {

                sprintf(the.value,format(),
                   (int)the.host->get(Queries::PART_NUMBER),
                   (int)the.host->get(Queries::PART_NUMBER));
            }

            break;

        case Pages::ERASE:
            {

                sprintf(the.value,format(),
                   (int)the.host->get(Queries::SELECTION));
            }

            break;

        case Pages::MERGE:
            {

                sprintf(the.value,format());
            }

            break;

        case Pages::CHANNEL:
            {
                char b[16];
                int n=(int)the.host->get(Queries::TRACK_CHANNEL);
                if(n==0){
                    sprintf(b,"  UNCHANGED");
                }
                else{
                    sprintf(b,"  CHANNEL %d",n);
                }
                sprintf(the.value,format(),b);
            }

            break;

        case Pages::FILTER:
            {
                if(the.current<6){
                    sprintf(the.value,format(),
                       ((bool)the.host->get(variable()))?"ON":"OFF");
                }
                else{
                    int n=(int)the.host->get(Queries::RECORD_CHANNEL);
                    if (n==0){
                        sprintf(the.value,format(),"ANY");
                    }
                    else{
                        char b[16];
                        sprintf(b,"%02d",n);
                        sprintf(the.value,format(),b);
                    }
                }
            }

            break;

        case Pages::CLICK:
            {
                if(the.current<2){
                    int qi=(int)the.host->get(Queries::CLICK_INTERVAL);
                    sprintf(the.value,format(),
                        print_interval(qi),
                       ((bool)the.host->get(Queries::CLICK_RECORD))?"ON":"OFF");
                }
                else{
                    sprintf(the.value,format(),
                       ((bool)the.host->get(Queries::CLICK_PLAY))?"ON":"OFF",
                       (int)the.host->get(Queries::COUNT_DOWN));
                }
            }
            break;

        case Pages::CLOCK:
            {
                int q=0;
                int v=0;
                switch(the.current){
                    case 0:q=Queries::CLOCK_SOURCE;break;
                    case 1:q=Queries::CLOCK_MIDI_OUT;break;
                    case 2:q=Queries::CLOCK_AUTO_START;break;

                }
                v=(int)the.host->get(q);
                switch(the.current){
                    case 0:
                        {
                            const char* nm;
                            switch(v){
                                case 0: nm="UNKNOWN";break;
                                case 1: nm="MIDI & INTERNAL";break;
                                case 2: nm="INTERNAL ONLY";break;
                                case 3: nm="TAPE SYNC IN";break;
                            }
                            sprintf(the.value,format(),nm);
                        }
                        break;
                    case 1:
                    case 2:
                        sprintf(the.value,format(),
                        ((bool)v)?"ON":"OFF");
                        break;

                }


            }

            break;

        case Pages::TEMPO:
            {
               sprintf(the.value,format(),
                  (int)the.host->get(Queries::TEMPO));

            }

            break;

        case Pages::TAPE:
            {
                int fmt=(int)the.host->get(Queries::FORMAT);
                int num=(int)the.host->get(Queries::SELECTION);
                const char* md = ((bool)the.host->get(Queries::MODE))?"PART":"SONG";
                switch(the.current){

                    case 0:
                    {
                        // save all
                        sprintf(the.value,format(),print_fileformat(fmt));
                        break;
                    }

                    case 1:
                    case 2:
                    {
                        // save a song or part
                        sprintf(the.value,format(),md,num,print_fileformat(fmt));
                        break;
                    }

                    case 3:
                    {
                        // load all
                        sprintf(the.value,format(),print_fileformat(fmt));
                        break;
                    }

                    case 4:
                    case 5:
                    {
                        // load a song or part
                        sprintf(the.value,format(),md,num,print_fileformat(fmt));
                        break;
                    }

                }



            }

            break;



        default:
            strcpy(the.value,the.formats[the.current]);
            break;
    }


    //sprintf(the.value,the.formats[the.current]);
}

} // namespace gui
