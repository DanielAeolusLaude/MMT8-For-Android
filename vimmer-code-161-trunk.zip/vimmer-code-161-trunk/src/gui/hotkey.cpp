/*
    VMM-R 0.2
    Virtual MIDI Multitrack Recorder
    Copyright (c) 2006 MIDI Team

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software Foundation,
    Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/
/**
  @file hotkey.cpp
  @brief Implementation of Hotkey class
*/
#include "hotkey.h"

namespace gui{

Hotkey::Hotkey(int k,int m,int c,void* a)
{
    the.key=k;
    the.modifiers=m;
    the.event=c;
    the.arguments=a;
}

Hotkey::~Hotkey()
{
    //dtor
}

bool Hotkey::test(Keyboard* kbd){
    if(kbd->is_down(the.key)){
        if (fltk::event_state(the.modifiers)){
            return true;
        }
        if(the.modifiers==0) return true;
        return false;
    }
    return false;
}

void Hotkey::fire(Plugin* p){
    p->on(the.event,the.arguments,the.key);
}
} // namespace gui
