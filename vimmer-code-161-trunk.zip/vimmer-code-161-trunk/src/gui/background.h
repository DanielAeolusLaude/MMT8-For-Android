/*
    VMM-R 0.2
    Virtual MIDI Multitrack Recorder
    Copyright (c) 2006 MIDI Team

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software Foundation,
    Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/
/**
    @file background.h
    @brief Declares class Background
*/
#ifndef VMMR_GUI_BACKGROUND_H
#define VMMR_GUI_BACKGROUND_H

#include <fltk/Widget.h>
#include <fltk/draw.h>
#include <fltk/math.h>
#include <fltk/string.h>
#include <fltk/Group.h>
using namespace fltk;

namespace gui{

/**
    @class Background
    @ingroup replica
    @brief Draws a stretchy image of the sequencer, taking custom colours into account.
*/
class Background:public fltk::Widget{
  public:

    /**
      @brief creates a Background instance with given parameters
      @param x left position
      @param y top position
      @param w width of Background
      @param h height of Background
    */
    Background(int x, int y, int width, int height):Widget(x,y,width,height,0){
        box(fltk::NO_BOX);

    }

    /**
      @brief draw the Background image when required
    */
    void draw(){
        const char* logo="VMM-R";
        const char* title="VIRTUAL MIDI MULTITRACK RECORDER";

        // under shadow
        start_shape();
        addvertex(4.2f,1.1f);
        addvertex(10.4f,1.6f);
        addvertex(89.7f,1.6f);
        addvertex(96.3f,1.1f);
        addvertex(98.9f,99.0f);
        addvertex(93.2f,99.6f);
        addvertex(6.8f,99.6f);
        addvertex(1.1f,99.0f);
        end_shape(GRAY15,GRAY40);

        // left side rail
        start_shape();
        addvertex(4.2f,1.1f);
        addvertex(9.9f,1.1f);
        addvertex(8.2f,33.0f);
        addvertex(6.8f,98.6f);
        addvertex(1.1f,98.6f);
        addvertex(2.5f,33.0f);
        addvertex(4.2f,1.1f);
        end_shape();

        start_shape();
        addvertex(4.2f,1.1f);
        addvertex(9.9f,1.1f);
        addvertex(8.2f,33.0f);
        addvertex(2.5f,33.0f);
        addvertex(4.2f,1.1f);
        end_shape(GRAY30,GRAY45);

        start_shape();
        addvertex(4.2f,1.1f);
        addvertex(9.9f,1.1f);
        addvertex(8.2f,33.0f);
        addvertex(6.8f,98.6f);
        addvertex(1.1f,98.6f);
        addvertex(2.5f,33.0f);
        addvertex(4.2f,1.1f);
        end_shape(GRAY75,GRAY10);

        // top strip
        start_shape();
        addvertex(10.4f,1.6f);
        addvertex(89.7f,1.6f);
        addvertex(89.7f,4.5f);
        addvertex(85.3f,4.5f);
        addvertex(85.3f,3.8f);
        addvertex(10.4f,3.8f);
        addvertex(10.4f,1.6f);
        end_shape(GRAY30,GRAY10);

        // top strip ridges
        int i;float f;
        for (i=0;i<35;i++){
            f=i*2.28;
            start_shape();
            addvertex(10.6f+f,1.1f);
            addvertex(11.8f+f,1.1f);
            addvertex(11.8f+f,3.3f);
            addvertex(10.6f+f,3.3f);
            addvertex(10.6f+f,1.1f);
            end_shape(GRAY25,GRAY10);
        }
        // right side rail
        start_shape();
        addvertex(90.4f,1.1f);
        addvertex(96.3f,1.1f);
        addvertex(97.5f,33.0f);
        addvertex(98.9f,98.6f);
        addvertex(93.2f,98.6f);
        addvertex(91.8f,33.0f);
        addvertex(90.4f,1.1f);
        end_shape();

        start_shape();
        addvertex(90.4f,1.1f);
        addvertex(96.3f,1.1f);
        addvertex(97.5f,33.0f);
        addvertex(91.8f,33.0f);
        addvertex(90.4f,1.1f);
        end_shape(GRAY30,GRAY45);

        start_shape();
        addvertex(90.4f,1.1f);
        addvertex(96.3f,1.1f);
        addvertex(97.5f,33.0f);
        addvertex(98.9f,98.6f);
        addvertex(93.2f,98.6f);
        addvertex(91.8f,33.0f);
        addvertex(90.4f,1.1f);
        end_shape(GRAY75,GRAY10);

        // centre top lid
        start_shape();
        addvertex(10.5f,4.3f);
        addvertex(84.6f,4.3f);
        addvertex(85.6f,33.0f);
        addvertex(65.7f,33.0f);
        addvertex(65.7f,32.0f);
        addvertex(38.5f,32.0f);
        addvertex(38.5f,33.0f);
        addvertex(9.0f,33.0f);
        addvertex(10.5f,4.3f);
        end_shape(GRAY30,GRAY10);

        // right top side of lid
        start_shape();
        addvertex(85.5f,5.0f);
        addvertex(89.8f,5.0f);
        addvertex(90.7f,33.0f);
        addvertex(86.4f,33.0f);
        addvertex(85.5f,5.0f);
        end_shape(GRAY30,GRAY10);

        // centre middle panel
        start_shape();
        addvertex(9.2f,33.6f);
        addvertex(38.5f,33.6f);
        addvertex(38.5f,36.5f);
        addvertex(65.7f,36.5f);
        addvertex(65.7f,33.6f);
        addvertex(90.8f,33.6f);
        addvertex(91.6f,65.0f);
        addvertex(8.6f,65.0f);
        addvertex(9.2f,33.6f);
        end_shape();

        // centre bottom panel
        start_shape();
        addvertex(8.5f,65.7f);
        addvertex(91.7f,65.7f);
        addvertex(92.6f,99.4f);
        addvertex(7.6f,99.4f);
        addvertex(8.5f,65.7f);
        end_shape();

        float x=w()/100.0f;
        float y=h()/100.0f;
        //float xt=1.5f;
        //float yt=1.0f;

        setfont(fltk::font("Arial Black"), x*6.5f);
        setcolor(WHITE);
        drawtext_transformed(logo,5, x*12,y*10);

        setfont(fltk::font("Arial"), x*1.5);
        drawtext(title,32, x*52,y*8);
    }

    /**
      @brief helper method starts a shape instance
    */
    void start_shape(){
        push_matrix();
        scale(w()/100.0f, h()/100.0f);
        translate(0,0);

    }

    /**
      @brief helper method ends a shape instance
    */
    void end_shape(fltk::Color bg=GRAY45,fltk::Color fg = GRAY10){
        if (bg==parent()->color()){
            setcolor(fg);
            strokepath();
        }
        else{
            setcolor(bg);
            fillstrokepath(fg);
        }

        pop_matrix();
    }
};

} // namespace UI

#endif // VMMR_GUI_BACKGROUND_H
