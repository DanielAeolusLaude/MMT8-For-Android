/*
    VMM-R 0.2
    Virtual MIDI Multitrack Recorder
    Copyright (c) 2006 MIDI Team

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software Foundation,
    Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/
/**
  @file pages.h
  @brief Declaration of Page identifiers
*/
#ifndef VMMR_GUI_PAGES_H
#define VMMR_GUI_PAGES_H

namespace gui{

/**
  @brief Identifers for Page instances
  @ingroup replica
*/
class Pages{
public:
    enum{
        POWER_ON=2500,        ///< series of pages displaying information 'about' VMM-R
        NOT_DONE_YET,         ///< page displayed when a feature is requested that isn't ready
        NOT_WHILE_PLAYING,
        NOT_WHILE_RECORDING,
        IN,                   ///< displays current MIDI input device
        OUT,                  ///< displays current MIDI output device
        QUANTIZE,             ///< displays a series of pages related to Part quantization
        QUANTIZED,            ///< indicates that a quantize operation has completed
        OFFSETS,
        TRANSPOSE,            ///< displays a series of pages related to Part transposing
        TRANSPOSED,
        COPY,                 ///< displays a series of pages related to Part duplication
        COPIED,
        ERASE,                ///< displays a series of pages related to Part erasing
        ERASED,
        MERGE,                ///< displays a series of pages related to Part merging
        MERGED,
        LENGTH,
        LENGTH_CHANGED,       ///< displays Part length
        PART,                 ///< displays the current Part number and name
        SONG,                 ///< displays the current Song number and name
        COUNTING,             ///< displays a count-in if enabled before playing
        PART_POSITION,        ///< displays the current Part number and sequencer position
        SONG_POSITION,        ///< displays the current Song number and sequencer position
        TAPE,
        CHANNEL,
        FILTER,
        CLOCK,
        CLICK,
        TEMPO,
        TEMPO_SAVED,
    };
};     // class Pages
}      // namespace gui
#endif // VMMR_GUI_PAGES_H
