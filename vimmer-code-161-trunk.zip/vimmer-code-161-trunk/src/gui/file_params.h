/*
    VMM-R 0.2
    Virtual MIDI Multitrack Recorder
    Copyright (c) 2006 MIDI Team

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software Foundation,
    Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/
/**
  @file file_params.h
  @brief Helper class describes a load/save request
*/
#ifndef VMMR_GUI_FILE_PARAMS_H
#define VMMR_GUI_FILE_PARAMS_H

namespace gui{

/**
  @brief encapsulates a file load/save request
  @ingroup win
*/
class FileParams{
  public:

    enum{
        SYX, ///<identifier for SysEx file format
        MID, ///< identifier for MIDI file format
        XML ///< identifier for native XML file format
    };

    enum{
        LOAD,///< identifier for load request
        SAVE ///< identifier for save request
    };

    struct{
        const char* filename; ///< stores filename
        int format;  ///< stores file format
        int action;  ///< stores action
    }the;

    /**
      @brief constructor for FileParams
      @param fn filename to load/save
      @param f format of file
      @param a action (load or save)
    */
    FileParams(const char* fn=0,int f=XML,int a=LOAD){
        filename(fn);
        format(f);
        action(a);
    }

    /**
      @brief set the filename
      @param f const pointer to filename
    */
    inline void filename(const char* f){the.filename=f;}

    /**
      @brief set the file format
      @param f one of SYX, MID, or XML
    */
    inline void format(int f){the.format=f;}

    /**
      @brief set the requested action
      @param a either LOAD or SAVE
    */
    inline void action(int a){the.action=a;}

    /**
      @brief get the filename
      @return const pointer to c string
    */
    inline const char* filename(){return the.filename;}

    /**
      @brief get the file format
      @return either SYX, MID, or XML
    */
    inline int format(){return the.format;}

    /**
      @brief get the requested action
      @return either LOAD or SAVE
    */
    inline int action(){return the.action;}
};     // class FileParams
}      // namespace gui
#endif // VMMR_GUI_FILE_PARAMS_H
