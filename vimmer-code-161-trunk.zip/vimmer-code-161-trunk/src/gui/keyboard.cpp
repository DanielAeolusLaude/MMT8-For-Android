/*
    VMM-R 0.2
    Virtual MIDI Multitrack Recorder
    Copyright (c) 2006 MIDI Team

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software Foundation,
    Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/
/**
  @file keyboard.cpp
  @brief Implementation of Keyboard class
*/

#include "keyboard.h"
#include <cstdlib>

namespace gui{

Keyboard::Keyboard(Plugin* p,int type){
    bool r=true;
    host=p;
    switch(type){

        case STANDARD_NO_REPEAT:
            r=false;
        case STANDARD:
            {
                add(fltk::AddKey,r,true,true);
                add(fltk::BackSpaceKey,r,true,true);
                add(fltk::CapsLockKey,r,true,true);
                add(fltk::ClearKey,r,true,true);
                add(fltk::DecimalKey,r,true,true);
                add(fltk::DeleteKey,r,true,true);
                add(fltk::DivideKey,r,true,true);
                add(fltk::DownKey,r,true,true);
                add(fltk::EndKey,r,true,true);
                add(fltk::EscapeKey,r,true,true);
                add(fltk::F0Key,r,true,true);
                add(fltk::F1Key,r,true,true);
                add(fltk::F2Key,r,true,true);
                add(fltk::F3Key,r,true,true);
                add(fltk::F4Key,r,true,true);
                add(fltk::F5Key,r,true,true);
                add(fltk::F6Key,r,true,true);
                add(fltk::F7Key,r,true,true);
                add(fltk::F8Key,r,true,true);
                add(fltk::F9Key,r,true,true);
                add(fltk::F10Key,r,true,true);
                add(fltk::F11Key,r,true,true);
                add(fltk::F12Key,r,true,true);
                add(fltk::HelpKey,r,true,true);
                add(fltk::HomeKey,r,true,true);
                add(fltk::InsertKey,r,true,true);
                add(fltk::Keypad,r,true,true);
                add(fltk::Keypad0,r,true,true);
                add(fltk::Keypad1,r,true,true);
                add(fltk::Keypad2,r,true,true);
                add(fltk::Keypad3,r,true,true);
                add(fltk::Keypad4,r,true,true);
                add(fltk::Keypad5,r,true,true);
                add(fltk::Keypad6,r,true,true);
                add(fltk::Keypad7,r,true,true);
                add(fltk::Keypad8,r,true,true);
                add(fltk::Keypad9,r,true,true);
                add(fltk::KeypadEnter,r,true,true);
                add(fltk::LeftAccKey,r,true,true);
                add(fltk::LeftAltKey,r,true,true);
                add(fltk::LeftCmdKey,r,true,true);
                add(fltk::LeftCtrlKey,r,true,true);
                add(fltk::LeftKey,r,true,true);
                add(fltk::LeftMetaKey,r,true,true);
                add(fltk::LeftShiftKey,r,true,true);
                add(fltk::MenuKey,r,true,true);
                add(fltk::MultiplyKey,r,true,true);
                add(fltk::NumLockKey,r,true,true);
                add(fltk::PageDownKey,r,true,true);
                add(fltk::PageUpKey,r,true,true);
                add(fltk::PauseKey,r,true,true);
                add(fltk::PrintKey,r,true,true);
                add(fltk::ReturnKey,r,true,true);
                add(fltk::RightAccKey,r,true,true);
                add(fltk::RightAltKey,r,true,true);
                add(fltk::RightCmdKey,r,true,true);
                add(fltk::RightCtrlKey,r,true,true);
                add(fltk::RightKey,r,true,true);
                add(fltk::RightMetaKey,r,true,true);
                add(fltk::RightShiftKey,r,true,true);
                add(fltk::ScrollLockKey,r,true,true);
                add(fltk::SpaceKey,r,true,true);
                add(fltk::SubtractKey,r,true,true);
                add(fltk::TabKey,r,true,true);
                add(fltk::UpKey,r,true,true);
                add('1',r,true,true);
                add('2',r,true,true);
                add('3',r,true,true);
                add('4',r,true,true);
                add('5',r,true,true);
                add('6',r,true,true);
                add('7',r,true,true);
                add('8',r,true,true);
                add('9',r,true,true);
                add('0',r,true,true);
                add('-',r,true,true);
                add('=',r,true,true);
                add('q',r,true,true);
                add('w',r,true,true);
                add('e',r,true,true);
                add('r',r,true,true);
                add('t',r,true,true);
                add('y',r,true,true);
                add('u',r,true,true);
                add('i',r,true,true);
                add('o',r,true,true);
                add('p',r,true,true);
                add('[',r,true,true);
                add(']',r,true,true);
                add('\\',r,true,true);
                add('a',r,true,true);
                add('s',r,true,true);
                add('d',r,true,true);
                add('f',r,true,true);
                add('g',r,true,true);
                add('h',r,true,true);
                add('j',r,true,true);
                add('k',r,true,true);
                add('l',r,true,true);
                add(';',r,true,true);
                add('\'',r,true,true);
                add('z',r,true,true);
                add('x',r,true,true);
                add('c',r,true,true);
                add('v',r,true,true);
                add('b',r,true,true);
                add('n',r,true,true);
                add('m',r,true,true);
                add(',',r,true,true);
                add('.',r,true,true);
                add('/',r,true,true);
                add('`',r,true,true);
            }
            break;

        default:

            break;
    }
}
void Keyboard::add(int k,bool repeat,bool down_event,bool up_event){
    Key* ki=new Key(k,repeat,down_event,up_event);
    keys.insert(std::make_pair(k,ki));
}

Key* Keyboard::get(int k){
    if(keys.find(k)==0) return NULL;
    return keys[k];
}

void Keyboard::remove(int k){
    keys.erase(keys.find(k));
}

bool Keyboard::is_down(int k){
    if(keys.find(k)==0) return false;
    Key* ki = keys[k];
    if (ki==0) return false;
    return (ki->down>0);
}

void Keyboard::on_down(int k){
    if(keys.find(k)==0) return;
    Key* ki = keys[k];
    if (ki==0) return;
    if(ki->repeat){
        ki->down++;
        if(ki->down_event) host->on(Key::DOWN,(void*)fltk::LeftButton,k);
    }
    else{
        if (ki->down==0){
            ki->down++;
            if(ki->down_event) host->on(Key::DOWN,(void*)fltk::LeftButton,k);
        }
    }
}

void Keyboard::on_up(int k){
    if(keys.find(k)==0) return;
    Key* ki = keys[k];
    if (ki==0) return;
    ki->down=0;
    if(ki->up_event) host->on(Key::UP,(void*)fltk::LeftButton,k);
}

Keyboard::~Keyboard()
{
    // should we delete the keys? will they leak memory?
}

} // namespace gui
