/*
    VMM-R 0.2
    Virtual MIDI Multitrack Recorder
    Copyright (c) 2006 MIDI Team

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software Foundation,
    Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/
/**
  @file window_properties.h
  @brief Declaration of Property identifiers for a Window
*/
namespace gui{

/**
  @brief declares various property identifiers used within a Window
  @ingroup win
*/
class WindowProperties{
  public:
    enum{

        /// left position of Window
        LEFT_PIXELS,
        /// top position of Window
        TOP_PIXELS,
        /// width of Window
        WIDTH_PIXELS,
        /// height of Window
        HEIGHT_PIXELS,
        /// title of Window
        TITLE_TEXT,
        /// tooltip for Window
        TOOLTIP_TEXT,
        /// Window small icon
        SMALL_ICON,
        /// Window large icon
        LARGE_ICON,
        /// Window background image path
        IMAGE_PATH,
        /// Window xbm image used to modify Window shape
        SHAPE_BITS,
        /// Window flag indicates that it allows user resizing
        RESIZABLE_FLAG,
        /// Window flag indicates that it is currently in fullscreen display mode
        FULLSCREEN_FLAG,
        /// Window flag indicates that it is currently a top-most Window (always on top)
        TOPMOST_FLAG,
        /// Window flag indicates that the background image (if any) should be tiled
        IMAGE_TILE_FLAG,
        /// current state of Window
        WINDOW_STATE,
        /// The Keyboard instance (and bahaviour) associated with this Window
        KEYBOARD
    };
}; // class WindowProperties

} // namespace gui
