/*
    VMM-R 0.2
    Virtual MIDI Multitrack Recorder
    Copyright (c) 2006 MIDI Team

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software Foundation,
    Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/
/**
  @file lcd.h
  @brief Declaration of Lcd class
*/
#ifndef VMMR_GUI_LCD_H
#define VMMR_GUI_LCD_H

#include "shared.h"
#include <fltk/Widget.h>

namespace gui{

/**
  @class Lcd
  @ingroup widgets
  @brief Represents a very basic LCD text display
*/
class Lcd : public fltk::Widget
{
  public:


    /**
      @brief create a Lcd widget with given dimensions and identifier
      @param x left position
      @param y top position
      @param w width in pixels
      @param h height in pixels
      @param m mask indicating minimum desired length of a text line
    */
    Lcd(int x,int y,int w,int h,const char* m);

    virtual ~Lcd(); ///< keeping the compiler happy

    void layout();   ///< used to resize font when size changes

    /**
      @brief visually indicate a highlight
      @param v determines whether to highlight or not
    */
    void highlight(bool v){
        color((v)?fltk::color(0xFF,0xEE,0x88):fltk::color(0xFF,0xCC,0x66));
        redraw();
    }

  protected:

    struct{
        const char* mask; ///< indicates minimum desired length of a text line
    }the; ///< internal storage for Lcd variables
  private:
};     // class Lcd
}      // namespace gui
#endif // VMMR_GUI_LCD_H
