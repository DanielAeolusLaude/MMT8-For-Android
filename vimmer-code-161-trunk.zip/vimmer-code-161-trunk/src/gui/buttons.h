/*
    VMM-R 0.2
    Virtual MIDI Multitrack Recorder
    Copyright (c) 2006 MIDI Team

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software Foundation,
    Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/
/**
  @file buttons.h
  @brief Declaration of Button identifiers
*/
#ifndef VMMR_GUI_BUTTONS_H
#define VMMR_GUI_BUTTONS_H

namespace gui{

/**
  @brief Contains identifiers for all gui Button instances
  @ingroup replica
*/
class Buttons{
  public:
    enum{
        QUANT=2000, ///< Quantize button (Operation)
        COPY,       ///< Copy button (Operation)
        TRANS,      ///< Transpose button (Operation)
        ERASE,      ///< Erase button (Operation)
        LENGTH,     ///< Length button (Operation)
        NAME,       ///< Name button (Operation)
        MERGE,      ///< Merge button (Operation)
        TAPE,       ///< Tape button (Operation)
        PART,       ///< Part mode button
        EDIT,       ///< Edit mode button
        SONG,       ///< Song mode button
        CHAN,       ///< Channel button (Operation)
        LOOP,       ///< Loop button (toggle)
        ECHO,       ///< Echo button (toggle)
        FILTER,     ///< Filter button (operation)
        CLOCK,      ///< MIDI Clock button
        CLICK,      ///< Click (metronome) button
        TEMPO,      ///< Tempo button
        UP,         ///< Page up button
        DOWN,       ///< Page down button
        PLUS,       ///< Keypad plus (increment) button
        MINUS,      ///< Keypad minus (decrement) button
        NUM1,       ///< Keypad number 1 button
        NUM2,       ///< Keypad number 2 button
        NUM3,       ///< Keypad number 3 button
        NUM4,       ///< Keypad number 4 button
        NUM5,       ///< Keypad number 5 button
        NUM6,       ///< Keypad number 6 button
        NUM7,       ///< Keypad number 7 button
        NUM8,       ///< Keypad number 8 button
        NUM9,       ///< Keypad number 9 button
        NUM0,       ///< Keypad number 0 button
        TRACK1,     ///< Track 1 button
        TRACK2,     ///< Track 2 button
        TRACK3,     ///< Track 3 button
        TRACK4,     ///< Track 4 button
        TRACK5,     ///< Track 5 button
        TRACK6,     ///< Track 6 button
        TRACK7,     ///< Track 7 button
        TRACK8,     ///< Track 8 button
        REWIND,     ///< Transport rewind button
        FORWARD,    ///< Transport forward button
        PLAY,       ///< Transport play button
        STOP,       ///< Transport stop/continue button
        RECORD,     ///< Transport record button
        IN,         ///< MIDI Input device button
        OUT,        ///< MIDI Output device button
        ABOUT       ///< Aboutbox button
    };
};     // class Buttons
}      // namespace gui
#endif // VMMR_GUI_BUTTONS_H
