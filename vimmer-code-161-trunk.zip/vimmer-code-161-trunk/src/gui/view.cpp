/*
    VMM-R 0.2
    Virtual MIDI Multitrack Recorder
    Copyright (c) 2006 MIDI Team

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software Foundation,
    Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/
/**
  @file view.cpp
  @brief Implementation of View class
*/
#include "view.h"
#include <fltk/run.h>
#include <sstream>
#include "Part.hpp"
#include "StringConverter.hpp"
#include "SongStep.hpp"
#include "Events.hpp"
#include "SequencerModes.hpp"
#include "SequencerStates.hpp"
using namespace std;

namespace gui{

View::View(WindowParams& p, ModernSequencer* mm):Window(p), m_SongEditor(mm)
{
    this->disableObserver();

    m_Sequencer = mm;
    m_Sequencer->addObserver(this);

    keypad.direct=false;
    keypad.enabled=true;
    keypad.position=2;
    keypad.variable=0;
    keypad.input[0]=0;
    keypad.input[1]=0;
    keypad.input[2]=0;

    policy.transport=View::TRANSPORT;
    policy.tracks=View::TRACKS_FREE;
    policy.track=1;
    policy.rec_track=1;
    policy.first_pick=true;
    policy.property=0;

    file = new FileParams(0,FileParams::XML,FileParams::LOAD);

    db.armed=false;
    db.playing=false;
    db.position=0;
    db.selected=0;
    db.stopped=true;

    db.fileformat=0;
    db.mode_part=true;
    db.mode_edit=false;

    db.p_num=0;
    db.p_len=0;
    db.p_len_flag=false;
    db.p_tempo=120;
    sprintf(db.p_nam,"SAMPLE PART %02d",db.p_num);


    db.p_trk[1]=true;
    db.p_trk[2]=true;
    db.p_trk[3]=true;
    db.p_trk[4]=true;
    db.p_trk[5]=false;
    db.p_trk[6]=false;
    db.p_trk[7]=false;
    db.p_trk[8]=true;

    db.s_num=0;
    db.s_tempo=120;
    db.s_tempo_temporary=120;
    db.s_trk[1]=true;
    db.s_trk[2]=false;
    db.s_trk[3]=false;
    db.s_trk[4]=false;
    db.s_trk[5]=false;
    db.s_trk[6]=false;
    db.s_trk[7]=false;
    db.s_trk[8]=true;
    sprintf(db.s_nam,"SAMPLE SONG %02d",db.s_num);

    db.ch_trk[1]=0;
    db.ch_trk[2]=0;
    db.ch_trk[3]=0;
    db.ch_trk[4]=0;
    db.ch_trk[5]=0;
    db.ch_trk[6]=0;
    db.ch_trk[7]=0;
    db.ch_trk[8]=0;

    db.loop = (bool)get(Queries::LOOP);
    db.count_beat = 2;
    db.count_down=4;

    db.click_record=true;
    db.click_play=true;
    db.click_interval=1;

    db.clock_source=1;
    db.clock_midi_out=false;
    db.clock_auto_start=true;

    db.record_notes=true;
    db.record_pitchbend=true;
    db.record_aftertouch=false;
    db.record_controllers=true;
    db.record_progchange=true;
    db.record_sysex=false;
    db.record_channel=4;

    db.midi_in  = 0;
    db.midi_out = 0;
    db.midi_echo=(bool)get(Queries::ECHO);

    db.transpose_interval=0;
    db.quantize_interval=0;
    db.quantize_type=0;

    page = 0;

}

int View::run(int w,int h){
    init();
    resize(w,h);
    show();
    on(Window::SHOW_PAGE,(void*)Pages::POWER_ON);
    on((db.loop)?Led::ON:Led::OFF,NULL,Leds::LOOP);
    on((db.midi_echo)?Led::ON:Led::OFF,NULL,Leds::ECHO);
    on(View::PARTMODE);
    for(int i =1;i<9;i++){
        set(Queries::TRACK_ON,(void*)i);
        on(Led::ON,NULL,track_2_led(i));
    }
    set(Queries::CLICK_PLAY, (void*)db.click_play);
    set(Queries::CLICK_RECORD, (void*)db.click_record);
    this->enableObserver();
	return fltk::run();
}

View::~View()
{
    //dtor
}

void View::refresh_page(){
    page->refresh();
    lcd->label(page->value());
    lcd->redraw();
}

void View::button(int x,int y,int w,int h,const char* t,int i,const char* tt,unsigned int hk,int b,int pg){
    call(Window::ADD_BUTTON,new ButtonParams(i,x,y,w,h,t,b,tt));
    if(hk>0) call(Window::ADD_BUTTONKEY,new ButtonKeyParams(hk,i));
    if (!pg==0){
        call(Window::ADD_TRIGGER,new Trigger(i,Window::SHOW_PAGE,(void*)pg,true,true,fltk::LeftButton,false));
        call(Window::ADD_TRIGGER,new Trigger(i,Window::PAGE_BACK,NULL,false,false,fltk::LeftButton,false));
    }
}

} // namespace gui
