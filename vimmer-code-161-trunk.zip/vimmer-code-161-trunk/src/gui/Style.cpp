/*
    VMM-R 0.2
    Virtual MIDI Multitrack Recorder
    Copyright (c) 2006 MIDI Team

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software Foundation,
    Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/
/**
  @file style.cpp
  @brief Implementation of Style class
*/

#include "style.h"
#include <fltk/SharedImage.h>

namespace gui{

Style::Style(int id,int context)
{
    the.id=id;
    the.context=context;
}

Style::~Style()
{
    //dtor
}

void Style::add(int item,void* value){
    the.items.insert(std::make_pair(item,value));
}


void Style::remove(int item){
    the.items.erase(the.items.find(item));
}


void Style::apply(fltk::Widget* w,int v){
    for (std::map<int,void*>::iterator p = the.items.begin();p != the.items.end(); ++p){
        switch(p->first){
            case Style::BG_IMAGE:
                {
                    w->image(fltk::pngImage::get((const char*)p->second));
                }
                break;

            case Style::BG_COLOR:
                {
                    switch(v){
                        case Buttons::PLAY:
                            w->color(fltk::GREEN);
                            break;
                        case Buttons::RECORD:
                            w->color(fltk::RED);
                            break;
                        default:
                            w->color((fltk::Color)p->second);
                            break;
                    }


                }
                break;

            case Style::BOX:
                {
                    w->box((fltk::Box*)p->second);

                }
                break;

            case Style::LABEL_COLOR:
                {
                    w->labelcolor((fltk::Color)p->second);

                }
                break;

            case Style::LABEL_BOLD:
                {
                    w->labelfont((fltk::Font*)((p->second)?fltk::HELVETICA_BOLD:fltk::HELVETICA));

                }
                break;

            case Style::LABEL_ITALIC:
                {
                    w->labelfont((fltk::Font*)((p->second)?fltk::HELVETICA_ITALIC:fltk::HELVETICA));

                }
                break;

            default:

                break;
        }

   }
   w->redraw();
}

} // namespace gui

