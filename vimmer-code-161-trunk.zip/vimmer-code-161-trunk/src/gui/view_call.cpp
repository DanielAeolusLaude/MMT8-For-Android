/*
    VMM-R 0.2
    Virtual MIDI Multitrack Recorder
    Copyright (c) 2006 MIDI Team

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software Foundation,
    Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/
/**
  @file view_call.cpp
  @brief Implementation of View::call method
*/
#include "view.h"
#include <fltk/file_chooser.h>

namespace gui{

void View::call(int command,void* arguments){
    switch(command){
        case Queries::PART_LENGTH:
            {
                int v=(int)arguments;
                m_Sequencer->getSequencer()->getPartSequencer()->setLength(v);
                on(Window::SHOW_PAGE,(void*)Pages::LENGTH_CHANGED);
                DBG_ECHO("Set PART Length to " << m_Sequencer->getSequencer()->getActiveStep().getPart()->getLength());
            }
            break;

        case Queries::QUANTIZE_INTERVAL:
        case Queries::QUANTIZE_TYPE:
            {
                bool done=false;
                Part* p = m_Sequencer->getSequencer()->getActiveStep().getPart();
                Track* t;
                for(int i=1;i<9;i++){
                    if(policy.selected[i]){
                        t=p->getTrack(i-1);
                        if (!t==0){
                            t->quantize(db.quantize_interval,db.quantize_type);
                            DBG_ECHO("QUANTIZE TRACK " << i << " to " << db.quantize_interval);
                        }
                        else{
                            DBG_ECHO("QUANTIZE TRACK " << i << " to " << db.quantize_interval << " failed");
                        }

                        done=true;
                    }
                }
                if (done){
                     policy.property=0;
                     on(Window::SHOW_PAGE,(void*)Pages::QUANTIZED);
                }
            }
            break;

        case Queries::TRANSPOSE_INTERVAL:
            {
                bool done=false;
                Part* p = m_Sequencer->getSequencer()->getActiveStep().getPart();
                Track* t;
                for(int i=1;i<9;i++){
                    if(policy.selected[i]){
                        t=p->getTrack(i-1);
                        if (!t==0){
                            t->transpose(db.transpose_interval);
                            DBG_ECHO("TRANSPOSE TRACK " << i << " to " << db.transpose_interval);
                        }
                        else{
                            DBG_ECHO("TRANSPOSE TRACK " << i << " to " << db.transpose_interval << " failed");
                        }
                        done=true;
                    }
                }
                if (done) on(Window::SHOW_PAGE,(void*)Pages::TRANSPOSED);
            }
            break;

        case Queries::MERGE_TRACKS:
            {
                for(int i=1;i<9;i++){
                    if(policy.selected[i]){
                        DBG_ECHO("MERGE TRACK " << i);
                    }
                }
                on(Window::SHOW_PAGE,(void*)Pages::MERGED);
            }
            break;

        case Queries::COPY_TRACKS:
            {
                for(int i=1;i<9;i++){
                    if(policy.selected[i]){
                        DBG_ECHO("COPY TRACK " << i);
                    }
                }
                on(Window::SHOW_PAGE,(void*)Pages::COPIED);
            }
            break;

        case Queries::SELECTION:
        case Queries::FORMAT:
            {
                const char* fn;
                const char* filepattern;
                char prompt[MAX_PATH];

                file->format(db.fileformat);
                filepattern=Page::print_filepattern(db.fileformat);
                switch(page->current()){
                    case 0:
                    {
                        file->action(FileParams::SAVE);
                        sprintf(prompt,"Save %s to ...",Page::print_fileformat(db.fileformat));
                        fn=fltk::file_chooser(prompt,filepattern,file->filename(),true);
                        if (!fn==0){
                            file->filename(fn);
                            if (m_Sequencer->save(fn,db.fileformat,ModernSequencer::ALL,0)){
                                DBG_ECHO(prompt << fn << " succeeded");
                            }
                            else{
                                DBG_ECHO(prompt << fn << " failed");
                            }
                            on(Window::APPLY_STYLE,(void*)Style::OUT_OFF,Buttons::RECORD);

                        }
                        else{
                            DBG_ECHO("SAVE cancelled");

                        }
                        on(Window::SHOW_PAGE,(void*)((db.mode_part)?Pages::PART:Pages::SONG));
                    }
                    break;

                    case 1:
                    case 2:
                    {
                        const char* md=(db.mode_part)?"PART":"SONG";
                        int act=(db.mode_part)?ModernSequencer::PART:ModernSequencer::SONG;
                        int x=(int)get(Queries::SELECTION);
                        file->action(FileParams::SAVE);
                        sprintf(prompt,"Save %s %02d as %s to ...",md,x,Page::print_fileformat(db.fileformat));
                        fn=fltk::file_chooser(prompt,filepattern,file->filename(),true);
                        if (!fn==0){
                            file->filename(fn);
                            if (m_Sequencer->save(fn,db.fileformat,act,x)){
                                DBG_ECHO(prompt << fn << " succeeded");
                            }
                            else{
                                DBG_ECHO(prompt << fn << " failed");
                            }
                            on(Window::APPLY_STYLE,(void*)Style::OUT_OFF,Buttons::RECORD);

                        }
                        else{
                            DBG_ECHO("SAVE cancelled");

                        }
                        on(Window::SHOW_PAGE,(void*)((db.mode_part)?Pages::PART:Pages::SONG));
                    }
                    break;



                    case 3:
                    {
                        file->action(FileParams::LOAD);
                        sprintf(prompt,"Load %s from ...",Page::print_fileformat(db.fileformat));
                        fn=fltk::file_chooser(prompt,filepattern,file->filename(),false);
                        if (!fn==0){
                            file->filename(fn);
                            if (m_Sequencer->load(fn,db.fileformat,ModernSequencer::ALL,0)){
                                DBG_ECHO(prompt << fn << " succeeded");
                            }
                            else{
                                DBG_ECHO(prompt << fn << " failed");
                            }
                            on(Window::APPLY_STYLE,(void*)Style::OUT_OFF,Buttons::RECORD);

                        }
                        else{
                            DBG_ECHO("LOAD cancelled");
                        }
                        on(Window::SHOW_PAGE,(void*)((db.mode_part)?Pages::PART:Pages::SONG));
                    }
                    break;

                    case 4:
                    case 5:
                    {
                        const char* md=(db.mode_part)?"PART":"SONG";
                        int act=(db.mode_part)?ModernSequencer::PART:ModernSequencer::SONG;
                        int x=(int)get(Queries::SELECTION);
                        file->action(FileParams::LOAD);
                        sprintf(prompt,"Load %s %02d as %s from ...",md,x,Page::print_fileformat(db.fileformat));
                        fn=fltk::file_chooser(prompt,filepattern,file->filename(),false);
                        if (!fn==0){
                            file->filename(fn);
                            if (m_Sequencer->load(fn,db.fileformat,act,x)){
                                DBG_ECHO(prompt << fn << " succeeded");
                            }
                            else{
                                DBG_ECHO(prompt << fn << " failed");
                            }
                            on(Window::APPLY_STYLE,(void*)Style::OUT_OFF,Buttons::RECORD);

                        }
                        else{
                            DBG_ECHO("LOAD cancelled");
                        }
                        on(Window::SHOW_PAGE,(void*)((db.mode_part)?Pages::PART:Pages::SONG));

                    }
                    break;
                }
            }
            break;


        case Buttons::ERASE:
            {
                bool whole_part=true;
                bool done=false;

                Part* p = m_Sequencer->getStore()->getPartSystem()->getPart(db.selected);
                Track* t;
                for(int i=1;i<9;i++){
                    if (policy.selected[i]){
                        whole_part=false;
                        done=true;
                        t=p->getTrack(i-1);
                        t->erase();
                        DBG_ECHO("ERASED TRACK " << i << " FROM PART " << db.selected);
                    }
                }
                if (whole_part){
                    /// @todo how do I erase a Part?
                    DBG_ECHO("ERASED PART " << db.selected);
                    //p->erase();
                    done=true;
                }
                if (done) on(Window::SHOW_PAGE,(void*)Pages::ERASED);

            }
            break;

        case Buttons::STOP:
            {
                int p = (db.mode_part)?Pages::PART:Pages::SONG;
                on(View::TRACKS_POLICY,NULL,View::TRACKS_FREE);
                call(Buttons::RECORD,(void*)false);
                m_Sequencer->getSequencer()->stop();
                on(Window::SHOW_PAGE,(void*)p);
            }
            break;

        case Pages::COUNTING:
            {
                int p = (db.mode_part)?Pages::PART_POSITION:Pages::SONG_POSITION;
                db.counting=false;
                on(Window::SHOW_PAGE,(void*)p);
            }
            break;

        case Buttons::PLAY:
            {
                int p = (db.mode_part)?Pages::PART_POSITION:Pages::SONG_POSITION;
                db.counting=(db.count_down>0 && db.click_play);
                if (db.counting)p=Pages::COUNTING;
                m_Sequencer->getSequencer()->jump(0);
                m_Sequencer->getSequencer()->play();
                on(Window::SHOW_PAGE,(void*)p);
            }
            break;


        case Buttons::RECORD:
            {
                if ((bool)arguments==false){
                    on(View::TRACKS_POLICY,NULL,View::TRACKS_FREE);
                    m_Sequencer->getSequencer()->record(false);
                    db.armed=false;
                    keypad.enabled=true;
                    on(Led::OFF,NULL,Leds::RECORD);
                }
                else{
                    on(View::TRACKS_POLICY,NULL,View::TRACKS_RECORD);
                    m_Sequencer->getSequencer()->record(true);
                    db.armed=true;
                    keypad.enabled=false;
                    on(Led::BLINK_CONTINUOUS,NULL,Leds::RECORD);
                }
            }
            break;


        default:
            this->Window::call(command,arguments);
    }

}

} // namespace
