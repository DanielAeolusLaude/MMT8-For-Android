/*
    VMM-R 0.2
    Virtual MIDI Multitrack Recorder
    Copyright (c) 2006 MIDI Team

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software Foundation,
    Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/
/**
  @file queries.h
  @brief Declaration of Query identifiers
*/
#ifndef VMMR_GUI_QUERIES_H
#define VMMR_GUI_QUERIES_H

namespace gui{

/**
  @brief Identifiers for all properties/queries
  @ingroup replica
*/
class Queries{
  public:
    enum{
        UNDEFINED = 4000,
        FORMAT,
        IN,
        IN_NAME,
        OUT,
        OUT_NAME,
        ECHO,
        MODE,
        EDIT,
        TRACK_ON,
        TRACK_MASK,
        TRACK_OFF,
        SELECTION,
        PART_NUMBER,
        PART_NAME,
        PART_LENGTH,
        DESTINATION,
        SONG_NUMBER,
        SONG_NAME,
        SONG_STEP,
        SONG_PART,
        EDIT_BEAT,
        EDIT_PULSE,
        ARMED,
        PLAYING,
        POSITION,
        LOOP,
        COUNT_BEAT,
        CLOCK_SOURCE,
        CLOCK_MIDI_OUT,
        CLOCK_AUTO_START,
        CLICK_RECORD,
        CLICK_PLAY,
        CLICK_INTERVAL,
        COUNT_DOWN,
        MERGE_TRACKS,
        COPY_TRACKS,
        RECORD_NOTES,
        RECORD_PITCHBEND,
        RECORD_AFTERTOUCH,
        RECORD_CONTROLLERS,
        RECORD_PROGCHANGE,
        RECORD_SYSEX,
        RECORD_CHANNEL,
        TRANSPOSE_INTERVAL,
        QUANTIZE_INTERVAL,
        QUANTIZE_TYPE,
        TRACK,TRACK_OFFSET,
        TRACK_CHANNEL,
        TEMPO,
        MEMORY_LOAD_ERROR_PART,
        MEMORY_FREE,
        MEMORY_CHECKING_TYPE,
        MEMORY_CHECKING_NUMBER,
        MEMORY_LOADING_TYPE,
        MEMORY_LOADING_NUMBER,
        MEMORY_SAVING_TYPE,
        MEMORY_SAVING_NUMBER,
        NEXT_PART_NUMBER,
        NEXT_SONG_NUMBER,
        PROGRESS,

        //PLAYING, RECORDING

    };

};     // class Queries
}      // namespace gui
#endif // VMMR_GUI_QUERIES_H
