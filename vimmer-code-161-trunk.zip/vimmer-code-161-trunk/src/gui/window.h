/*
    VMM-R 0.2
    Virtual MIDI Multitrack Recorder
    Copyright (c) 2006 MIDI Team

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software Foundation,
    Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/
/**
  @file window.h
  @brief Declaration of Window class
*/
#ifndef VMMR_GUI_WINDOW_H
#define VMMR_GUI_WINDOW_H

#include "shared.h"
#include "trigger.h"
#include "plugin.h"
#include "button.h"


#include "led.h"
#include "lcd.h"
#include "keyboard.h"
#include "hotkey.h"
#include "style.h"
#include "page.h"
#include <vector>
#include <map>

#include <fltk/ShapedWindow.h>

#include <fltk/events.h>
#include <fltk/x.h>


namespace gui{

/**
  @class WindowState
  @ingroup win
  @brief Declares various window states
*/
class WindowState{
public:
enum{
    ICONIZED,
    WINDOWED,
    MAXIMIZED,
    FULLSCREEN
};

};  // class WindowState

/**
  @class WindowParams
  @ingroup win
  @brief Describes various Window arguments used to construct a Window.

  A Window has many options, so to make Window creation a little more convenient,
  this class was created as an intermediatry specification class.

  It also serves as an easy way to create multiple Window instances with
  the same creation parameters, by passing the same WindowParams object to
  the Window constructors.
*/
class WindowParams{
  public:
    int id; ///< identifier for Window
    Plugin* parent; ///< Plugin pointer to parent

    int left;  ///< left position of Window
    int top;   ///< top position of Window
    int width; ///< width of Window
    int height;///< height of Window

    const char* title; ///< title for Window
    const char* tooltip; ///< tooltip for Window

    bool resizable; ///< if true, Window can resize
    bool fullscreen;///< if true, Window is fullscreen
    bool topmost;   ///< if true, Window is a top-most Window
    bool image_tile;

    int icon_small; ///< resource id of small icon
    int icon_large; ///< resource id of big icon

    const unsigned char* shape_bits; ///< xbm image used ti define Window shape

    const char* image_path; ///< path to background image for Window

    int window_state; ///< desired initial WindowState

    int keyboard_type; ///< preset Keyboard type (@see Keyboard)

    /// default window parameters
    WindowParams(){
        id=0;
        parent=0;
        left=50;
        top=50;
        width=400;
        height=300;
        title=0;
        tooltip=0;
        resizable=true;
        fullscreen=false;
        topmost=false;
        image_tile=false;
        image_path=0;
        shape_bits=0;
        icon_small=0;
        icon_large=0;
        window_state=WindowState::WINDOWED;
        keyboard_type=Keyboard::STANDARD;
    }


}; // class WindowParams

/**
  @class Window
  @ingroup win
  @brief A Window that 'talks' like a Plugin but 'walks' like a fltk::Window

*/
class Window : public Plugin, public fltk::ShapedWindow
{
  public:

    enum{
        ADD_HOTKEY=1300,
        REMOVE_HOTKEY,
        ADD_BUTTON,
        REMOVE_BUTTON,
        ADD_LED,
        REMOVE_LED,
        ADD_BUTTONKEY,
        REMOVE_BUTTONKEY,
        ADD_TRIGGER,
        REMOVE_TRIGGER,
        ADD_PAGE,
        REMOVE_PAGE,
        SHOW_PAGE,
        PAGE_UP,
        PAGE_DOWN,
        PAGE_BACK,
        STYLE,
        ADD_STYLE,
        REMOVE_STYLE,
        APPLY_STYLE,
        TOGGLE_FULLSCREEN,
        TOGGLE_TOPMOST,
        PROPERTY_SET
    };

    /**
      @brief constructor with same arguments as fltk::Window
    */
    Window(int x, int y, int w, int h, const char* t=0);

    /**
      @brief constructor with WindowParams structure as arguments
    */
    Window(WindowParams& wp);

    /**
      @brief destructor for vtable
    */
    virtual ~Window();

    virtual void call(int command,void* arguments=0);
    virtual void* get(int property,void* arguments=0);
    virtual void set(int property,void* value);
    virtual void on(int event,void* arguments=0,int identifier=0);
    void hover(const char* t=0,int ki=0,const char* help="None available, sorry");
    virtual void trigger(int id,bool down,bool active,int button,bool modifier);

    int handle(int event);

  protected:
    WindowParams options;
    Keyboard* keyboard;
    bool recording_hotkey;
    int recording_key;
    int recording_button;

    std::vector<Hotkey*> hotkeys;     ///< fixed system hotkeys
    std::map<int,Button*> buttons;   ///< visual buttons (mapped to identifier)
    std::map<int,int> buttonkeys;   ///< user key to button id
    std::vector<Style*> styles;     ///< style variations in current theme
    std::vector<Trigger*> triggers;///< events and their trigger conditions
    Lcd* hovertip;                ///< shows some context specific help
    Lcd* lcd;                    ///< holds the default (main) Lcd instance
    char hoverbuf[240];         ///< string buffer for hovertip
    std::map<int,Page*> pages; ///< the various pages
    Page* page;                ///< current page
    int page_previous;        ///< idenifier of previous page

    std::map<int,Led*> leds; ///< visual Led instances (mapped to identifier)

  private:
}; // class Window

} // namespace gui

#endif // VMMR_GUI_WINDOW_H
