/*
    VMM-R 0.2
    Virtual MIDI Multitrack Recorder
    Copyright (c) 2006 MIDI Team

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software Foundation,
    Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/
/**
  @file lcd.cpp
  @brief Implementation of LCD class
*/
#include "lcd.h"
#include <fltk/draw.h>
#include <cstring>

namespace gui{

Lcd::Lcd(int x,int y,int w,int h,const char* m):
fltk::Widget(x,y,w,h,0)
{
    the.mask=m;
    align(fltk::ALIGN_INSIDE_LEFT);
    flags(fltk::ALIGN_CLIP);
    box(fltk::THIN_DOWN_BOX);

    labelfont(fltk::font("Courier New"));
    labelcolor(fltk::GRAY15);
    highlight(false);

}

Lcd::~Lcd()
{
    //dtor
}

void Lcd::layout(){
    float w1=(float)w()*0.86;
    float fs=3.0;
    fltk::setfont(labelfont(),fs);
    float w2=fltk::getwidth(the.mask,strlen(the.mask));

    while(w2<w1){
        fs=fs+0.25;
        fltk::setfont(labelfont(),fs);
        w2=fltk::getwidth(the.mask,strlen(the.mask));
    }
    labelsize(fs);

}

} // namespace gui
