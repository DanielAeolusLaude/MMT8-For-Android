/*
    VMM-R 0.2
    Virtual MIDI Multitrack Recorder
    Copyright (c) 2006 MIDI Team

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software Foundation,
    Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/

/**
  @file matts_main.cpp
  @brief Program entry point
*/
#include "view.h"
#include "ModernSequencer.hpp"
#include "XMLExporter.hpp"
#include "XMLImporter.hpp"
#include "ConfigurationManager.hpp"
#include "Exception.hpp"
#include <fltk/run.h>

//using namespace Vimmer;
//using namespace gui;

// DEBUG (JVR)
#include "StandardMIDIImporter.hpp"

/**
  @brief OS entry point and first program call
  @param argc number of arguments passed to program
  @param argv array of arguments passed to program
  @return 0 is good, 1 is not, but pretty meaningless in a GUI world
*/
int main(int argc,char** argv)
{

/*
Vimmer::Store* store = new Store(100, 100);

Vimmer::StandardMIDIImporter* smi = new Vimmer::StandardMIDIImporter(store);

smi->fileImportStore("h:\\cat.mid");


return 0;
*/



//    // just run a quick config test.
////    Group& root = ConfigurationManager::getSingleton().getRoot();
////    root.addGroup("Test1");
////
////    Group& group = root.getGroup("Test1");
////    group.addEntry("Entry1", "val1");
//    ConfigurationManager::getSingleton().load("tester.cfg");
//    Entry& test1 = ConfigurationManager::getSingleton().findEntry("Test1", "Entry1");
//    std::cout << "Entry: " << test1.getName() << " " << test1.getStringValue() << endl;
//
//
//    ConfigurationManager::getSingleton().save("tester.cfg");

    int return_value = 0;
    Vimmer::ModernSequencer* sequencer = new Vimmer::ModernSequencer();

    try
    {
        sequencer->getFileManager()->loadStore("dito.vmr");
    }
    catch (Exception e)
    {
        LogManager::getSingleton()->log("Import failed");
    }

    fltk::lock();

    gui::WindowParams p;
    p.id=777;
    p.left=80;
    p.top=60;
    p.width=731;
    p.height=806;
    p.title="VMM-R";
    p.tooltip="Virtual MIDI Mulitrack Recorder";
    p.fullscreen=false;
    p.icon_small=ICO_APP;
    p.icon_large=ICO_APP;
    //p.image_path="app.png";
    //p.image_tile=false;
    //p.shape_bits=my_shape;
    p.keyboard_type=gui::Keyboard::STANDARD_NO_REPEAT;
    gui::View* view = new gui::View(p,sequencer);
    sequencer->init();
    return_value = view->run(504,600);

    try
    {
        sequencer->getFileManager()->saveStore("dito.vmr");
    }
    catch (Exception e)
    {
        LogManager::getSingleton()->log("Export failed");
    }

    delete view;
    delete sequencer;

    return return_value;
}
