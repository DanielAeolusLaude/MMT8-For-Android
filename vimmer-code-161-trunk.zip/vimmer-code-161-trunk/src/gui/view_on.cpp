/*
    VMM-R 0.2
    Virtual MIDI Multitrack Recorder
    Copyright (c) 2006 MIDI Team

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software Foundation,
    Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/
/**
  @file view_on.cpp
  @brief Implementation of View::on method
*/
#include "view.h"
#include "SequencerModes.hpp"
#include "Exception.hpp"

#include <fltk/ask.h>
#include <fltk/run.h>
#include "mattsguii.h"

namespace gui{


void View::on(int event,void* arguments,int identifier){
    switch(event){

        case View::TRACKS_POLICY:
            {
                policy.tracks=identifier;
                switch(identifier){
                    case View::TRACKS_FREE:
                        {
                            if(db.mode_part)
                            {
                                for(int i =1;i<9;i++){
                                    db.p_trk[i]?set(Queries::TRACK_ON,(void*)i):set(Queries::TRACK_OFF,(void*)i);
                                    on(((bool)get(Queries::TRACK_ON,(void*)i))?Led::ON:Led::OFF,NULL,track_2_led(i));
                                }
                            }
                            else if(!m_Sequencer->getSequencer()->getSongSequencer()->getSong()->isEmpty())
                            {
                                for(int i =1;i<9;i++){
                                    (m_Sequencer->getSequencer()->getActiveStep().getTrackState(i-1) != SongStep::TRACK_STATE_CLEAR)?
                                        set(Queries::TRACK_ON,(void*)i):set(Queries::TRACK_OFF,(void*)i);
                                DBG_ECHO("Song Track[" << i << "]=" << (m_Sequencer->getSequencer()->getActiveStep().getTrackState(i-1) != SongStep::TRACK_STATE_CLEAR));

                                    on(((bool)get(Queries::TRACK_ON,(void*)i))?Led::ON:Led::OFF,NULL,track_2_led(i));
                                }
                            }
                        }
                        break;

                    case View::TRACKS_RECORD:
                        {
                            if(m_Sequencer->getSequencer()->getMode() == SequencerModes::PART_MODE)
                            {
                                for(int i=0;i<8;i++){
                                    if(m_Sequencer->getSequencer()->getActiveStep().getPart()->getTrack(i)->empty())
                                    {
                                        policy.rec_track=i+1;
                                        break;
                                    }
                                }

                                // update track states
                                m_Sequencer->getSequencer()->getActiveStep().setTrackStateAll(SongStep::TRACK_STATE_PLAY);
                                m_Sequencer->getSequencer()->getActiveStep().setTrackState(policy.rec_track-1, SongStep::TRACK_STATE_RECORD);

                                // update leds
                                for(int i=1;i<9;i++){
                                    on((i==policy.rec_track)?Led::ON:Led::OFF,NULL,track_2_led(i));
                                }
                            }
                        }
                        break;
                    case View::TRACKS_SINGLE:
                        {

                            for(int i=1;i<9;i++){
                                on((i==policy.track)?Led::ON:Led::OFF,NULL,track_2_led(i));
                            }
                        }
                        break;

                    case View::TRACKS_MULTI:
                        {
                            policy.first_pick=true;
                            for(int i =1;i<9;i++){
                                policy.selected[i]=false;
                                on(Led::BLINK_CONTINUOUS,NULL,track_2_led(i));
                            }
                        }
                        break;
                }
            }

            break;

        case View::REFRESH_CURRENT_MODE:
        {
           on((db.mode_part)?PARTMODE:SONGMODE);
        }
        break;

        case View::PARTMODE:
            {
                m_Sequencer->getSequencer()->setMode(SequencerModes::PART_MODE);
                db.mode_part=true;
                policy.property=0;
                policy.transport=View::TRANSPORT;
                on(View::TRACKS_POLICY,NULL,View::TRACKS_FREE);
                on(Led::OFF,NULL,Leds::SONG);
                on(Button::OFF,NULL,Buttons::SONG);
                on(Led::ON,NULL,Leds::PART);
                on(Button::ON,NULL,Buttons::PART);
                on(Window::SHOW_PAGE,db.playing?(void*)Pages::PART_POSITION:(void*)Pages::PART);
            }
            break;

        case View::SONGMODE:
            {
                try{
                m_Sequencer->getSequencer()->setMode(SequencerModes::SONG_MODE);
                }
                catch (MIDIToolkit::Exception e){
                    DBG_ECHO("RIP Song Mode - you died too young!");
                }
                db.mode_part=false;
                policy.property=0;
                policy.transport=View::TRANSPORT;
                on(View::TRACKS_POLICY,NULL,View::TRACKS_FREE);
                on(Led::ON,NULL,Leds::SONG);
                on(Button::ON,NULL,Buttons::SONG);
                on(Led::OFF,NULL,Leds::PART);
                on(Button::OFF,NULL,Buttons::PART);
                on(Window::SHOW_PAGE,(void*)Pages::SONG);
            }
            break;

        /*case View::RENAME:
            {
                //on(Button::ON,NULL,identifier);
                int q=(db.mode_part)?Queries::PART_NAME:Queries::SONG_NAME;
                const char* t = fltk::input("New name:",(const char*)get(q));
                if (t!=0){
                    set(q,(void*)t);
                    page->refresh();
                    lcd->label(page->value());

                    lcd->highlight(false);
                    lcd->redraw();

                }
                //on(Button::OFF,NULL,identifier);
                on(Window::APPLY_STYLE,(void*)Style::OUT_OFF,Buttons::NAME);
            }*/

        case View::BUTTON_FOR_KEYPAD:
            {
                if (keypad.enabled==false) return;
                lcd->highlight(true);
                int v=-1;
                switch(identifier){
                    case Buttons::PLUS:
                    case Buttons::MINUS:
                        {
                            int x=keypad.value+((identifier==Buttons::PLUS)?1:-1);
                            on(View::KEYPAD_SEND,(void*)x);
                            return;
                        }
                        break;

                    case Buttons::NUM0: v=0;break;
                    case Buttons::NUM1: v=1;break;
                    case Buttons::NUM2: v=2;break;
                    case Buttons::NUM3: v=3;break;
                    case Buttons::NUM4: v=4;break;
                    case Buttons::NUM5: v=5;break;
                    case Buttons::NUM6: v=6;break;
                    case Buttons::NUM7: v=7;break;
                    case Buttons::NUM8: v=8;break;
                    case Buttons::NUM9: v=9;break;
                }
                if(v>-1){
                    switch(keypad.position){
                      case 2:
                           keypad.input[0]=0;
                           keypad.input[1]=0;
                           keypad.input[2]=v;
                           break;
                      case 1:
                           //keypad_vars.input[0]=0;
                           keypad.input[1]=keypad.input[2];
                           keypad.input[2]=v;
                           break;

                      case 0:
                           keypad.input[0]=keypad.input[1];
                           keypad.input[1]=keypad.input[2];
                           keypad.input[2]=v;
                           break;
                    }
                    keypad.position--;
                    if (keypad.position==-1){
                        on(View::KEYPAD_TIMEOUT);
                    }
                    else{
                        fltk::add_timeout(2,View::keypad_timeout,this);
                    }

                }
            }
            break;


        case View::KEYPAD_TIMEOUT:
            {
                if (keypad.position>-1){
                  keypad.position=2;
                  lcd->highlight(false);
                  return;
                }
                int v;
                v = 100 * keypad.input[0];
                v+=10 * keypad.input[1];
                v+= keypad.input[2];
                on(View::KEYPAD_SEND,(void*)v);
                keypad.position=2;

            }
            break;

        case View::KEYPAD_SEND:
            {
                int v=(int)arguments;
                int p = page->variable();
                //DBG_ECHO(p << " = " << v);
                set(p,(void*)v);
                page->refresh();
                keypad.value=(int)get(p);
                lcd->highlight(false);
                lcd->label(page->value());
                lcd->redraw();
                fltk::remove_timeout(View::keypad_timeout,this);

            }
            break;


        case Window::SHOW_PAGE:
            {
                std::map<int, Page*>::const_iterator p = pages.find((int)arguments);

                if (page==0){
                    page_previous=(int)arguments;
                }
                else{
                    page_previous=page->id();
                }
                if (p != pages.end()){
                    page=p->second;
                    page->zero();
                    keypad.value=(int)get(page->variable());
                    page->refresh();
                    lcd->label(page->value());
                    lcd->redraw();
                    redraw();
                }
            }
            break;

        case Window::PAGE_BACK:
            {
                if(page_previous==0) return;
                std::map<int, Page*>::const_iterator p = pages.find(page_previous);

                if (p != pages.end()){
                    page_previous=page->id();
                    page=p->second;
                    page->zero();
                    keypad.value=(int)get(page->variable());
                    page->refresh();
                    lcd->label(page->value());
                    lcd->redraw();
                    Button* b=buttons[identifier];
                    b->user_data((void*)false);
                }
            }
            break;


        case Window::PAGE_UP:
            {
                if(page==0) return;
                page->up();
                keypad.value=(int)get(page->variable());
                lcd->label(page->value());
                lcd->redraw();
                Button* b=buttons[Buttons::UP];
                b->user_data((void*)true);

            }
            break;

        case Window::PAGE_DOWN:
            {
                if(page==0) return;
                page->down();
                keypad.value=(int)get(page->variable());
                lcd->label(page->value());
                lcd->redraw();
                Button* b=buttons[Buttons::DOWN];
                b->user_data((void*)true);
            }
            break;

        case View::BUTTON_FOR_TRACKS:
            {
                int n = button_2_track(identifier);
                int l = track_2_led(n);
                switch(policy.tracks){
                    case View::TRACKS_FREE:
                        {
                            bool is_on=(bool)get(Queries::TRACK_ON,(void*)n);
                            on((is_on)?Led::OFF:Led::ON,NULL,l);
                            set((is_on)?Queries::TRACK_OFF:Queries::TRACK_ON,(void*)n);
                        }
                       break;

                    case View::TRACKS_RECORD:
                        {
                            policy.rec_track=n;
                            for(int i=1;i<9;i++){
                                on((n==i)?Led::ON:Led::OFF,NULL,track_2_led(i));
                                (n==i)?m_Sequencer->getSequencer()->getActiveStep().setTrackState(i-1, SongStep::TRACK_STATE_RECORD):m_Sequencer->getSequencer()->getActiveStep().setTrackState(i-1, SongStep::TRACK_STATE_PLAY);
                            }

                            page->refresh();
                            keypad.value=(int)get(page->variable());
                            lcd->label(page->value());
                            lcd->redraw();
                            break;
                        }
                    case View::TRACKS_SINGLE:
                        {
                            policy.track=n;
                            for(int i=1;i<9;i++){
                                on((n==i)?Led::ON:Led::OFF,NULL,track_2_led(i));
                            }
                            page->refresh();
                            keypad.value=(int)get(page->variable());
                            lcd->label(page->value());
                            lcd->redraw();
                        }
                       break;

                    case View::TRACKS_MULTI:
                        {
                            if(policy.first_pick){
                                for(int i=1;i<9;i++){
                                    on((n==i)?Led::ON:Led::OFF,NULL,track_2_led(i));
                                }
                                policy.first_pick=false;
                                policy.selected[n]=true;
                            }
                            else{
                                policy.selected[n]=!policy.selected[n];
                                on(policy.selected[n]?Led::ON:Led::OFF,NULL,track_2_led(n));
                            }
                        }
                        break;
                }
            }
            break;

        case View::TRANSPORT:
            {
                switch(policy.transport){
                    case View::TRANSPORT:
                    {
                        switch(identifier){
                            case Buttons::RECORD:
                            {
                                if (db.mode_part==false) return;
                                if(m_Sequencer->getSequencer()->isRecordArmed()==true){
                                    call(Buttons::RECORD,(void*)false);
                                }
                                else{
                                    if(m_Sequencer->getSequencer()->getState()==SequencerStates::STOPPED){
                                        call(Buttons::RECORD,(void*)true);
                                    }
                                }
                            }
                            break;
                            case Buttons::PLAY:
                            {
                                if(m_Sequencer->getSequencer()->getState()==SequencerStates::RECORDING){
                                    call(Buttons::STOP);
                                }
                                else{
                                    call(Buttons::PLAY);
                                }
                            }
                            break;
                            case Buttons::STOP:
                            {
                                if(m_Sequencer->getSequencer()->getState()!=SequencerStates::STOPPED)
                                {
                                    call(Buttons::STOP);
                                }
                                else
                                {
                                    if(m_Sequencer->getSequencer()->isRecordArmed()==true){
                                        call(Buttons::RECORD,(void*)false);
                                    }
                                    else{
                                        int p = (db.mode_part)?Pages::PART_POSITION:Pages::SONG_POSITION;
                                        m_Sequencer->getSequencer()->play();
                                        on(Window::SHOW_PAGE,(void*)p);
                                    }
                                }
                            }
                            break;
                            case Buttons::REWIND:
                            {
                                if(m_Sequencer->getSequencer()->isRecordArmed()==true){

                                    call(Buttons::STOP);
                                }
                                else{
                                    db.position = m_Sequencer->getSequencer()->getBeat() - 1;
                                    m_Sequencer->getSequencer()->jump(db.position);
                                }
                            }
                            break;
                            case Buttons::FORWARD:
                            {
                                if(m_Sequencer->getSequencer()->isRecordArmed()==true){
                                    call(Buttons::STOP);

                                }
                                else{
                                    db.position = m_Sequencer->getSequencer()->getBeat() + 1;
                                    m_Sequencer->getSequencer()->jump(db.position);
                                }
                            }
                            break;


                        }
                        break;
                    }
                    case View::TRANSPORT_ALT:
                        switch(identifier){
                            case Buttons::RECORD:
                            {
                                call(policy.property,(void*)keypad.value);

                            }
                            break;
                            case Buttons::PLAY:
                            {

                            }
                            break;
                            case Buttons::STOP:
                            {

                            }
                            break;
                            case Buttons::REWIND:
                            {

                            }
                            break;
                            case Buttons::FORWARD:
                            {

                            }
                            break;
                        }
                        break;

                }
            }
            break;

        /*case View::EDIT:
        {
            if(!db.mode_part)
            {
                m_SongEditor.show_window();
                cout << "Editor" << endl;
            }
            break;
        }*/

        default:
            this->Window::on(event,arguments,identifier);
            break;
    }
}

}// namespace gui
