/*
    VMM-R 0.2
    Virtual MIDI Multitrack Recorder
    Copyright (c) 2006 MIDI Team

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software Foundation,
    Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/
/**
  @file keyboard.h
  @brief Declaration of Keyboard class
*/

#ifndef VMMR_GUI_KEYBOARD_H
#define VMMR_GUI_KEYBOARD_H

#include "plugin.h"
#include "shared.h"
#include "key.h"


#include <fltk/events.h>
#include <map>

namespace gui{

/**
  @class Keyboard
  @ingroup widgets
  @brief Holds a representation of a hardware Keyboard and the interesting Key instances

  The purpose of this class is to claw back control of Keyboard events, and this
  is achieved by giving the user control over the behaviour of every Key.

  The Window class 'owns' an instance of this class, and it passes all low-level
  key events to Keyboard, where the events are filtered. They are then
  passed to the supplied Plugin* host, which also happens to be the Window.

  By default, the Keyboard is BLANK (has NO Key instances), and the user
  may add() the Keys (and circumstances) under which the Keyboard will
  pass on these events.

  Effectively, it is a giant customizable filter for Key events, so
  you actually GET the events you want (fltk2 has bugs with this).

*/
class Keyboard{

  public:

    friend class Window;

    enum{
        /// represents a placeholder Keyboard with no keys (awaiting customisation)
        BLANK = 0,
        /// by default, a Keyboard is constructed with no keys
        DEFAULT = BLANK,
        /// represents a typical Keyboard, and supports ALL keys on Keyboard
        STANDARD,
        /// same as STANDARD, but all key repetition is suppressed
        STANDARD_NO_REPEAT
    };

    /**
      @brief construct a Keyboard with Plugin host and optional type
      @param p pointer to Plugin that will receive Key event callbacks
      @param type whether the Keyboard should be BLANK, or just build a normal keyboard (with or without key repetition)
    */
    Keyboard(Plugin* p,int type=DEFAULT);

    /**
      @brief destructor for vtable
    */
    virtual ~Keyboard();

    /**
      @brief add a Key to the Keyboard, and specify the events to fire
      @param k key code (see fltk documentation for details)
      @param repeat if false, key repetition is suppressed
      @param down_event if true, down event is fired when appropriate
      @param up_event if true, up event is fired when appropriate
    */
    void add(int k,bool repeat,bool down_event,bool up_event);

    /**
      @brief get one of the Key instances on the Keyboard
      @param k key code identifier
      @return pointer to Key
    */
    Key* get(int k);

    /**
      @brief remove one of the Key instances from the Keyboard
      @param k key code identifier
    */
    void remove(int k);

    /**
      @brief determine Key state
      @param k key code identifier
      @return true if Key is down, false otherwise
    */
    bool is_down(int k);




  protected:

    /**
      @brief low level key down event passed from Window
      @param k key code identifier
      @post If appropriate, will raise a corresponding Key event
    */
    void on_down(int k);

    /**
      @brief low level key up event passed from Window
      @param k key code identifier
      @post If appropriate, will raise a corresponding Key event
    */
    void on_up(int k);

    /// maps key code to Key pointer
    std::map<int,Key*> keys;

    /// pointer to host Plugin (receives Key events)
    Plugin* host;

};  // class Keyboard

} // namespace gui

#endif // VMMR_GUI_KEYBOARD_H
