/*
    VMM-R 0.2
    Virtual MIDI Multitrack Recorder
    Copyright (c) 2006 MIDI Team

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software Foundation,
    Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/
/**
  @file window.cpp
  @brief Implementation of Window class
*/
#include "window.h"

#include "background.h"
#include <Windows.h>
#include <fltk/HelpView.h>
#include <fltk/SharedImage.h>
#include <fltk/TiledImage.h>

namespace gui{

Window::Window(int x, int y, int w, int h, const char* t):
Plugin(0,0),
fltk::ShapedWindow(x,y,w,h,t)
{
    //ctor
}

Window::Window(WindowParams& p):
Plugin(0,0),
fltk::ShapedWindow(0,0,0)
{
    Background* bg;
    plugin.id=(int)p.id;
    plugin.parent=(Plugin*)p.parent;

    keyboard = new Keyboard(this,p.keyboard_type);
    recording_hotkey=false;
    recording_button=0;
    recording_key=0;
    recording_button=0;

    set(WindowProperties::LEFT_PIXELS,(void*)p.left);
    set(WindowProperties::TOP_PIXELS,(void*)p.top);
    set(WindowProperties::WIDTH_PIXELS,(void*)p.width);
    set(WindowProperties::HEIGHT_PIXELS,(void*)p.height);

    set(WindowProperties::RESIZABLE_FLAG,(void*)p.resizable);
    set(WindowProperties::FULLSCREEN_FLAG,(void*)p.fullscreen);

    set(WindowProperties::IMAGE_TILE_FLAG,(void*)p.image_tile);
    set(WindowProperties::TITLE_TEXT,(void*)p.title);
    set(WindowProperties::TOOLTIP_TEXT,(void*)p.tooltip);
    set(WindowProperties::WINDOW_STATE,(void*)p.window_state);

    // only after shown() !
    set(WindowProperties::SMALL_ICON,(void*)p.icon_small);
    set(WindowProperties::LARGE_ICON,(void*)p.icon_large);
    set(WindowProperties::TOPMOST_FLAG,(void*)p.topmost);
    set(WindowProperties::IMAGE_PATH,(void*)p.image_path);
    set(WindowProperties::SHAPE_BITS,(void*)p.shape_bits);

    begin();
    hovertip = new Lcd(100,90,485,90,"1234567890123456789012345678901234567890");
    hovertip->hide();
    bg=new Background(0,0,p.width,p.height);
    lcd = new Lcd(286,306,190,60,"123456789012345678");
    end();

}

void* Window::get(int property,void* arguments){
    switch(property){

        case WindowProperties::LEFT_PIXELS:
            return (void*)options.left;
            break;

        case WindowProperties::TOP_PIXELS:
            return (void*)options.top;
            break;

        case WindowProperties::WIDTH_PIXELS:
            return (void*)options.width;
            break;

        case WindowProperties::HEIGHT_PIXELS:
            return (void*)options.height;
            break;

        case WindowProperties::TITLE_TEXT:
            return (void*)options.title;
            break;

        case WindowProperties::TOOLTIP_TEXT:
            return (void*)options.tooltip;
            break;

        case WindowProperties::SMALL_ICON:
            return (void*)options.icon_small;
            break;

        case WindowProperties::LARGE_ICON:
            return (void*)options.icon_large;
            break;

        case WindowProperties::IMAGE_PATH:
            return (void*)options.image_path;
            break;

        case WindowProperties::SHAPE_BITS:
            return (void*)options.shape_bits;
            break;

        case WindowProperties::RESIZABLE_FLAG:
            return (void*)options.resizable;
            break;

        case WindowProperties::FULLSCREEN_FLAG:
            return (void*)options.fullscreen;
            break;

        case WindowProperties::TOPMOST_FLAG:
            return (void*)options.topmost;
            break;

        case WindowProperties::IMAGE_TILE_FLAG:
            return (void*)options.image_tile;
            break;

        case WindowProperties::WINDOW_STATE:
            return (void*)options.window_state;
            break;

        case Key::DOWN:
            return (void*)keyboard->is_down((int)arguments);
            break;

        case Key::UP:
            return (void*)(keyboard->is_down((int)arguments)==false);
            break;

        case WindowProperties::KEYBOARD:
            return (void*)keyboard;
            break;

        case Window::STYLE:
            {
                for(unsigned int i=0;i<styles.size();i++){
                    Style* s=styles[i];
                    if(s->id()==(int)arguments){
                        return (void*) s;
                        break;
                    }
                }
                return 0;
            }
            break;

        default:

            break;
    }
    if(plugin.parent==0)return NULL;
    return plugin.parent->get(property,arguments);
}

void Window::set(int property,void* value){
    switch(property){

        case WindowProperties::LEFT_PIXELS:
            options.left=(int)value;
            x(options.left);
            break;

        case WindowProperties::TOP_PIXELS:
            options.top=(int)value;
            y(options.top);
            break;

        case WindowProperties::WIDTH_PIXELS:
            options.width=(int)value;
            w(options.width);
            break;

        case WindowProperties::HEIGHT_PIXELS:
            options.height=(int)value;
            h(options.height);
            break;

        case WindowProperties::TITLE_TEXT:
            options.title=(const char*)value;
            label(options.title);
            break;

        case WindowProperties::TOOLTIP_TEXT:
            options.tooltip=(const char*)value;
            tooltip(options.tooltip);
            break;

        case WindowProperties::SMALL_ICON:
            {
                options.icon_small = (int)value;
                if(!shown()) return;
                HANDLE ic = LoadImage(GetModuleHandle(0), MAKEINTRESOURCE(options.icon_small), IMAGE_ICON, 16, 16, 0);
                SendMessage(fltk::xid(this), WM_SETICON, ICON_SMALL, reinterpret_cast<LPARAM>(ic));
            }
            break;

        case WindowProperties::LARGE_ICON:
            {
                options.icon_large = (int)value;
                if(!shown()) return;
                HANDLE ic = LoadImage(GetModuleHandle(0), MAKEINTRESOURCE(options.icon_large), IMAGE_ICON, 32, 32, 0);
                SendMessage(fltk::xid(this), WM_SETICON, ICON_BIG, reinterpret_cast<LPARAM>(ic));
            }
            break;

        case WindowProperties::IMAGE_PATH:
            options.image_path=(const char*)value;
            if (options.image_path==0){
                image((fltk::SharedImage*)0);
            }
            else{
                if(options.image_tile){
                    image(new fltk::TiledImage(fltk::pngImage::get(options.image_path)));
                }
                else{
                    image(fltk::pngImage::get(options.image_path));
                }
            }
            redraw();
            break;

        case WindowProperties::IMAGE_TILE_FLAG:
            options.image_tile=(bool)value;
            set(WindowProperties::IMAGE_PATH,(void*)options.image_path);
            break;

        case WindowProperties::SHAPE_BITS:
            options.shape_bits=(const unsigned char*)value;
            if (options.shape_bits==0){
                this->shape((fltk::xbmImage*)0);
                if (options.resizable) this->resizable(this);
            }
            else{
                this->resize(options.width, options.height);
                this->resizable(0);
                this->shape(new fltk::xbmImage(options.shape_bits, options.width, options.height));
            }
            redraw();
            break;

        case WindowProperties::RESIZABLE_FLAG:
            options.resizable=(bool)value;
            resizable((options.resizable)?this:0);
            break;

        case WindowProperties::FULLSCREEN_FLAG:
            options.fullscreen=(bool)value;
            if(options.fullscreen==false){
                fullscreen_off(options.left,options.top,options.width,options.height);
            }
            else{
                options.left=x();
                options.top=y();
                options.width=w();
                options.height=h();
                fullscreen();
            }
            break;

        case WindowProperties::TOPMOST_FLAG:
            {
                if (!shown()) return;
                options.topmost=(bool)value;
                options.left=x();
                options.top=y();
                options.width=w();
                options.height=h();
                if (options.topmost){
                    SetWindowPos(fltk::xid(this), HWND_TOPMOST, x(), y()-32, w(), h()+32, 0);
                }
                else{
                    SetWindowPos(fltk::xid(this), HWND_NOTOPMOST, x(), y()-32, w(), h()+32, 0);
                }
                x(options.left);
                y(options.top);
                w(options.width);
                h(options.height);
            }
            break;

        case WindowProperties::WINDOW_STATE:
            {
                switch((int)value){

                    case WindowState::ICONIZED:
                        options.window_state = (int)value;
                        iconize();
                        break;

                    case WindowState::WINDOWED:
                        options.window_state = (int)value;
                        show();
                        break;

                    case WindowState::MAXIMIZED:
                        options.window_state = (int)value;
                        show();
                        DBG_ECHO("MAXIMIZE NOT SUPPORTED");
                        break;

                    case WindowState::FULLSCREEN:
                        set(WindowProperties::FULLSCREEN_FLAG,(void*)true);
                        break;
                }
            }
            break;



        default:
            if(plugin.parent==0){
                return;
            }
            else{
                plugin.parent->set(property,value);
                return;
            }
            break;
    }
    on(Window::PROPERTY_SET,(void*)property,options.id);
}

void Window::call(int command,void* arguments){
    switch(command){
        case Window::ADD_HOTKEY:
            {
                hotkeys.push_back((Hotkey*)arguments);
            }
            break;

        case Window::ADD_TRIGGER:
            {
                triggers.push_back((Trigger*)arguments);
            }
            break;


        case Window::ADD_PAGE:
            {
                Page* p=(Page*)arguments;
                p->host(this);
                pages.insert(std::make_pair(p->id(),p));
            }
            break;

        case Window::REMOVE_PAGE:
            {
                pages.erase(pages.find((int)arguments));
            }
            break;

        case Window::SHOW_PAGE:
            {
                on(Window::SHOW_PAGE,arguments);
            }
            break;


        case Window::ADD_LED:
            {
                Led* l = (Led*)arguments;
                this->add(l);
                leds.insert(std::make_pair(l->id(),l));
            }
            break;

        case Window::REMOVE_LED:
            {
                leds.erase(leds.find((int)arguments));
            }
            break;

        case Window::ADD_BUTTON:
            {
                ButtonParams* b=(ButtonParams*)arguments;
                Button* b2=new Button(b->id,this,b->x,b->y,b->w,b->h,b->t,b->b,b->tt);

                this->add(b2);
                buttons.insert(std::make_pair(b->id,b2));
                on(Window::APPLY_STYLE,(void*)Style::OUT_OFF,b->id);
                delete b;
            }
            break;

        case Window::ADD_BUTTONKEY:
            {
                ButtonKeyParams* b=(ButtonKeyParams*)arguments;
                buttonkeys.insert(std::make_pair(b->key,b->button));
                delete b;
            }
            break;

        case Window::REMOVE_BUTTONKEY:
            {
                int bi=(int)arguments;
                int ki=0;
                for (std::map<int,int>::iterator p = buttonkeys.begin();p!= buttonkeys.end(); ++p ){
                        if(p->second==bi) {
                            ki=p->first;
                            break;
                        }
                }
                if(ki>0){
                    buttonkeys.erase(buttonkeys.find(ki));
                }
            }
            break;

        case Window::ADD_STYLE:
            {
                styles.push_back((Style*)arguments);
            }
            break;

        case Window::REMOVE_STYLE:
            {
                int id=(int)arguments;
                for(unsigned int i=0;i<styles.size();i++){
                    Style* s=styles[i];
                    if (s->id()==id){
                        delete styles[i];
                    }
                }
            }
            break;

        default:
            if(plugin.parent==0){

            }
            else{
               plugin.parent->call(command,arguments);
            }
            break;

    }
}

int Window::handle(int event){
    switch(event){

        case fltk::ENTER:

            fltk::focus(this);
            break;

        case fltk::KEY:
            if (recording_hotkey){

                recording_key = fltk::event_key();
                return 1;
            }
            else{
                fltk::event_is_click(false);
                keyboard->on_down(fltk::event_key());
                return 1;
            }

            break;

        case fltk::KEYUP:


            if (recording_hotkey){
                if ((recording_key==fltk::LeftCtrlKey)||(recording_key==fltk::RightCtrlKey)){
                    on(Window::APPLY_STYLE,(void*)Style::OUT_OFF,recording_button);
                    hover("CANCELLED",0,"No longer waiting for a ButtonKey, business as usual.");
                    recording_key=0;
                    recording_button=0;
                    recording_hotkey=false;
                    return 1;
                }
                else{
                    bool existing_hotkey=false;
                    for(unsigned int i=0;i<hotkeys.size();i++){
                        Hotkey* hk=hotkeys[i];
                        if(hk->key()==recording_key){
                            existing_hotkey=true;
                            break;
                        }
                    }
                    if(!existing_hotkey){
                        for (std::map<int,int>::iterator p = buttonkeys.begin();p!= buttonkeys.end(); ++p ){
                            if(p->first==recording_key) {
                                existing_hotkey=true;
                                break;
                            }
                        }
                        if(!existing_hotkey){

                            Button* b=buttons[recording_button];
                            hover(b->label(),recording_key,"New ButtonKey set for this button.");
                            // look for existing buttonkey and delete it
                            call(REMOVE_BUTTONKEY,(void*)recording_button);
                            // add new buttonkey
                            call(ADD_BUTTONKEY,new ButtonKeyParams(recording_key,recording_button));
                        }
                        else{
                            hover("WARNING",recording_key,"ButtonKey exists for this key, try again.");
                        }
                    }
                    else{
                        hover("WARNING",recording_key,"Hotkey exists for this key, choose another.");
                    }
                }
                on(Window::APPLY_STYLE,(void*)Style::OUT_OFF,recording_button);
                recording_hotkey=false;
                return 1;
            }
            else{
                fltk::event_is_click(false);
                keyboard->on_up(fltk::event_key());
                return 1;
            }
            break;
    }
    return this->fltk::Window::handle(event);
}

void Window::trigger(int id,bool down,bool active,int button,bool modifier){
    //DBG_ECHO(id << "\t" << (down?"   PUSH":" RELEASE") << (active?"  ON":" OFF") << ((button==fltk::LeftButton)?"  LEFT":" RIGHT") << ((modifier)?"   ALT":" NOALT"));
}

void Window::on(int event,void* arguments,int identifier){
    switch(event){

        case Key::DOWN:
            {
                for(unsigned int i=0;i<hotkeys.size();i++){
                    Hotkey* hk=hotkeys[i];
                    if(hk->test(keyboard)){
                        hk->fire(this);
                    }
                }
                std::map<int, int>::const_iterator p = buttonkeys.find(identifier);

                if (p != buttonkeys.end()){

                    on(Button::PUSH,arguments,p->second);

                }
            }
            break;

        case Key::UP:
            {
                std::map<int, int>::const_iterator p = buttonkeys.find(identifier);

                if (p != buttonkeys.end()){
                    on(Button::RELEASE,arguments,p->second);
                }
            }
            break;

        case Window::PROPERTY_SET:
            //std::cout << "PROPERTY_SET " << (int)arguments << " id@" << identifier << std::endl;
            break;

        case Button::HANDLE:
            {
                int e = (int)arguments;
                switch(e){

                    case fltk::ENTER:
                        on(Button::ENTER,0,identifier);
                        break;

                    case fltk::LEAVE:
                        on(Button::LEAVE,0,identifier);
                        break;

                    case fltk::PUSH:
                        if(fltk::event_state(fltk::CTRL)){
                            on(Button::LEARN_HOTKEY,0,identifier);
                        }
                        else{
                            on(Button::PUSH,(void*)fltk::event_button(),identifier);
                        }
                        break;

                    case fltk::RELEASE:
                        if(fltk::event_state(fltk::CTRL)){
                            on(Window::APPLY_STYLE,(void*)Style::OVER_OFF,identifier);
                        }
                        else{
                            on(Button::RELEASE,(void*)fltk::event_button(),identifier);
                        }
                        break;

                    case fltk::KEY:
                    case fltk::KEYUP:

                        handle(e);
                        break;

                }
            }
            break;

        case Button::ENTER:

            {
                // find any buttonkey assignment
                int ki=0;
                for (std::map<int,int>::iterator p = buttonkeys.begin();p!= buttonkeys.end(); ++p ){
                        if(p->second==identifier) {
                            ki=p->first;
                            break;
                        }
                }
                Button* b=buttons[identifier];
                if ((bool)b->user_data()==true){
                    on(Window::APPLY_STYLE,(void*)Style::OVER_ON,identifier);
                }
                else{
                    on(Window::APPLY_STYLE,(void*)Style::OVER_OFF,identifier);
                }
                hover(b->label(),ki,b->tooltip());
            }
            break;

        case Button::LEAVE:
            {
                Button* b=buttons[identifier];
                if ((bool)b->user_data()==true){
                    on(Window::APPLY_STYLE,(void*)Style::OUT_ON,identifier);
                }
                else{
                    on(Window::APPLY_STYLE,(void*)Style::OUT_OFF,identifier);
                }
                hover(0);
            }
            break;

        case Button::PUSH:
        case Button::RELEASE:
            {
                Button* btn=buttons[identifier];
                int mode=0;
                bool modifier=(fltk::event_state(fltk::ALT)==true);
                bool value=false;
                bool over = btn->belowmouse();
                int style=0;
                bool triggered=false;
                switch(btn->behaviour()){
                    case Button::MOMENTARY: mode=1;break;
                    case Button::SHIFT_STICKY: mode=(fltk::event_state(fltk::SHIFT)==true)?2:1;break;
                    case Button::TOGGLE: mode=2;break;
                }
                if(event==Button::PUSH){
                    value = (!((mode==2)&&((bool)btn->user_data()==true)));

                    style=(value)?Style::DOWN_ON:Style::DOWN_OFF;
                }
                else{
                    value=((mode==2)&&((bool)btn->user_data()==true));

                    if (value){
                        style=(over)?Style::OVER_ON:Style::OUT_ON;
                    }
                    else{
                        style=(over)?Style::OVER_OFF:Style::OUT_OFF;
                    }
                }

                on(Window::APPLY_STYLE,(void*)style,identifier);

                for(unsigned int i =0;i<triggers.size();i++){
                    Trigger* t = triggers[i];
                    if (t!=NULL){
                        if (t->test(identifier,(event==Button::PUSH),value,(int)arguments,modifier)){
                            t->fire(this);
                            triggered=true;
                            //break;
                        }
                    }
                }
                btn->user_data((void*)value);
                if(triggered){

                }
                else{
                    trigger(identifier,(event==Button::PUSH),value,(int)arguments,modifier);
                }

            }
            break;

        case Button::LEARN_HOTKEY:
            {
                if (identifier!=0){
                    Button* b=buttons[identifier];
                    if ((bool)b->user_data()==true){
                        on(Window::APPLY_STYLE,(void*)Style::DOWN_ON,identifier);
                    }
                    else{
                        on(Window::APPLY_STYLE,(void*)Style::DOWN_OFF,identifier);
                    }
                    hover(b->label(),0,"Waiting ... press new ButtonKey now.");
                    recording_hotkey=true;
                    recording_button=identifier;
                    recording_key=0;
                }
            }

            break;

        case Button::ON:
            {
                Button* b=buttons[identifier];
                b->value(true);
                if(b->belowmouse()){
                    on(Window::APPLY_STYLE,(void*)Style::OVER_ON,identifier);
                }
                else{
                    on(Window::APPLY_STYLE,(void*)Style::OUT_ON,identifier);
                }
            }
            break;

        case Button::OFF:
            {
                Button* b=buttons[identifier];
                b->value(false);
                if(b->belowmouse()){
                    on(Window::APPLY_STYLE,(void*)Style::OVER_OFF,identifier);
                }
                else{
                    on(Window::APPLY_STYLE,(void*)Style::OUT_OFF,identifier);
                }
            }
            break;

        case Window::TOGGLE_FULLSCREEN:
            {
                if((bool)get(WindowProperties::FULLSCREEN_FLAG)==true){
                    set(WindowProperties::FULLSCREEN_FLAG,(void*)false);
                }
                else{
                    set(WindowProperties::FULLSCREEN_FLAG,(void*)true);
                }
            }
            break;


        case Window::TOGGLE_TOPMOST:
            {
                if((bool)get(WindowProperties::TOPMOST_FLAG)==true){
                    set(WindowProperties::TOPMOST_FLAG,(void*)false);
                }
                else{
                    set(WindowProperties::TOPMOST_FLAG,(void*)true);
                }
            }
            break;

        case Window::APPLY_STYLE:
            {
                Style* s = (Style*)get(Window::STYLE,arguments);
                Button* b=buttons[identifier];
                s->apply(b,identifier);
            }
            break;

        case Led::ON:
        case Led::OFF:
        case Led::STOP_BLINKING:
        case Led::BLINK_ONCE:
        case Led::BLINK_CONTINUOUS:
            {
                Led* l=leds[identifier];
                l->call(event,arguments);
            }
            break;

        default:

            if(plugin.parent==0){

            }
            else{
                plugin.parent->on(event,arguments,identifier);
            }
            break;
    }
}

void Window::hover(const char* t,int ki,const char* help){
    if(!t==0){
        if(ki>0){
            sprintf(hoverbuf,"Button: @b %s @n\nHotkey: @b %s @n @C0x0\n%s",t,Key::name(ki),help);
        }
        else{
            sprintf(hoverbuf,"Button: @b %s @n\nHotkey: @b %s @n @C0x0\n%s",t,"CTRL-Click to set a hotkey",help);

        }
        hovertip->show();
        hovertip->label(hoverbuf);
        hovertip->redraw();
    }
    else{
        hovertip->label(0);
        hovertip->hide();
    }


}

Window::~Window()
{
    //dtor
    delete keyboard;
}

} // namespace gui
