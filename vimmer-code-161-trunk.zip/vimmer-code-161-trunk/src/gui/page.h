/*
    VMM-R 0.2
    Virtual MIDI Multitrack Recorder
    Copyright (c) 2006 MIDI Team

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software Foundation,
    Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/
/**
  @file page.h
  @brief Declaration of Page class
*/

#ifndef VMMR_GUI_PAGE_H
#define VMMR_GUI_PAGE_H

#include <cstdio>
#include <vector>
#include "plugin.h"
#include "file_params.h"

namespace gui{

/**
  @class Page
  @ingroup widgets
  @brief an identifiable Page of text amongst other things

  This class groups a series of text/variable pairs, where the
  text is a printf format string and the variable is a Query identifier.

  Pressing the page up/down keys allows scrolling through different
  'pages' of text and/or changing the primary variable bound to the Keypad.
*/
class Page
{
  public:

    /**
      @brief constructor for a Page instance
      @param id unique Page identifier
      @param fmt text (including printf formating) to display
      @param variable identifier (one from Queries) to 'bind' Page to
      @param h pointer to Plugin host

      This constructs a Page with an initial value/variable
    */
    Page(int id,const char* fmt,int variable=0,Plugin* h=0);

    /**
      @brief destructor for vtable
    */
    virtual ~Page();

    /**
      @brief get the Page text from cache
      @return most recently refreshed text value
    */
    const char* value();

    /**
      @brief get the raw format string for this Page
      @return const pointer to c string
    */
    const char* format(){return the.formats[the.current];}

    /**
      @brief get the variable identifier associated with Page
      @return Queries identifier
    */
    int variable(){return the.variables[the.current];}


    /**
      @brief refresh the contents of this Page
      @post value will be up-to-date
    */
    virtual void refresh();

    /**
      @brief set the host of this Page
      @param p Plugin pointer
    */
    void host(Plugin* p){the.host=p;}

    /**
      @brief get the current page index
    */
    inline int current(){return the.current;}

    /**
      @brief get the Page identifier
      @return Pages identifier
    */
    inline int id(){return the.id;}

    /**
      @brief set the Page identifier
      @param v value to assign to id()
    */
    inline void id(int v){the.id=v;}

    /**
      @brief add another text/variable pair to this Page
      @param fmt format string or text to display
      @param variable Queries identifier to bind to
    */
    void add(const char* fmt,int variable=0);

    /**
      @brief make the first page the current page
    */
    void zero();

    /**
      @brief move up to the next page
      @note page up will wrap around if no more pages exist
    */
    void up();

    /**
      @brief move down to the previous page
      @note page down will wrap around if already on first page
    */
    void down();

    /**
      @brief utility labels an interval based on enum value
      @param i interval (0 to 9), as per MMT-8 spec
      @return text label appropriate for interval
    */
    static const char* print_interval(int i){
        const char* s;
        switch(i){
           case 0: s="1/2";break;  // ppq*0.5
           case 1: s="1/4";break;  // ppq
           case 2: s="1/6";break;  // ppq/1.5
           case 3: s="1/8";break;  // ppq/2
           case 4: s="1/12";break; // ppq/3
           case 5: s="1/16";break; // ppq/4
           case 6: s="1/24";break; // ppq/6
           case 7: s="1/32";break; // ppq/8
           case 8: s="1/48";break; // ppq/12
           case 9: s="1/64";break; // ppq/16
           default:s="?/?";break;
        }
        return s;
    }

    /**
      @brief utility labels a file format
      @param i identifier is one of FileParams supplied formats
      @return text label for file format
    */
    static const char* print_fileformat(int i){
        const char* s;
        switch(i){
           case FileParams::XML: s="XML";break;
           case FileParams::MID: s="MID";break;
           case FileParams::SYX: s="SYX";break;
           default:s="???";break;
        }
        return s;
    }

    /**
      @brief get a file chooser compatible file pattern
      @param i file format to get label for
      @return file mask pattern required by file chooser
    */
    static const char* print_filepattern(int i){
        const char* s;
        switch(i){
           case FileParams::XML: s="*.xml";break;
           case FileParams::MID: s="*.mid";break;
           case FileParams::SYX: s="*.syx";break;
           default:s="*.*";break;
        }
        return s;
    }


  protected:
    struct{
        int id; ///< stores the Page identifier
        std::vector<const char*> formats; ///< storage for page format strings
        std::vector<int>variables; ///< storage for variable identifiers
        int current; ///< stores current page index
        char value[254]; ///< cache for current display string
        Plugin* host; ///< stores pointer to host Plugin
    }the; ///< stores the internal Page variables

};

} // namespace gui

#endif // VMMR_GUI_PAGE_H
