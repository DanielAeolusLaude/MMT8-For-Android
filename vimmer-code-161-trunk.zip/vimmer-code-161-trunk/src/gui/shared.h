/*
    VMM-R 0.2
    Virtual MIDI Multitrack Recorder
    Copyright (c) 2006 MIDI Team

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software Foundation,
    Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/
/**
  @file shared.h
  @brief Declaration of shared resource identifiers
*/
#ifndef VMMR_GUI_SHARED_H
#define VMMR_GUI_SHARED_H

#include "resource.h"
#include <iostream>
#include "window_properties.h"
#include "buttons.h"
#include "leds.h"
#include "pages.h"
#include "queries.h"

#define DBG_ECHO(m) std::cout << "DEBUG\t" << m << std::endl;

#endif // VMMR_GUI_SHARED_H
