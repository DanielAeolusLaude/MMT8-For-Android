/*
    VMM-R 0.2
    Virtual MIDI Multitrack Recorder
    Copyright (c) 2006 MIDI Team

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software Foundation,
    Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/
/**
  @file trigger.h
  @brief Declaration of Trigger class
*/
#ifndef VMMR_GUI_TRIGGER_H
#define VMMR_GUI_TRIGGER_H

#include "plugin.h"
#include <fltk/events.h>

namespace gui{

/**
  @class Trigger
  @ingroup win
  @brief A Button event and reaction to raise (the signal mask and slot identifier)

  A Window holds a bunch of these Triggers and when a Button event hapens,
  each Trigger is tested to find a potential match.

  For each matching Trigger, a Plugin pointer is passed via fire() and
  the Trigger will raise the corresponding event and arguments.
*/
class Trigger{
  public:

    /**
      @brief constructor
    */
    Trigger(int id,int event,void* arguments=0,bool down=true,bool active=true,int button=fltk::LeftButton,bool modifier=false);

    bool test(int id_,bool down_,bool active_,int button_,bool modifier_);

    void fire(Plugin* p);

  protected:

    int id;
    bool down;
    bool active;
    int button;
    bool modifier;

    int event;
    void* arguments;

};  // class Trigger

} // namespace gui

#endif // VMMR_GUI_TRIGGER_H
