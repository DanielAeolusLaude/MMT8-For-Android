/*
    VMM-R 0.2
    Virtual MIDI Multitrack Recorder
    Copyright (c) 2006 MIDI Team

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software Foundation,
    Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/
/**
  @file leds.h
  @brief Declaration of Led identifiers
*/
#ifndef VMMR_GUI_LEDS_H
#define VMMR_GUI_LEDS_H

namespace gui{

/**
  @brief Identifiers for Led instances
  @ingroup replica
*/
class Leds{
  public:
    enum{
        PART=3000, ///< Indicates that Part mode is active
        EDIT,      ///< Indicates that editing mode is active
        SONG,      ///< Indicates that Song mode is active
        LOOP,      ///< Indicates that looping is active
        ECHO,      ///< Indicates that MIDI input is being passed to MIDI output
        PLAY,      ///< Indicates that the sequencer is currently playing
        RECORD,    ///< Indicates that the sequencer is currently recording
        TRACK1,    ///< Indicates that Track 1 is active
        TRACK2,    ///< Indicates that Track 2 is active
        TRACK3,    ///< Indicates that Track 3 is active
        TRACK4,    ///< Indicates that Track 4 is active
        TRACK5,    ///< Indicates that Track 5 is active
        TRACK6,    ///< Indicates that Track 6 is active
        TRACK7,    ///< Indicates that Track 7 is active
        TRACK8,    ///< Indicates that Track 8 is active
        IN,        ///< Indicates that MIDI input has been received
        OUT        ///< Indicates that MIDI output is being transmitted
   };
};     // class Leds
}      // namespace gui
#endif // VMMR_GUI_LEDS_H
