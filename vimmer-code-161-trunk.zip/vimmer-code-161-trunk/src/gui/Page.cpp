/*
    VMM-R 0.2
    Virtual MIDI Multitrack Recorder
    Copyright (c) 2006 MIDI Team

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software Foundation,
    Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/
/**
  @file page.cpp
  @brief Implementation of Page class
*/

#include "page.h"

namespace gui{


Page::Page(int id,const char* fmt,int variable,Plugin* p)
{
    the.id=id;
    the.host=p;
    the.current=0;
    add(fmt,variable);
}


Page::~Page()
{
    //dtor
}


void Page::zero(){
    the.current=0;
}


const char* Page::value(){
    return the.value;
}


void Page::add(const char* fmt,int variable){
    if (!fmt==0){
        the.formats.push_back(fmt);
        the.variables.push_back(variable);
    }
}


void Page::up(){
    if((unsigned int)the.current<(the.formats.size()-1)) the.current++;
    else the.current=0;
    refresh();
}


void Page::down(){
    if(the.current>0) the.current--;
    else the.current=the.formats.size()-1;
    refresh();
}

} // namespace gui
