/*
    VMM-R 0.2
    Virtual MIDI Multitrack Recorder
    Copyright (c) 2006 MIDI Team

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software Foundation,
    Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/
/**
  @file button.cpp
  @brief Implementation of Button class
*/

#include "button.h"
#include "keyboard.h"
#include <cstring>
#include <fltk/events.h>
#include <fltk/draw.h>

namespace gui{

Button::Button(int i,Plugin* p,int x,int y,int w,int h,const char* t,int b,const char* tt):
fltk::ToggleButton(x,y,w,h,t)
{
    //ctor
    the.id=i;
    the.host=p;
    the.behaviour=b;
    tooltip(tt);
    //labelfont(fltk::font("Courier New"));
    value(false);
    user_data((void*)false);
}

Button::~Button()
{
    //dtor
}

int Button::handle(int e){
    the.host->on(Button::HANDLE,(void*)e,the.id);
    return 1;
}

int Button::behaviour(){
    return the.behaviour;
}

void Button::layout(){
    float w1=(float)w()*0.76;
    float fs=3.0;
    const char* t=label();
    fltk::setfont(labelfont(),fs);
    float w2=fltk::getwidth(t,6);//strlen(t));

    while(w2<w1){
        fs=fs+0.5;
        fltk::setfont(labelfont(),fs);
        w2=fltk::getwidth(t,6);//strlen(t));
    }
    labelsize(fs);

}



} // namespace gui
