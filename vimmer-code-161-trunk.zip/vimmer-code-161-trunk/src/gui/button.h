/*
    VMM-R 0.2
    Virtual MIDI Multitrack Recorder
    Copyright (c) 2006 MIDI Team

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software Foundation,
    Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/
/**
  @file button.h
  @brief Declaration of Button class
*/
#ifndef VMMR_GUI_BUTTON_H
#define VMMR_GUI_BUTTON_H

#include "shared.h"
#include "plugin.h"
#include "button_params.h"
#include "button_key_params.h"
#include <fltk/ToggleButton.h>

namespace gui{

/**
  @class Button
  @ingroup widgets
  @brief A Button widget with a stretchy label and helpful event handler
*/
class Button : public fltk::ToggleButton
{
  public:

    enum{
        HANDLE=1400, ///< used to identify an event being passed to Button host
        ENTER,       ///< Button has been entered - event identifier
        LEAVE,       ///< Button has been left - event identifier
        PUSH,        ///< Button has been pushed - event identifier
        RELEASE,     ///< Button has been released - event identifier
        LEARN_HOTKEY,///< Button wants to learn a Hotkey - high level event
        ON,          ///< Button is now ON - high level event
        OFF,         ///< Button is now OFF - high level event
        MOMENTARY,   ///< Button behaves as a momentary button
        SHIFT_STICKY,///< Button is momentary, but the SHIFT key will make it 'stick'
        TOGGLE       ///< Button behaves as a toggle button
    };

    /// default button width
    static const int DEFAULT_WIDTH = 60;

    /// default button height
    static const int DEFAULT_HEIGHT = 20;


    /**
     @brief Constructor for a Button
     @param i identifier for this Button
     @param p Plugin parent or host
     @param x Left position of Button
     @param y Top position of Button
     @param w Width of Button
     @param h Height of Button
     @param t label for Button
     @param b optional behaviour expected of Button
     @param tt optional tooltip text

    */
    Button(int i,Plugin* p,int x,int y,int w,int h,const char* t,int b=MOMENTARY,const char* tt=0);

    virtual ~Button(); ///< a happy compiler is a short compile log

    /**
     @brief handle an event from fltk
     @param e event identifier
     @return 0 means ignored, non-zero means consumed
    */
    int handle(int e);

    /**
      @brief internal method resizes label when resized
    */
    void layout();


    /**
      @brief getter for behaviour variable, indicating desired Button behaviour
    */
    int behaviour();

  protected:
    struct{
        int id;            ///< Button identifier
        Plugin* host;      ///< pointer to host (parent) Plugin
        char hovertip[64]; ///< buffer for tooltip
        int behaviour;     ///< indicator for desired behaviour
    } the; ///< local storage for Button properties
};     // class Button
}      // namespace gui
#endif // VMMR_GUI_BUTTON_H
