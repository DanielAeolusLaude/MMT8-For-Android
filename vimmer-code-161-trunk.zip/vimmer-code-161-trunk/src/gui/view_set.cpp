/*
    VMM-R 0.2
    Virtual MIDI Multitrack Recorder
    Copyright (c) 2006 MIDI Team

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software Foundation,
    Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/
/**
  @file view_set.cpp
  @brief Implementation of View::set method
*/
#include "view.h"
#include "Exception.hpp"
#include "LogManager.hpp"
#include "SequencerModes.hpp"

namespace gui{

void View::set(int property,void* value){
    /// @todo check for bad values and wrap or reject accordingly
    switch(property){

        case Queries::FORMAT:
            db.fileformat=wrap((int)value,0,2);
            break;

        case Queries::SELECTION:
            db.selected=wrap((int)value,0,99);
            break;

        case Queries::PART_NUMBER:
            db.p_num=wrap((int)value,0,99);
            db.selected=db.p_num;
            m_Sequencer->getSequencer()->getPartSequencer()->setActivePart(db.p_num);
            break;

        case Queries::PART_NAME:
            sprintf(db.p_nam,"%s",(const char*)value);
            m_Sequencer->getSequencer()->getActiveStep().getPart()->setName(db.p_nam);
            break;

        case Queries::PART_LENGTH:
            db.p_len=wrap((int)value,0,9999);
            break;

        case Queries::SONG_NUMBER:
            db.s_num=wrap((int)value,0,99);
            db.selected=db.s_num;
            m_Sequencer->getSequencer()->getSongSequencer()->setActiveSong(db.s_num);
            break;

        case Queries::SONG_NAME:
            sprintf(db.s_nam,"%s",(const char*)value);
            m_Sequencer->getSequencer()->getSongSequencer()->getSong()->setName(db.s_nam);
            break;

        case Queries::TRANSPOSE_INTERVAL:
            db.transpose_interval=wrap((int)value,-99,99);
            break;

        case Queries::QUANTIZE_INTERVAL:
            db.quantize_interval=wrap((int)value,0,9);
            break;

        case Queries::QUANTIZE_TYPE:
            db.quantize_type=wrap((int)value,0,3);
            break;

        case Queries::TRACK_OFFSET:
            {
                db.o_trk[policy.track]=wrap((int)value,-48,48);
            }
            break;

        case Queries::TRACK_CHANNEL:
            {
                try
                {
                    int ch = wrap((int)value,0,16);
                    SongStep* step = &m_Sequencer->getSequencer()->getActiveStep();
                    step->setTrackChannel(policy.track-1,ch);
                    db.ch_trk[policy.track]=step->getTrackChannel(policy.track-1);
                    DBG_ECHO("Setting track "<< policy.track << " to channel " << ch);
                }
                catch (Exception e)
                {
                    LogManager::getSingleton()->log("Error: couldn't set channel.");
                }
            }
            break;

        case Queries::TRACK_ON:
        case Queries::TRACK_OFF:
            {
                bool turn_it_on=
                   (property==Queries::TRACK_ON)?
                   true:
                   false;
               if (m_Sequencer->getSequencer()->getMode()==SequencerModes::PART_MODE){
                    if (m_Sequencer->getSequencer()->getState()!=SequencerStates::RECORDING)
                    {
                        if(turn_it_on)
                        {
                            db.p_trk[(int)value]=true;
                            m_Sequencer->getSequencer()->getActiveStep().setTrackState((int)value - 1, SongStep::TRACK_STATE_PLAY);
                        }
                        else
                        {
                            db.p_trk[(int)value]=false;
                            m_Sequencer->getSequencer()->getActiveStep().setTrackState((int)value - 1, SongStep::TRACK_STATE_CLEAR);

                        }
                    }
                    else
                    {
                        db.p_trk[(int)value]=turn_it_on;
                    }
               }
               else if (!m_Sequencer->getSequencer()->getSongSequencer()->getSong()->isEmpty()){
                    if(turn_it_on)
                    {
                        db.p_trk[(int)value]=true;
                        m_Sequencer->getSequencer()->getActiveStep().setTrackState((int)value - 1, SongStep::TRACK_STATE_PLAY);
                        cout << "Track[" << ((int)value) <<"]="<< db.p_trk[(int)value] << endl;
                    }
                    else
                    {
                        db.p_trk[(int)value]=false;
                        m_Sequencer->getSequencer()->getActiveStep().setTrackState((int)value - 1, SongStep::TRACK_STATE_CLEAR);
                        cout << "Track[" << ((int)value) <<"]="<<db.p_trk[(int)value] << endl;
                    }
               }
            }
            break;

        case Queries::LOOP:
            {
                db.loop=(bool)wrap((int)value,0,1);
                m_Sequencer->getSequencer()->setLoop(db.loop);
            }
            break;

        case Queries::ECHO:
            {
                db.midi_echo=(bool)wrap((int)value,0,1);
                if(db.midi_echo)
                    m_Sequencer->getDevice()->enableThru();
                else
                    m_Sequencer->getDevice()->disableThru();
            }
            break;

        case Queries::RECORD_NOTES:
            {
                db.record_notes=(bool)wrap((int)value,0,1);
                m_Sequencer->getDevice()->getInputFilter()->setNoteState(db.record_notes);
            }
            break;

        case Queries::RECORD_PITCHBEND:
            {
                db.record_pitchbend=(bool)wrap((int)value,0,1);
                m_Sequencer->getDevice()->getInputFilter()->setPitchBendState(db.record_pitchbend);
            }
            break;

        case Queries::RECORD_AFTERTOUCH:
            {
                db.record_aftertouch=(bool)wrap((int)value,0,1);
                m_Sequencer->getDevice()->getInputFilter()->setAfterTouchState(db.record_aftertouch);
            }
            break;

        case Queries::RECORD_CONTROLLERS:
            {
                db.record_controllers=(bool)wrap((int)value,0,1);
                m_Sequencer->getDevice()->getInputFilter()->setControllerState(db.record_controllers);
            }
            break;

        case Queries::RECORD_PROGCHANGE:
            {
                db.record_progchange=(bool)wrap((int)value,0,1);
                m_Sequencer->getDevice()->getInputFilter()->setProgramChangeState(db.record_progchange);
            }
            break;

        case Queries::RECORD_SYSEX:
            {
                db.record_sysex=(bool)wrap((int)value,0,0); // always OFF.
            }
            break;

        case Queries::RECORD_CHANNEL:
            {
                db.record_channel=wrap((int)value,0,16);
                m_Sequencer->getDevice()->getInputFilter()->setChannel(db.record_channel);
            }
            break;

        case Queries::TEMPO:
            {
                //if (db.mode_part){
                db.p_tempo=wrap((int)value,30,300);
                m_Sequencer->getSequencer()->setTempo(db.p_tempo);
                 //}
                 //else{
                 //   db.s_tempo_temporary=wrap((int)value,30,300);
                 //}
            }
            break;

        case Queries::CLICK_INTERVAL:
            {
                db.click_interval=wrap((int)value,0,9);

                int temp=ClickTrack::getInterval(db.click_interval);
                //DBG_ECHO("Setting click to 1/" << temp);
                m_Sequencer->getSequencer()->setClickInterval(temp);
            }
            break;

        case Queries::CLICK_RECORD:
            {
                db.click_record=(bool)wrap(((int)value),0,1);
                m_Sequencer->getSequencer()->setClickRecord(db.click_record);
            }
            break;

        case Queries::CLICK_PLAY:
            {
                db.click_play=(bool)wrap(((int)value),0,1);
                m_Sequencer->getSequencer()->setClickPlay(db.click_play);
            }
            break;

        case Queries::COUNT_DOWN:
            {
                db.count_down=wrap((int)value,0,99);
                m_Sequencer->getSequencer()->setCountin(db.count_down);
            }
            break;

        case Queries::CLOCK_SOURCE:
            {
                db.clock_source=wrap((int)value,1,3);
            }
            break;

        case Queries::CLOCK_MIDI_OUT:
            {
                db.clock_midi_out=(bool)wrap((int)value,0,1);
            }
            break;

        case Queries::CLOCK_AUTO_START:
            {
                db.clock_auto_start=(bool)wrap((int)value,0,1);
            }
            break;

        case Queries::IN:
            {
                /// @todo get max devices
                db.midi_in=wrap((int)value,-1,m_Sequencer->getDevice()->getInputCount()-1);
                m_Sequencer->getDevice()->setInput( db.midi_in );
            }
            break;

        case Queries::OUT:
            {
                /// @todo get max devices
                db.midi_out=wrap((int)value,-1,m_Sequencer->getDevice()->getOutputCount()-1);
                m_Sequencer->getDevice()->setOutput( db.midi_out );
            }
            break;

        default:
            this->Window::set(property,value);
            break;
    }
}

} // namespace gui
