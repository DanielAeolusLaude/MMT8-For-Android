/*
    VMM-R 0.2
    Virtual MIDI Multitrack Recorder
    Copyright (c) 2006 MIDI Team

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software Foundation,
    Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/
/**
  @file key.h
  @brief Declaration of Key class
*/
#ifndef VMMR_GUI_KEY_H
#define VMMR_GUI_KEY_H

#include <fltk/events.h>

namespace gui{

/**
  @class Key
  @ingroup widgets
  @brief represents a single key on a Keyboard, and various properties of a Key

  This class is used by Keyboard to specify a filter for low level Key events.
*/
class Key{
  public:

    enum{
        DOWN=1000,///< identifies a Key::DOWN event
        UP        ///< identifies a Key::UP event
    };

    /**
      @brief get the 'name' of a particular Key
      @param k Key identifier
      @return text name of Key
    */
    static const char* name(int k){
        switch(k){
            case fltk::AddKey:return "AddKey";break;
            case fltk::BackSpaceKey:return "BackSpaceKey";break;
            case fltk::CapsLockKey: return "CapsLockKey";break;
            case fltk::ClearKey: return "ClearKey";break;
            case fltk::DecimalKey: return "DecimalKey";break;
            case fltk::DeleteKey: return "DeleteKey";break;
            case fltk::DivideKey: return "DivideKey";break;
            case fltk::DownKey: return "DownKey";break;
            case fltk::EndKey: return "EndKey";break;
            case fltk::EscapeKey: return "EscapeKey";break;
            case fltk::F0Key: return "F0Key";break;
            case fltk::F1Key: return "F1Key";break;
            case fltk::F2Key: return "F2Key";break;
            case fltk::F3Key: return "F3Key";break;
            case fltk::F4Key: return "F4Key";break;
            case fltk::F5Key: return "F5Key";break;
            case fltk::F6Key: return "F6Key";break;
            case fltk::F7Key: return "F7Key";break;
            case fltk::F8Key: return "F8Key";break;
            case fltk::F9Key: return "F9Key";break;
            case fltk::F10Key: return "F10Key";break;
            case fltk::F11Key: return "F11Key";break;
            case fltk::F12Key: return "F12Key";break;
            case fltk::HelpKey: return "HelpKey";break;
            case fltk::HomeKey: return "HomeKey";break;
            case fltk::InsertKey: return "InsertKey";break;
            case fltk::Keypad: return "Keypad";break;
            case fltk::Keypad0: return "Keypad0";break;
            case fltk::Keypad1: return "Keypad1";break;
            case fltk::Keypad2: return "Keypad2";break;
            case fltk::Keypad3: return "Keypad3";break;
            case fltk::Keypad4: return "Keypad4";break;
            case fltk::Keypad5: return "Keypad5";break;
            case fltk::Keypad6: return "Keypad6";break;
            case fltk::Keypad7: return "Keypad7";break;
            case fltk::Keypad8: return "Keypad8";break;
            case fltk::Keypad9: return "Keypad9";break;
            case fltk::KeypadEnter: return "KeypadEnter";break;
//            case fltk::LeftAccKey: return "LeftAccKey";break;
//            case fltk::LeftAltKey: return "LeftAltKey";break;
//            case fltk::LeftCmdKey: return "LeftCmdKey";break;
//            case fltk::LeftCtrlKey: return "LeftCtrlKey";break;
            case fltk::LeftKey: return "LeftKey";break;
            case fltk::LeftMetaKey: return "LeftMetaKey";break;
            case fltk::LeftShiftKey: return "LeftShiftKey";break;
            case fltk::MenuKey: return "MenuKey";break;
            case fltk::MultiplyKey: return "MultiplyKey";break;
            case fltk::NumLockKey: return "NumLockKey";break;
            case fltk::PageDownKey: return "PageDownKey";break;
            case fltk::PageUpKey: return "PageUpKey";break;
            case fltk::PauseKey: return "PauseKey";break;
            case fltk::PrintKey: return "PrintKey";break;
            case fltk::ReturnKey: return "ReturnKey";break;
//            case fltk::RightAccKey: return "xxx";break;
            case fltk::RightAltKey: return "AltKey";break;
//            case fltk::RightCmdKey: return "xxx";break;
            case fltk::RightCtrlKey: return "RightCtrlKey";break;
            case fltk::RightKey: return "RightKey";break;
            case fltk::RightMetaKey: return "RightMetaKey";break;
            case fltk::RightShiftKey: return "RightShiftKey";break;
            case fltk::ScrollLockKey: return "ScrollLockKey";break;
            case fltk::SpaceKey: return "SpaceKey";break;
            case fltk::SubtractKey: return "SubtractKey";break;
            case fltk::TabKey: return "TabKey";break;
            case fltk::UpKey: return "UpKey";break;
            case '1': return "\"1\" Key";break;
            case '2': return "\"2\" Key";break;
            case '3': return "\"3\" Key";break;
            case '4': return "\"4\" Key";break;
            case '5': return "\"5\" Key";break;
            case '6': return "\"6\" Key";break;
            case '7': return "\"7\" Key";break;
            case '8': return "\"8\" Key";break;
            case '9': return "\"9\" Key";break;
            case '0': return "\"0\" Key";break;
            case '-': return "\"-\" Key";break;
            case '=': return "\"=\" Key";break;
            case 'q': return "\"q\" Key";break;
            case 'w': return "\"w\" Key";break;
            case 'e': return "\"e\" Key";break;
            case 'r': return "\"r\" Key";break;
            case 't': return "\"t\" Key";break;
            case 'y': return "\"y\" Key";break;
            case 'u': return "\"u\" Key";break;
            case 'i': return "\"i\" Key";break;
            case 'o': return "\"o\" Key";break;
            case 'p': return "\"p\" Key";break;
            case '[': return "\"[\" Key";break;
            case ']': return "\"]\" Key";break;
            case '\\': return "\"\\\" Key";break;
            case 'a': return "\"a\" Key";break;
            case 's': return "\"s\" Key";break;
            case 'd': return "\"d\" Key";break;
            case 'f': return "\"f\" Key";break;
            case 'g': return "\"g\" Key";break;
            case 'h': return "\"h\" Key";break;
            case 'j': return "\"j\" Key";break;
            case 'k': return "\"k\" Key";break;
            case 'l': return "\"l\" Key";break;
            case ';': return "\";\" Key";break;
            case '\'': return "\"\'\" Key";break;
            case 'z': return "\"z\" Key";break;
            case 'x': return "\"x\" Key";break;
            case 'c': return "\"c\" Key";break;
            case 'v': return "\"v\" Key";break;
            case 'b': return "\"b\" Key";break;
            case 'n': return "\"n\" Key";break;
            case 'm': return "\"m\" Key";break;
            case ',': return "\",\" Key";break;
            case '.': return "\".\" Key";break;
            case '/': return "\"/\" Key";break;
            case '`': return "\"`\" Key";break;
        }
        return "???";
    }

    /**
      @brief creates a new Key instance
      @param k key identifier
      @param r repeat switch (false suppresses multiple key down events)
      @param d down switch (false supresses key down event)
      @param u up switch (false supresses key up event)
    */
    Key(int k,bool r=false,bool d=true,bool u=false){
        this->key=k;
        this->repeat=r;
        this->down_event=d;
        this->up_event=u;
        this->down=0;
    }

    int key; ///< stores key code for this Key
    bool repeat; ///< stores repetition option
    bool down_event; ///< flag for down event
    bool up_event; ///< flag for up event
    int down; ///< stores number of down events currently registered with Key



};

} // namespace gui

#endif // VMMR_GUI_KEY_H
