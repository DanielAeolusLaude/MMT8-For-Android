/*
    VMM-R 0.2
    Virtual MIDI Multitrack Recorder
    Copyright (c) 2006 MIDI Team

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software Foundation,
    Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/
/**
  @file hotkey.h
  @brief Declaration of Hotkey class
*/
#ifndef VMMR_GUI_HOTKEY_H
#define VMMR_GUI_HOTKEY_H

#include "plugin.h"
#include "keyboard.h"
#include <fltk/events.h>

namespace gui{
/**
  @class Hotkey
  @ingroup widgets
  @brief Represents a keystroke that raises a user supplied event

  A Hotkey can be any 'regular' key on a Keyboard combined with any combination
  of CTRL,ALT, META, and/or SHIRT modifier keys.

  You can 'test' a Keyboard for the Hotkey combo, and 'fire' the custom event via
  a supplied Plugin.

  This class is included in the project as a replacement for fltk::shortcut(), which requires
  a different signalling method, is not data driven, and doesn't always work.
*/
class Hotkey{
  public:

    /**
      @brief constructor for a HotKey
      @param k key code of HotKey
      @param m key modifiers (SHIFT, CTRL, ALT)
      @param e event identifier to raise
      @param a arguments to pass with event
    */
    Hotkey(int k,int m=0,int e=0,void* a=0);

    /**
      @brief destructor for vtable
    */
    ~Hotkey();

    /**
      @brief get the identity of this HotKey
      @return key code
    */
    inline int key(){return the.key;}

    /**
      @brief test if hotkey is ready to fire
      @param kbd pointer to Keyboard
    */
    bool test(Keyboard* kbd);

    /**
      @brief fire the event associated with HotKey
      @param p Plugin pointer
      @post Plugin will be passed event and arguments via on() method.
    */
    void fire(Plugin* p);

  protected:
    struct {
        int key; ///< stores key code
        int modifiers; ///< stores key modifiers (SHIFT, CTRL, ALT)
        int event; ///< stores resulting event identifier
        void* arguments; ///< stores optional arguments
    }the; ///< storage for HotKey variables

};  // class Hotkey

} // namespace gui

#endif // VMMR_GUI_HOTKEY_H
