/*
    VMM-R 0.2
    Virtual MIDI Multitrack Recorder
    Copyright (c) 2006 MIDI Team

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software Foundation,
    Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/
/**
  @file button_params.h
  @brief Declaration of ButtonParams class
*/
#ifndef VMMR_GUI_BUTTON_PARAMS_H
#define VMMR_GUI_BUTTON_PARAMS_H

namespace gui{

/**
  @class ButtonParams
  @ingroup widgets
  @brief Wraps the essential parameters for defining a Button
*/
class ButtonParams{
  public:
    int id;///< button identifier
    int x; ///< left position
    int y; ///< top position
    int w; ///< width in pixels
    int h; ///< height in pixels
    const char* t; ///< label for button
    int b; ///< behaviour type
    const char* tt; ///< tooltip for button

    /**
      @brief create a ButtonParams instance with given parameters
      @param i identifier for Button
      @param x left position for Button
      @param y top position for Button
      @param w width for Button
      @param h height for Button
      @param t label for Button
      @param b behaviour indicator for Button
      @param tt tooltip for Button
    */
    ButtonParams(int i,int x,int y,int w,int h,const char* t,int b=0,const char* tt=0){
        this->id=i;
        this->x=x;
        this->y=y;
        this->w=w;
        this->h=h;
        this->t=t;
        this->b=b;
        this->tt=tt;
    }
};     // class ButtonParams
}      // namespace
#endif // VMMR_GUI_BUTTON_PARAMS_H
