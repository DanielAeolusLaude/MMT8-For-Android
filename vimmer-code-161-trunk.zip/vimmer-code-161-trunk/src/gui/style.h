/*
    VMM-R 0.2
    Virtual MIDI Multitrack Recorder
    Copyright (c) 2006 MIDI Team

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software Foundation,
    Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/
/**
  @file style.h
  @brief Declaration of Style class
*/
#ifndef VMMR_GUI_STYLE_H
#define VMMR_GUI_STYLE_H

#include "shared.h"
#include <fltk/Widget.h>
#include <map>

namespace gui{

/**
  @class Style
  @ingroup widgets
  @brief a container for style rules
*/
class Style
{
  public:

    // variations within a Style::id();

    static const int OUT_ON = 1600;
    static const int OUT_OFF = 1601;
    static const int OVER_ON = 1602;
    static const int OVER_OFF = 1603;
    static const int DOWN_ON = 1604;
    static const int DOWN_OFF = 1605;

    static const int BG_IMAGE = 1650;
    static const int BG_COLOR = 1651;
    static const int BOX = 1652;
    static const int LABEL_COLOR = 1653;
    static const int LABEL_BOLD = 1654;
    static const int LABEL_ITALIC = 1655;

    /**
      @brief constructor
    */
    Style(int id,int context);

    virtual ~Style();

    inline int id(){return the.id;}

    inline int context(){return the.context;}

    void add(int item,void* value);
    void remove(int item);
    void apply(fltk::Widget* w,int v=0);

  protected:

    struct{
        int id;
        int context;
        std::map<int,void*> items;
    }the;

  private:
};

} // namespace gui

#endif // VMMR_GUI_STYLE_H
