/*
   Virtual MIDI Multitrack Recorder
   Copyright (c) 2006 MIDI Team

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/

/**
   Application.hppile Application.hpp
   Charles Weld, David Wilson, James Brown, Jonathan Van Rossum, and Matthew Harrolduthor Charles Weld, David Wilson, James Brown, Jonathan Van Rossum, and Matthew Harrold
   @brief Declaration of class Application, part of Virtual MIDI Multitrack Recorder
*/

#ifndef VIMMER_APPLICATION_H
#define VIMMER_APPLICATION_H

//#include "VimmerPrerequisites.hpp"

namespace Vimmer
{
    /**
     * Starts the application, ie creats a view and backend and then links them together.
     */
    class Application
    {
    public:
        /**
         * Gives the user a choose of which setup they want to run, and then runs that setup.
         */
        int run(int argc, char** argv);
    private:
        /**
         * The main setup, this creates the real Vimmer view and Backend and links them together.
         */
        int runMain(int argc, char** argv);

        /**
         * Chuck's run method.
         */
        int runCharles(int argc, char** argv);

        /**
         * John's run method.
         */
        int runJohn(int argc, char** argv);

        /**
         * Matt's run method.
         */
        int runMatt(int argc, char** argv);

        /**
         * David's run method.
         */
        int runDavid(int argc, char** argv);

        /**
         * Jimi's run method.
         */
        int runJimi(int argc, char** argv);
    };
}

#endif  //_APPLICATION_H
