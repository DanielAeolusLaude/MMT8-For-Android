/*
   Virtual MIDI Multitrack Recorder
   Copyright (c) 2006 MIDI Team

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/

/**
   Application.cppile Application.cpp
   Charles Weld, David Wilson, James Brown, Jonathan Van Rossum, and Matthew Harrolduthor Charles Weld, David Wilson, James Brown, Jonathan Van Rossum, and Matthew Harrold
   @brief Declaration of class Application, part of Virtual MIDI Multitrack Recorder
*/

#include "Application.hpp"
#include "VimmerPrerequisites.hpp"

#include <iostream>

// chucks includes (don't touch :o
#include "Device.hpp"
#include "VimmerSequencer.hpp"
#include "XMLExporter.hpp"
#include "XMLImporter.hpp"
//#include "cgui.hpp"
#include "ModernSequencer.hpp"
#include "StringCompress.hpp"
// chucks section end.

// JVR's includes
#include "Events.hpp"
#include "ChannelMessage.hpp"
#include "Track.hpp"
#include "MultiTrack.hpp"
#include "Sequencer.hpp"
#include "Observer.hpp"
#include "Observable.hpp"
#include "Win32InputPort.hpp"
#include "Win32OutputPort.hpp"
#include "StandardMIDIImporter.hpp"
#include "MMT8Importer.hpp"
#include "MMT8Exporter.hpp"
#include "Store.hpp"
// JVR's includes - end

//Dave's includes
#include "Exception.hpp"
#include "ExceptionHandler.hpp"
#include "LogManager.hpp"
#include "ConfigurationManager.hpp"
#include "Group.hpp"
#include "Entry.hpp"
//Dave concludes his includes

// Matt's includes

// Matt's includes -end

using namespace std;
using namespace MIDIToolkit;

namespace Vimmer
{
    class JvrObserver : public MIDIToolkit::Observer
    {
        void onEvent(int id, void* param);
    };

    int Application::run(int argc, char** argv)
    {
        int section_result = 0;
        try
        {
            cout << "Who's app do you want to run?" << endl;
            cout << "0 - Main" << endl;
            cout << "1 - Charles" << endl;
            cout << "2 - Matt" << endl;
            cout << "3 - John" << endl;
            cout << "4 - Jimi" << endl;
            cout << "5 - David" << endl;
            cout << "6 - Exit" << endl;
            cout << "Menu: ";
            int result = 0;
            cin >> result;

            switch (result)
            {
                case 0:
                {
                    cout << endl << "Running Main's App" << endl;
                    section_result = runMain(argc, argv);
                    break;
                }
                case 1:
                {
                    cout << endl << "Running Charles's App" << endl;
                    section_result = runCharles(argc, argv);
                    break;
                }
                case 2:
                {
                    cout << endl << "Running Matt's App" << endl;
                    section_result = runMatt(argc, argv);
                    break;
                }
                case 3:
                {
                    cout << endl << "Running John's App" << endl;
                    section_result = runJohn(argc, argv);
                    break;
                }
                case 4:
                {
                    cout << endl << "Running Jimi's App" << endl;
                    section_result = runJimi(argc, argv);
                    break;
                }
                case 5:
                {
                    cout << endl << "Running David's App" << endl;
                    section_result = runDavid(argc, argv);
                    break;
                }
                case 6:
                {
                    cout << endl << "Exiting" << endl;
                    section_result = 0;
                    break;
                }
                default:
                {
                    cout << endl << "Exiting" << endl;
                    section_result = 0;
                    break;
                }
            }
        }
        catch (Exception e)
        {
            ExceptionHandler eh;
            eh.handle(e);
        }

        // cleanup log manager
        delete (LogManager::getSingleton());

        return section_result;
    }

    int Application::runMain(int argc, char** argv)
    {
        return 0;

    }

    int Application::runCharles(int argc, char** argv)
    {

        return 0;
    }

    int Application::runJohn(int argc, char** argv)
    {
        std::cout << "\n";

        // DEBUGGING
        MIDIToolkit::Win32InputPort* wi = new MIDIToolkit::Win32InputPort();
        std::cout << "Win32InputPort w->getNumPorts() = " << wi->getNumPorts() << "\n";
        for (int i=0; i<wi->getNumPorts(); i++)
        {
            std::cout << "    Win32InputPort w->getPortName(" << i << ") = " << wi->getPortName(i) << "\n";
        }
        std::cout << "\n";
        free(wi);

        // DEBUGGING
        MIDIToolkit::Win32OutputPort* wo = new MIDIToolkit::Win32OutputPort();
        std::cout << "Win32OutputPort w->getNumPorts() = " << wo->getNumPorts() << "\n";
        for (int i=0; i<wo->getNumPorts(); i++)
        {
            std::cout << "    Win32OutputPort w->getPortName(" << i << ") = " << wo->getPortName(i) << "\n";
        }
        std::cout << "\n";
        free(wo);

        // MultiTrackLink
        MIDIToolkit::MultiTrackLink mtl;

        // Sequencer
        cout << "Sequencer: Creating SEQUENCER ...\n";
        MIDIToolkit::Sequencer sequencer;
        cout << "    Done.\n\n";

        // Device
        cout << "Device: Creating DEVICE ...\n";
        MIDIToolkit::Device device;
        device.connect(&sequencer);
        sequencer.connect(&device);

        // Get Devices From User
        int inputdevice;
        int outputdevice;
        cout << "    Select Input device, -1=none): ";
        cin >> inputdevice;
        if (inputdevice != -1)
        {
            cout << "selecting input..." << endl;
            device.setInput(inputdevice);
        }
        cout << "    Select Output device, -1=none): ";
        cin >> outputdevice;
        if (outputdevice != -1) device.setOutput(outputdevice);
        cout << "    Starting device: ";
        device.start();
        cout << "    Done.\n\n";

        // DEBUGGING - Pretend Observer
        JvrObserver j;
        sequencer.addObserver(&j);

        // Store
        Vimmer::Store store(100,100);

        // Importers
        Vimmer::StandardMIDIImporter smi(&store);
        Vimmer::MMT8Importer mmt8i(&store);

        // Exporters
        Vimmer::MMT8Exporter mmt8e(&store);


        // Load Part 00
        cout << "Sequencer: Connecting Sequencer to MultiTrackLink ...\n";
        int partnumber = 0;
        mtl.setLink(store.getPartSystem()->getPart(partnumber));
        sequencer.setMultiTrackLink(&mtl);
        cout << "Sequencer: Connecting Device to Sequencer ...\n";

        while(true)
        {
            char cmd;

            // what do we want to do know.
            cout << "\n\n";
            cout << "Tempo: " << sequencer.getTempo() << " bpm\n";
            cout << "PART " << partnumber << ": " << ((Part*)(mtl.getLink()))->getName() << "\n";
            cout << "Length: " << mtl.getLink()->getLength() << " beats\n";
            cout << "Tracks: ";
            for (int i=0; i< mtl.getLink()->count(); i++)
            {
                if (mtl.isPlaying(i))
                {
                    cout << "[x] ";
                }
                else
                {
                    cout << "[ ] ";
                }
            }
            cout << "\nData:   ";
            for (int i=0; i< mtl.getLink()->count(); i++)
            {
                if (mtl.getLink()->getTrack(i)->empty())
                {
                    cout << "[ ] ";
                }
                else
                {
                    cout << "[x] ";
                }
            }
            cout << "\nCommands:\n";
            cout << "  (p-play, s-stop, r-record, <-rewind, t-tempo, q-quit):\n";
            cout << "  (z - Load Part, x - Load Song):\n";
            cout << "  (l - load standard midi file):\n";
            cout << "  (m - load mmt8 sysex file):\n";
            cout << "  (v - save mmt8 sysex file):\n";
            cout << "\n";
            cout << "  (b - transpose)\n";
            cout << "  (n - quantize)\n";
            cout << ">";
            cin >> cmd;
            switch (cmd)
            {
                case 'b':
                {
                    unsigned int tracknumber;
                    int semitones;
                    Track* t;
                    std::cout << "\nTRANSPOSE";
                    std::cout << "\nEnter track number (1-8): ";
                    std::cin >> tracknumber;
                    std::cout << "\nEnter number of semitones (+ or -): ";
                    std::cin >> semitones;
                    t = mtl.getLink()->getTrack(tracknumber - 1);
                    t->transpose(semitones);
                    break;
                }
                case 'n':
                {
                    unsigned int tracknumber;
                    int interval;
                    Track* t;
                    std::cout << "\nQUANTIZE";
                    std::cout << "\nEnter track number (1-8):";
                    std::cin >> tracknumber;
                    std::cout << "\nEnter interval";
                    std::cout << "\n(2, 4, 6, 8, 12, 16, 24, 32, 48, 64): ";
                    std::cin >> interval;
                    t = mtl.getLink()->getTrack(tracknumber - 1);
                    t->quantize(interval, 0);
                    break;
                }
                case 'z':
                {
                    std::cout << "Enter part number (00-99)";
                    std::cin >> partnumber;
                    mtl.setLink(store.getPartSystem()->getPart(partnumber));
                    sequencer.setMultiTrackLink(&mtl);
                    break;
                }
                case 'x':
                {
                    std::cout << "Feature not supported yet.\n\n";
                    break;
                }
                case 'm':
                {

                    //cout << "Importing MMT8 SYSEX file (z:\\mmt8fact.syx) ...";
                    //mmt8i.import("z:\\mmt8fact.syx", 0);
                    cout << "Importing MMT8 SYSEX file (z:\\Graham-MMT8.syx) ...";
                    mmt8i.fileImportPart("z:\\Graham-MMT8.syx", 0);
                    cout << "done. \n";

                    sequencer.setMultiTrackLink(&mtl);
                    break;
                }
                case 'v':
                {

                    cout << "Exporting MMT8 SYSEX file (z:\\mmt8_export.syx) ...";
                    mmt8e.fileExportStore("z:\\mmt8_export.syx");
                    cout << "done. \n";
                    break;
                }
                case 'l':
                {

                    cout << "Importing STANDARD MIDI file (z:\\cat.mid) ... ";
                    smi.import("z:\\cat.mid", mtl.getLink());
                    cout << "done. \n";

                    cout << "Setting length ... ";
                    mtl.getLink()->setLength(10*60*120);
                    cout << "done. \n";

                    cout << "Printing track ... ";
                    //t0->print(2);
                    cout << "done. \n";

                    sequencer.setMultiTrackLink(&mtl);
                    break;
                }

                case '1':   mtl.setTrackState(0, mtl.isPlaying(0) ? MultiTrackLink::TRACK_STATE_CLEAR : MultiTrackLink::TRACK_STATE_PLAY); break;
                case '2':   mtl.setTrackState(1, mtl.isPlaying(1) ? MultiTrackLink::TRACK_STATE_CLEAR : MultiTrackLink::TRACK_STATE_PLAY); break;
                case '3':   mtl.setTrackState(2, mtl.isPlaying(2) ? MultiTrackLink::TRACK_STATE_CLEAR : MultiTrackLink::TRACK_STATE_PLAY); break;
                case '4':   mtl.setTrackState(3, mtl.isPlaying(3) ? MultiTrackLink::TRACK_STATE_CLEAR : MultiTrackLink::TRACK_STATE_PLAY); break;
                case '5':   mtl.setTrackState(4, mtl.isPlaying(4) ? MultiTrackLink::TRACK_STATE_CLEAR : MultiTrackLink::TRACK_STATE_PLAY); break;
                case '6':   mtl.setTrackState(5, mtl.isPlaying(5) ? MultiTrackLink::TRACK_STATE_CLEAR : MultiTrackLink::TRACK_STATE_PLAY); break;
                case '7':   mtl.setTrackState(6, mtl.isPlaying(6) ? MultiTrackLink::TRACK_STATE_CLEAR : MultiTrackLink::TRACK_STATE_PLAY); break;
                case '8':   mtl.setTrackState(7, mtl.isPlaying(7) ? MultiTrackLink::TRACK_STATE_CLEAR : MultiTrackLink::TRACK_STATE_PLAY); break;

                case 't':
                    int t;
                    std::cout << "\nEnter tempo: ";
                    std::cin >> t;
                    sequencer.setTempo(t);
                    break;

                case '<':
                case ',':
                    sequencer.jump(0);
                    break;
                case 'a':
                {
                    String t = "number of track to print [1-8]";
                    t += 'c';
                    std::cout << t;
                    int i;
                    std::cin >> i;
                    mtl.getLink()->getTrack(i-1)->print(2);
                    std::cout << "\n\n";
                    break;
                }
                case 'p':
                    sequencer.play();
                    break;
                case 's':
                    sequencer.stop();
                    break;
                case 'r':

                    // Disable all tracks for PLAYING
                    // Set TRACK 0 to record.
                    mtl.setTrackStateAll(MultiTrackLink::TRACK_STATE_CLEAR);
                    mtl.setTrackState(0, MultiTrackLink::TRACK_STATE_RECORD);

                    sequencer.record();
                    sequencer.play();
                    break;
                case 'q':
                    goto here;
                    break;
                default:
                    cout << "Unknown Command" << endl;
            }
        }
        here:

        device.stop();

        return 0;
    }

    int Application::runMatt(int argc, char** argv)
    {
        return 0;
    }

    int Application::runDavid(int argc, char** argv)
    {
        Group root = ConfigurationManager::getSingleton().getRoot();
        root.addGroup("Test1");

        Group group = root.getGroup("Test1");
        root.addEntry("Entry1", "val1");

        Group test1 = root.getGroup("Test1");
        std::cout << test1.getName() << "\n";

/*
        Group getGroup(String name);
        Entry getEntry(String name);

*/


        /*
        Exception e(999999,"OMGWTFBBQ! what did you DO! you've screwed it up royally now!","tomato please.");

        ExceptionHandler eh;
        eh.handle(e);


        return 0;*/
    }

    int Application::runJimi(int argc, char** argv)
    {
       VimmerSequencer* vm = new VimmerSequencer();

        bool exit = false;
        char cmd;
        while(!exit)
        {
            // get sequencer state and update screen
            int state;
            vm->invokeQuery("sequencer state", &state);
            switch (state)
            {
                case 0:
                    cout << "Sequencer is Playing" << endl;
                    break;
                case 1:
                    cout << "Sequencer is Recording" << endl;
                    break;
                case 2:
                    cout << "Sequencer is Stopped" << endl;
                    break;
                default:
                    cout << "Sequencer State Unknown" << endl;
            }

            // what do we want to do know.
            cout << "Command(p-play,s-stop,r-record, e-exit):";
            cin >> cmd;
            switch (cmd)
            {
                case 'p':
                    vm->invokeCommand("play", NULL);
                    break;
                case 's':
                    vm->invokeCommand("stop", NULL);
                    break;
                case 'r':
                    vm->invokeCommand("record", NULL);
                    break;
                case 'e':
                    exit = true;
                    break;
                default:
                    cout << "Unknown Command" << endl;
            }
        }

        delete vm;

        return 0;
    }

    void JvrObserver::onEvent(int id, void* param)
    {
        switch (id)
        {
            case Events::SEQUENCER_STOPPED:
            {
                std::cout << "\nStopped.\n\n" << std::endl;
                break;
            }
            case Events::SEQUENCER_PLAYING:
            {
                std::cout << "\nPlaying.\n\n" << std::endl;
                break;
            }
            case Events::SEQUENCER_MULTITRACK_END:
            {
                std::cout << "\nReached end of Multitrack.\n\n" << std::endl;
                break;
            }
            case Events::SEQUENCER_BEAT_UPDATE:
            {
                int current_beat = *((int*)param);
                std::cout << "\r     Beat: " << current_beat;
                break;
            }
            case Events::SEQUENCER_ACTIVITY_MIDI_IN:
            {
                std::cout << "\r I";
                break;
            }
            case Events::SEQUENCER_ACTIVITY_MIDI_OUT:
            {
                std::cout << "\r   O";
                break;
            }
            default:
            {
                break;
            }
        }
    }

}
