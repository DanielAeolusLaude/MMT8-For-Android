#include <iostream>

#include "Application.hpp"

int main(int argc, char** argv)
{
    Vimmer::Application app;
    return app.run(argc, argv);
}
