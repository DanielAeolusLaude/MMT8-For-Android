/**
  @mainpage VMM-R Users Manual

  <img src="main.png" width="400" height="280" alt="Virtual MIDI Multitrack Recorder (VMM-R)" border="0">
*/

/**
  @defgroup toc Table of Contents
*/

/**
  @defgroup intro Introduction
  @ingroup toc
  @brief A brief introduction to VMM-R

  VMM-R is a tribute to the classic Alesis MMT-8 hardware sequencer. A
sequencer is a device or program that allows the user to record, edit,
save, and play back sets of commands which relate to music performance.

The VMM-R sequencer emulates the MMT-8 with the objective of resurrecting
the efficient operational style of late 1980's MIDI sequencing hardware,
complete with a look-a-like interface and backward compatibility.
Sequencers have become expensive and complicated in modern times, and the
number of independent enthusiasts has dropped. The VMM-R sequencer is
intended to be both cheap (free) and simple to use in order to bring back
those enthusiasts. The Alesis MMT-8 sequencer already has a strong fan
base, and creating an emulated version of this catering to those
enthusiasts will ensure the VMM-R sequencer realises its potential.

The Alesis MMT-8 is a Multi-Track MIDI Recorder that was designed with
the user in mind. For this reason the MMT-8 was very simple to use and
was utilised by a number of bands in live performances. VMM-R, like the
Alesis MMT-8, is designed to be a simple but powerful. It contains 8
tracks that can be played back simultaneously and operates in a manner
similar to an 8 track tape recorder.

Now you can sound like DuranDuran from the comfort of your own beanbag.
Record countless songs on this virtual 8-track MIDI recorder ... You
really can't touch this!


*/

/**
  @defgroup credits Credits
  @ingroup intro
  @brief Wall of shame, those to blame

MIDI Team is the ever popular "Gang of four" + 1!  From
varying age groups, interests and backgrounds have combined
well as a unit and expressed the talents and ability needed to
compliment each other within the constraints of this project.

Our client, Graham Meredith - a Chemistry Technical Officer at
University of Tasmania with 25 years musical experience harks
from an era when pioneering enthusiasts and wealthy pop stars
dabbled in digital mayhem - the 1980's.

When only the best would do, the 1980s produced countless inventions
and applications in digital music, with MIDI forming the central digital
language of music. The pure elegance of the best 1980s technology is
not matched in today's modern computer based sequencers.

Graham commissioned this project to put some cool into the tool. Our
task is to harness the power of the 1980s and temporally transport this
level of funky into a modern solution and desired a virtual replica of his
favourite "Beatbox".

His sound knowledge of the product and expertise handling were an
excellent utility and helped considerably with the project.





*/

/**
  @defgroup jimi Jimi James Brown
  @ingroup credits




As a �Weekend Warrior Musician� I was immediately attracted to this
project. Not only was this an opportunity to play about with some musical
creations it provided an opportunity to create a functional program not
to mention my formative years were spent in the 1980�s admiring �Band in
a box� musicians in every corner pub � with �flock of seagulls�
hairstyles and suede winklepickers?!

After 10 years in the I.T. Industry from sales to web design this project
placed me in the position of working with four complete strangers and a
programming language (C++) I knew very little about. Although
fundamental, the project required the team to follow a process of design,
documentation and implementation from a client brief and ideally
producing an open source, stand-alone executable for a client who will
actually use it. The success of the job was a great team of people all
interested in achieving the same goal.

Not sure what the future holds for a man with an interest in reproducing
a hardware module�s which although efficient are really unpleasant to the
eye � maybe P.R. Manager for Jeff Fenech's return fight.

Always remember � Rock�n�Roll!!!




*/

/**
  @defgroup chuck Charles Weld
  @ingroup credits



Unlike many of my team mates, I was not attracted to the project from a
musical stand point, though this was an advantage. For me it was more the
challenge of writing a C++ program from the ground up that would actually
be useful to a number of people.

I've also gained a lot of insight into how to right efficient C++
programs from doing the MIDI project which as mentioned previously was
one of the reasons why I chose this project. However I also learned a lot
more about the software development life cycle as a whole.

My main interests over the next few years will be developing my knowledge
into a number of sections in computing, but mainly focusing on topics
related to AI such as signal processing, 3D simulation, and knowledge
based systems. Ideally I'd like to work on a system in which it is fed
real world data, processed into a 3D model, and be capable of allowing
the user to modify this data preferably in real-time.



*/

/**
  @defgroup matt Matthew Harrold
  @ingroup credits




21 years ago I bought a Yamaha DX7, the first commercially available MIDI
equipped keyboard. A few years later I worked in a Club Lounge Duo using
the very hardware this project was to emulate. Yes, I was an owner of an
MMT-8 sequencer.

It seemed appropriate to pick a project that could leverage my knowledge
of MIDI (and music) whilst giving me a real programming challenge. I was
familiar with C and C++ through many years of computer hacking and
pointless coding, now I was presented a project with a purpose. I had
never attempted to mix music and computer programming, this was the most
compelling reason.
Personally, it has opened up an entire world of open source software,
online collaboration, computer music, and a rewarding hobby that I will
continue beyond this project.

Almost all my past programming experience has been as a solo programmer,
usually working for a non technical client. Joining forces with four
other programmers, to build a classic MIDI sequencer for a client who is
a fellow '80's era muso made the project an enjoyable experience

As a programmer, the implementation of this MIDI sequencer was both
difficult and rewarding. Technically, the largest obstacle we had to
overcome was not how to do it, but which way to do it. With the wide
variety of skills in our team, we had many options at our disposal, and
this made choosing a single approach difficult. The program is much more
feature rich, and robust as a consequence, so our main challenge was also
the source of our success.

The project was very useful as a learning-by-doing tool and I've gained
heaps of C++ and development tool experience. I love my Apple iBook, but
programming on Windows is surprisingly fun, and I've since brought a
Windows laptop. I've regained an entire platform after a 5 year hiatus,
so that can't be too bad. I consider my cross-platform transition as the
most helpful skill acquired. I have development tools for both Windows
and Mac OSX now, and I've finally invested in some computer music tools.


*/

/**
  @defgroup jon Jonathan Van Rossum
  @ingroup credits


jvr85@users.sourceforge.net
Of a myriad of projects, it was this one which interested me. I was
already involved with music, and this project provided a different aspect
to learn about. I achieved sound from a hollow piece of wood in grade 3
(cello), and was presented with a glorified plastic pipe (clarinet) in
grade 7.

From this project, I gained experience developing medium-scale software
that matters - not only is it something people actually care about, the
enthusiasm of the team was matched only by that of our client.
Implementation of this project required learning C++, which was valuable
in itself. I had previously used other languages such as Java, Assembler,
C, BASIC, and Haskell.

I am in my fourth and final year, completing a Science \ Computing
combined degree. The science degree includes a major in each of maths and
physics. I'd like to work in the computing \ IT industry generally, but
have a particular interest in computing for scientific applications.

*/

/**
  @defgroup dave David Wilson
  @ingroup credits

I am currently studying for a bachelor of science degree, majoring in
Computing and Mathmatics..

As a keen programmer and music enthusiast, the MIDI project stood out as
a challenging undertaking, requiring intricate methods of programming
which link existing OS and other hardware systems via C++; something I
had not previously attempted. I was also drawn to this project because of
its fun side; the VMM-R sequencer is a tool for MIDI enthusiasts and as
such it is used primarily for enjoyment, and having members of the team
who have been in the music scene in the eighties their enthusiasm has
spread through the team.

Although I have had plenty of experience working in a team, this was the
first time it has been in a professional environment, and as such there
is more tension to deal with and stressful situations to overcome. I also
gained several more tangible skills, such as a solid knowledge of the C++
programming language, and many tips/tricks/workarounds/hacks to fix many
problems that can occur.

*/

/**
  @defgroup midi About MIDI
  @ingroup intro
  @brief A brief introduction to MIDI

    <b>Brief History</b>








    To gain the full complexity and functionaltiy of MIDI, it is suggested
    any new user should attempt to understand some basic principles about
    musical instruments. MIDI (Musical Instrument Digital Interface) is a
    music industry standard communications protocol that lets MIDI
    instruments and sequencers (or computers running sequencer software) talk
    to each other to play and record music.

    All musical instruments make a sound under a musicians control, for
    example, a musician can push down a key on a piano, begin dragging a bow
    across a violin string or pick a guitar string to start a sound. Let's
    refer to this action as a "Note On".  A musician pushes down (HOLDS) a
    key on a keyboard. This action creates a musical note which continues to
    sound while the musician continues holding down the key. This single
    action is known as a "Note-On" to MIDI.  Most instruments also allow the
    musician to stop the sound at any given time -  Let's refer to the action
    as a "Note Off".

    Instruments can play distinct pitches (ie, a musical scale). For example,
    an acoustic piano has 88 keys, or 88 distinct pitches/notes. There are
    other things that many musical instruments may have in common, for
    example, most instruments can make sounds at various volumes or if the
    pianist pushes down a key with great force, the resulting note will be
    louder than if they were to gently press down the key.

    Suffice it to say that MIDI can do everything musical to an electronic
    instrument that a human being can physically do, and a few things that
    humans can't do and will almost always require the use of a "sequencer"
    or sequencing unit of some kind which does exactly what it says -
    sequences all MIDI data into legible arrangments.

    With the brief music appreciation over let's look more at what MIDI
    actually is.  As mentioned earlier MIDI is a specific set of digital
    communication standards introduced to the analog music industry in the 1980's.

    It was developed because of a desire by technocratic musicians who began
    using "digital technology" to enable flexibility and greater resources at
    a comparatively minimal cost and to also aid in musical production -
    effectively allowing a single musician the ability to create layered
    compositions having complete artistic control and the ability to edit as
    freely and often as needed of practically any instrument using a single
    midi device (or many as they can "daisy chain") from the comfort of a
    small studio space, even a room at home.

    The introduction of this new "tool" also enabled musicians to combine the
    sounds of several instruments playing in perfect unison to "thicken" or
    layer a musical part. If they want to blend certain patches upon those
    instruments. Perhaps you wish to blend the sax patches upon 5 different
    instruments to create a more authentic-sounding sax section in a big
    band. But, since a musician has only two hands and feet, it's not
    possible to play 5 instruments at once unless he has some method of
    remote control.

    Or, sometimes a musician wants to use only one physical keyboard to
    control several, separate sound modules. In the old days, every single
    musical instrument manufactured had its own built-in method of
    controlling it. For example, an electronic organ, an electronic piano, a
    string ensemble, a synthesizer, etc, each had its own built-in keyboard.
    This got to be rather expensive, as the physical keyboard is one of the
    more expensive parts of an instrument. Also, all of those keyboards tend
    to take up a lot of space, which is a problem for a gigging musician. So
    musicians thought "Wouldn't it be great if I could buy a small box that
    made organ sounds into which I could plug a physical keyboard? And
    wouldn't it be great if I could buy other boxes that made piano, string,
    synth, etc, sounds, into which I could plug that same keyboard? And
    wouldn't it be great if I could attach them all together simultaneously,
    and switch the keyboard between playing any of them? I could save money
    and space. All I need is a standard for remotely controlling all of those
    boxes with that one keyboard."

    Automatic control is when the musician uses some other device to play a
    musical instrument as if another musician were playing it. (Such a device
    is referred to as a Sequencer).

    For example, some musicians want to be able to have "backing tracks" in
    live performance, but they found it too cumbersome, unreliable, and
    limiting to use prerecorded tapes. They wanted a method that allowed more
    flexibility, perhaps to do things such as subtlely alter the arrangement
    live. To achieve this, rather than playing pre-recorded backing tracks,
    they wanted a method to automatically control their instruments during
    the performance using a device that could "intelligently" manipulate the
    arrangement (such as a computer).

    So, musicians had a need to remotely or automatically control their
    musical instruments, and they wanted a method that wasn't tied to one
    particular manufacturer's product, nor one particular type of instrument.
    (ie, They wanted a method that worked as well with an electronic piano as
    it did with a drum box, for example). They wanted a standard that could
    be useful in controlling any electronic musical device. To satisfy this
    need, a few music manufacturers got together in mid 1983 and created
    MIDI, which stands for Musical Instrument Digital Interface. (For more
    information about the history of MIDI's development, see The beginnings
    of MIDI).

    In a nutshell, that's what MIDI is -- a set of commands that electronic
    devices digitally pass between their MIDI jacks to tell each other what
    to do (ie, what actions to perform).

    Bring your sheet music to life! Hear the music collecting dust on your
    shelf. If you can hear it, you can play it! See it play! Print out lead
    sheets.




























    <b>MIDI Messages</b>

    But MIDI is much more than just some jacks on
    an electronic instrument. In fact, MIDI is a lot more than just hardware.
    Mostly, MIDI is an extensive set of "musical commands" which electronic
    instruments use to control each other. The MIDI instruments pass these
    commands to each other over the cables connecting their MIDI jacks
    together. (ie, Those MIDI signals that I referred to above are these
    commands).So, what is a MIDI command? A MIDI command consists of a few
    (usually 2 or 3) "data bytes" (like the data bytes within files that you
    have on your computer's hard drive). These data bytes are merely a series
    of numbers. We refer to one of these groups of numbers as a "message"
    (rather than a command). There are many different MIDI messages, and each
    one correlates to a specific musical action. For example, there is a
    certain group of numbers that tells an instrument to make a sound. (This
    would be that "Note On" message which I mentioned earlier). There is a
    different group of numbers that tells an instrument to stop making a
    sound. (This is the "Note Off" message). One of the numbers within that
    "Note On" or "Note Off" message tells the instrument which one of its
    "keys" (ie, notes) to start or stop sounding. (Remember that a piano has
    88 notes. MIDI instruments can have a maximum of 128 different notes,
    although some instruments respond to only messages limited to a smaller
    range, say 72 notes).Many electronic instruments not only respond to MIDI
    messages that they receive (at their MIDI IN jack), they also
    automatically generate MIDI messages while the musician plays the
    instrument (and send those messages out their MIDI OUT jacks).

    <b>Features</b>




    Sequencers - which arrange MIDI data - can be dedicated hardware units or
    computer software.

    Allows flexibility and control when arranging compositions.

    Most generic MIDI hardware and software will allow functionality like:
    Change tempo, Transpose a key, Isolate parts, Change feel and swing,
    Accent, Alternate lines, Orchestrate, record and playback MIDI data and
    utilise functions like: Perform & Record ensembles, duets, trios,
    concertos, songs (with Lyrics).

    Cost - cheaper and easier than buying a bunch of recordings or hiring others

    Easy to Use - compact, quicker than tapes. It takes only a second to
    start a file, cue to a section, etc.

    Allows a computer OR a dedicated sequencer/synthesizer connected to a
    sound module/keyboard can enable MIDI Interfacing

    Compact - Hours of music can fit on a single 3 1/2" floppy disk

    Efficient - Just about any computer can handle it

    Powerful - A whole orchestra is at your command

    Versatile - A click of a button is all it takes to change key, tempo,
    instrument, etc.

    Intuitive - a MIDI file is just an electronic version of a player piano
    roll for many instruments

    An Industry Standard - Any MIDI instrument can talk to any other

    <b>Strengths</b>





    There are two main advantages of MIDI:
    - It's an easily edited/manipulated form of data
    - and it is a compact form of data and produces small data files.

    Because MIDI is a digital signal, it's very easy to interface and
    manipulate any MIDI data with any MIDI compatible hardware or software.
    All MIDI files can be played with the same rhythms as used when
    originally recorded, so a musician can digitally record a musical
    performance and store it safe in the knowledge it has faithfully
    maintained exactly what they recorded.  Sequencers can be dedicated
    hardware units or computer software.

    The great advantage of MIDI is that the "notes" and other musical
    actions, such as moving the pitch wheel, pressing the sustain pedal, etc,
    are all still separated by messages on different channels.  In other
    words, when using MIDI, a musician never loses control over every single
    individual action that is made upon each instrument, from playing a
    particular note at a particular point, to pushing the sustain pedal at a
    certain time, etc. The data is all there, but it's put together in such a
    way that every single musical action can be easily examined and edited.

    <b>Weaknesses</b>

    MIDI is a low speed serial interface which creates a problem when
    transferring large amounts of digital data and there can be some
    interpretation issues when using different MIDI devices not used to
    create the original data.

    <b>Why use it?</b>

    It is an international standard which is not constrained by cross
    platform issues and is supports by all major sequencers, keyboards and
    MIDI hardware.  It is light on system resources and does not require a
    lot of technical knowledge or expensive hardware to operate.  Finally it
    has a huge support network base who have all been touched by the power
    MIDI gives!

*/

/**
  @defgroup music Computer Music
  @ingroup intro
  @brief A brief introduction to Computer Music

  This is not an introduction to Computer Music, that would take an entire
  book. Instead, it introduces the music <em>model</em> used by VMM-R to
  organize and digitize music.

  As discussed in <strong>About MIDI</strong>, individual notes and performance
  controllers can be digitised as MIDI data. This captures all the tiny details
  of a performance, but it doesn't suggest how to manage or store music,
  only a stream of data.

  Most modern music is rather repetitive, and this makes it easy to imagine
  a music model where a song is simply a collection of musical passages.

  These passages are parts of the song that happen in a sequence.

  A typical pop song might have an introduction, two verses, and infinite choruses.

  This might suggest three different parts:

  - intro part 1
  - verse part 2
  - chorus part 3

  A song could be assembled by <em>stringing</em> these three parts together
  in the order 1,2,3,2,3,2,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3.

*/

/**
  @defgroup start Quick Start Guide
  @ingroup toc
  @brief Quick start guide for the brave

Get the software
You can obtain a copy of the software by following the instructions on
the SourceForge download page (https://sourceforge.net/projects/vimmer).
It is recommended that new users start with the latest release.

Setup to Rock
Pick a directory for VMMR to live under and because VMMR doesn't require
any unpacking or installation, simply copy the stand alone.EXE to your
chosen directory.

Read the Warning signs
As VMMR is an open source project the only COPYRIGHT or LICENSING issues
are those placed upon the origins of the emulated hardware device and
associated documentation. VMMR is a community project and the original
design team request that VMMR only be used for non-profit, non-commercial
projects and that the program not be abused for financial or political
gain but instead suggest you "cook the joint!" with unacceptable over
use.  Please read more from this documentation for detailed information.

Run and Boogie
You are now ready to run VMMR.  Simply go to the directory where VMMR.EXE
is stored and, check this, DOUBLE CLICK!  If you are using external
peripheral hardware (e.g. MIDI Keyboard) make sure all connections are
secure and powered.  The VMMR GUI has "IN" and "OUT" buttons at the top
left and right corners of the screen respectively - click and hold the
left "IN" option and select (MIDI YOKE NT for instance, there are many so
check your hardware User Guide for best results) your MIDI device by
pressing "+/-" keys.  Now click the right "OUT" button and follow the
same procedure.

If you play your MIDI hardware device you should be hearing sound?  You
are now just 2 steps from recording!  "F12" key arm's the first empty
track of the active part of your very first song.  Now hit the "Enter"
key and you�re away.  Hit "Play" to stop recording and follow the same
procedure to arm and record on the next track.  This is the end of the
Quick Start tutorial.  Good luck and Rock and Roll Baby!!!

*/

/**
  @defgroup install Installing VMM-R
  @ingroup toc
  @brief Instructions on how to install VMM-R on your computer

  So you want to be a one-man band in a box?  VMMR is an excellent choice
however, you will need to follow these specific steps to successfully
download, run, compile and install a functioning VMMR on your Windows system.

Get the software
You can obtain a pre-compiled copy of the VMMR.EXE software which has no
dependant libraries and is a stand alone executable by following the
instructions on the SourceForge download page
(https://sourceforge.net/projects/vimmer).

It is recommended that new users start with the latest release. As VMMR
is an open-source project, you may choose to download the source code,
add your own customisation (cross platform functionality for instance)
and compile a personalised VMMR.

Run & Compile
To create a custom VMMR you will need a copy of CodeBlocks (the IDE used
in the design of VMMR - www.codeblocks.org) or and IDE similar. All
related packages and classes containing VMMR code downloaded from the
SourcForge repository.  Finally your IDE/Compiler MUST be configured to
include specific libraries or VMMR will not compile.

Setup to Rock
Pick a directory for VMMR to live under and because VMMR doesn't require
any unpacking or installation, simply copy the stand alone.EXE to your
chosen directory.  You should now have a standard or customised VMMR
ready to use.

*/

/**
  @defgroup fileinfo Installed files
  @ingroup install

  VMM-R consists of the following files.

    @par VMM-R.EXE
    <b>(The executable file.)</b>

    This is the only file needed to use VMM-R, and can be run from any
    folder. VMM-R doesn't remember which folder it is installed to, so it can
    be moved to any other folder on your computer, or copied from computer to
    computer.

    This file can also run from a read-only medium, such as a CD or floppy disk.

    @par DITO.VMR
    <b>(Part and song data)</b>

    When you close VMM-R, it remembers all of the parts and songs that are
    stored in it. They are stored in this file, which VMM-R creates in the
    same folder. When you run VMM-R, it looks for this file again, and
    reloads the parts and songs from it.

    VMM-R can be run without this file, but all of its parts and songs will
    be empty. (In fact, a convenient way to clear VMM-R is to delete this
    file). This file can also be copied to different computers, as a
    convenient way of distributing parts and songs to other VMM-R users.

    @par SAVETMP.XML
    <b>(Temporary file)</b>

    This file is created when VMM-R exits. VMM-R creates this file when it
    saves its parts and songs, and then compresses it to create "DITO.VMR" .
    This file can then be deleted if desired.

    @par LOADTMP.XML
    <b>(Temporary file)</b>

    This file is created when VMM-R runs. VMM-R creates this file when it
    decompresses "DITO.VMR", and loads its parts and songs from this file.
    This file can then be deleted if desired.

    @par LOG.TXT
    <b>(Temporary file)</b>

    This file is used to record errors and other events that have occured
    while running VMM-R. If it file doesn't exist, VMM-R will try to create
    it. If it does exist, and information already in this file is not used,
    and is written over. This file can be deleted at any time.

    VMM-R is still a work in progress, and this file is used by the
    developers to fix problems with the program. If you report a problem with
    VMM-R to the developers, please include a copy of this file.
*/

/**
  @defgroup gui Interacting with VMM-R
  @ingroup toc
  @brief Understanding how to use the interface

  <img src="um_vmmr.png">

*/

/**
  @defgroup buttons Buttons
  @ingroup gui
  @brief descriptions of the various Buttons on the interface

  <img src="um_buttons.png">

*/

/**
  @defgroup Led Leds
  @ingroup gui
  @brief descriptions of the LED lights on the interface

  <img src="um_leds.png">
*/

/**
  @defgroup setup Setting up MIDI
  @ingroup toc
  @brief How to set up a suitable MIDI environment for VMM-R.

    VMM-R allows configuration of a few MIDI-related aspects. These are
    summarized below, and see the relevant page for more details on that section.

    @par INPUT
    VMM-R can receive (record) MIDI data from a number of different devices.
    To receive data, the user must select which device to use.

    @par OUTPUT
    VMM-R can send (play) MIDI data to a number of different devices. The
    user must select which device to send data to.

    @par ECHO
    If this option is set, VMM-R will receive data from its input device, and
    send it straight to its output. This allows the user to hear the notes as
    they play them on the keyboard.

    @par FILTER
    VMM-R can be configured to only record certain types of messages, (such
    as Note messages for example), and ignore unwanted messages. This is
    controlled by its filter. The default is to record everything.

    @par CLOCK
    VMM-R only uses its own internal clock to keep time. Future versions may
    allow VMM-R to synchronize to an external device, and this will be
    controlled by the "clock" settings.

*/



/**
  @defgroup mm Windows MIDI devices
  @ingroup setup
  @brief Ensuring your computer has atleast one MIDI input and output

  VMM-R is a Windows application, and takes advantage of existing MIDI
  devices provided by Windows.  Most Windows PCs come with atleast one
  MIDI output device: Microsoft GM Synth. This MIDI device is a GM Synth
  used to render MIDI files for playback in Windows Media Player.

  Some computers also have another output device provided by their soundcard
  manufacturer, which will often be superior in sound quality to the GM Synth.

  Before you can record some music with MIDI, you will need a MIDI input device,
  such as a USB MIDI keyboard or software virtual keyboard.

  Like all Windows MIDI software, VMM-R can only work with the system provided
  devices, and expects this matter to be resolved before using the sequencer.
*/

/**
  @defgroup late Latency problems
  @ingroup mm
  @brief Why is the sound taking so long to happen?

  There is a long standing issue with MIDI and realtime software in general, where
  performance seems to drag, and there is a noticable delay between playing a note, and
  the note sounding.

  A single MIDI note is ...

  - converted to a digital (MIDI) signal.
  - transmitted via MIDI output down the MIDI cable
  - converted to a USB signal by MIDI interface
  - transmitted via USB cable to computer
  - converted back into a MIDI signal by MIDI interface driver
  - passed to Windows Multimedia System
  - passed to VMM-R
  - recorded into VM-R store (assuming you are recording)
  - sent to MIDI output device by VMM-R (assuming you have ECHO on)
  - received by Windows Multimedia System
  - passed on to desired MIDI output device
  - converted to audio signal by synthesizer hardware or software
  - sent as an audio stream to soundcard
  - sent as an analog signal down speaker cables
  - sound is output via speakers
  - audio moves (relatively) slowly to your ears.

  The amount of delay between the first and last steps is often called
  <em>latency</em> and will be more noticable on older computer systems.
*/

/**
  @defgroup input IN - Selecting a MIDI input device
  @ingroup setup
  @brief

  <img src="um_in2.png">

  The input device is the device that VMM-R records MIDI data from.
  Before you can record any music, you will need to tell VMM-R which
  INPUT DEVICE to record from. No device is selected by default.

  <img src="um_in0.png">

  <b>SELECTING AN INPUT DEVICE</b>

    - Hold down the IN button (keyboard hotkey 'I').
    - Press the + or - buttons to cycle through the list of available devices,
      until the device you wish to use appears.
    - Release the IN button.

    <img src="um_in1.png">

    <b>EXAMPLE INPUT DEVICES</b>

    If you have a musical keyboard connected into your computer, the input
    device name might look like "Soundcard XYZ MIDI IN".

    You can also connect other programs to VMM-R through MIDI Yoke, such as
    Virtual MIDI Keyboard. You should then use "MIDI Yoke NT: #".

*/

/**
  @defgroup output OUT - Selecting a MIDI output device
  @ingroup setup
  @brief Getting MIDI information out of VMM-R

    <img src="um_out2.png">

    The output device is the device that VMM-R plays MIDI data to.
    Before you can play any music, you will need to tell VMM-R which OUTPUT
    DEVICE to play to. No device is selected by default.

    <img src="um_out0.png">

    <b>SELECTING AN OUTPUT DEVICE</b>

    - Hold down the OUT button (keyboard hotkey 'O').
    - Press the + or - buttons to cycle through the list of available devices,
      until the device you wish to use appears.
    - Release the OUT button.

    <img src="um_out1.png">

    <b>EXAMPLE OUTPUT DEVICES</b>

    If you have a (hardware) synthesizer connected to your computer, the
    output device name might look like "Soundcard XYZ MIDI OUT".

    If you want to hear the sound through your computer speakers, look for
    something like "Microsoft GS Wave Synth". This is a software synthesizer
    built into Microsoft Windows.

    You can also connect other programs to VMM-R through MIDI Yoke, such as
    synthesizing software. You should set VMM-R to play to any "MIDI Yoke NT:
    #" (that isn't already used for input).


*/

/**
  @defgroup echo ECHO - listening to MIDI input
  @ingroup setup
  @brief Passing MIDI information from input to output devices

    When ECHO is enabled, VMM-R sends to its output device any data it
    receives on its input device.

    VMM-R will accept MIDI data from its selected input device, but doesn't
    automatically forward it to its output port. This generally means that
    you won't hear any music as you record it, but only when you play it.

    <b>If ECHO is disabled:</b>

    VMM-R will receive MIDI data from its input device, but won't forward it
    to its output port. You won't hear notes as you play them on the keyboard.

    <b>If ECHO is enabled:</b>

    VMM-R will receive MIDI data from its input device, and will forward it
    to its output port. You should hear the notes as you play them.

    <b>CHANGING ECHO</b>

    - Press the ECHO button. The LED will change.
    - If it is lit, ECHO is now enabled.
    - If it is unlit, ECHO is now disabled.

      <img src="um_echo0.png">
      <img src="um_echo1.png">

*/

/**
  @defgroup filter FILTER - Filtering MIDI data
  @ingroup setup
  @brief Setting up the inbuilt MIDI filter in VMM-R

    Filter allows the user to prevent unwanted MIDI messages from being recorded.
    Most filtering is based on the type of message. Filter also controls
    whether recording is from a particular channel only, or from all channels.

    <b>How To Filter Messages</b>

    <img src="um_filter0.png">

    - Hold down the FILTER button.
    - Use PGUP or PGDN buttons to select the message type you wish to filter.
    - Use + or - buttons to switch between ON and OFF.
    (Note: ON allows messages to be recorded, while OFF blocks them out.)
    - Release the FILTER BUTTON.

    <b>Types Of Messages</b>

    VMM-R filters the following types of messages:
    - Notes          <img src="um_filter1.png">
    - Pitchbend      <img src="um_filter2.png">
    - Aftertouch     <img src="um_filter3.png">
    - Controllers    <img src="um_filter4.png">
    - Program Change <img src="um_filter7.png">
    - System Exclusive <img src="um_filter8.png">

    <b>How To Filter Channels</b>

    - Hold down the FILTER button.
    - Use PGUP or PGDN buttons until you reach "RECORD ON MIDI CHANNEL".
      <img src="um_filter9.png">
    - Use + or - buttons to change the channel.
      MIDI data on this channel will be allowed, and all other channels will be
      blocked. If channel is set to "ANY", all channels will be allowed.
    - Release the FILTER BUTTON.

*/

/**
  @defgroup clock CLOCK - Synchronizing VMM-R via MIDI Clock
  @ingroup setup
  @brief Don't get too excited ... this feature is missing.

  <img src="um_clock0.png">

  CLOCK functionality is not yet implemented.
  VMM-R uses its own internal clock to keep time. Future versions may also
  allow VMM-R to synchronize to the clock of an external device.

*/

/**
  @defgroup making Making music
  @ingroup toc
  @brief How to get started making music with VMM-R
*/

/**
  @defgroup transport Playing, stopping, etc
  @ingroup making
  @brief How to play, stop, and cue to desired locations


  The buttons pictured below make up the <em>transport</em> bar.

  <img src="um_transport0.png">

    The buttons shown are referred to here as the transport buttons, as they
    allow the user to move through tracks, parts and songs. The VMM-R
    sequencer operates similarly to most audio devices in this respect.

    The Fast Forward and Rewind buttons allow the user to move through the
    Song by increasing or decreasing the beat number. This is useful for
    moving to specific beat numbers in the part.

    The Play Button starts the Song playing from the beginning. Contrary to
    some audio devices, pressing play after having paused the sequencer will
    cause the part to play from the beginning rather than continuing from the
    position it was paused at. The Stop Button stops the song from playing
    and continues it playing from the same beat number if pressed again.
    The Record Button allows the user to enter record-armed mode. see
    recording a part for more detail.

    The hotkeys for these buttons are as follows;

    - Play          = 'enter'
    - Stop/Continue = 'space'
    - Fast Forward  = ']'
    - Rewind        = '['
    - Record        = F12

*/

/**
  @defgroup tracks Selecting tracks for playback
  @ingroup making
  @brief Choosing which tracks to mute/play

  The <em>track bar</em> contains 8 buttons, one for each Track in the sequencer.
  They are realtime play/mute toggle buttons that allow you to control which tracks
  will play at any time.

  The buttons can be pressed on/off, or the function keys F1 to F8 can be used to
  activate the buttons. Examples of differing track states follow ...


  All tracks are selected ... <img src="um_tracks0.png">

  No tracks are selected ... <img src="um_tracks1.png">

  Some tracks are selected  (1,3,4,6,7) ... <img src="um_tracks2.png">



*/

/**
  @defgroup tempo TEMPO - Picking your speed
  @ingroup making
  @brief Choosing a tempo for the music

  <img src="um_tempo0.png">
  Changing the Tempo in your music will change the numbers of beats per
  minute, making your music play faster or slower.

  Changing the Tempo in your music will change the numbers of beats per minute
  you will hear in your music, making your music play faster or slower.

  Deriving from the Latin word 'tempus' meaning time, the tempo of a song directly
  influences the timing of your music, changing the feel of the piece.
  Minor problems may occur when the tempo is set to 88mph, in the style of
  Back to the Future's De Lorean, the VMM-R sequencer will be cast at the
  mercy of the Lords of Time.
*/

/**
  @defgroup click CLICK - Keeping in time
  @ingroup making
  @brief About the VMM-R inbuilt metronome

  <img src="um_click0.png">

  A metronome is a device used by musicians to assist with tempo and timing. It produces
  a steady 'click' sound at a regular interval and provides an anchor for the timing.
  The speed (tempo) of the metronome is controlled by the tempo of the sequencer, and is
  automatically synchronised to playback.

  The CLICK button allows the user to set the rythmic value of the metronome.
  There are 10 options for the click value;

  <img src="um_click1.png">

  - 1/2, 1/4, 1/6, 1/8, 1/12, 1/16, 1/24, 1/32, 1/48, 1/64,

  These can be cycled through using the +/- buttons or by typing 0-9 on the keyboard.

  By pressing the pageup and pagedown buttons different screens relating to the
  click function can be accessed, such as the Record Click function and the Play
  Click function.

  <img src="um_click2.png">
  The Record Click function determines whether the metronome will
  click while recording. This can be turned on/off by accessing it's screen as mentioned
  above and pressing the +/- buttons. Its default value is on.

  <img src="um_click3.png">
  The Play Click function
  is used to turn on/off the metronome function while in Play Mode. It can be toggled
  using the +/- buttons. Its default value is off.

  <img src="um_click4.png">
  Also from this screen the countdown
  can be set (the number of clicks counted before recording) its default value is 4.

*/

/**
  @defgroup loop LOOP - Repeating the current Part
  @ingroup making
  @brief Looping the current Part

  Looping refers to the ability of the sequencer to loop back to
the start of the currently playing part or song when it reaches the
part or song�s end. To enable or disable looping press the loop
button

  Loop button can also be accessed with the hotkey 'L'.

  Loop is off ... <img src="um_loop0.png">

  Loop is on ... <img src="um_loop1.png">
*/


/**
  @defgroup parts Part mode
  @ingroup toc
  @brief Recording and playing a single Part


  Ensure the Sequencer is in Part Mode. If the LED on the Part mode button
  is lit then you are already in Part Mode, otherwise click on the
  Part Mode button.

*/


/**
  @defgroup partnum Part selection
  @ingroup parts
  @brief Choosing a Part to work on

  <img src="um_part_select.png">

  To select a specific Part, type the number of that Part on the keyboard, or use the +/-
buttons to select it. The name of the Part should be shown on the display, if an empty
Part is selected the display will show 'EMPTY PART'.

Note: That when entering the part number using the keyboard you must enter two digits;
For example to select Part 1 you will need to enter 0 then 1, ie "01".

*/


/**
  @defgroup partname Naming a Part
  @ingroup parts
  @brief Giving the Part a memorable name

  <img src="um_part_name.png">

  To change the length of a part press and hold the Length key (default hotkey 'k') and
the press the "-" or "+" buttons (default hotkeys '-' and '+') or directly type
in the length using the numeric key pad. To finalize the new length
press the record button (default hotkey 'F12') and release all buttons.


*/

/**
  @defgroup partedit Editing a Part
  @ingroup parts
  @brief Altering the information in a Part

  Editing Features

VMM-R allows many operations to be performed on the MIDI data, including the ones listed below.

 - Instrument 	Change the musical instrument the notes sound as.
 - Tempo 	Change the speed at which the music plays.
 - Quantize 	Adjust the timing of a particular note, or fix timing errors in the whole piece.
 - Transpose 	Adjust the pitch ("highness" or "lowness") of a single note, or transpose an entire section to a completely different octave or key.
 - Erase 	Remove one or more notes from a track, without disturbing any others.

*/

/**
  @defgroup partlen Changing the Part length
  @ingroup partedit
  @brief Adjusting the number of beats in a Part

To change the length of a part press and hold the Length key (default hotkey 'k') and
the press the "-" or "+" buttons (default hotkeys '-' and '+') or directly type
in the length using the numeric key pad. To finalize the new length
press the record button (default hotkey 'F12') and release all buttons.

  <img src="um_part_length.png">

Note: When entering the part number using the keypad it must alway be three digits in length
example to change the length to 19 beats enter the number "019".



*/

/**
  @defgroup transpose TRANSPOSE
  @ingroup partedit
  @brief Adjusting the pitch of notes.


Transpose is a high level function that enables the user to alter
the "pitch" of an existing note to be altered by a semi-tone
increment higher or lower than that existing note.

This function works in Part mode only

1. Start up your VMMR.EXE.
2. From the VMMR GUI, click and hold the "Trans" button.
3. All tracks will begin flashing, to select the track you plan to
transpose select the corresponding function key (e.g. TRK 1 = F1).
<img src="TRANS-1.png">
4. You will notice the LCD screen has also changed and now allows
you to choose the increment unit ("+/-" keys) you would like the pitch
to change. <img src="TRANS-2.png">
5. Hit the "F12" key on your keyboard (Record button on the GUI), this will set the selection


*/

/**
  @defgroup quantize QUANTIZE (Fixing timing errors)
  @ingroup partedit

  Quantize allows you to fix timing errors in a recorded piece of music. It adjusts the timing of the notes, and aligns them to a particular interval.
  For example, quantizing by an interval of 1/16 would align all notes to a sixteenth-note. Any timing information quicker than this will be lost.
  Quantize can be applied to a single track, to multiple tracks, or to an entire part. See "How to quantize" below for instructions.

  <b>Quantize intervals</b>

  Notes can be quantized by these intervals:
  1/2, 1/4, 1/6, 1/8, 1/12, 1/16, 1/24, 1/32, 1/48, 1/64

  <b>Quantize types</b>

  The following quantize types (modes) are supported:
      - NOTE START :		Quantize NOTE ON events only .
      - NOTE START & END :	Quantize NOTE ON and NOTE OFF events.
      - NOTE END :		Quantize NOTE OFF events only.
      - KEEP DURATION :		Quantize NOTE ON events, and adjust the
				NOTE OFF event such that the duration of the
				note remains constant.

  <b>Warning</b>

  Quantizing cannot be undone. Use it carefully!

  <b>How to quantize (simple)</b>

      - Select the part you wish to quantize.
      - Press and hold the QUANT button.
        (The track LEDs will now flash repeatedly).
        <img alt="QUANT button" src="QUANT-1.png">
      - Press the track button for each track you wish to quantize.
        To quantize the entire part, press all all track buttons.
        (Quantize will apply to each track with its LED lit).
      - Press + and - to change the quantize interval.
        <img alt="QUANT button" src="QUANT-2.png">
      - Press RECORD button (hotkey: F12).
        (LCD should then display "QUANTIZE COMPLETE.")
      - Release QUANT button.

  <b>How to quantize (advanced)</b>

      - Follow the first three steps as for simple quantize (above).
      - Press + and - to change the quantize interval.
      - Press PGUP of PGDN to highlight the quantize type.
      - Press + and - to change the quantize type.
        <img alt="QUANT button" src="QUANT-3.png">
      - Press RECORD button (hotkey: F12).
        (LCD should then display "QUANTIZE COMPLETE.")
      - Release QUANT button.
*/


/**
  @defgroup songs Song mode
  @ingroup toc
  @brief Assembling a single Song

  <img src="song_mode_SS1.png">

To enter Song Mode, click on the Song Mode button highlighted in the
picture above. The mode you are currently in is indicated by the lit LED
next to either the Part Mode or Song Mode button.


Song Mode is a 'step above' Part Mode. where Part Mode deals with editing
and playing tracks, Song Mode allows the user to edit and play Parts.

In Part Mode, when the end of the playing part is reached, the sequencer
will either replay the same part again (if loop is on) or it will stop.
In Song Mode however, the user can select which part will play next along
with other 'part-editing' features.

*/


/**
  @defgroup songnum Song selection
  @ingroup songs
  @brief Choosing a Song to work on

To select an open song, first make sure you are in Song Mode then press
the +/- buttons either on the screen or on the keyboard until the
required song's name appears in the display. Note that unnamed songs will
appear as "Song 0" to "Song 99".
*/

/**
  @defgroup songname Naming a Song
  @ingroup songs
  @brief Giving the Song a memorable name

  Songs can be given a name by first entering Song Mode by pressing the
Song Mode button, and then clicking on the Name button.

<img src="song_mode_SS2.png">

A box like the one shown above will appear in which you can type the name
you want to give the Song. The song will be renamed once the OK button is
clicked.

The song name can also be changed from the Song Editor.
*/

/**
  @defgroup songedit Song Editor
  @ingroup songs
  @brief Altering the information in a Song


The Song Editor is used to edit songs in VMM-R. There are six main editing functions that are available to
make editing a song easier. These are Renaming a Song, Song Length, Adding a Song Step, Removing
as Song Step, Removing all Song Steps and Reorganising Song Steps.

*/

/**
  @defgroup songname2 Renaming the Song
  @ingroup songedit

Renaming the current song is as easy as changing the text in the Song Name text field and pressing Enter.
*/

/**
  @defgroup songlen Song Length
  @ingroup songedit

The Song Length field displays the current song's length in beats this value is non-editable.
*/

/**
  @defgroup songins Adding a Song Step
  @ingroup songedit

To add a new Song Step to the current song press "Add" and in the "Add Part" dialog choose the part you want
to add to the song. This part will now be appended to the end of the current song as a new song step.
*/

/**
  @defgroup songdel Removing a Song Step
  @ingroup songedit

To remove a song step from the current song first select the song step you want to remove from the Parts list
and then press "Remove", the currently selected song step will now be removed from the song. For example
selecting "Part 2" and pressing "Remove" will result in the step containing "Part 0, Part 1, Part 1".

*/

/**
  @defgroup songdelall Removing all Song Steps
  @ingroup songedit

To remove all song steps from the current songs press "Clear".
*/

/**
  @defgroup songgorg Reorganising Song Steps
  @ingroup songedit

To rearrange the current song's steps order use the "Up" and "Down" buttons, these will move the currently
selected song step up or down the list of steps in the song. For example if "Part 2" is selected in Song Editor
pressing "Up" would result in the song containing "Part 0, Part 2, Part 1, Part 1". While pressing "Down" will
result in the song containing the steps "Part 0, Part 1, Part 1, Part 2".

*/

/**
  @defgroup tape Managing your music
  @ingroup toc
  @brief How to import and export music files

  VMMR supports 3 specific file types: MIDI - which is a popular and well
supported music Industry standard, XML - Easy to manipulate, very
versatile format used more by the programming community and System
Exclusive (SysEX) - An Industry format used in the early years of
sequencer hardware module production and specific ONLY to those modules
(Native to the VMMR's predecessor the MMT-8).

These formats are supported by VMMR because of their compatibility and
wide user and support base which offers VMMR users more flexibility with
file production and communication.  There are no plans to extend the file
format support base.

It is important for users to understand �Loading� and �Saving� of files
for their own enjoyment and to understand the full power of VMMR's
functionality.
*/


/**
  @defgroup xml XML file format
  @ingroup tape
  @brief The native file format of VMM-R

    <b>Brief History</b>

    XML (Extensible Markup Language) is derived from SGML (ISO 8879) and was
    created as a potential solution to problem of compatibility with the
    World Wide Web that were arising within the printing industry during the
    1980's and 1990's.Consortium (W3C) initiative that allows information and
    services to be encoded with meaningful structure and semantics that
    computers and humans can more easily understand. XML is great for
    information exchange, and can easily be extended to include
    user-specified and industry-specified "tags" which allow greater
    flexibility when creating common information formats and sharing both the
    format and the data on the World Wide Web, intranets, and elsewhere.


    <b>Features</b>

    XML is designed using a tree based hierarchical structure which can be
    built using simple text "tags" which indicate specific parts of a
    container e.g. branches of a tree.  As the fundamental syntactic unit of
    XML is characters the data can be saved as a simple text file which
    facilitates fast XML document authoring and maintenance, greater
    portability and cross platform flexibility.

    XML is a true general purpose language which is fully customisable, easy
    to learn and Internet protocol-friendly.  Because it is a standard all
    XML-aware software can at least read (parse) and understand the general
    arrangement of information within them although XML is not particular
    concerned about how it is used.


    <b>Strengths</b>

    Its simultaneously human-and machine-readable format (it allows almost
    any information in any written human language to be communicated).
    The ability to represent most data structures (records, lists and trees).
    The self-documenting format that describes structure and field names as
    well as specific values.
    Its format is based on international standards.
    The hierarchical structure is suitable for most (but not all) types of
    documents.
    Because it's a plain text file, it is not encumbered by licenses or
    restrictions.
    It is platform-independent.


    <b>Weaknesses</b>

    Its syntax is verbose and redundant which yields higher storage costs.
    This makes XML difficult to apply in cases where bandwidth is limited.
    Reading the data uses a recursion which is slow which causes a
    significant overhead for most basic uses of XML, particularly where
    resources may be scarce. Furthermore.
    Security considerations arise due to possible stack overflow problems.
    Contains a number of obscure, unnecessary features born of its legacy of
    SGML compatibility.
    Uses the hierarchical model compared to the relational model since it
    only gives a fixed view of the actual information. (Either actors under
    movies, for example, or movies under actors).
    Mapping XML to the relational or object oriented paradigms is often
    clumsy and slow.
    XML keystrokes on a standard PC keyboard are particularly awkward.


    <b>Why use it?</b>

    XML is a standard file type which can be easily read and edited from a
    text editor.  VMMR data saved to this format are able to be edited in a
    fundamental fashion and create small file sizes. Apart from the positive
    aspects to this format and the fact it is a standard it is NOT the music
    industry standard like that of the MIDI format, so in terms of user file
    exchange or hardware device interchange, XML may still require some promotion.


*/

/**
  @defgroup xml_load Loading an XML file
  @ingroup xml
  @brief Loading a different set of Parts/Songs

This function works in both Part and Song modes.

1. Start up your VMMR.EXE.

2. From the VMMR GUI, click and hold the "Tape" button. <img src="XML-1.png">

3. You will notice the LCD screen has changed and now allows you to
choose the file format you would like to load, in this case XML. You can
change the format by using "+/-" keys until you find the required file type.

4. While remaining to click and hold the "Tape" button, press the "UP"
or"DOWN" keys on your keyboard ( PG UP / PG DOWN buttons on VMMR) until
the LCD screen displays "LOAD ALL PARTS & SONGS FROM XML" <img src="XML-2.png">

5. Hit the "F12" key on your keyboard (Record button on the GUI), this
will open a "Load XML from ..." window.  From this window, select an
exisitng file to load then click "OK". <img src="XML-3.png">

6. You are now able to manipulate existing XML files.


*/

/**
  @defgroup xml_save Saving to a datafile
  @ingroup xml
  @brief Saving your Parts/Songs to a XML

    This function works in both Part and Song modes.

    1. Start up your VMMR.EXE.

    2. From the VMMR GUI, click and hold the "Tape" button. <img src="XML-1.png">

    3. You will notice the LCD screen has changed and now allows you to
    choose the file format you would like to save, in this case XML. You can
    change the format by using "+/-" keys until you find the required file type.

    4. While remaining to click and hold the "Tape" button, press the "UP"
    or"DOWN" keys on your keyboard ( PG UP / PG DOWN buttons on VMMR) until
    the LCD screen displays "SAVE ALL PARTS & SONGS FROM XML" <img src="XML-4.png">

    5. Hit the "F12" key on your keyboard (Record button on the GUI), this
    will open a "Save XML from ..." window.  From this window, select the
    folder you would like to save the file to then click "OK". <img src="XML-5.png">

    6. You are now able to save current Part/Song data to XML files.

*/

/**
  @defgroup mid MIDI file format
  @ingroup tape
  @brief Importing and exporting MIDI files with VMM-R

    <b>Brief History</b>

    To gain appreciation of the full complexity and functionality of MIDI, it
    is suggested any new user should attempt to understand some basic
    principles about musical instruments. MIDI (Musical Instrument Digital
    Interface) is a music industry standard communications protocol that lets
    MIDI instruments and hardware sequencers (or computers running sequencer
    software) talk to each other to play and record music.

    All musical instruments make a sound under a musicians control, for
    example, a musician can push down a key on a piano, begin dragging a bow
    across a violin string or pick a guitar string to start a sound- let's
    refer to this action as a "Note On".  A musician pushes down (HOLDS) a
    key on a keyboard.  Most instruments also allow the musician to stop the
    sound at any given time - let's refer to the action as a "Note Off".

    Instruments can play distinct pitches (ie, a musical scale). For example,
    an acoustic piano has 88 keys, or 88 distinct pitches/notes. There are
    other things that many musical instruments may have in common, for
    example, most instruments can make sounds at various volumes or if the
    pianist pushes down a key with great force, the resulting note will be
    louder than if they were to gently press down the key.

    Suffice it to say that MIDI can do everything musical to an electronic
    instrument that a human being can physically do, and a few things that
    humans can't do and will almost always require the use of a "sequencer"
    or sequencing unit of some kind which does exactly what it says -
    sequences all MIDI data into legible arrangements.

    Files created using MIDI are simply a series of these �Note on� - �Note
    Off� digital signals which emulate the creators arrangement (sequence)
    which can then be saved and stored enabling simple transportation (as
    most MIDI files are relatively small in size) and duplication (make as
    many copies as required and manipulate each using other sequencing
    equipment ).

    In a nutshell, that's what MIDI is -- a set of commands that electronic
    devices digitally pass between their MIDI jacks to tell each other what
    to do (ie, what actions to perform).

    Bring your sheet music to life! Hear the music collecting dust on your
    shelf. If you can hear it, you can play it! See it play! Print out lead
    sheets.

    <b>Features</b>

    Sequencers - which arrange MIDI data - can be dedicated hardware units or
    computer software.

    Allows flexibility and control when arranging compositions.

    Most generic MIDI hardware and software will allow functionality like:
    Change tempo, Transpose a key, Isolate parts, Change feel and swing,
    Accent, Alternate lines, Orchestrate, record and playback MIDI data and
    utilise functions like: Perform & Record ensembles, duets, trios,
    concertos, songs (with Lyrics).

    Cost - cheaper and easier than buying a bunch of recordings or hiring others

    Easy to Use - compact, quicker than tapes. It takes only a second to
    start a file, cue to a section, etc.

    Allows a computer OR a dedicated sequencer/synthesizer connected to a
    sound module/keyboard can enable MIDI Interfacing

    Compact - Hours of music can fit on a single 3 1/2" floppy disk

    Efficient - Just about any computer can handle it

    Powerful - A whole orchestra is at your command

    Versatile - A click of a button is all it takes to change key, tempo,
    instrument, etc.

    Intuitive - a MIDI file is just an electronic version of a player piano
    roll for many instruments

    An Industry Standard - Any MIDI instrument can talk to any other

    <b>Strengths</b>

    There are two main advantages of MIDI:
    - It's an easily edited/manipulated form of data
    - and it is a compact form of data and produces small data files.

    Because MIDI is a digital signal, it's very easy to interface and
    manipulate any MIDI data with any MIDI compatible hardware or software.
    All MIDI files can be played with the same rhythms as used when
    originally recorded, so a musician can digitally record a musical
    performance and store it safe in the knowledge it has faithfully
    maintained exactly what they recorded.  Sequencers can be dedicated
    hardware units or computer software.

    The great advantage of MIDI is that the "notes" and other musical
    actions, such as moving the pitch wheel, pressing the sustain pedal, etc,
    are all still separated by messages on different channels.  In other
    words, when using MIDI, a musician never loses control over every single
    individual action that is made upon each instrument, from playing a
    particular note at a particular point, to pushing the sustain pedal at a
    certain time, etc. The data is all there, but it's put together in such a
    way that every single musical action can be easily examined and edited.

    <b>Weaknesses</b>

    MIDI is a low speed serial interface which creates a problem when
    transferring large amounts of digital data and there can be some
    interpretation issues when using different MIDI devices not used to
    create the original data.

    <b>Why use it?</b>

    It is an international standard which is not constrained by cross
    platform issues and is supports by all major sequencers, keyboards and
    MIDI hardware.  It is light on system resources and does not require a
    lot of technical knowledge or expensive hardware to operate.  Finally it
    has a huge support network base who have all been touched by the power
    MIDI gives!
*/

/**
  @defgroup mid_load Loading a MIDI file
  @ingroup mid
  @brief Loading a different set of Parts/Songs from a MIDI file

  This function works in both Part and Song modes.

    1. Start up your VMMR.EXE.

    2. From the VMMR GUI, click and hold the "Tape" button. <img src="MID-1.png">

    3. You will notice the LCD screen has changed and now allows you to
    choose the file format you would like to load, in this case MID. You can
    change the format by using "+/-" keys until you find the required file type.

    4. While remaining to click and hold the "Tape" button, press the "UP" or
    "DOWN" keys on your keyboard (PG UP / PG DOWN buttons on VMMR) until the
    LCD screen displays "LOAD ALL PARTS & SONGS FROM MID" <img src="MID-2.png">

    5. Hit the "F12" key on your keyboard (Record button on the GUI), this
    will open a "Load MID from ..." window.  From this window, select an
    existing file to load then click "OK". <img src="MID-3.png">

    6. You are now able to manipulate existing MID files.
*/

/**
  @defgroup mid_save Saving to a MIDI file
  @ingroup mid
  @brief Saving your Parts/Songs to a MIDI file

    This function works in both Part and Song modes.

    1. Start up your VMMR.EXE.

    2. From the VMMR GUI, click and hold the "Tape" button. <img src="MID-1.png">

    3. You will notice the LCD screen has changed and now allows you to
    choose the file format you would like to save, in this case MID. You can
    change the format by using "+/-" keys until you find the required file type.

    4. While remaining to click and hold the "Tape" button, press the "UP" or
    "DOWN" keys on your keyboard (PG UP / PG DOWN buttons on VMMR) until the
    LCD screen displays "SAVE ALL PARTS & SONGS FROM MID" <img src="MID-4.png">

    5. Hit the "F12" key on your keyboard (Record button on the GUI), this
    will open a "Save MID from ..." window.  From this window, select the
    folder you would like to save the file to then click "OK". <img src="MID-5.png">

    6. You are now able to save current Part/Song data to MID files.

*/

/**
  @defgroup syx System Exclusive file format
  @ingroup tape
  @brief Importing and exporting SysEx files with VMM-R

    <b>Brief History</b>

    Digital Instrument manufacturers wanted their MIDI devices to do
    something special that no other MIDI device can do. Rather than clutter
    the MIDI standard with thousands of messages that are exclusive to a
    single device, the MIDI standard defined a message type called System
    Exclusive.

    The System Exclusive Message (SysEx) was created to assist with the
    internal parameters setup of MIDI machines as MIDI does not always
    include hardware specific parameters as part of its data.  A SysEx
    message contains 3 parts - a standard beginning - this includes the
    manufacturer�s factory number.  Then, whatever manufacturer the user is
    using and the thirdly is a standard ending.

    SysEx is able to store its native files on hardware units and all SysEx
    data is sent out as one block of system exclusive data, with the length
    being determined by the amount of memory being used. All these parameters
    are indicated in the machines documentation. It is in fact the machine
    language.

    To use any SysEx (or for that matter MIDI of any type) first you need a
    Midi Interface. If a user is just interested in loading new sounds via
    SysEx, then a simple interface with one or two inputs/outputs will do.
    Once you get the midi interface and have everything connected you use
    your computer to perform what is called a �System Exclusive� or SYSEX
    Dump. You can load the sounds through the �Midi Port� on your hardware.
    You can also store all your sounds for all your MIDI instruments on your
    hard drive.


    <b>Features</b>

    In order to optimise the data transfer, 8 MIDI bytes are used to transmit
    each block of 7 MMT-8 data bytes. If the 7 data bytes are looked at as
    one 56-bit word, the format for transmission is eight 7-bit words,
    beginning with the most significant bit of the first byte.


    <b>Strengths</b>

    Solves the problem of using "Plug in" hardware storage like PCM cards
    which have a limited battery life most of which are hard to find and expensive


    <b>Weaknesses</b>

    Outdated format which is hard to work with.
    Requires specific hardware for specific SysEx data.
    Has a compression format that is not widely supported.


    <b>Why use it?</b>

    This format will only ever be used with relic hardware devices which
    require the existing SysEx data to be updated to a newer, more widely
    supported MIDI format.

*/

/**
  @defgroup syx_load Importing data from SysEx
  @ingroup syx
  @brief Loading a System Exclusive data dump from a .syx file

    This function works in both Part and Song modes.

    1. Start up your VMMR.EXE.

    2. From the VMMR GUI, click and hold the "Tape" button. <img src="SYX-1.png">

    3. You will notice the LCD screen has changed and now allows you to
    choose the file format you would like to load, in this case SYX. You can
    change the format by using "+/-" keys until you find the required file type.

    4. While remaining to click and hold the "Tape" button, press the "UP" or
    "DOWN" keys on your keyboard (PG UP / PG DOWN buttons on VMMR) until the
    LCD screen displays "LOAD ALL PARTS & SONGS FROM MID" <img src="SYX-2.png">

    5. Hit the "F12" key on your keyboard (Record button on the GUI), this
    will open a "Load MID from ..." window.  From this window, select an
    existing file to load then click "OK". <img src="SYX-3.png">

    6. You are now able to manipulate existing SYX files.

*/

/**
  @defgroup syx_save Saving to a SysEx file
  @ingroup syx
  @brief Saving System Exclusive data dump to a .syx file

    This function works in both Part and Song modes.

    1. Start up your VMMR.EXE.

    2. From the VMMR GUI, click and hold the "Tape" button. <img src="SYX-1.png">

    3. You will notice the LCD screen has changed and now allows you to
    choose the file format you would like to save, in this case SYX. You can
    change the format by using "+/-" keys until you find the required file type.

    4. While remaining to click and hold the "Tape" button, press the "UP" or
    "DOWN" keys on your keyboard (PG UP / PG DOWN buttons on VMMR) until the
    LCD screen displays "SAVE ALL PARTS & SONGS FROM MID" <img src="SYX-4.png">

    5. Hit the "F12" key on your keyboard (Record button on the GUI), this
    will open a "Save MID from ..." window.  From this window, select the
    folder you would like to save the file to then click "OK". <img src="SYX-5.png">

    6. You are now able to save current Part/Song data to SYX files.
*/




/**
  @defgroup trouble Trouble shooting
  @ingroup toc
  @brief Some help with common VMM-R related problems


  <b>Q.</b>  VMM-R won't receive or record any MIDI data.
    The input activity LED (top-left) corner blinks.

  - <b>A1.</b> Make sure the filter is not blocking the MIDI data.
    - Press FILTER.
    - Press PGDN for each message type, check it is set to "ON".
    - Set "RECORD ON MIDI CHANNEL" to "ANY".


  <b>Q.</b>  VMM-R won't receive or record any MIDI data.
    The input activity LED (top-left) corner does NOT blink.

  - <b>A1.</b> Make sure the correct input device is selected.
    (Hotkey 'I').

  - <b>A2.</b> If the input device is correct, there might be a problem with the device itself.
    Make sure all MIDI devices (real or virtual) are broadcasting properly, on the right channel. Make sure all cables are correctly inserted.


  <b>Q.</b>  VMM-R won't play any MIDI data.
    The output activity LED (top-right) corner blinks.

  - <b>A1.</b> Make sure the correct output device is selected.
    (Hotkey 'I').

  - <b>A2.</b> If the output device is correct, check that the tracks are not
channelizing to an unexpected channel.

  - <b>A3.</b> There might be a problem with the device itself.
    Make sure all MIDI devices (real or virtual) are receiving properly,
on the right channel. Make sure all cables are correctly inserted.



  <b>Q.</b>  VMM-R won't play any MIDI data.
    The output activity LED (top-right) corner does NOT blink.

  - <b>A1.</b> If you are playing notes to the input (eg. from a keyboard), and
expecting to hear them through VMM-R output: first check the input
activity LED (top-left). Then check that ECHO is enabled.

  - <b>A2.</b> If you are playing a part or song, make sure you have the correct
Part or Song selected, and that it contains data.

  - <b>A3.</b> Make sure all required tracks are not muted.
    (Make sure the track LEDs are lit).



*/
